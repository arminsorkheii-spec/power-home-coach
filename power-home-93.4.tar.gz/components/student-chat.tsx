"use client";
import {useAutoRefresh} from "@/hooks/use-auto-refresh";
import {notifyDataUpdated} from "@/lib/auto-refresh";
import {MessageReceipt,useMessageReadReceipts} from "@/components/message-receipt";
import {useStudentWorkspace} from "@/components/student-dashboard-shell";
import { useCallback, useEffect, useState } from "react";
import { LoaderCircle, MessageCircle, RefreshCw, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { GlassSectionIcon } from "@/components/glass-section-icon";
type Message={id:string;sender_role:"coach"|"student";body:string;created_at:string;read_at?:string|null};
export function StudentChat(){
  const workspace=useStudentWorkspace(),active=!workspace||workspace.selection.module==='chat';
  const[messages,setMessages]=useState<Message[]>([]),[body,setBody]=useState(""),[busy,setBusy]=useState(false),[error,setError]=useState("");
  const markRead=useCallback((ids:string[],at:string)=>setMessages(current=>current.map(m=>ids.includes(m.id)?{...m,read_at:at}:m)),[]);
  useMessageReadReceipts(messages,'student',undefined,active,markRead);
  const load=useCallback(async()=>{if(!active||document.visibilityState==='hidden')return;try{const r=await fetch("/api/messages?read=0",{cache:"no-store",signal:AbortSignal.timeout(15000),headers:{"x-portal-role":"student"}});const data=await r.json() as {messages?:Message[];error?:string};if(!r.ok)throw new Error(data.error??"دریافت پیام‌ها انجام نشد.");setMessages(data.messages??[]);setError("");}catch(e){setError(e instanceof Error?e.message:"دریافت پیام‌ها انجام نشد.");}},[active]);
  useAutoRefresh(load,{intervalMs:10000,enabled:active,initial:true});
  const send=async()=>{if(!body.trim()||busy)return;setBusy(true);setError("");const text=body.trim();setBody("");try{const r=await fetch("/api/messages",{method:"POST",headers:{"content-type":"application/json","x-portal-role":"student"},body:JSON.stringify({body:text})});const data=await r.json() as {error?:string};if(!r.ok)throw new Error(data.error??"ارسال پیام انجام نشد.");await load();notifyDataUpdated();}catch(e){setBody(text);setError(e instanceof Error?e.message:"ارسال پیام انجام نشد.");}finally{setBusy(false)}};
  return <section id="student-chat" className="student-chat"><div className="student-files-heading"><div><span>COACH CHAT</span><h2><GlassSectionIcon name="messages" size={42} className="student-heading-glass"/> ارتباط با مربی</h2><p>پیام‌های این بخش فقط بین شما و مربی است.</p></div><Button type="button" variant="outline" size="icon" onClick={()=>void load()} aria-label="تازه‌سازی پیام‌ها"><RefreshCw/></Button></div>{error&&<p className="request-error" role="alert">{error}</p>}<div className="student-chat-history">{messages.map(m=><div key={m.id} className={m.sender_role==="student"?"mine":"coach"}><p>{m.body}</p><time>{new Date(m.created_at).toLocaleString("fa-IR")}</time>{m.sender_role==="student"&&<MessageReceipt readAt={m.read_at}/>}</div>)}{!messages.length&&!error&&<p className="student-empty">هنوز پیامی ثبت نشده است.</p>}</div><div className="student-chat-compose"><Textarea value={body} onChange={e=>setBody(e.target.value)} placeholder="پیامت را برای مربی بنویس…" onKeyDown={(event)=>{if(event.key==="Enter"&&!event.shiftKey){event.preventDefault();void send();}}}/><Button onClick={send} disabled={busy||!body.trim()}>{busy?<LoaderCircle className="animate-spin"/>:<Send/>} ارسال</Button></div></section>}
