import { z } from "zod";
import { database, sameOrigin } from "@/lib/raw-db";
import { coachDataKey, requestHasValidSession } from "@/lib/password-auth";
import { studentIdFromRequest } from "@/lib/student-auth";
import { createNotification } from "@/lib/notifications";
import type { CoachState } from "@/lib/coach-data";

const bodySchema=z.object({clientId:z.string().min(1).optional(),body:z.string().trim().min(1).max(2000)});

type ThreadRow={client_id:string;name:string;phone:string;last_message:string|null;last_at:string|null;unread:number;has_account:number};

async function identity(request:Request){
  const requested=request.headers.get("x-portal-role");
  if(requested==="student"){const clientId=await studentIdFromRequest(request);return clientId?{role:"student" as const,clientId}:null;}
  if(requested==="coach")return (await requestHasValidSession(request))?{role:"coach" as const,clientId:null}:null;
  const clientId=await studentIdFromRequest(request);
  if(clientId)return {role:"student" as const,clientId};
  if(await requestHasValidSession(request))return {role:"coach" as const,clientId:null};
  return null;
}

export async function GET(request:Request){
  const owner=await identity(request);if(!owner)return new Response(null,{status:401});
  const url=new URL(request.url);const requested=url.searchParams.get("clientId");
  const clientId=owner.role==="coach"?requested:owner.clientId;
  const db=database();
  if(owner.role==="coach"&&!clientId){
    const accountRows=await db.prepare(`SELECT s.client_id,COALESCE(json_extract(a.profile_json,'$.name'),'شاگرد') name,s.phone,
      (SELECT body FROM chat_messages m WHERE m.client_id=s.client_id ORDER BY created_at DESC LIMIT 1) last_message,
      (SELECT created_at FROM chat_messages m WHERE m.client_id=s.client_id ORDER BY created_at DESC LIMIT 1) last_at,
      (SELECT COUNT(*) FROM chat_messages m WHERE m.client_id=s.client_id AND sender_role='student' AND read_at IS NULL) unread,
      1 has_account
      FROM student_accounts s LEFT JOIN applications a ON a.id=(SELECT id FROM applications WHERE client_id=s.client_id ORDER BY created_at DESC LIMIT 1)
      ORDER BY COALESCE(last_at,s.updated_at) DESC`).all<ThreadRow>();
    const stateRow=await db.prepare("SELECT payload FROM coach_states WHERE owner_email=?").bind(coachDataKey()).first<{payload:string}>();
    const state=stateRow?JSON.parse(stateRow.payload) as CoachState:null;
    const merged=new Map(accountRows.results.map((row)=>[row.client_id,{...row}]));
    for(const client of state?.clients??[]){
      const existing=merged.get(client.id);
      if(existing){existing.name=client.name||existing.name;existing.phone=client.phone||existing.phone;}
      else merged.set(client.id,{client_id:client.id,name:client.name||"شاگرد",phone:client.phone||"",last_message:null,last_at:null,unread:0,has_account:0});
    }
    for(const row of merged.values())if(row.phone.startsWith("google:"))row.phone="حساب گوگل";
    const threads=[...merged.values()].sort((a,b)=>{
      if(a.last_at&&b.last_at)return b.last_at.localeCompare(a.last_at);
      if(a.last_at)return -1;if(b.last_at)return 1;return a.name.localeCompare(b.name,"fa");
    });
    return Response.json({threads},{headers:{"cache-control":"no-store"}});
  }
  if(!clientId)return Response.json({error:"شاگرد انتخاب نشده است."},{status:400});
  const account=await db.prepare("SELECT client_id FROM student_accounts WHERE client_id=?").bind(clientId).first();
  if(!account&&owner.role==="coach")return Response.json({messages:[],accountReady:false,error:"دسترسی پنل شاگرد برای این پرونده هنوز فعال نشده است."},{status:200,headers:{"cache-control":"no-store"}});
  if(!account)return Response.json({error:"حساب شاگرد پیدا نشد."},{status:404});
  if(url.searchParams.get("read")!=="0")await db.prepare("UPDATE chat_messages SET read_at=? WHERE client_id=? AND sender_role=? AND read_at IS NULL").bind(new Date().toISOString(),clientId,owner.role==="coach"?"student":"coach").run();
  const messages=await db.prepare("SELECT id,client_id,sender_role,body,read_at,created_at FROM chat_messages WHERE client_id=? ORDER BY created_at ASC LIMIT 500").bind(clientId).all();
  return Response.json({messages:messages.results,accountReady:true},{headers:{"cache-control":"no-store"}});
}

export async function POST(request:Request){
  if(!sameOrigin(request))return Response.json({error:"درخواست نامعتبر است؛ صفحه را یک‌بار تازه‌سازی کنید."},{status:403});
  const owner=await identity(request);if(!owner)return new Response(null,{status:401});
  try{
    const parsed=bodySchema.parse(await request.json());
    const clientId=owner.role==="coach"?parsed.clientId:owner.clientId;
    if(!clientId)return Response.json({error:"شاگرد انتخاب نشده است."},{status:400});
    const exists=await database().prepare("SELECT client_id FROM student_accounts WHERE client_id=?").bind(clientId).first();
    if(!exists)return Response.json({error:owner.role==="coach"?"ابتدا از پروفایل شاگرد، دسترسی پنل شاگرد را فعال کنید.":"حساب شاگرد پیدا نشد."},{status:409});
    const id=crypto.randomUUID(),now=new Date().toISOString();
    await database().prepare("INSERT INTO chat_messages (id,client_id,sender_role,body,created_at) VALUES (?,?,?,?,?)").bind(id,clientId,owner.role,parsed.body,now).run();
    if(owner.role==="coach")await createNotification({role:"student",clientId,actorClientId:null,type:"chat_message",title:"پیام جدید از مربی",body:parsed.body.slice(0,120),url:"/student",tag:`chat-${id}`});
    else await createNotification({role:"coach",actorClientId:clientId,type:"chat_message",title:"پیام جدید شاگرد",body:parsed.body.slice(0,120),url:"/coach",tag:`chat-${id}`});
    return Response.json({message:{id,client_id:clientId,sender_role:owner.role,body:parsed.body,read_at:null,created_at:now}});
  }catch(error){return Response.json({error:error instanceof z.ZodError?"متن پیام معتبر نیست.":"ارسال پیام انجام نشد."},{status:400});}
}

export async function PATCH(request:Request){if(!sameOrigin(request))return new Response(null,{status:403});const owner=await identity(request);if(!owner)return new Response(null,{status:401});try{const body=z.object({clientId:z.string().min(1).max(120).optional(),ids:z.array(z.string().min(1).max(120)).min(1).max(500)}).strict().parse(await request.json());const clientId=owner.role==='coach'?body.clientId:owner.clientId;if(!clientId)return new Response(null,{status:400});const readAt=new Date().toISOString(),ids=[...new Set(body.ids)];await database().prepare(`UPDATE chat_messages SET read_at=? WHERE client_id=? AND sender_role=? AND read_at IS NULL AND id IN (${ids.map(()=>'?').join(',')})`).bind(readAt,clientId,owner.role==='coach'?'student':'coach',...ids).run();return Response.json({ok:true,readAt},{headers:{'cache-control':'no-store'}})}catch{return new Response(null,{status:400})}}
