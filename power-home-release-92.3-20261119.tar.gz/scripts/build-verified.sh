#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ "${SITES_ENV_READY:-}" != "1" ]]; then
  exec "${script_dir}/sites-env.sh" -- "$0" "$@"
fi

command -v timeout || {
  echo "build-verified.sh requires GNU timeout." >&2
  exit 69
}

vinext="${SITES_PROJECT_ROOT}/node_modules/.bin/vinext"
if [[ ! -x "${vinext}" ]]; then
  echo "vinext is unavailable. Run npm run install:ci and wait for it to finish before building." >&2
  exit 69
fi

echo "Running bounded vinext build..."
timeout \
  --signal=TERM \
  --kill-after="${SITES_BUILD_KILL_AFTER:-10s}" \
  "${SITES_BUILD_TIMEOUT:-3m}" \
  "${vinext}" build

# Keep the previous production asset names available for clients that still
# have the last HTML shell cached while a new version is rolling out.
client_assets="${SITES_PROJECT_ROOT}/dist/client/assets"
cp "$(find "${client_assets}" -maxdepth 1 -name 'index-*.js' ! -name 'index-BdD6PDbG.js' -print -quit)" "${client_assets}/index-BdD6PDbG.js"
cp "$(find "${client_assets}" -maxdepth 1 -name 'coach-app-*.js' ! -name 'coach-app-ClhghW51.js' -print -quit)" "${client_assets}/coach-app-ClhghW51.js"
cp "$(find "${client_assets}" -maxdepth 1 -name 'layout-segment-context-*.js' ! -name 'layout-segment-context-8rHkGmkT.js' -print -quit)" "${client_assets}/layout-segment-context-8rHkGmkT.js"
