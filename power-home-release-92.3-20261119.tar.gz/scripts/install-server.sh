#!/usr/bin/env bash
set -euo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET_DIR="/opt/power-home-coach"
BACKUP_DIR="/opt/power-home-backups"

if [[ "${EUID}" -ne 0 ]]; then
  echo "این نصب باید با کاربر root اجرا شود." >&2
  exit 1
fi

apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y ca-certificates curl openssl rsync docker.io docker-compose-plugin || \
  DEBIAN_FRONTEND=noninteractive apt-get install -y ca-certificates curl openssl rsync docker.io docker-compose
systemctl enable --now docker

mkdir -p "${TARGET_DIR}" "${BACKUP_DIR}"
if [[ -d "${TARGET_DIR}/data" ]] && find "${TARGET_DIR}/data" -mindepth 1 -print -quit | grep -q .; then
  tar -czf "${BACKUP_DIR}/data-$(date +%Y%m%d-%H%M%S).tar.gz" -C "${TARGET_DIR}" data
fi

rsync -a --delete \
  --exclude='.git/' \
  --exclude='.next/' \
  --exclude='node_modules/' \
  --exclude='data/' \
  --exclude='.env' \
  "${SOURCE_DIR}/" "${TARGET_DIR}/"

mkdir -p "${TARGET_DIR}/data"
chown -R 1001:1001 "${TARGET_DIR}/data"
chmod 700 "${TARGET_DIR}/data"

if [[ ! -f "${TARGET_DIR}/.env" ]]; then
  APP_PASSWORD="$(openssl rand -base64 18 | tr -d '/+=' | cut -c1-18)"
  APP_SESSION_SECRET="$(openssl rand -hex 32)"
  umask 077
  {
    printf 'APP_PASSWORD=%s\n' "${APP_PASSWORD}"
    printf 'APP_SESSION_SECRET=%s\n' "${APP_SESSION_SECRET}"
    printf 'COACH_DATA_KEY=arminsorkheii@gmail.com\n'
  } > "${TARGET_DIR}/.env"
  echo "رمز موقت مربی: ${APP_PASSWORD}"
fi

cd "${TARGET_DIR}"
if docker compose version >/dev/null 2>&1; then
  COMPOSE=(docker compose)
else
  COMPOSE=(docker-compose)
fi

"${COMPOSE[@]}" up -d --build --remove-orphans
"${COMPOSE[@]}" ps

for attempt in {1..30}; do
  if "${COMPOSE[@]}" exec -T app node -e "fetch('http://127.0.0.1:3000/').then(r=>{if(!r.ok)process.exit(1)})"; then
    echo "بررسی داخلی: 200"
    break
  fi
  if [[ "${attempt}" -eq 30 ]]; then
    echo "بررسی داخلی برنامه ناموفق بود." >&2
    exit 1
  fi
  sleep 2
done

curl -fsSIL --max-time 20 https://arminsorkhei.ir/ | head -n 1 || true
