import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";

const source = (process.env.SOURCE_URL ?? "https://power-home-coach.arminsorkheii.chatgpt.site").replace(/\/$/, "");
const token = process.env.MIGRATION_TOKEN;
const dataDir = path.resolve(process.env.DATA_DIR ?? "data");
if (!token) throw new Error("MIGRATION_TOKEN is required.");

async function request(pathname) {
  const response = await fetch(`${source}${pathname}`, { headers: { authorization: `Bearer ${token}` } });
  if (!response.ok) throw new Error(`Migration request failed (${response.status}): ${pathname}`);
  return response;
}

const payload = await (await request("/api/internal-migration")).json();
for (const name of ["coachStates","coachSecurity","studentAccounts","applications","applicationUploads","checkins","bodyPhotos","pushSubscriptions","objects"]) {
  if (!Array.isArray(payload[name])) throw new Error(`Missing ${name} collection.`);
}

await mkdir(path.join(dataDir, "uploads"), { recursive: true });
const db = new DatabaseSync(path.join(dataDir, "power-home.sqlite"));
db.exec(`
  PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;
  CREATE TABLE IF NOT EXISTS coach_security (owner TEXT PRIMARY KEY,password_hash TEXT NOT NULL,salt TEXT NOT NULL,revision TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS login_attempts (key TEXT PRIMARY KEY,count INTEGER NOT NULL,reset_at INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS coach_states (owner_email TEXT PRIMARY KEY,payload TEXT NOT NULL,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS student_accounts (client_id TEXT PRIMARY KEY,phone TEXT NOT NULL UNIQUE,password_hash TEXT NOT NULL,salt TEXT NOT NULL,revision TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS applications (id TEXT PRIMARY KEY,client_id TEXT NOT NULL REFERENCES student_accounts(client_id),package_id TEXT NOT NULL,package_name TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'draft',price_amount INTEGER,profile_json TEXT NOT NULL DEFAULT '{}',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS application_uploads (id TEXT PRIMARY KEY,application_id TEXT NOT NULL REFERENCES applications(id),client_id TEXT NOT NULL,kind TEXT NOT NULL,key TEXT NOT NULL,filename TEXT NOT NULL,content_type TEXT NOT NULL,size INTEGER NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS checkins (id TEXT PRIMARY KEY,owner TEXT NOT NULL,client_id TEXT NOT NULL,date TEXT NOT NULL,payload TEXT NOT NULL,created_at TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS body_photos (id TEXT PRIMARY KEY,owner TEXT NOT NULL,checkin_id TEXT NOT NULL REFERENCES checkins(id),pose TEXT NOT NULL,key TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS push_subscriptions (id TEXT PRIMARY KEY,role TEXT NOT NULL,client_id TEXT,endpoint TEXT NOT NULL UNIQUE,p256dh TEXT NOT NULL,auth TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
  CREATE INDEX IF NOT EXISTS idx_checkins_owner_client_date ON checkins(owner,client_id,date);
  CREATE UNIQUE INDEX IF NOT EXISTS idx_body_photos_checkin_pose ON body_photos(owner,checkin_id,pose);
  CREATE INDEX IF NOT EXISTS idx_applications_status_updated ON applications(status,updated_at);
  CREATE INDEX IF NOT EXISTS idx_applications_client_created ON applications(client_id,created_at);
  CREATE INDEX IF NOT EXISTS idx_application_uploads_application ON application_uploads(application_id);
  CREATE INDEX IF NOT EXISTS idx_application_uploads_client_kind ON application_uploads(client_id,kind);
  CREATE INDEX IF NOT EXISTS idx_push_subscriptions_role_client ON push_subscriptions(role,client_id);
`);

const imports = [
  ["coachStates","INSERT OR REPLACE INTO coach_states(owner_email,payload,updated_at) VALUES(?,?,?)",["owner_email","payload","updated_at"]],
  ["coachSecurity","INSERT OR REPLACE INTO coach_security(owner,password_hash,salt,revision) VALUES(?,?,?,?)",["owner","password_hash","salt","revision"]],
  ["studentAccounts","INSERT OR REPLACE INTO student_accounts(client_id,phone,password_hash,salt,revision,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",["client_id","phone","password_hash","salt","revision","created_at","updated_at"]],
  ["applications","INSERT OR REPLACE INTO applications(id,client_id,package_id,package_name,status,price_amount,profile_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",["id","client_id","package_id","package_name","status","price_amount","profile_json","created_at","updated_at"]],
  ["applicationUploads","INSERT OR REPLACE INTO application_uploads(id,application_id,client_id,kind,key,filename,content_type,size,created_at) VALUES(?,?,?,?,?,?,?,?,?)",["id","application_id","client_id","kind","key","filename","content_type","size","created_at"]],
  ["checkins","INSERT OR REPLACE INTO checkins(id,owner,client_id,date,payload,created_at) VALUES(?,?,?,?,?,?)",["id","owner","client_id","date","payload","created_at"]],
  ["bodyPhotos","INSERT OR REPLACE INTO body_photos(id,owner,checkin_id,pose,key) VALUES(?,?,?,?,?)",["id","owner","checkin_id","pose","key"]],
  ["pushSubscriptions","INSERT OR REPLACE INTO push_subscriptions(id,role,client_id,endpoint,p256dh,auth,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",["id","role","client_id","endpoint","p256dh","auth","created_at","updated_at"]],
];

db.exec("BEGIN IMMEDIATE");
try {
  for (const [collection, sql, fields] of imports) {
    const statement = db.prepare(sql);
    for (const row of payload[collection]) statement.run(...fields.map((field) => row[field] ?? null));
  }
  db.exec("COMMIT");
} catch (error) { db.exec("ROLLBACK"); throw error; }
db.close();

let downloaded = 0;
for (const object of payload.objects) {
  const key = String(object.key);
  if (!/^(?:exercise-images|body-photos|student-applications)\/[0-9a-z./-]+$/i.test(key) || key.includes("..")) throw new Error(`Unsafe object key: ${key}`);
  const response = await request(`/api/internal-migration?key=${encodeURIComponent(key)}`);
  const filePath = path.join(dataDir, "uploads", key);
  await mkdir(path.dirname(filePath), { recursive: true });
  await writeFile(filePath, new Uint8Array(await response.arrayBuffer()), { mode: 0o600 });
  await writeFile(`${filePath}.json`, JSON.stringify({ httpMetadata: { contentType: response.headers.get("content-type") ?? "application/octet-stream" } }), { mode: 0o600 });
  downloaded += 1;
}

console.log(`Migration complete: ${payload.coachStates.length} state, ${payload.studentAccounts.length} students, ${payload.applications.length} applications, ${payload.checkins.length} check-ins, ${downloaded} uploads.`);
