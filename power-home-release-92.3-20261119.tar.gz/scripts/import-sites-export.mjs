import { mkdir, readFile } from "node:fs/promises";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";

const sourcePath = process.argv[2];
const output = path.resolve(process.env.DATA_DIR ?? "data");
if (!sourcePath) throw new Error("Usage: node scripts/import-sites-export.mjs <export.json>");

const payload = JSON.parse(await readFile(sourcePath, "utf8"));
for (const name of ["coachStates", "coachSecurity", "checkins", "bodyPhotos", "objects"]) {
  if (!Array.isArray(payload[name])) throw new Error(`Missing ${name} collection.`);
}
if (payload.objects.length) {
  throw new Error("The export contains stored objects. Download them before importing the database.");
}

await mkdir(output, { recursive: true });
const db = new DatabaseSync(path.join(output, "power-home.sqlite"));
db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;
  CREATE TABLE IF NOT EXISTS coach_security (owner TEXT PRIMARY KEY, password_hash TEXT NOT NULL, salt TEXT NOT NULL, revision TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS login_attempts (key TEXT PRIMARY KEY, count INTEGER NOT NULL, reset_at INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS coach_states (owner_email TEXT PRIMARY KEY, payload TEXT NOT NULL, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS checkins (id TEXT PRIMARY KEY, owner TEXT NOT NULL, client_id TEXT NOT NULL, date TEXT NOT NULL, payload TEXT NOT NULL, created_at TEXT NOT NULL);
  CREATE INDEX IF NOT EXISTS idx_checkins_owner_client_date ON checkins(owner, client_id, date);
  CREATE TABLE IF NOT EXISTS body_photos (id TEXT PRIMARY KEY, owner TEXT NOT NULL, checkin_id TEXT NOT NULL REFERENCES checkins(id), pose TEXT NOT NULL, key TEXT NOT NULL);
  CREATE UNIQUE INDEX IF NOT EXISTS idx_body_photos_checkin_pose ON body_photos(owner, checkin_id, pose);
`);

db.exec("BEGIN IMMEDIATE");
try {
  const state = db.prepare("INSERT OR REPLACE INTO coach_states (owner_email, payload, updated_at) VALUES (?, ?, ?)");
  for (const row of payload.coachStates) state.run(row.owner_email, row.payload, row.updated_at);

  const security = db.prepare("INSERT OR REPLACE INTO coach_security (owner, password_hash, salt, revision) VALUES (?, ?, ?, ?)");
  for (const row of payload.coachSecurity) security.run(row.owner, row.password_hash, row.salt, row.revision);

  const checkin = db.prepare("INSERT OR REPLACE INTO checkins (id, owner, client_id, date, payload, created_at) VALUES (?, ?, ?, ?, ?, ?)");
  for (const row of payload.checkins) checkin.run(row.id, row.owner, row.client_id, row.date, row.payload, row.created_at);

  const photo = db.prepare("INSERT OR REPLACE INTO body_photos (id, owner, checkin_id, pose, key) VALUES (?, ?, ?, ?, ?)");
  for (const row of payload.bodyPhotos) photo.run(row.id, row.owner, row.checkin_id, row.pose, row.key);
  db.exec("COMMIT");
} catch (error) {
  db.exec("ROLLBACK");
  throw error;
}
db.close();

console.log(`Imported ${payload.coachStates.length} state, ${payload.coachSecurity.length} security, ${payload.checkins.length} check-ins, and ${payload.bodyPhotos.length} photo rows.`);
