import { createHash, pbkdf2Sync, randomUUID } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";

const source = (process.env.SOURCE_URL ?? "https://power-home-coach.arminsorkheii.chatgpt.site").replace(/\/$/, "");
const output = path.resolve(process.env.DATA_DIR ?? "migration-data");
const owner = process.env.COACH_DATA_KEY ?? "arminsorkheii@gmail.com";

function readSecret() {
  return new Promise((resolve, reject) => {
    process.stdout.write("Current app password: ");
    process.stdin.setEncoding("utf8");
    process.stdin.once("data", (value) => resolve(value.trimEnd()));
    process.stdin.once("error", reject);
  });
}

async function request(pathname, cookie, options = {}) {
  const response = await fetch(`${source}${pathname}`, {
    ...options,
    headers: {
      origin: source,
      ...(options.headers ?? {}),
      ...(cookie ? { cookie } : {}),
    },
    redirect: "manual",
  });
  return response;
}

function initialize(db) {
  db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
    CREATE TABLE coach_security (owner TEXT PRIMARY KEY, password_hash TEXT NOT NULL, salt TEXT NOT NULL, revision TEXT NOT NULL);
    CREATE TABLE login_attempts (key TEXT PRIMARY KEY, count INTEGER NOT NULL, reset_at INTEGER NOT NULL);
    CREATE TABLE coach_states (owner_email TEXT PRIMARY KEY, payload TEXT NOT NULL, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE checkins (id TEXT PRIMARY KEY, owner TEXT NOT NULL, client_id TEXT NOT NULL, date TEXT NOT NULL, payload TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE INDEX idx_checkins_owner_client_date ON checkins(owner, client_id, date);
    CREATE TABLE body_photos (id TEXT PRIMARY KEY, owner TEXT NOT NULL, checkin_id TEXT NOT NULL REFERENCES checkins(id), pose TEXT NOT NULL, key TEXT NOT NULL);
    CREATE UNIQUE INDEX idx_body_photos_checkin_pose ON body_photos(owner, checkin_id, pose);
  `);
}

async function saveImage(url, cookie, target, contentTypeFallback) {
  const response = await request(url, cookie);
  if (!response.ok) throw new Error(`Image download failed (${response.status}): ${url}`);
  const bytes = new Uint8Array(await response.arrayBuffer());
  await mkdir(path.dirname(target), { recursive: true });
  await writeFile(target, bytes, { mode: 0o600 });
  const type = response.headers.get("content-type") ?? contentTypeFallback;
  await writeFile(`${target}.json`, JSON.stringify({ httpMetadata: { contentType: type } }), { mode: 0o600 });
  return bytes.length;
}

const password = await readSecret();
if (!password) throw new Error("Password is required.");

const login = await request("/api/auth/login", "", {
  method: "POST",
  headers: { "content-type": "application/json" },
  body: JSON.stringify({ password }),
});
if (!login.ok) throw new Error(`Login failed (${login.status}).`);
const cookie = login.headers.get("set-cookie")?.split(";")[0];
if (!cookie) throw new Error("The source did not return a session cookie.");

const stateResponse = await request("/api/state", cookie);
if (!stateResponse.ok) throw new Error(`State export failed (${stateResponse.status}).`);
const { state } = await stateResponse.json();
if (!state || !Array.isArray(state.clients)) throw new Error("The source state is empty or invalid.");

await mkdir(output, { recursive: true });
const databasePath = path.join(output, "power-home.sqlite");
const db = new DatabaseSync(databasePath);
initialize(db);
db.prepare("INSERT INTO coach_states (owner_email, payload) VALUES (?, ?)").run(owner, JSON.stringify(state));

const salt = randomUUID();
const passwordHash = pbkdf2Sync(password, salt, 100000, 32, "sha256").toString("hex");
db.prepare("INSERT INTO coach_security (owner, password_hash, salt, revision) VALUES (?, ?, ?, ?)").run(owner, passwordHash, salt, randomUUID());

let checkinCount = 0;
let photoCount = 0;
let imageBytes = 0;
for (const client of state.clients) {
  const listResponse = await request(`/api/checkins?clientId=${encodeURIComponent(client.id)}`, cookie);
  if (listResponse.status === 403) continue;
  if (!listResponse.ok) throw new Error(`Check-in list failed (${listResponse.status}) for ${client.id}.`);
  const { records = [] } = await listResponse.json();
  for (const summary of records) {
    const detailResponse = await request(`/api/checkins?clientId=${encodeURIComponent(client.id)}&id=${encodeURIComponent(summary.id)}`, cookie);
    if (!detailResponse.ok) throw new Error(`Check-in export failed (${detailResponse.status}) for ${summary.id}.`);
    const { record } = await detailResponse.json();
    const photos = record.photos ?? {};
    delete record.photos;
    db.prepare("INSERT OR IGNORE INTO checkins (id, owner, client_id, date, payload, created_at) VALUES (?, ?, ?, ?, ?, ?)").run(
      record.id,
      owner,
      record.clientId,
      record.date,
      JSON.stringify(record),
      record.createdAt ?? new Date().toISOString(),
    );
    checkinCount += 1;
    for (const [pose, url] of Object.entries(photos)) {
      const id = String(url).split("/").pop();
      if (!id || !/^[0-9a-f-]+$/i.test(id)) throw new Error(`Invalid body photo URL: ${url}`);
      const key = `body-photos/${id}`;
      imageBytes += await saveImage(String(url), cookie, path.join(output, "uploads", key), "image/jpeg");
      db.prepare("INSERT OR IGNORE INTO body_photos (id, owner, checkin_id, pose, key) VALUES (?, ?, ?, ?, ?)").run(id, owner, record.id, pose, key);
      photoCount += 1;
    }
  }
}

let customImageCount = 0;
for (const exercise of state.customExercises ?? []) {
  if (typeof exercise.image !== "string" || !exercise.image.startsWith("/api/exercise-images/")) continue;
  const key = exercise.image.split("/").pop();
  if (!key || !/^[0-9a-f-]+\.(jpg|png|webp)$/i.test(key)) throw new Error(`Invalid exercise image URL: ${exercise.image}`);
  imageBytes += await saveImage(exercise.image, cookie, path.join(output, "uploads", "exercise-images", key), "application/octet-stream");
  customImageCount += 1;
}

db.close();
const fingerprint = createHash("sha256").update(JSON.stringify(state)).digest("hex").slice(0, 12);
console.log(`\nExport complete: ${state.clients.length} clients, ${checkinCount} check-ins, ${photoCount} body photos, ${customImageCount} custom exercise images, ${imageBytes} image bytes, state ${fingerprint}.`);
