const BADGE_CACHE = "armin-coach-badge-v1";
const BADGE_KEY = "/__app-badge-count__";
const SW_RELEASE = "92.3";

self.addEventListener("install", () => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    const cacheNames = await caches.keys();
    await Promise.all(cacheNames.filter((name) => name !== BADGE_CACHE).map((name) => caches.delete(name)));
    await self.clients.claim();
    // Activation must never reload open forms or notification screens.
  })());
});

async function readBadgeCount() {
  const cache = await caches.open(BADGE_CACHE);
  const stored = await cache.match(BADGE_KEY);
  if (!stored) return 0;
  const value = Number(await stored.text());
  return Number.isFinite(value) ? value : 0;
}

async function showBadge(count) {
  const cache = await caches.open(BADGE_CACHE);
  await cache.put(BADGE_KEY, new Response(String(Math.max(0, count))));
  if (count > 0 && "setAppBadge" in self.registration) {
    await self.registration.setAppBadge(count);
  } else if (count === 0 && "clearAppBadge" in self.registration) {
    await self.registration.clearAppBadge();
  }
}

self.addEventListener("push", (event) => {
  let data = { title: "آرمین سرخه‌ای", body: "اعلان جدید", url: "/", tag: "armin-coach" };
  try { data = { ...data, ...event.data.json() }; } catch {}
  event.waitUntil((async () => {
    const nextCount = (await readBadgeCount()) + 1;
    await Promise.all([
      self.registration.showNotification(data.title, {
        body: data.body,
        icon: "/icon-512.png",
        badge: "/apple-touch-icon.png",
        tag: data.tag,
        data: { url: data.url },
        renotify: true,
      }),
      showBadge(nextCount),
    ]);
  })());
});

self.addEventListener("message", (event) => {
  if (event.data?.type === "CLEAR_BADGE") event.waitUntil(showBadge(0));
  if (event.data?.type === "SKIP_WAITING") self.skipWaiting();
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  let target;
  try { target = new URL(event.notification.data?.url || "/", self.location.origin); } catch { target = new URL("/", self.location.origin); }
  if(target.origin===self.location.origin&&!target.search&&!target.hash){
    if(target.pathname==="/coach")target.search="?view=notifications";
    if(target.pathname==="/student")target.search="?section=notifications";
  }
  const url = target.origin === self.location.origin ? target.href : self.location.origin + "/";
  event.waitUntil(Promise.all([
    showBadge(0),
    clients.matchAll({ type: "window", includeUncontrolled: true }).then((list) => {
      for (const client of list) {
        if (client.url.startsWith(self.location.origin) && "focus" in client) {
          return client.navigate(url).then((navigated) => (navigated || client).focus());
        }
      }
      return clients.openWindow(url);
    }),
  ]));
});
