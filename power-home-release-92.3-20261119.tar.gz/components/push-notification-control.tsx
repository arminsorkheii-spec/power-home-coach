"use client";
import { useEffect, useRef, useState } from "react";
import { Bell, CheckCircle2, LoaderCircle } from "lucide-react";
import { appServiceWorker, bounded, portalFetch } from "@/lib/pwa-client";

function keyBytes(value: string) {
  const binary = atob((value + "=".repeat((4 - value.length % 4) % 4)).replace(/-/g, "+").replace(/_/g, "/"));
  return Uint8Array.from(binary, c => c.charCodeAt(0));
}
function supported() { return "serviceWorker" in navigator && "PushManager" in window && "Notification" in window; }
function role() { return location.pathname.startsWith("/student") ? "student" : "coach"; }

export function PushNotificationControl() {
  const [state, setState] = useState<"loading" | "off" | "on" | "unsupported">("loading");
  const [message, setMessage] = useState("");
  const busy = useRef(false);
  useEffect(() => {
    let alive = true;
    if (!supported()) { setState("unsupported"); return; }
    void (async () => {
      const registration = await appServiceWorker();
      const subscription = await bounded(registration.pushManager.getSubscription());
      if (!alive) return;
      setState(subscription ? "on" : "off");
      if (subscription) {
        const json = subscription.toJSON();
        await portalFetch("/api/push/subscription", { method: "POST", headers: { "content-type": "application/json", "x-portal-role": role() }, body: JSON.stringify({ endpoint: json.endpoint, keys: json.keys }) });
      }
    })().catch(() => {
      if (alive) { setState("off"); setMessage("اتصال اعلان برقرار نشد؛ دوباره تلاش کنید."); }
    });
    return () => { alive = false; };
  }, []);

  const toggle = async () => {
    if (busy.current || !supported()) return;
    const isIos = /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
    const standalone = matchMedia("(display-mode: standalone)").matches || (navigator as Navigator & { standalone?: boolean }).standalone;
    if (isIos && !standalone) {
      setMessage("در آیفون اول Share را بزن، Add to Home Screen را انتخاب کن و از آیکن برنامه اعلان را فعال کن.");
      return;
    }
    busy.current = true; setMessage(""); setState("loading");
    let created: PushSubscription | undefined;
    try {
      // Keep permission request inside the user's click gesture.
      const permission = Notification.permission === "default" ? await bounded(Notification.requestPermission(), 60000) : Notification.permission;
      if (permission !== "granted") throw new Error("اجازه اعلان داده نشد؛ تنظیمات اعلان دستگاه را بررسی کنید.");
      await appServiceWorker();
      const registration = await bounded(navigator.serviceWorker.ready);
      const current = await bounded(registration.pushManager.getSubscription());
      if (current) {
        const response = await portalFetch("/api/push/subscription", { method: "DELETE", headers: { "content-type": "application/json", "x-portal-role": role() }, body: JSON.stringify({ endpoint: current.endpoint }) });
        if (!response.ok) throw new Error("خاموش‌کردن اعلان انجام نشد.");
        if (!await bounded(current.unsubscribe())) throw new Error("خاموش‌کردن اعلان دستگاه انجام نشد.");
        setState("off"); setMessage("اعلان خاموش شد."); return;
      }
      const keyResponse = await portalFetch("/api/push/key", { cache: "no-store" });
      const keyData = await keyResponse.json() as { publicKey?: string; error?: string };
      if (!keyResponse.ok || !keyData.publicKey) throw new Error(keyData.error || "کلید اعلان دریافت نشد.");
      created = await bounded(registration.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: keyBytes(keyData.publicKey) }));
      const json = created.toJSON();
      const response = await portalFetch("/api/push/subscription", { method: "POST", headers: { "content-type": "application/json", "x-portal-role": role() }, body: JSON.stringify({ endpoint: json.endpoint, keys: json.keys }) });
      if (!response.ok) throw new Error("ثبت اعلان انجام نشد.");
      setState("on"); setMessage("اعلان این دستگاه فعال شد.");
    } catch (error) {
      if (created) await bounded(created.unsubscribe()).catch(() => {});
      setState("off"); setMessage(error instanceof Error ? error.message : "فعال‌سازی اعلان انجام نشد.");
    } finally { busy.current = false; }
  };
  if (state === "unsupported") return <div className="push-control unsupported"><Bell/><span>اعلان روی این مرورگر پشتیبانی نمی‌شود. در آیفون از Safari و «Add to Home Screen» استفاده کنید.</span></div>;
  return <div className={`push-control ${state === "on" ? "enabled" : ""}`}><button type="button" onClick={() => void toggle()} disabled={state === "loading"} aria-pressed={state === "on"}>{state === "loading" ? <LoaderCircle className="animate-spin"/> : state === "on" ? <CheckCircle2 className="push-enabled-check"/> : <Bell/>}<span>{state === "on" ? "اعلان فعال است" : "فعال‌کردن اعلان"}</span></button>{message && <small role="status">{message}</small>}</div>;
}
