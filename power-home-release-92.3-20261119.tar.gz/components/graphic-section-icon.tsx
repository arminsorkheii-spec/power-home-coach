import Image from "next/image";

export type GraphicSectionIconName = "training" | "nutrition" | "supplements" | "medications" | "messages" | "billing" | "notifications" | "pdf";

const labels: Record<GraphicSectionIconName,string> = {
  training:"برنامه تمرینی", nutrition:"رژیم غذایی", supplements:"مکمل", medications:"دارو / PCT",
  messages:"پیام‌ها", billing:"حسابداری", notifications:"نوتیفیکیشن", pdf:"PDF",
};

export function GraphicSectionIcon({name,size=76,className=""}:{name:GraphicSectionIconName;size?:number;className?:string}){
  return <Image className={`graphic-section-icon ${className}`} src={`/section-icons/${name}.webp`} alt={labels[name]} width={size} height={Math.round(size*.82)} priority={false}/>;
}
