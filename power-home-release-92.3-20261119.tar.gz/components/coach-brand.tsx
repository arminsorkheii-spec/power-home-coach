export function CoachBrand() {
  return <header className="print-brand">
    <div className="print-brand-copy" dir="ltr">
      <h1>ARMIN SORKHEI</h1>
      <p className="print-kicker">PERSONAL COACHING · آرمین سرخه‌ای</p>
      <div className="coach-contacts">
        <a href="https://www.instagram.com/armin_sorkhei/" aria-label="Instagram armin_sorkhei">
          <span className="instagram-logo"><svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="1.8"><rect x="4" y="4" width="16" height="16" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17" cy="7" r="1" fill="white" stroke="none"/></svg></span><span className="contact-label">@armin_sorkhei</span>
        </a>
        <a href="https://wa.me/989338720392" aria-label="WhatsApp 09338720392">
          <span className="whatsapp-logo"><svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="1.7"><path d="M5 18 3 22l5-2a9 9 0 1 0-3-2Z"/><path d="M8 7c-2 3 3 9 7 9l2-2-3-2-1 2c-2-1-3-2-3-4l1-1Z" fill="white" stroke="none"/></svg></span><span className="contact-label">09338720392</span>
        </a>
      </div>
    </div>
    <img className="coach-portrait" src="/brand/armin.png" alt="آرمین سرخه‌ای" />
  </header>;
}
