"use client";
import {type Package,formatPrice} from '@/lib/packages';
export function PackageChoices({packages,selected,onChange,disabled=false}:{packages:readonly Package[];selected:string[];onChange:(ids:string[])=>void;disabled?:boolean}){
 const choose=(id:string)=>{if(selected.includes(id)){onChange(selected.filter(x=>x!==id));return;}const bundle=id==='natural'||id==='professional';onChange(bundle?[id]:[...selected.filter(x=>x!=='natural'&&x!=='professional'),id]);};
 return <fieldset className="package-choices" disabled={disabled}><legend>خدمات مورد نیازت را انتخاب کن</legend><p>می‌توانی یک یا چند خدمت مستقل را با هم بگیری. پکیج‌های نچرال و VIP جداگانه انتخاب می‌شوند.</p><div>{packages.map(item=><label key={item.id} className={selected.includes(item.id)?'selected':''}><input type="checkbox" checked={selected.includes(item.id)} onChange={()=>choose(item.id)}/><span>{item.name}<small>{formatPrice(item.price)}</small></span></label>)}</div><strong>جمع خدمات انتخابی: {formatPrice(packages.filter(p=>selected.includes(p.id)).reduce((n,p)=>n+p.price,0))}</strong></fieldset>;
}
