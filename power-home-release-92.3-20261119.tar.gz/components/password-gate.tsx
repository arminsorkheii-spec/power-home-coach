"use client";

import { usePackages } from "@/components/package-catalog";

import { ArrowLeft, ArrowDown, AtSign, Award, Check, ChevronLeft, GraduationCap, LockKeyhole, Medal, MessageCircle, ShieldCheck, Sparkles, Trophy, UserPlus, UserRound, Dumbbell, Utensils, Image as ImageIcon, Info } from "lucide-react";
import { PACKAGES, type Package, formatPrice } from "@/lib/packages";
import { InstallAppButton } from "@/components/install-app-button";
import { GraphicSectionIcon, type GraphicSectionIconName } from "@/components/graphic-section-icon";
import { GlassSectionIcon } from "@/components/glass-section-icon";

const packages = [
  { id:"natural", name: "پکیج نچرال", subtitle: "مسیر کامل پیشرفت بدون دارو", items: ["برنامه تمرینی اختصاصی", "برنامه تغذیه", "مکمل و ویتامین"], featured: true },
  { id:"professional", name: "پکیج VIP", subtitle: "کوچینگ پیشرفته همراه با بررسی آزمایش", items: ["تمرین پیشرفته و دوره‌بندی‌شده", "تغذیه تخصصی", "بررسی آزمایش", "چک‌این منظم"], featured: true },
  { id:"training", name: "برنامه تمرینی", subtitle: "برنامه تمرینی به‌صورت جداگانه", items: ["تقسیم‌بندی اختصاصی", "سیستم‌های تمرینی", "تصویر و توضیح حرکات"] },
  { id:"nutrition", name: "برنامه غذایی", subtitle: "برنامه غذایی به‌صورت جداگانه", items: ["محاسبه کالری و درشت‌مغذی", "وعده‌های قابل‌اجرا", "جایگزین مواد غذایی"] },
  { id:"supplements", name: "برنامه مکمل", subtitle: "برنامه مکمل و ویتامین به‌صورت جداگانه", items: ["مکمل‌های ورزشی", "ویتامین و مینرال", "بررسی تداخل‌ها"] },
  { id:"pct", name: "پاک‌سازی (PCT)", subtitle: "بررسی شرایط پس از دوره", items: ["بررسی سابقه", "ارزیابی آزمایش‌ها", "ارجاع پزشکی در صورت نیاز"], caution: true },
  { id:"cycle", name: "سایکل دارویی", subtitle: "ارزیابی تخصصی ورزشکاران حرفه‌ای", items: ["بررسی هدف و سابقه", "الزام آزمایش‌های مرتبط", "نظارت و ارجاع پزشکی"], caution: true },
];

const services:{icon:GraphicSectionIconName;title:string;text:string}[]=[
  {icon:"training",title:"برنامه تمرینی اختصاصی",text:"بر اساس سطح، هدف، تجهیزات و سابقه تمرینی تو."},
  {icon:"nutrition",title:"رژیم غذایی علمی",text:"متناسب با هدف، سبک زندگی و شرایط واقعی بدن."},
  {icon:"supplements",title:"برنامه مکمل",text:"مکمل و ویتامین با زمان‌بندی و دوزبندی مشخص."},
  {icon:"medications",title:"دارو / PCT",text:"فقط پس از بررسی شرایط و آزمایش‌های لازم."},
  {icon:"messages",title:"ارتباط با مربی",text:"پیگیری مستقیم مسیر و پاسخ به سوالات داخل پنل."},
];

const transformations=[
  {src:"/brand/student-transform-1-anon.webp",title:"کات و آماده‌سازی",text:"تغییر ترکیب بدنی و رسیدن به فرم خشک‌تر"},
  {src:"/brand/student-transform-2-anon.webp",title:"کاهش چربی",text:"کاهش وزن و سایز همراه با حفظ فرم عضلانی"},
  {src:"/brand/student-transform-3-anon.webp",title:"آماده‌سازی مسابقه",text:"پیشرفت واقعی از شروع مسیر تا استیج"},
  {src:"/brand/student-transform-4-anon.webp",title:"ریکامپ و عضله‌سازی",text:"کاهش چربی همراه با افزایش وضوح عضلات"},
];

const competitionGallery = [
  { src:"/achievements/tehran-overall-medal.webp", title:"قهرمانی اورال تهران" },
  { src:"/achievements/tehran-stage.webp", title:"استیج مسابقات تهران" },
  { src:"/achievements/tehran-front.webp", title:"مسابقات تهران" },
  { src:"/achievements/tehran-side-medal.webp", title:"مدال مسابقات تهران" },
  { src:"/achievements/iran-classic-medal.webp", title:"مسابقات کشوری" },
  { src:"/achievements/armenia-medal-front.webp", title:"NPC ارمنستان" },
  { src:"/achievements/armenia-side.webp", title:"استیج ارمنستان" },
  { src:"/achievements/dubai-stage.webp", title:"Muscle Beach Dubai" },
  { src:"/achievements/south-east-overall-back.webp", title:"قهرمانی اورال" },
  { src:"/achievements/stage-lat-spread.webp", title:"استیج بدنسازی" },
];

const resumeItems = [
  { icon: Trophy, text: "قهرمان اورال چندین دوره مسابقات بدنسازی تهران" },
  { icon: Medal, text: "قهرمان فوق‌سنگین کشور" },
  { icon: Award, text: "قهرمان مسابقات NPC ارمنستان" },
  { icon: Medal, text: "نایب‌قهرمان دسته سنگین Muscle Beach دبی" },
  { icon: GraduationCap, text: "کارشناس تربیت بدنی" },
  { icon: ShieldCheck, text: "بیش از ۱۵ سال سابقه حرفه‌ای در بدنسازی و مربیگری" },
];

export function PasswordGate({initialPackages=PACKAGES}:{initialPackages?:readonly Package[]}) {
  const { packages: PACKAGES, packageById } = usePackages(initialPackages);
  return <main className="public-coaching-page armin-home" dir="rtl">
    <nav className="public-nav" aria-label="ناوبری اصلی">
      <a className="public-wordmark" href="#top" aria-label="صفحه اصلی آرمین سرخه‌ای"><span>AS</span><div><strong>آرمین سرخه‌ای</strong><small>ARMIN SORKHEI</small></div></a>
      <div className="public-nav-actions">
        <a href="#services"><Dumbbell/> خدمات</a><a href="#results"><ImageIcon/> نتایج شاگردها</a><a href="#packages"><Utensils/> پکیج‌ها</a><a href="#resume"><Info/> درباره من</a>
        <a className="public-signup-link" href="/signup"><UserPlus/> ثبت‌نام</a>
        <a className="public-student-link" href="/student"><UserRound/> ورود شاگرد</a>
        <a className="public-login-link" href="/coach"><LockKeyhole/> مربی</a>
      </div>
    </nav>

    <InstallAppButton />

    <section id="top" className="armin-hero">
      <div className="armin-hero-copy">
        <p className="public-eyebrow"><Sparkles/> مربیگری تخصصی بدنسازی</p>
        <h1>بدن رویایی با <em>مربیگری حرفه‌ای</em></h1>
        <p className="armin-hero-sub">تمرین، تغذیه، مکمل و پیگیری مستمر؛ برنامه‌ای که با شرایط واقعی بدن تو نوشته می‌شود، نه نسخه آماده برای همه.</p>
        <div className="public-hero-actions"><a className="public-primary-btn" href="#packages">دریافت برنامه اختصاصی <ArrowLeft/></a><a className="public-secondary-btn" href="#results">دیدن نتایج شاگردها <ChevronLeft/></a></div>
        <div className="armin-trust"><span><strong>+۱۵</strong> سال سابقه</span><span><strong>NPC</strong> ارمنستان</span><span><strong>۲nd</strong> Muscle Beach Dubai</span></div>
      </div>
      <div className="armin-hero-photo"><img src="/brand/armin-hero.webp" alt="آرمین سرخه‌ای روی استیج مسابقات بدنسازی"/><div className="armin-hero-badge"><Trophy/><span>ARMIN SORKHEI<br/><b>COACHING</b></span></div></div>
    </section>

    <section id="packages" className="public-section public-packages-section armin-packages">
      <div className="public-section-heading"><p>COACHING PLANS</p><h2>پکیج مناسب هدفت را انتخاب کن</h2><span>هر پکیج بعد از ثبت درخواست وارد پنل می‌شود و روند پرداخت، نگارش و تحویل برنامه قابل پیگیری است.</span></div>
      <div className="public-packages-grid">{packages.map(item=><article key={item.name} className={`public-package-card ${item.featured?"is-featured":""}`}>{item.featured&&<span className="public-package-badge">پیشنهاد ویژه</span>}<h3>{item.name}</h3><p>{item.subtitle}</p><strong className="public-package-price">{formatPrice(packageById(item.id)?.price??null)}</strong><ul>{item.items.map(feature=><li key={feature}><Check/> {feature}</li>)}</ul>{item.caution&&<small>ارائه خدمات پس از بررسی آزمایش‌ها و با رعایت الزامات پزشکی انجام می‌شود.</small>}<a href={`/signup?package=${item.id}`}>انتخاب و ثبت‌نام <UserRound/></a></article>)}</div>
    </section>

    <section id="resume" className="public-section public-resume-section armin-resume">
      <div className="public-resume-copy"><div className="public-section-heading align-start"><p>ARMIN SORKHEI</p><h2>تجربه‌ای که پشت برنامه توست</h2><span>سال‌ها مسابقه، آماده‌سازی، مربیگری و تجربه عملی در کنار ساختار علمی برنامه.</span></div><div className="public-resume-list">{resumeItems.map(({icon:Icon,text})=><div key={text}><Icon/><span>{text}</span></div>)}</div><a className="public-instagram" href="https://www.instagram.com/armin_sorkhei/" target="_blank" rel="noreferrer"><AtSign/> @armin_sorkhei</a></div>
      <div className="armin-resume-card"><img src="/achievements/tehran-overall-medal.webp" alt="آرمین سرخه‌ای قهرمان اورال مسابقات تهران"/><div><Medal/><span>مسابقه، تجربه، مربیگری<br/><strong>یک مسیر حرفه‌ای</strong></span></div></div>
    </section>

    <section className="public-section armin-competition-gallery">
      <div className="public-section-heading"><p>COMPETITION GALLERY</p><h2>مسابقات و افتخارات</h2><span>عکس‌های مسابقات و رزومه قبلی سایت حفظ شده‌اند و با ظاهر جدید نمایش داده می‌شوند.</span></div>
      <div className="armin-competition-grid">{competitionGallery.map((item,index)=><figure key={item.src}><img src={item.src} alt={`${item.title} آرمین سرخه‌ای`} loading={index>3?"lazy":"eager"}/><figcaption><Trophy/><span>{item.title}</span></figcaption></figure>)}</div>
    </section>

    <section id="services" className="public-section armin-services">
      <div className="public-section-heading"><p>COACHING SYSTEM</p><h2>همه‌چیز برای پیشرفت، یک‌جا</h2></div>
      <div className="armin-service-grid">{services.map(item=><article key={item.title}><GraphicSectionIcon name={item.icon} size={70} className="public-color-icon"/><div><h3>{item.title}</h3><p>{item.text}</p></div><ChevronLeft/></article>)}</div>
    </section>

    <section className="public-section armin-app-showcase"><div><p>ARMIN SORKHEI APP</p><h2>برنامه‌ات همیشه همراهته</h2><span>تمرین، تغذیه، مکمل، پیام‌ها، روند پیشرفت و PDFهای جدا داخل پنل شاگرد.</span><div className="armin-app-icons"><GraphicSectionIcon name="training" size={68} className="public-color-icon"/><GraphicSectionIcon name="nutrition" size={68} className="public-color-icon"/><GraphicSectionIcon name="messages" size={68} className="public-color-icon"/><GraphicSectionIcon name="pdf" size={68} className="public-color-icon"/></div></div><div className="armin-app-actions"><a href="/student">ورود به پنل شاگرد <ArrowLeft/></a><a href="/signup">شروع ثبت‌نام <UserPlus/></a></div></section>

    <section id="results" className="public-section armin-results">
      <div className="public-section-heading"><p>REAL RESULTS</p><h2>نتایج واقعی شاگردها</h2><span>نمونه‌هایی از تغییرات واقعی شاگردها؛ برای حفظ حریم خصوصی، چهره افراد در تصاویر عمومی پوشانده شده است.</span></div>
      <div className="armin-transform-grid">{transformations.map((item,index)=><article key={item.src}><div className="armin-transform-photo"><img src={item.src} alt={`تغییر شاگرد آرمین سرخه‌ای ${index+1}`} loading={index>1?"lazy":"eager"}/><span>قبل / بعد</span></div><div><strong>{item.title}</strong><p>{item.text}</p></div></article>)}</div>
      <a className="armin-results-cta" href="/signup">تو نفر بعدی باش <ArrowLeft/></a>
    </section>

    <footer className="public-footer"><div><strong>ARMIN SORKHEI</strong><span>کوچینگ تخصصی بدنسازی</span></div><a href="https://wa.me/989338720392" target="_blank" rel="noreferrer"><MessageCircle/> ارتباط در واتس‌اپ</a></footer>
  </main>;
}
