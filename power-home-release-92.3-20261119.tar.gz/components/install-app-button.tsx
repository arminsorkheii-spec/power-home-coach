"use client";

import { useEffect, useState } from "react";
import { Download, Plus, Share, Smartphone } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";

type InstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

function isStandalone() {
  return window.matchMedia("(display-mode: standalone)").matches || Boolean((navigator as Navigator & { standalone?: boolean }).standalone);
}

function isAppleMobile() {
  return /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
}

import { appServiceWorker } from "@/lib/pwa-client";

export function InstallAppButton() {
  const [promptEvent, setPromptEvent] = useState<InstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(true);
  const [guideOpen, setGuideOpen] = useState(false);
  const [apple, setApple] = useState(false);

  useEffect(() => {
    setInstalled(isStandalone());
    setApple(isAppleMobile());
    if ("serviceWorker" in navigator) {
      void appServiceWorker().catch(() => { /* Installation guide remains usable offline. */ });
    }
    const capture = (event: Event) => {
      event.preventDefault();
      setPromptEvent(event as InstallPromptEvent);
      setInstalled(false);
    };
    const complete = () => setInstalled(true);
    window.addEventListener("beforeinstallprompt", capture);
    window.addEventListener("appinstalled", complete);
    return () => {
      window.removeEventListener("beforeinstallprompt", capture);
      window.removeEventListener("appinstalled", complete);
    };
  }, []);

  if (installed) return null;

  const install = async () => {
    if (promptEvent) {
      await promptEvent.prompt();
      const choice = await promptEvent.userChoice;
      if (choice.outcome === "accepted") setInstalled(true);
      setPromptEvent(null);
      return;
    }
    setGuideOpen(true);
  };

  return <>
    <section className="public-app-promo" aria-label="نصب اپ کوچینگ">
      <div className="public-app-icon"><img src="/apple-touch-icon.png" alt="" /><span><Plus /></span></div>
      <div className="public-app-copy"><strong>اپ کوچینگ آرمین سرخه‌ای</strong><span>برنامه‌ها، عکس‌ها و روند پیشرفتت همیشه روی گوشی</span></div>
      <button type="button" className="install-app-cta" onClick={install} aria-label="نصب برنامه" title="نصب برنامه">
        <Download />
        <strong>نصب برنامه</strong>
      </button>
    </section>
    <Dialog open={guideOpen} onOpenChange={setGuideOpen}>
      <DialogContent dir="rtl" className="install-guide">
        <DialogHeader>
          <div className="install-guide-icon"><Smartphone /></div>
          <DialogTitle>نصب اپ روی صفحه گوشی</DialogTitle>
          <DialogDescription>{apple ? "در آیفون نصب اپ از منوی Share مرورگر Safari انجام می‌شود." : "اگر پنجره نصب باز نشد، از منوی مرورگر گزینه نصب برنامه را انتخاب کن."}</DialogDescription>
        </DialogHeader>
        {apple ? <ol>
          <li><b>۱</b><span>در نوار پایین Safari روی دکمه <strong><Share /> Share</strong> بزن.</span></li>
          <li><b>۲</b><span>گزینه <strong>Add to Home Screen</strong> را انتخاب کن.</span></li>
          <li><b>۳</b><span>بالای صفحه روی <strong>Add</strong> بزن تا آیکون اپ اضافه شود.</span></li>
        </ol> : <ol>
          <li><b>۱</b><span>منوی سه‌نقطه مرورگر را باز کن.</span></li>
          <li><b>۲</b><span>گزینه <strong>Install app</strong> یا <strong>Add to Home screen</strong> را بزن.</span></li>
          <li><b>۳</b><span>نصب را تأیید کن؛ آیکون اپ روی صفحه گوشی می‌آید.</span></li>
        </ol>}
      </DialogContent>
    </Dialog>
  </>;
}
