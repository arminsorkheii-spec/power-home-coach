"use client";

import { useState } from "react";
import { BellRing, LoaderCircle, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export function CoachNotificationComposer(){
  const [title,setTitle]=useState("");
  const [body,setBody]=useState("");
  const [busy,setBusy]=useState(false);
  const [message,setMessage]=useState("");
  const [error,setError]=useState(false);
  const send=async()=>{
    setBusy(true);setMessage("");setError(false);
    try{
      const response=await fetch("/api/push/broadcast",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({title,body})});
      const data=await response.json() as {error?:string;total?:number;sent?:number;failed?:number};
      if(!response.ok)throw new Error(data.error??"ارسال اعلان انجام نشد.");
      if(!data.total)setMessage("هنوز هیچ شاگردی اعلان گوشی را فعال نکرده است.");
      else setMessage(`اعلان برای ${(data.sent??0).toLocaleString("fa-IR")} دستگاه ارسال شد${data.failed?`؛ ${data.failed.toLocaleString("fa-IR")} ارسال ناموفق بود.`:"."}`);
      if(data.sent)setBody("");
    }catch(reason){setError(true);setMessage(reason instanceof Error?reason.message:"ارسال اعلان انجام نشد.");}
    finally{setBusy(false);}
  };
  return <section className="mb-5 overflow-hidden rounded-3xl border border-amber-500/20 bg-[radial-gradient(circle_at_100%_0%,rgba(174,184,196,.16),transparent_42%),#111316] p-5" dir="rtl">
    <div className="flex items-start gap-3"><span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-amber-500 text-white"><BellRing className="size-5"/></span><div><h2 className="font-black text-white">ارسال اعلان به شاگردها</h2><p className="mt-1 text-xs leading-6 text-zinc-500">تخفیف، اطلاعیه یا هر پیام دلخواه را برای شاگردهایی که اعلان را فعال کرده‌اند بفرست.</p></div></div>
    <div className="mt-4 grid gap-3">
      <label className="text-sm text-zinc-300">عنوان اعلان<Input value={title} onChange={event=>setTitle(event.target.value)} maxLength={60} placeholder="مثلاً تخفیف ویژه برنامه جدید" className="mt-2 border-white/10 bg-black/25"/></label>
      <label className="text-sm text-zinc-300">متن اعلان<Textarea value={body} onChange={event=>setBody(event.target.value)} maxLength={240} placeholder="متن پیام را اینجا بنویس…" className="mt-2 min-h-24 border-white/10 bg-black/25"/></label>
      <div className="flex flex-wrap items-center justify-between gap-3"><p className={`text-xs ${error?"text-red-300":"text-emerald-300"}`} role="status">{message}</p><Button type="button" onClick={send} disabled={busy||title.trim().length<2||body.trim().length<3} className="bg-amber-500 hover:bg-amber-500">{busy?<LoaderCircle className="animate-spin"/>:<Send/>} ارسال برای همه شاگردها</Button></div>
    </div>
  </section>;
}
