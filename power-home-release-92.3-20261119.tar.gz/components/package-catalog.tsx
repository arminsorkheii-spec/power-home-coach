"use client";

import { createContext, useContext, useCallback, useEffect, useState, type ReactNode } from "react";
import { PACKAGES, packageById, type Package } from "@/lib/packages";

const InitialCatalog = createContext<readonly Package[]>(PACKAGES);

export function PackageCatalogProvider({packages,children}:{packages:readonly Package[];children:ReactNode}) {
  return <InitialCatalog.Provider value={packages}>{children}</InitialCatalog.Provider>;
}

export function usePackages(initialPackages?: readonly Package[]) {
  const inherited = useContext(InitialCatalog);
  const [packages, setPackages] = useState<Package[]>([...(initialPackages??inherited)]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const reload = useCallback(async () => {
    try {
      const response = await fetch("/api/packages", {cache:"no-store"});
      if (!response.ok) throw new Error();
      const data = await response.json() as {packages:Package[]};
      setPackages(data.packages); setError("");
    } catch { setError("دریافت قیمت‌های به‌روز انجام نشد؛ دوباره تلاش کنید."); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => {
    void reload();
    const refresh = () => { void reload(); };
    window.addEventListener("package-prices-updated", refresh);
    window.addEventListener("focus", refresh);
    return () => {
      window.removeEventListener("package-prices-updated", refresh);
      window.removeEventListener("focus", refresh);
    };
  }, [reload]);
  return {packages, packageById:(id:string)=>packageById(id,packages), loading, error, reload};
}
