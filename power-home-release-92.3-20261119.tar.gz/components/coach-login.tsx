"use client";

import { FormEvent, useState } from "react";
import { ArrowRight, Dumbbell, LoaderCircle, LockKeyhole } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export function CoachLogin() {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (!password || loading) return;
    setLoading(true); setError("");
    try {
      const response = await fetch("/api/auth/login", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ password }) });
      const result = (await response.json()) as { error?: string };
      if (!response.ok) { setError(result.error ?? "رمز درست نیست."); setPassword(""); return; }
      window.location.replace("/coach");
    } catch { setError("اتصال برقرار نشد؛ دوباره امتحان کنید."); }
    finally { setLoading(false); }
  };
  return <main className="portal-login-page" dir="rtl">
    <a href="/" className="portal-back"><ArrowRight /> بازگشت به صفحه اصلی</a>
    <form onSubmit={submit} className="portal-login-card">
      <div className="portal-login-icon"><Dumbbell /></div>
      <p>ARMIN SORKHEI</p><h1>ورود پنل مربی</h1><span>مدیریت شاگردها، برنامه‌ها و سوابق</span>
      <label htmlFor="coach-login-password">رمز اختصاصی مربی</label>
      <Input id="coach-login-password" type="password" autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} autoFocus className="h-12 text-base" />
      <div className="min-h-6 text-center text-xs text-amber-300" role="alert">{error}</div>
      <Button type="submit" disabled={!password || loading} className="h-12 w-full rounded-xl bg-amber-500 text-base hover:bg-amber-500">{loading ? <LoaderCircle className="animate-spin" /> : <LockKeyhole />} ورود به مدیریت</Button>
    </form>
  </main>;
}
