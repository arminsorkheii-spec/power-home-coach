"use client";

import { useState } from "react";
import { Save, LoaderCircle, RefreshCw } from "lucide-react";
import { usePackages } from "@/components/package-catalog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { formatPrice } from "@/lib/packages";

const normalize = (value:string) => value.replace(/[۰-۹]/g,d=>String("۰۱۲۳۴۵۶۷۸۹".indexOf(d))).replace(/[٠-٩]/g,d=>String("٠١٢٣٤٥٦٧٨٩".indexOf(d))).replace(/[,٬\s]/g,"");

export function CoachPricing() {
  const {packages,loading,error,reload} = usePackages();
  const [draft,setDraft] = useState<Record<string,string>>({});
  const [busy,setBusy] = useState(false);
  const [message,setMessage] = useState("");
  const save = async () => {
    setMessage("");
    const prices = packages.map(item=>({id:item.id,price:Number(normalize(draft[item.id]??String(item.price)))}));
    if (packages.some(item=>normalize(draft[item.id]??String(item.price))==="") || prices.some(item=>!Number.isInteger(item.price)||item.price<0||item.price>2_000_000_000)) {
      setMessage("برای هر پکیج یک مبلغ صحیح بین صفر تا دو میلیارد تومان وارد کنید."); return;
    }
    setBusy(true);
    try {
      const response = await fetch("/api/packages",{method:"PUT",headers:{"content-type":"application/json"},body:JSON.stringify({prices})});
      const data = await response.json() as {error?:string};
      if (!response.ok) throw new Error(data.error??"ذخیره قیمت‌ها انجام نشد.");
      await reload(); setDraft({});
      window.dispatchEvent(new Event("package-prices-updated"));
      setMessage("قیمت‌ها ذخیره شدند و برای ثبت‌نام و درخواست‌های جدید اعمال می‌شوند.");
    } catch (e) { setMessage(e instanceof Error?e.message:"ذخیره قیمت‌ها انجام نشد."); }
    finally { setBusy(false); }
  };
  return <section className="coach-pricing" dir="rtl">
    <h1>مدیریت قیمت پکیج‌ها و برنامه‌ها</h1>
    <p>مبلغ‌ها به تومان هستند. تغییر قیمت، مبلغ درخواست‌های قبلی و سوابق پرداخت را تغییر نمی‌دهد.</p>
    {error&&<div role="alert">{error} <Button variant="outline" onClick={()=>void reload()}><RefreshCw/> تلاش دوباره</Button></div>}
    <div className="coach-pricing-grid">{packages.map(item=><label key={item.id} className="coach-price-field">
      <strong>{item.name}</strong><span>قیمت (تومان)</span>
      <Input inputMode="numeric" dir="ltr" disabled={loading||busy||Boolean(error)} value={draft[item.id]??String(item.price)} onChange={e=>setDraft(current=>({...current,[item.id]:e.target.value}))}/>
      <small>{formatPrice(item.price)}</small>
    </label>)}</div>
    <Button onClick={()=>void save()} disabled={loading||busy||Boolean(error)}>{loading||busy?<LoaderCircle className="animate-spin"/>:<Save/>} ذخیره قیمت‌ها</Button>
    {message&&<p role="status">{message}</p>}
  </section>;
}
