"use client";

import { useEffect, useState } from "react";
import { Camera, ChevronLeft, ExternalLink, FileText, Folder, FolderOpen, RefreshCw } from "lucide-react";
import { PhotoGallery } from "@/components/photo-gallery";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { APPLICATION_STATUSES, formatPrice } from "@/lib/packages";

type IntakeUpload = {
  id: string;
  kind: string;
  filename: string;
  size: number;
  created_at: string;
};

type IntakeApplication = {
  id: string;
  client_id: string;
  phone: string;
  package_name: string;
  status: string;
  price_amount: number | null;
  created_at: string;
  updated_at: string;
  profile: Record<string, string>;
  uploads: IntakeUpload[];
};

const POSE_NAMES: Record<string, string> = {
  front: "روبه‌رو",
  side: "بغل",
  back: "پشت",
  front_double: "جفت بازو از جلو",
  back_double: "جفت بازو از پشت",
};

const PROFILE_FIELDS: Array<[string, string, string?]> = [
  ["age", "سن", "سال"],
  ["gender", "جنسیت"],
  ["height", "قد شروع", "سانتی‌متر"],
  ["weight", "وزن شروع", "کیلوگرم"],
  ["waist", "دور کمر شروع", "سانتی‌متر"],
  ["goal", "هدف"],
  ["experience", "سابقه تمرین"],
  ["trainingDays", "تعداد روز تمرین"],
  ["injuries", "آسیب یا محدودیت"],
  ["diseases", "سابقه بیماری"],
  ["medications", "داروهای مصرفی"],
  ["allergies", "حساسیت‌ها"],
  ["supplements", "مکمل‌های مصرفی"],
  ["sleep", "خواب"],
  ["activity", "فعالیت روزانه"],
  ["notes", "توضیحات شاگرد"],
];

const formatDate = (value: string) => {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "—" : date.toLocaleString("fa-IR", { dateStyle: "medium", timeStyle: "short" });
};

export function ClientIntakeHistory({ clientId, embedded = false, programNumber = 1 }: { clientId: string; embedded?: boolean; programNumber?: number }) {
  const [application, setApplication] = useState<IntakeApplication | null>(null);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = async () => {
    setLoading(true);
    setError("");
    try {
      const response = await fetch(`/api/client-intake?clientId=${encodeURIComponent(clientId)}`, { cache: "no-store" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "دریافت سابقه ثبت‌نام انجام نشد.");
      setApplication(data.applications?.[programNumber - 1] ?? null);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "دریافت سابقه ثبت‌نام انجام نشد.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, [clientId, programNumber]);

  if (loading) return <section className="mb-5 animate-pulse rounded-2xl border border-white/8 bg-card p-5"><div className="h-5 w-44 rounded bg-white/10"/><div className="mt-4 h-24 rounded-xl bg-white/5"/></section>;
  if (error) return <section className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-amber-500/25 bg-amber-500/5 p-4"><p className="text-sm text-red-300">{error}</p><Button variant="outline" size="sm" onClick={load}><RefreshCw/> تلاش دوباره</Button></section>;
  if (!application) return <section className="mb-5 rounded-2xl border border-dashed border-white/10 p-4 text-sm text-zinc-500">برای برنامه شماره {programNumber.toLocaleString("fa-IR")} عکس یا ثبت‌نام آنلاین جداگانه‌ای وجود ندارد.</section>;

  const fields = PROFILE_FIELDS.map(([key, label, unit]) => ({ key, label, unit, value: application.profile[key]?.trim() })).filter((field) => field.value);
  const bodyPhotos = application.uploads.filter((upload) => POSE_NAMES[upload.kind]);
  const documents = application.uploads.filter((upload) => !POSE_NAMES[upload.kind]);

  if (embedded) return <section className="overflow-hidden rounded-2xl border border-white/10 bg-black/10" dir="rtl">
    <div className="border-b border-white/8 p-4"><h3 className="font-bold text-white">اطلاعات و عکس‌های شروع این برنامه</h3><p className="mt-1 text-sm text-zinc-500">{formatDate(application.created_at)}</p></div>
    <div className="space-y-6 p-4 sm:p-5">
      <div className="grid gap-3 sm:grid-cols-3">
        <div className="rounded-2xl border border-white/8 bg-white/[.025] p-4"><p className="text-sm text-zinc-500">پکیج درخواستی</p><p className="mt-2 font-bold text-white">{application.package_name}</p></div>
        <div className="rounded-2xl border border-white/8 bg-white/[.025] p-4"><p className="text-sm text-zinc-500">هزینه ثبت‌شده</p><p className="mt-2 font-bold text-white">{formatPrice(application.price_amount)}</p></div>
        <div className="rounded-2xl border border-white/8 bg-white/[.025] p-4"><p className="text-sm text-zinc-500">موبایل</p><p className="mt-2 font-bold text-white" dir="ltr">{application.phone}</p></div>
      </div>
      {fields.length > 0 && <div><h3 className="mb-3 font-bold text-white">مشخصات ثبت‌شده توسط شاگرد</h3><dl className="grid gap-2 sm:grid-cols-2">{fields.map((field) => <div key={field.key} className="rounded-xl border border-white/7 bg-black/15 p-3"><dt className="text-sm text-zinc-500">{field.label}</dt><dd className="mt-1 whitespace-pre-wrap text-sm leading-7 text-zinc-200">{field.value}{field.unit ? ` ${field.unit}` : ""}</dd></div>)}</dl></div>}
      <div><div className="mb-3 flex items-center gap-2"><Camera className="size-5 text-amber-400"/><h3 className="font-bold text-white">عکس‌های شروع بدن</h3><span className="text-sm text-zinc-500">({bodyPhotos.length.toLocaleString("fa-IR")} عکس)</span></div>{bodyPhotos.length ? <PhotoGallery images={bodyPhotos.map((upload) => ({ src: `/api/application-files/${upload.id}`, label: POSE_NAMES[upload.kind], caption: `برنامه شماره ${programNumber.toLocaleString("fa-IR")} · ${new Date(application.created_at).toLocaleDateString("fa-IR")}` }))}/> : <p className="rounded-xl border border-dashed border-white/10 p-4 text-sm text-zinc-500">عکس شروعی در ثبت‌نام ذخیره نشده است.</p>}</div>
      {documents.length > 0 && <div><h3 className="mb-3 font-bold text-white">مدارک ثبت‌نام</h3><div className="flex flex-wrap gap-2">{documents.map((upload) => <a key={upload.id} href={`/api/application-files/${upload.id}`} target="_blank" rel="noreferrer" className="inline-flex min-h-11 items-center gap-2 rounded-xl border border-white/10 px-3 text-sm text-zinc-200 transition hover:border-amber-500/40 hover:text-white"><FileText className="size-4 text-amber-400"/>{upload.kind === "lab" ? "آزمایش" : upload.kind === "receipt" ? "رسید پرداخت" : upload.filename}<ExternalLink className="size-4 text-zinc-500"/></a>)}</div></div>}
    </div>
  </section>;

  return <section className="mb-5 overflow-hidden rounded-[28px] border border-white/10 bg-card" dir="rtl">
    <button type="button" aria-expanded={open} onClick={()=>setOpen(value=>!value)} className={`flex w-full items-center gap-3 p-5 text-right transition sm:p-6 ${open?"border-b border-amber-500/20 bg-amber-500/[.05]":"hover:bg-white/[.025]"}`}>
      <div className={`grid size-11 shrink-0 place-items-center rounded-2xl ${open?"bg-amber-500 text-white":"bg-amber-500/15 text-amber-400"}`}>{open?<FolderOpen className="size-5"/>:<Folder className="size-5"/>}</div>
      <div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><h2 className="text-lg font-black text-white">پرونده ثبت‌نام اولیه</h2><Badge className="bg-amber-500 text-white">اطلاعات شروع</Badge></div><p className="mt-1 text-sm text-zinc-500">مشخصات، عکس‌های شروع و مدارک · {formatDate(application.created_at)}</p></div>
      <Badge variant="outline" className="hidden border-white/10 text-zinc-300 sm:inline-flex">{APPLICATION_STATUSES[application.status] ?? application.status}</Badge>
      <ChevronLeft className={`size-5 shrink-0 text-zinc-600 transition ${open?"-rotate-90 text-amber-400":""}`}/>
    </button>

    {open&&<div className="space-y-6 p-5 sm:p-6">
      <div className="grid gap-3 sm:grid-cols-3">
        <div className="rounded-2xl border border-white/8 bg-white/[.025] p-4"><p className="text-sm text-zinc-500">پکیج درخواستی</p><p className="mt-2 font-bold text-white">{application.package_name}</p></div>
        <div className="rounded-2xl border border-white/8 bg-white/[.025] p-4"><p className="text-sm text-zinc-500">هزینه ثبت‌شده</p><p className="mt-2 font-bold text-white">{formatPrice(application.price_amount)}</p></div>
        <div className="rounded-2xl border border-white/8 bg-white/[.025] p-4"><p className="text-sm text-zinc-500">موبایل</p><p className="mt-2 font-bold text-white" dir="ltr">{application.phone}</p></div>
      </div>

      {fields.length > 0 && <div><h3 className="mb-3 font-bold text-white">مشخصات ثبت‌شده توسط شاگرد</h3><dl className="grid gap-2 sm:grid-cols-2">{fields.map((field) => <div key={field.key} className="rounded-xl border border-white/7 bg-black/15 p-3"><dt className="text-sm text-zinc-500">{field.label}</dt><dd className="mt-1 whitespace-pre-wrap text-sm leading-7 text-zinc-200">{field.value}{field.unit ? ` ${field.unit}` : ""}</dd></div>)}</dl></div>}

      <div>
        <div className="mb-3 flex items-center gap-2"><Camera className="size-5 text-amber-400"/><h3 className="font-bold text-white">عکس‌های شروع بدن</h3><span className="text-sm text-zinc-500">({bodyPhotos.length.toLocaleString("fa-IR")} عکس)</span></div>
        {bodyPhotos.length ? <PhotoGallery images={bodyPhotos.map((upload) => ({ src: `/api/application-files/${upload.id}`, label: POSE_NAMES[upload.kind], caption: `ارزیابی اولیه · ${new Date(application.created_at).toLocaleDateString("fa-IR")}` }))}/> : <p className="rounded-xl border border-dashed border-white/10 p-4 text-sm text-zinc-500">عکس شروعی در ثبت‌نام ذخیره نشده است.</p>}
      </div>

      {documents.length > 0 && <div><h3 className="mb-3 font-bold text-white">مدارک ثبت‌نام</h3><div className="flex flex-wrap gap-2">{documents.map((upload) => <a key={upload.id} href={`/api/application-files/${upload.id}`} target="_blank" rel="noreferrer" className="inline-flex min-h-11 items-center gap-2 rounded-xl border border-white/10 px-3 text-sm text-zinc-200 transition hover:border-amber-500/40 hover:text-white"><FileText className="size-4 text-amber-400"/>{upload.kind === "lab" ? "آزمایش" : upload.kind === "receipt" ? "رسید پرداخت" : upload.filename}<ExternalLink className="size-4 text-zinc-500"/></a>)}</div></div>}
    </div>}
  </section>;
}
