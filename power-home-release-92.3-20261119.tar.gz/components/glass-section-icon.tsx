import {
  BellRing,
  CircleDollarSign,
  Dumbbell,
  FileText,
  MessageCircle,
  Pill,
  Syringe,
  Utensils,
} from "lucide-react";
import type { GraphicSectionIconName } from "@/components/graphic-section-icon";

const iconMap = {
  training: Dumbbell,
  nutrition: Utensils,
  supplements: Pill,
  medications: Syringe,
  messages: MessageCircle,
  billing: CircleDollarSign,
  notifications: BellRing,
  pdf: FileText,
} satisfies Record<GraphicSectionIconName, typeof Dumbbell>;

export function GlassSectionIcon({
  name,
  size = 42,
  className = "",
}: {
  name: GraphicSectionIconName;
  size?: number;
  className?: string;
}) {
  const Icon = iconMap[name];
  return (
    <span
      className={`glass-section-icon ${className}`}
      style={{ width: size, height: size }}
      aria-hidden="true"
    >
      <Icon />
    </span>
  );
}
