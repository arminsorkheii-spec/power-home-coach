"use client";

import { type ChangeEvent, type ReactNode, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, LoaderCircle, Minus, Plus, Upload } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export type GalleryImage = { src: string; label: string; caption?: string; key?: string };

export function PhotoGallery({ images, onReplace, trigger }: {
  images: GalleryImage[];
  onReplace?: (image: GalleryImage, file: File) => Promise<void> | void;
  trigger?: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const [index, setIndex] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [replacing, setReplacing] = useState(false);
  const touch = useRef(0);

  if (!images.length) return null;

  const show = (next: number) => {
    setIndex((next + images.length) % images.length);
    setZoom(1);
  };

  const replace = async (event: ChangeEvent<HTMLInputElement>) => {
    const input = event.currentTarget;
    const file = input.files?.[0];
    if (!file || !onReplace) return;
    setReplacing(true);
    try {
      await onReplace(images[index], file);
    } finally {
      setReplacing(false);
      input.value = "";
    }
  };

  return <>
    {trigger ? <button type="button" className="photo-gallery-trigger" onClick={() => { setIndex(0); setZoom(1); setOpen(true); }}>{trigger}</button> : <div className="body-photo-grid">
      {images.map((image, imageIndex) => <button type="button" key={`${image.src}-${imageIndex}`} onClick={() => { setIndex(imageIndex); setZoom(1); setOpen(true); }}>
        <img src={image.src} alt={image.label} />
        <span>{image.label}</span>
        {image.caption && <small>{image.caption}</small>}
      </button>)}
    </div>}
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent dir="rtl" className="photo-lightbox max-w-5xl">
        <DialogHeader>
          <DialogTitle>{images[index]?.label}</DialogTitle>
          <DialogDescription>{images[index]?.caption || `${(index + 1).toLocaleString("fa-IR")} از ${images.length.toLocaleString("fa-IR")}`}</DialogDescription>
        </DialogHeader>
        <div className="photo-stage" onTouchStart={(event) => { touch.current = event.changedTouches[0].clientX; }} onTouchEnd={(event) => { const delta = event.changedTouches[0].clientX - touch.current; if (Math.abs(delta) > 45) show(index + (delta < 0 ? 1 : -1)); }}>
          <img src={images[index]?.src} alt={images[index]?.label} style={{ transform: `scale(${zoom})` }} onDoubleClick={() => setZoom(zoom === 1 ? 2 : 1)} />
          {images.length > 1 && <>
            <button className="photo-prev" type="button" onClick={() => show(index - 1)} aria-label="عکس قبلی"><ChevronRight /></button>
            <button className="photo-next" type="button" onClick={() => show(index + 1)} aria-label="عکس بعدی"><ChevronLeft /></button>
          </>}
        </div>
        <div className="photo-tools">
          <button type="button" onClick={() => setZoom(Math.max(1, zoom - .5))}><Minus /> کوچک‌نمایی</button>
          <span>{Math.round(zoom * 100).toLocaleString("fa-IR")}٪</span>
          <button type="button" onClick={() => setZoom(Math.min(3, zoom + .5))}><Plus /> بزرگ‌نمایی</button>
          {onReplace && <label className="photo-replace">
            <input type="file" accept="image/*" disabled={replacing} onChange={replace} />
            <span>{replacing ? <LoaderCircle className="animate-spin" /> : <Upload />} تعویض عکس</span>
          </label>}
        </div>
      </DialogContent>
    </Dialog>
  </>;
}
