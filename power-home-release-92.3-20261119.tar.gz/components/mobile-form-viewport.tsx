"use client";

import { useEffect } from "react";

// Keep layout height stable while the keyboard changes the visual viewport.
// Native scrolling remains available to reach inputs above the keyboard.
export function MobileFormViewport() {
  useEffect(() => {
    const root = document.documentElement;
    // Dialogs follow the visible screen when the keyboard opens or the phone rotates.
    const viewport = window.visualViewport;
    let frame = 0;
    const updateViewport = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        root.style.setProperty("--overlay-viewport-height", `${viewport?.height ?? window.innerHeight}px`);
        root.style.setProperty("--overlay-viewport-width", `${viewport?.width ?? window.innerWidth}px`);
        root.style.setProperty("--overlay-viewport-top", `${viewport?.offsetTop ?? 0}px`);
        root.style.setProperty("--overlay-viewport-left", `${viewport?.offsetLeft ?? 0}px`);
      });
    };
    updateViewport();
    viewport?.addEventListener("resize", updateViewport);
    viewport?.addEventListener("scroll", updateViewport);
    window.addEventListener("resize", updateViewport);
    const editable = (element: Element | null) => element?.matches("input:not([type=checkbox]):not([type=radio]):not([type=file]), textarea, select, [contenteditable=true]");
    const focus = () => {
      if (!matchMedia("(max-width: 1024px)").matches || !editable(document.activeElement)) return;
      if (!root.classList.contains("form-keyboard-open")) {
        root.style.setProperty("--form-layout-height", `${window.innerHeight}px`);
        root.classList.add("form-keyboard-open");
      }
    };
    let timer: ReturnType<typeof setTimeout>;
    const blur = () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        if (editable(document.activeElement)) return;
        root.classList.remove("form-keyboard-open");
        root.style.removeProperty("--form-layout-height");
      }, 200);
    };
    document.addEventListener("focusin", focus);
    document.addEventListener("focusout", blur);
    return () => {
      clearTimeout(timer);
      cancelAnimationFrame(frame);
      viewport?.removeEventListener("resize", updateViewport);
      viewport?.removeEventListener("scroll", updateViewport);
      window.removeEventListener("resize", updateViewport);
      for (const property of ["height", "width", "top", "left"]) root.style.removeProperty(`--overlay-viewport-${property}`);
      document.removeEventListener("focusin", focus);
      document.removeEventListener("focusout", blur);
      root.classList.remove("form-keyboard-open");
      root.style.removeProperty("--form-layout-height");
    };
  }, []);
  return null;
}
