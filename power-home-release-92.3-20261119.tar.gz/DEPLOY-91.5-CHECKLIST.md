# Power Home Coach — Release 91.5 deployment checklist

## Policy
This package is a staging candidate only. It has **not been deployed**. It deliberately contains no production `.env`, `data`, database, or student uploads. The live site is the source of truth for all production data.

## Verified in isolated environment
- Base archive SHA256 matched the reference file.
- 5 isolated Release 91.5 regression tests passed.
- TypeScript parser checked 151 TS/TSX files with no syntax errors.
- On 2026-10-12, networked `npm ci` succeeded (709 packages); production Next.js build and TypeScript passed; `npm test` passed all 20 tests. Tests now use the current Next.js output and isolated native SQLite/file storage rather than obsolete Cloudflare mocks. Real iPhone/PWA and production-account smoke checks remain required.

## Safe handoff to an operator with authorized IranServer access
1. Verify the candidate package SHA256 and extract to a NEW staging directory, not into `/opt/power-home-coach` directly.
2. Back up the current production source, `/opt/power-home-coach/data` (database and student uploads), and `.env` to separate timestamped storage. Confirm backups can be read and restored.
3. In staging, run `npm ci`, `npx tsc --noEmit`, `npm run build`, and `npm test`; stop on the first failure. The test script itself runs a build.
4. Take a copy of the production database and validate that legacy account sign-in, new registrations, renewal orders, active-request duplicate protection, receipt upload, payment statuses, and student program histories behave correctly. Ensure no migration removes any data.
5. On desktop and iPhone Safari/PWA, validate glass icons, the wrapping of all dashboard/navigation labels at 320/375/390/430/768/1024px widths, safe areas, registration input focus and form styles, and no yellow UI controls. Verify PDF downloads and chat.
6. Only after passing all tests, apply code-only changes with the deployment's existing process; **never overwrite production `data` or `.env`**. Rebuild/restart the Next.js app and Caddy per the existing Compose setup.
7. Run smoke tests against `arminsorkhei.ir` with a regular coach account and a legacy student. Check old programs, photos, uploads, billing, new package selection, chat, and notifications. If tests fail, roll back CODE ONLY from the backup while preserving current live data.

## Scope
- Student renewal CTA visible irrespective of prior online application record; pending requests are respected.
- All dashboard modules and navigation iconography: photo/glass style and non-overlapping labels.
- Registration/coach/student/public design surfaces: white/black/graphite palette with glass effects and no gold theme.
- Existing sign-in methods and student/accounting data preserved by the code-only approach.
