import { type ProgramExercise } from "@/lib/coach-data";

export type ExerciseUnit = {
  id: string;
  type: "single" | "superset";
  items: ProgramExercise[];
};

export function groupExerciseRows(rows: ProgramExercise[]): ExerciseUnit[] {
  const visited = new Set<string>();
  const units: ExerciseUnit[] = [];

  for (const row of rows) {
    if (!row.supersetId) {
      units.push({ id: row.rowId, type: "single", items: [row] });
      continue;
    }

    if (visited.has(row.supersetId)) continue;
    visited.add(row.supersetId);
    const grouped = rows.filter((candidate) => candidate.supersetId === row.supersetId);

    if (grouped.length < 2) {
      units.push({ id: row.rowId, type: "single", items: [row] });
      continue;
    }

    units.push({ id: row.supersetId, type: "superset", items: grouped });
  }

  return units;
}

export function normalizeLegacySupersets(rows: ProgramExercise[]): ProgramExercise[] {
  const normalized = rows.map((row) => ({ ...row }));
  const validGroupIds = new Set(
    normalized
      .map((row) => row.supersetId)
      .filter((id): id is string => Boolean(id))
      .filter((id) => normalized.filter((row) => row.supersetId === id).length >= 2),
  );

  for (const row of normalized) {
    if (row.supersetId && !validGroupIds.has(row.supersetId)) delete row.supersetId;
  }

  for (let index = 0; index < normalized.length; index += 1) {
    const row = normalized[index];
    if (row.technique !== "سوپرست" || row.supersetId) continue;

    const nextIndex = index + 1 < normalized.length ? index + 1 : index - 1;
    const partner = normalized[nextIndex];
    if (!partner || partner.supersetId) continue;

    const supersetId = `superset-${row.rowId}`;
    row.supersetId = supersetId;
    partner.supersetId = supersetId;
    partner.technique = "سوپرست";
  }

  return normalized;
}

export function setTechniqueWithSuperset(
  rows: ProgramExercise[],
  rowId: string,
  technique: string,
  supersetId: string,
): ProgramExercise[] {
  const selectedIndex = rows.findIndex((row) => row.rowId === rowId);
  if (selectedIndex < 0) return rows;

  const partnerIndex =
    selectedIndex + 1 < rows.length ? selectedIndex + 1 : selectedIndex - 1;
  const idsToClear = new Set<string>();
  const selectedGroup = rows[selectedIndex].supersetId;
  if (selectedGroup) idsToClear.add(selectedGroup);

  if (technique === "سوپرست" && partnerIndex >= 0) {
    const partnerGroup = rows[partnerIndex].supersetId;
    if (partnerGroup) idsToClear.add(partnerGroup);
  }

  const updated = rows.map((row) => {
    if (!row.supersetId || !idsToClear.has(row.supersetId)) return { ...row };
    return {
      ...row,
      technique: row.technique === "سوپرست" ? "عادی" : row.technique,
      supersetId: undefined,
    };
  });

  if (technique !== "سوپرست" || partnerIndex < 0) {
    updated[selectedIndex] = {
      ...updated[selectedIndex],
      technique,
      supersetId: undefined,
    };
    return updated;
  }

  updated[selectedIndex] = {
    ...updated[selectedIndex],
    technique: "سوپرست",
    supersetId,
  };
  updated[partnerIndex] = {
    ...updated[partnerIndex],
    technique: "سوپرست",
    supersetId,
  };
  return updated;
}
