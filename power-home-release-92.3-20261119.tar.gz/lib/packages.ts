export const PACKAGES = [
  { id: "natural", name: "پکیج نچرال", price: 1_790_000, requiresLabs: false },
  { id: "professional", name: "پکیج VIP", price: 4_000_000, requiresLabs: true },
  { id: "training", name: "برنامه تمرینی", price: 800_000, requiresLabs: false },
  { id: "nutrition", name: "برنامه غذایی", price: 800_000, requiresLabs: false },
  { id: "supplements", name: "برنامه مکمل", price: 800_000, requiresLabs: false },
  { id: "pct", name: "پاک‌سازی (PCT)", price: 1_500_000, requiresLabs: true },
  { id: "cycle", name: "سایکل دارویی", price: 1_500_000, requiresLabs: true },
] as const;

export type PackageId = (typeof PACKAGES)[number]["id"];
export type Package = { id: PackageId; name: string; price: number; requiresLabs: boolean };
export const packageById = (id: string, catalog: readonly Package[] = PACKAGES) => catalog.find((item) => item.id === id);
export function formatPrice(price: number | null) {
  return price === null ? "پس از بررسی آزمایش‌ها" : `${price.toLocaleString("fa-IR")} تومان`;
}

export const APPLICATION_STATUSES: Record<string, string> = {
  draft: "تکمیل اطلاعات",
  awaiting_payment: "در انتظار پرداخت",
  payment_review: "بررسی پرداخت",
  payment_approved: "پرداخت تأیید شد",
  writing: "در حال نوشتن برنامه",
  ready: "در حال نوشتن برنامه",
  delivered: "ارسال شده",
};
