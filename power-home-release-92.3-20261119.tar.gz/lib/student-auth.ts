import { database } from "@/lib/raw-db";

export const STUDENT_SESSION_COOKIE = "armin_student_session";
const SESSION_AGE_SECONDS = 60 * 60 * 24 * 30;

function runtimeEnv() {
  return process.env;
}

function toHex(value: ArrayBuffer) {
  return Array.from(new Uint8Array(value)).map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

export function safeEqual(left: string, right: string) {
  if (left.length !== right.length) return false;
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) difference |= left.charCodeAt(index) ^ right.charCodeAt(index);
  return difference === 0;
}

export function normalizePhone(value: string) {
  const latin = normalizeDigits(value);
  let phone = latin.replace(/\D/g, "");
  if (phone.startsWith("0098")) phone = `0${phone.slice(4)}`;
  if (phone.startsWith("98")) phone = `0${phone.slice(2)}`;
  return phone;
}

export function normalizeDigits(value: string) {
  return value.replace(/[۰-۹]/g, (digit) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(digit))).replace(/[٠-٩]/g, (digit) => String("٠١٢٣٤٥٦٧٨٩".indexOf(digit)));
}

export async function deriveStudentPassword(password: string, salt: string) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  return toHex(await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: new TextEncoder().encode(salt), iterations: 100000 }, key, 256));
}

async function sign(value: string) {
  const secret = runtimeEnv().APP_SESSION_SECRET;
  if (!secret) return "";
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return toHex(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(value)));
}

export async function createStudentSession(clientId: string, revision: string) {
  const expiresAt = Math.floor(Date.now() / 1000) + SESSION_AGE_SECONDS;
  const payload = `${clientId}.${revision}.${expiresAt}`;
  return `${payload}.${await sign(payload)}`;
}

export async function verifyStudentSession(token?: string | null) {
  if (!token) return null;
  const [clientId, revision, expires, signature, extra] = token.split(".");
  if (extra || !clientId || !revision || !expires || !signature) return null;
  const expiresAt = Number(expires);
  if (!Number.isFinite(expiresAt) || expiresAt <= Math.floor(Date.now() / 1000)) return null;
  const expected = await sign(`${clientId}.${revision}.${expires}`);
  if (!expected || !safeEqual(signature, expected)) return null;
  const account = await database().prepare("SELECT revision FROM student_accounts WHERE client_id = ?").bind(clientId).first<{ revision: string }>();
  if (account?.revision === revision) return clientId;
  // Coach-issued links have an independent session revision; revocation affects only
  // link logins and never invalidates normal phone/password sessions.
  const link=await database().prepare("SELECT session_revision,expires_at FROM student_magic_links WHERE client_id=?")
    .bind(clientId).first<{session_revision:string;expires_at:string}>();
  return link?.session_revision === revision && new Date(link.expires_at).getTime()>Date.now() ? clientId : null;
}

function cookieValue(cookieHeader: string | null, name: string) {
  if (!cookieHeader) return null;
  for (const part of cookieHeader.split(";")) {
    const [cookieName, ...rest] = part.trim().split("=");
    if (cookieName === name) return rest.join("=");
  }
  return null;
}

export async function studentIdFromRequest(request: Request) {
  return verifyStudentSession(cookieValue(request.headers.get("cookie"), STUDENT_SESSION_COOKIE));
}

export function studentSessionCookie(token: string) {
  return `${STUDENT_SESSION_COOKIE}=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${SESSION_AGE_SECONDS}`;
}

export function clearedStudentCookie() {
  return `${STUDENT_SESSION_COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`;
}
