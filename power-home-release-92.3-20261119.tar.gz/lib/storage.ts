import { createHash } from "node:crypto";
import { mkdir, readFile, rm, writeFile } from "node:fs/promises";
import path from "node:path";

type PutOptions = {
  httpMetadata?: { contentType?: string };
  customMetadata?: Record<string, string>;
};

function storageRoot() {
  return path.join(process.env.APP_DATA_DIR ?? "/data", "uploads");
}

function safePath(key: string) {
  if (!/^(?:exercise-images\/[0-9a-f-]+(?:\.(?:jpg|png|webp))?|body-photos\/[0-9a-f-]+|student-applications\/[0-9a-z-]+\/[0-9a-f-]+\/[0-9a-f-]+)$/i.test(key)) {
    throw new Error("مسیر تصویر معتبر نیست.");
  }
  return path.join(storageRoot(), key);
}

async function contentType(filePath: string) {
  try {
    const metadata = JSON.parse(await readFile(`${filePath}.json`, "utf8")) as PutOptions;
    return metadata.httpMetadata?.contentType ?? "application/octet-stream";
  } catch {
    return "application/octet-stream";
  }
}

const bucket = {
  async put(key: string, value: ArrayBuffer | ArrayBufferView, options: PutOptions = {}) {
    const filePath = safePath(key);
    await mkdir(path.dirname(filePath), { recursive: true });
    const bytes = value instanceof ArrayBuffer
      ? new Uint8Array(value)
      : new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
    await writeFile(filePath, bytes, { mode: 0o600 });
    await writeFile(`${filePath}.json`, JSON.stringify(options), { mode: 0o600 });
  },
  async get(key: string) {
    const filePath = safePath(key);
    try {
      const body = await readFile(filePath);
      const type = await contentType(filePath);
      const etag = createHash("sha256").update(body).digest("hex");
      return {
        body,
        httpEtag: etag,
        httpMetadata: { contentType: type },
        writeHttpMetadata(headers: Headers) {
          headers.set("content-type", type);
        },
      };
    } catch {
      return null;
    }
  },
  async delete(key: string) {
    const filePath = safePath(key);
    await Promise.all([
      rm(filePath, { force: true }),
      rm(`${filePath}.json`, { force: true }),
    ]);
  },
};

export function getExerciseBucket() {
  return bucket;
}
