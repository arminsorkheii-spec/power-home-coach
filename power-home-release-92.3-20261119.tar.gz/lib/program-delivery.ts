import { createHash } from "node:crypto";
export const programDigest = (plan:unknown) => createHash("sha256").update(JSON.stringify(plan)).digest("hex");
