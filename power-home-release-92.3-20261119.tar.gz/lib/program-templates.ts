import type { ClientPlan, ProgramExercise, WorkoutDay } from "@/lib/coach-data";

export type ProgramTemplateKind =
  | "split-4"
  | "single-5"
  | "beginner-fullbody"
  | "mass"
  | "cut"
  | "back-friendly"
  | "beginner-4"
  | "beginner-5"
  | "professional-4"
  | "professional-5"
  | "custom";

export type ProgramTemplate = {
  id: string;
  number: number;
  title: string;
  kind: ProgramTemplateKind;
  daysPerWeek: number;
  description: string;
  plan: ClientPlan;
  custom?: boolean;
};

const chest = [
  "barbell-bench-press","incline-dumbbell-press","machine-chest-press","incline-barbell-press","dumbbell-bench-press",
  "plate-loaded-incline-chest-press","smith-flat-bench-press","smith-incline-press","neutral-grip-dumbbell-bench-press",
  "decline-dumbbell-press","plate-loaded-decline-chest-press","pec-deck","cable-crossover","incline-cable-fly",
  "incline-dumbbell-fly","dumbbell-fly","chest-dip","dumbbell-squeeze-press","standard-push-up","decline-push-up",
];
const back = [
  "pull-up","wide-grip-lat-pulldown","neutral-lat-pulldown","underhand-lat-pulldown","machine-high-row","t-bar-row",
  "seated-cable-row","one-arm-dumbbell-row","chest-supported-dumbbell-row","plate-loaded-chest-supported-row","barbell-row",
  "smith-machine-bent-over-row","single-arm-landmine-row","barbell-seal-row","seated-bench-single-arm-cable-lat-pulldown",
  "standing-side-single-arm-cable-lat-pulldown","tall-kneeling-single-arm-cable-lat-pulldown","straight-arm-cable-pulldown",
  "rope-straight-arm-pulldown","plate-loaded-pullover-machine","dumbbell-pullover","45-degree-back-extension",
];
const legs = [
  "barbell-squat","hack-squat","leg-press","pendulum-squat","plate-loaded-belt-squat","smith-machine-back-squat",
  "smith-machine-front-squat","front-squat","bulgarian-split-squat","smith-machine-bulgarian-split-squat","dumbbell-reverse-lunge",
  "dumbbell-lunge","single-leg-45-degree-leg-press","leg-extension","single-leg-leg-extension","romanian-deadlift",
  "smith-romanian-deadlift","lying-leg-curl","seated-leg-curl","standing-single-leg-curl-machine","glute-ham-raise",
  "assisted-nordic-hamstring-curl","barbell-hip-thrust","plate-loaded-hip-thrust-machine","seated-hip-adduction-machine",
  "seated-hip-abduction-machine","standing-calf-raise-machine","seated-calf-raise","leg-press-calf-raise","tibialis-raise",
];
const shoulders = [
  "dumbbell-shoulder-press","machine-shoulder-press","seated-smith-shoulder-press","standing-barbell-overhead-press","arnold-press",
  "half-kneeling-landmine-press","dumbbell-lateral-raise","seated-dumbbell-lateral-raise","single-arm-cable-lateral-raise",
  "crossed-cable-lateral-raise","seated-machine-lateral-raise","reverse-pec-deck","standing-cable-rear-delt-fly",
  "prone-incline-dumbbell-rear-delt-raise","machine-rear-delt-row","cable-face-pull","cable-upright-row","smith-machine-shrug",
];
const biceps = [
  "standing-ez-bar-curl","barbell-curl","dumbbell-curl","preacher-curl","machine-preacher-curl","incline-dumbbell-curl",
  "single-arm-bayesian-cable-curl","cable-curl","hammer-curl","cross-body-hammer-curl","incline-dumbbell-hammer-curl",
  "spider-dumbbell-curl","dumbbell-hammer-preacher-curl","double-high-cable-biceps-curl","barbell-drag-curl","reverse-ez-bar-curl",
];
const triceps = [
  "straight-bar-triceps-pushdown","rope-triceps-pushdown","overhead-rope-triceps-extension","overhead-dumbbell-triceps-extension",
  "seated-single-arm-overhead-dumbbell-triceps-extension","ez-bar-skullcrusher","smith-close-grip-bench-press","close-grip-bench-press",
  "seated-triceps-dip-machine","bench-triceps-dip","reverse-grip-triceps-pushdown","single-arm-cable-triceps-kickback",
  "one-arm-dumbbell-triceps-kickback","close-grip-push-up",
];
const core = ["dead-bug-legs","bird-dog","forearm-plank","kneeling-cable-crunch","pallof-press","reverse-crunch","hanging-knee-raise"];

// Conservative options for trainees with a history of lumbar-disc symptoms. These are not a medical prescription.
const backFriendlyChest = ["machine-chest-press","plate-loaded-incline-chest-press","pec-deck","cable-crossover","dumbbell-squeeze-press"];
const backFriendlyBack = ["neutral-lat-pulldown","wide-grip-lat-pulldown","plate-loaded-chest-supported-row","chest-supported-dumbbell-row","plate-loaded-pullover-machine","straight-arm-cable-pulldown"];
const backFriendlyLegs = ["leg-press","single-leg-45-degree-leg-press","leg-extension","single-leg-leg-extension","seated-leg-curl","lying-leg-curl","seated-hip-abduction-machine","standing-calf-raise-machine","seated-calf-raise"];
const backFriendlyShoulders = ["machine-shoulder-press","seated-machine-lateral-raise","single-arm-cable-lateral-raise","reverse-pec-deck","machine-rear-delt-row","cable-face-pull"];
const backFriendlyCore = ["bird-dog","dead-bug-legs","pallof-press","forearm-plank","kneeling-side-plank"];

function take(pool: string[], start: number, count: number, step = 3) {
  const target = Math.min(count, pool.length);
  const result: string[] = [];
  let cursor = start;
  let attempts = 0;
  const maxAttempts = Math.max(pool.length * 3, target * 4);
  while (result.length < target && attempts < maxAttempts) {
    const item = pool[((cursor % pool.length) + pool.length) % pool.length];
    if (!result.includes(item)) result.push(item);
    cursor += step;
    attempts += 1;
  }
  if (result.length < target) {
    for (let offset = 0; offset < pool.length && result.length < target; offset += 1) {
      const item = pool[((start + offset) % pool.length + pool.length) % pool.length];
      if (!result.includes(item)) result.push(item);
    }
  }
  return result;
}

const standardReps = [
  ["6–8","8–10","10–12","12–15"],
  ["8–10","10–12","10–12","12–15"],
  ["6–10","8–12","12–15","15–20"],
  ["8–12","8–12","10–15","12–15"],
];

function exerciseRow(
  templateNo: number,
  dayNo: number,
  index: number,
  exerciseId: string,
  mode: "standard" | "mass" | "cut" | "beginner" | "back-friendly" | "professional" = "standard",
  supersetId?: string,
): ProgramExercise {
  const scheme = standardReps[templateNo % standardReps.length];
  const accessory = index >= 3;
  let sets = index < 2 ? (templateNo % 4 === 0 ? "4" : "3") : "3";
  let reps = scheme[Math.min(index, 3)];
  let rest = index < 2 ? "۹۰–۱۲۰ ثانیه" : "۶۰–۹۰ ثانیه";
  let tempo = (templateNo + index) % 3 === 0 ? "۳-۱-۱" : "کنترل‌شده";
  let technique = "عادی";
  let notes = "";

  if (mode === "mass") {
    sets = index < 3 ? (templateNo % 2 === 0 ? "4" : "3") : "3";
    reps = index === 0 ? "6–8" : index < 3 ? "8–12" : "10–15";
    rest = index < 2 ? "۱۲۰–۱۵۰ ثانیه" : "۷۵–۹۰ ثانیه";
    if (accessory && (templateNo + index) % 4 === 0) technique = "رست‌پاز ست آخر";
    notes = index === 0 ? "۱–۲ تکرار در ذخیره؛ افزایش بار فقط با حفظ دامنه کامل." : "ست‌های مؤثر با ۱–۲ تکرار در ذخیره اجرا شود.";
  } else if (mode === "cut") {
    sets = index < 2 ? "3" : templateNo % 3 === 0 ? "3" : "2–3";
    reps = index < 2 ? "8–12" : "12–15";
    rest = supersetId ? "بعد از جفت: ۶۰–۷۵ ثانیه" : index < 2 ? "۷۵–۹۰ ثانیه" : "۴۵–۷۵ ثانیه";
    technique = supersetId ? "سوپرست" : (accessory && (templateNo + index) % 5 === 0 ? "دراپ‌ست سبک ست آخر" : "عادی");
    notes = "شدت وزنه حفظ شود؛ کاهش زمان استراحت نباید فرم را خراب کند.";
  } else if (mode === "beginner") {
    sets = templateNo % 3 === 0 ? "3" : "2–3";
    reps = index < 2 ? "8–12" : "10–15";
    rest = "۶۰–۹۰ ثانیه";
    tempo = "کنترل‌شده ۲-۱-۲";
    notes = "۲–۳ تکرار در ذخیره؛ اولویت با یادگیری فرم صحیح و پیشرفت تدریجی است.";
  } else if (mode === "professional") {
    sets = index < 2 ? "4" : "3";
    reps = index === 0 ? "6–8" : index < 3 ? "8–10" : "10–15";
    rest = supersetId ? "بعد از جفت: ۶۰–۷۵ ثانیه" : index < 2 ? "۱۲۰–۱۵۰ ثانیه" : "۶۰–۹۰ ثانیه";
    tempo = index === 1 ? "۴-۱-۱ (نگاتیو کنترل‌شده)" : "کنترل‌شده";
    technique = supersetId ? "سوپرست" : "عادی";
    notes = "برای ورزشکار پیشرفته؛ شدت تکنیک‌ها فقط با فرم کامل و بدون رسیدن اجباری به ناتوانی در همه ست‌ها.";
  } else if (mode === "back-friendly") {
    sets = index < 2 ? "3" : "2–3";
    reps = "10–15";
    rest = "۷۵–۹۰ ثانیه";
    tempo = "کنترل‌شده ۳-۱-۲";
    notes = "بدون درد تیرکشنده/بی‌حسی؛ ستون فقرات خنثی و دامنه بدون علامت. در فاز درد حاد اجرا نشود.";
  } else {
    const hardTechnique = accessory && (templateNo + index) % 5 === 0;
    technique = hardTechnique ? ((templateNo + index) % 2 ? "دراپ‌ست ست آخر" : "رست‌پاز ست آخر") : "عادی";
    notes = hardTechnique ? "تکنیک شدت فقط در ست آخر و با فرم صحیح اجرا شود." : "";
  }

  return {
    rowId: `tpl-${templateNo}-${dayNo}-${index + 1}`,
    exerciseId,
    sets,
    reps,
    rest,
    tempo,
    technique,
    notes,
    supersetId,
  };
}

function day(
  templateNo: number,
  dayNo: number,
  title: string,
  focus: string,
  ids: string[],
  mode: "standard" | "mass" | "cut" | "beginner" | "back-friendly" | "professional" = "standard",
  supersetFromIndex?: number,
): WorkoutDay {
  const supersetIds = new Map<number,string>();
  if (typeof supersetFromIndex === "number") {
    for (let i = supersetFromIndex; i + 1 < ids.length; i += 2) {
      const sid = `tpl-${templateNo}-day-${dayNo}-ss-${i}`;
      supersetIds.set(i, sid);
      supersetIds.set(i + 1, sid);
    }
  }
  return {
    id: `tpl-${templateNo}-day-${dayNo}`,
    title,
    focus,
    exercises: ids.map((id, index) => exerciseRow(templateNo, dayNo, index, id, mode, supersetIds.get(index))),
  };
}

function basePlan(title: string, days: WorkoutDay[]): ClientPlan {
  return {
    title,
    workoutDays: days,
    nutritionGoals: { calories: "", protein: "", carbs: "", fat: "" },
    nutritionMeals: [],
    supplementItems: [],
    medicationItems: [],
  };
}

function split4Template(index: number): ProgramTemplate {
  const number = index + 1;
  const variant = index % 4;
  const chestCount = variant === 0 ? 5 : 6;
  const backCount = variant === 1 ? 8 : 7;
  const days = [
    day(number, 1, "روز ۱ — سینه + جلو بازو", "سینه و جلو بازو", [...take(chest, index * 2, chestCount, 3 + variant), ...take(biceps, index * 3, 3, 2 + variant)]),
    day(number, 2, "روز ۲ — پا", "چهارسر، همسترینگ، باسن و ساق", take(legs, index * 5, 8, 3 + variant)),
    day(number, 3, "روز ۳ — زیربغل", "عرض و ضخامت پشت", take(back, index * 4, backCount, 3 + variant)),
    day(number, 4, "روز ۴ — سرشانه + پشت بازو", "سرشانه، پشت شانه و پشت بازو", [...take(shoulders, index * 3, 5, 3 + variant), ...take(triceps, index * 4, 3, 2 + variant)]),
  ];
  return { id:`builtin-${number}`, number, title:`اسپلیت ۴ روزه — مدل ${number}`, kind:"split-4", daysPerWeek:4, description:"سینه + جلو بازو / پا / زیربغل / سرشانه + پشت بازو", plan:basePlan("اسپلیت چهارروزه", days) };
}

function single5Template(index: number): ProgramTemplate {
  const number = 101 + index;
  const variant = index % 5;
  const days = [
    day(number, 1, "روز ۱ — سینه", "تمرکز کامل سینه", take(chest, index * 3, 7, 2 + variant)),
    day(number, 2, "روز ۲ — زیربغل", "عرض و ضخامت پشت", take(back, index * 4, 7, 3 + variant)),
    day(number, 3, "روز ۳ — پا", "چهارسر، همسترینگ، باسن و ساق", take(legs, index * 5, 8, 3 + variant)),
    day(number, 4, "روز ۴ — سرشانه", "سرشانه قدامی، میانی و خلفی", take(shoulders, index * 4, 7, 2 + variant)),
    day(number, 5, "روز ۵ — جلو بازو + پشت بازو", "بازو کامل", [...take(biceps, index * 3, 4, 2 + variant), ...take(triceps, index * 5, 4, 3 + variant)]),
  ];
  return { id:`builtin-${number}`, number, title:`تک‌عضله ۵ روزه — مدل ${index + 1}`, kind:"single-5", daysPerWeek:5, description:"سینه / زیربغل / پا / سرشانه / جلو بازو + پشت بازو", plan:basePlan("تک‌عضله پنج‌روزه", days) };
}

function beginnerFullbodyTemplate(index: number): ProgramTemplate {
  const number = 201 + index;
  const makeFull = (shift: number) => [
    take(legs, index + shift, 1, 5)[0],
    take(chest, index * 2 + shift, 1, 4)[0],
    take(back, index * 3 + shift, 1, 4)[0],
    take(shoulders, index + shift + 2, 1, 5)[0],
    take(biceps, index + shift + 1, 1, 3)[0],
    take(triceps, index + shift + 2, 1, 3)[0],
    take(core, index + shift, 1, 2)[0],
  ];
  const days = [
    day(number, 1, "فول‌بادی A", "کل بدن — آموزش تکنیک و کنترل", makeFull(0), "beginner"),
    day(number, 2, "فول‌بادی B", "کل بدن — حرکات ساده و قابل پیشرفت", makeFull(2), "beginner"),
    day(number, 3, "فول‌بادی C", "کل بدن — تثبیت فرم و افزایش تدریجی", makeFull(4), "beginner"),
  ];
  return { id:`builtin-${number}`, number, title:`فول‌بادی مبتدی — مدل ${index + 1}`, kind:"beginner-fullbody", daysPerWeek:3, description:"۳ جلسه فول‌بادی؛ حجم کنترل‌شده، RIR بالا و مناسب شروع تمرین", plan:basePlan("فول‌بادی مبتدی", days) };
}

function massTemplate(index: number): ProgramTemplate {
  const number = 231 + index;
  const fiveDay = index % 2 === 1;
  const variant = index % 5;
  const days = fiveDay ? [
    day(number,1,"روز ۱ — سینه + جلو بازو","هایپرتروفی سینه و جلو بازو",[...take(chest,index*3,6,3+variant),...take(biceps,index*2,3,2+variant)],"mass"),
    day(number,2,"روز ۲ — پا (چهارسر)","چهارسر و ساق",[...take(legs,index*5,6,3+variant),...take(["standing-calf-raise-machine","seated-calf-raise","leg-press-calf-raise"],index,2,1)],"mass"),
    day(number,3,"روز ۳ — زیربغل + پشت شانه","ضخامت، عرض و پشت شانه",[...take(back,index*4,7,3+variant),...take(["reverse-pec-deck","machine-rear-delt-row","cable-face-pull"],index,2,1)],"mass"),
    day(number,4,"روز ۴ — سرشانه + پشت بازو","سرشانه کامل و پشت بازو",[...take(shoulders,index*3,6,2+variant),...take(triceps,index*4,3,3+variant)],"mass"),
    day(number,5,"روز ۵ — همسترینگ + بازو","زنجیره خلفی و بازو",[...take(["seated-leg-curl","lying-leg-curl","romanian-deadlift","glute-ham-raise","assisted-nordic-hamstring-curl","plate-loaded-hip-thrust-machine"],index*2,5,2),...take(biceps,index*3,2,3),...take(triceps,index*3,2,2)],"mass"),
  ] : [
    day(number,1,"روز ۱ — سینه + جلو بازو","حجم سینه و جلو بازو",[...take(chest,index*3,6,3+variant),...take(biceps,index*2,4,2+variant)],"mass"),
    day(number,2,"روز ۲ — پا","چهارسر، همسترینگ، باسن و ساق",take(legs,index*5,9,3+variant),"mass"),
    day(number,3,"روز ۳ — زیربغل","عرض و ضخامت پشت",take(back,index*4,8,3+variant),"mass"),
    day(number,4,"روز ۴ — سرشانه + پشت بازو","سرشانه کامل و پشت بازو",[...take(shoulders,index*3,6,2+variant),...take(triceps,index*4,4,3+variant)],"mass"),
  ];
  return {id:`builtin-${number}`,number,title:`حجم عضلانی — مدل ${index+1}`,kind:"mass",daysPerWeek:days.length,description:`برنامه هایپرتروفی ${days.length} روزه؛ حجم مؤثر بالاتر، استراحت کافی و پیشرفت بار`,plan:basePlan("برنامه حجم عضلانی",days)};
}

function cutTemplate(index: number): ProgramTemplate {
  const number = 281 + index;
  const fiveDay = index % 2 === 0;
  const variant = index % 4;
  const days = fiveDay ? [
    day(number,1,"روز ۱ — سینه + جلو بازو","حفظ قدرت و چگالی تمرین",[...take(chest,index*3,5,3+variant),...take(biceps,index*2,3,2+variant)],"cut",3),
    day(number,2,"روز ۲ — پا","حفظ عضله پایین‌تنه",take(legs,index*4,7,3+variant),"cut",3),
    day(number,3,"روز ۳ — زیربغل","عرض و ضخامت پشت",take(back,index*4,6,3+variant),"cut",2),
    day(number,4,"روز ۴ — سرشانه + پشت بازو","سرشانه و پشت بازو با استراحت کوتاه",[...take(shoulders,index*3,5,2+variant),...take(triceps,index*3,3,2+variant)],"cut",3),
    day(number,5,"روز ۵ — فول‌بادی سبک","پمپ، تکنیک و مصرف انرژی",[take(legs,index,1,5)[0],take(chest,index,1,4)[0],take(back,index,1,4)[0],take(shoulders,index,1,4)[0],take(biceps,index,1,3)[0],take(triceps,index,1,3)[0],take(core,index,1,2)[0]],"cut",1),
  ] : [
    day(number,1,"روز ۱ — بالاتنه A","سینه، پشت و بازو با سوپرست کنترل‌شده",[...take(chest,index*2,4,3+variant),...take(back,index*3,4,3+variant),...take(biceps,index,2,3),...take(triceps,index,2,3)],"cut",4),
    day(number,2,"روز ۲ — پایین‌تنه A","چهارسر، همسترینگ و ساق",take(legs,index*4,8,3+variant),"cut",4),
    day(number,3,"روز ۳ — بالاتنه B","سرشانه، پشت و بازو",[...take(shoulders,index*3,5,2+variant),...take(back,index*2+3,3,4),...take(biceps,index+2,2,3),...take(triceps,index+3,2,3)],"cut",4),
    day(number,4,"روز ۴ — پایین‌تنه B + میان‌تنه","پایین‌تنه و ثبات مرکزی",[...take(legs,index*5+2,6,4),...take(core,index,3,2)],"cut",4),
  ];
  return {id:`builtin-${number}`,number,title:`کات و حفظ عضله — مدل ${index+1}`,kind:"cut",daysPerWeek:days.length,description:`برنامه کات ${days.length} روزه؛ حفظ شدت، حجم متوسط و چگالی تمرین بالاتر`,plan:basePlan("برنامه کات و حفظ عضله",days)};
}

function backFriendlyTemplate(index: number): ProgramTemplate {
  const number = 331 + index;
  const days = [
    day(number,1,"روز ۱ — بالاتنه A","حرکات تکیه‌دار و بدون بار محوری سنگین",[...take(backFriendlyChest,index,4,2),...take(backFriendlyBack,index+1,4,2),...take(backFriendlyCore,index,2,2)],"back-friendly"),
    day(number,2,"روز ۲ — پایین‌تنه A","پایین‌تنه با دستگاه و دامنه بدون علامت",[...take(backFriendlyLegs,index*2,7,2),...take(backFriendlyCore,index+1,2,2)],"back-friendly"),
    day(number,3,"روز ۳ — بالاتنه B","سرشانه و پشت با حمایت بیشتر",[...take(backFriendlyShoulders,index,5,2),...take(backFriendlyBack,index+2,3,2),...take(biceps,index,2,3),...take(triceps,index,2,3)],"back-friendly"),
    day(number,4,"روز ۴ — پایین‌تنه B + Core","پا و ثبات ضدچرخش/ضداکستنشن",[...take(backFriendlyLegs,index*3+1,6,2),...take(backFriendlyCore,index+2,3,2)],"back-friendly"),
  ];
  return {id:`builtin-${number}`,number,title:`کم‌ریسک‌تر برای سابقه دیسک کمر — مدل ${index+1}`,kind:"back-friendly",daysPerWeek:4,description:"۴ روزه محافظه‌کارانه؛ بدون اسکوات/ددلیفت سنگین و پارویی خم. فقط با تأیید پزشک/فیزیوتراپیست و در نبود علائم حاد.",plan:basePlan("برنامه محافظه‌کارانه ستون فقرات",days)};
}

function beginner4Template(index: number): ProgramTemplate {
  const number = 341 + index;
  const days = [
    day(number,1,"روز ۱ — بالاتنه A","پرس، کشش و بازو",[...take(chest,index*2,3,4),...take(back,index*2,3,4),take(shoulders,index,1,4)[0],take(biceps,index,1,3)[0],take(triceps,index,1,3)[0]],"beginner"),
    day(number,2,"روز ۲ — پایین‌تنه A","چهارسر، پشت پا، ساق و میان‌تنه",[...take(legs,index*3,6,4),take(core,index,1,2)[0]],"beginner"),
    day(number,3,"روز ۳ — بالاتنه B","تنوع حرکتی بالاتنه",[...take(chest,index*2+2,3,4),...take(back,index*2+2,3,4),take(shoulders,index+2,1,4)[0],take(biceps,index+2,1,3)[0],take(triceps,index+2,1,3)[0]],"beginner"),
    day(number,4,"روز ۴ — پایین‌تنه B","پایین‌تنه و ثبات مرکزی",[...take(legs,index*3+2,6,4),take(core,index+2,1,2)[0]],"beginner"),
  ];
  return {id:`builtin-${number}`,number,title:`مبتدی ۴ روزه — مدل ${index+1}`,kind:"beginner-4",daysPerWeek:4,description:"Upper/Lower چهارروزه؛ حجم قابل‌کنترل، فرم‌محور و مناسب شروع",plan:basePlan("مبتدی چهارروزه",days)};
}

function beginner5Template(index: number): ProgramTemplate {
  const number = 366 + index;
  const days = [
    day(number,1,"روز ۱ — سینه + جلو بازو","حرکات ساده و قابل یادگیری",[...take(chest,index*2,4,4),...take(biceps,index,2,3)],"beginner"),
    day(number,2,"روز ۲ — پا","پایین‌تنه پایه",take(legs,index*3,6,4),"beginner"),
    day(number,3,"روز ۳ — زیربغل","کشش عمودی و افقی",take(back,index*3,5,4),"beginner"),
    day(number,4,"روز ۴ — سرشانه + پشت بازو","سرشانه و پشت بازو",[...take(shoulders,index*2,4,4),...take(triceps,index,2,3)],"beginner"),
    day(number,5,"روز ۵ — تکنیک + میان‌تنه","مرور حرکات پایه با خستگی پایین",[take(legs,index+2,1,5)[0],take(chest,index+2,1,5)[0],take(back,index+2,1,5)[0],take(shoulders,index+2,1,5)[0],...take(core,index,2,2)],"beginner"),
  ];
  return {id:`builtin-${number}`,number,title:`مبتدی ۵ روزه — مدل ${index+1}`,kind:"beginner-5",daysPerWeek:5,description:"۵ جلسه کوتاه‌تر؛ توزیع حجم هفتگی برای مبتدی با شدت کنترل‌شده",plan:basePlan("مبتدی پنج‌روزه",days)};
}


function professionalDay(
  templateNo: number,
  dayNo: number,
  title: string,
  focus: string,
  ids: string[],
): WorkoutDay {
  // The final pair is a true superset. The remaining advanced methods are
  // distributed through the session so every professional template contains
  // negative work, a drop set, FST-7 and at least one superset without stacking
  // every intensity technique on the same exercise.
  const supersetFrom = Math.max(5, ids.length - 2);
  const result = day(templateNo, dayNo, title, focus, ids, "professional", supersetFrom);
  return {
    ...result,
    exercises: result.exercises.map((exercise, index) => {
      if (exercise.supersetId) return { ...exercise, technique: "سوپرست", notes: "بدون استراحت بین دو حرکت؛ پس از جفت ۶۰–۷۵ ثانیه استراحت." };
      if (index === 1) return { ...exercise, technique: "نگاتیو / Negative", tempo: "۴-۱-۱", notes: "فاز منفی ۴ ثانیه؛ بار طوری انتخاب شود که فرم و دامنه کامل حفظ شود." };
      if (index === 3) return { ...exercise, technique: "دراپ‌ست ست آخر", notes: "فقط ست آخر: یک کاهش ۲۰–۳۰٪ بار و ادامه با فرم صحیح." };
      if (index === 4) return { ...exercise, sets: "7", reps: "10–15", rest: "۳۰–۴۵ ثانیه", technique: "FST-7", notes: "۷ ست کوتاه با کنترل کامل؛ هدف پمپ و تنش موضعی، نه شکستن فرم." };
      return exercise;
    }),
  };
}

function professional4Template(index: number): ProgramTemplate {
  const number = 391 + index;
  const variant = index % 5;
  const days = [
    professionalDay(number,1,"روز ۱ — سینه + جلو بازو","هایپرتروفی پیشرفته سینه و جلو بازو",[...take(chest,index*3,6,3+variant),...take(biceps,index*2+1,3,2+variant)]),
    professionalDay(number,2,"روز ۲ — پا","چهارسر، همسترینگ، باسن و ساق",take(legs,index*5+2,9,3+variant)),
    professionalDay(number,3,"روز ۳ — زیربغل","عرض، ضخامت و کنترل اسکاپولا",take(back,index*4+1,8,3+variant)),
    professionalDay(number,4,"روز ۴ — سرشانه + پشت بازو","سرشانه کامل و پشت بازو",[...take(shoulders,index*3+2,6,2+variant),...take(triceps,index*4+1,3,3+variant)]),
  ];
  return {id:`builtin-${number}`,number,title:`حرفه‌ای ۴ روزه — مدل ${index+1}`,kind:"professional-4",daysPerWeek:4,description:"۴ روزه پیشرفته با دراپ‌ست، سوپرست، FST-7 و نگاتیو کنترل‌شده",plan:basePlan("برنامه حرفه‌ای چهارروزه",days)};
}

function professional5Template(index: number): ProgramTemplate {
  const number = 441 + index;
  const variant = index % 5;
  const days = [
    professionalDay(number,1,"روز ۱ — سینه","قدرت-هایپرتروفی و پمپ سینه",take(chest,index*3+1,8,2+variant)),
    professionalDay(number,2,"روز ۲ — زیربغل","عرض و ضخامت پشت",take(back,index*4+2,9,3+variant)),
    professionalDay(number,3,"روز ۳ — پا","چهارسر، همسترینگ، باسن و ساق",take(legs,index*5+3,9,3+variant)),
    professionalDay(number,4,"روز ۴ — سرشانه","سرشانه قدامی، میانی و خلفی",take(shoulders,index*4+1,8,2+variant)),
    professionalDay(number,5,"روز ۵ — جلو بازو + پشت بازو","بازو کامل",[...take(biceps,index*3+2,5,2+variant),...take(triceps,index*4+2,5,3+variant)]),
  ];
  return {id:`builtin-${number}`,number,title:`حرفه‌ای ۵ روزه — مدل ${index+1}`,kind:"professional-5",daysPerWeek:5,description:"۵ روزه پیشرفته با دراپ‌ست، سوپرست، FST-7 و نگاتیو کنترل‌شده",plan:basePlan("برنامه حرفه‌ای پنج‌روزه",days)};
}

export const BUILTIN_PROGRAM_TEMPLATES: ProgramTemplate[] = [
  ...Array.from({ length: 100 }, (_, index) => split4Template(index)),
  ...Array.from({ length: 100 }, (_, index) => single5Template(index)),
  ...Array.from({ length: 30 }, (_, index) => beginnerFullbodyTemplate(index)),
  ...Array.from({ length: 50 }, (_, index) => massTemplate(index)),
  ...Array.from({ length: 50 }, (_, index) => cutTemplate(index)),
  ...Array.from({ length: 10 }, (_, index) => backFriendlyTemplate(index)),
  ...Array.from({ length: 25 }, (_, index) => beginner4Template(index)),
  ...Array.from({ length: 25 }, (_, index) => beginner5Template(index)),
  ...Array.from({ length: 50 }, (_, index) => professional4Template(index)),
  ...Array.from({ length: 50 }, (_, index) => professional5Template(index)),
];

function newId(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
}

export function cloneTemplatePlan(template: ProgramTemplate): ClientPlan {
  const supersetMap = new Map<string,string>();
  return {
    ...JSON.parse(JSON.stringify(template.plan)) as ClientPlan,
    coachProgramNumber: template.number,
    sourceTemplateId: template.id,
    workoutDays: template.plan.workoutDays.map((sourceDay, dayIndex) => ({
      ...JSON.parse(JSON.stringify(sourceDay)),
      id: newId(`day-${dayIndex + 1}`),
      exercises: sourceDay.exercises.map((item) => {
        let supersetId: string | undefined;
        if (item.supersetId) {
          if (!supersetMap.has(item.supersetId)) supersetMap.set(item.supersetId, newId("superset"));
          supersetId = supersetMap.get(item.supersetId);
        }
        return { ...JSON.parse(JSON.stringify(item)), rowId:newId("exercise"), supersetId };
      }),
    })),
    supplementItems: template.plan.supplementItems?.map(item => ({ ...item, id:newId("supplement") })) ?? [],
    medicationItems: template.plan.medicationItems?.map(item => ({ ...item, id:newId("medication") })) ?? [],
  };
}

export function planAsCustomTemplate(plan: ClientPlan, number: number, title?: string): ProgramTemplate {
  const clean = JSON.parse(JSON.stringify(plan)) as ClientPlan;
  delete clean.coachProgramNumber;
  delete clean.sourceTemplateId;
  return {
    id:newId("custom-program"), number, title:title?.trim() || plan.title || `برنامه شخصی ${number}`,
    kind:"custom", daysPerWeek:plan.workoutDays.length, description:"ذخیره‌شده توسط مربی", plan:clean, custom:true,
  };
}
