import { PACKAGES, packageById, type Package } from "@/lib/packages";
import { database } from "@/lib/raw-db";

export function getPackages(): Package[] {
  const rows = database().prepare("SELECT package_id,price FROM package_prices").all<{package_id:string;price:number}>().results;
  const prices = new Map(rows.map(row => [row.package_id, row.price]));
  return PACKAGES.map(item => ({ ...item, price: prices.get(item.id) ?? item.price }));
}

export function getPackageById(id: string) {
  return packageById(id, getPackages());
}

export class PackageSelectionError extends Error {}

// Snapshot the server catalog for a single-service or combined order.
export function quotePackages(ids: string[]) {
  if (!ids.length || ids.length > 7 || new Set(ids).size !== ids.length) throw new PackageSelectionError("خدمات انتخابی معتبر نیستند.");
  const items=ids.map(id=>getPackageById(id));
  if(items.some(item=>!item))throw new PackageSelectionError("خدمات انتخابی معتبر نیستند.");
  const selected=items as Package[];
  if(selected.length>1&&selected.some(item=>item.id==="natural"||item.id==="professional"))throw new PackageSelectionError("پکیج‌های نچرال و VIP باید جداگانه انتخاب شوند.");
  const price=selected.reduce((sum,item)=>sum+item.price,0);
  if(price>2_000_000_000)throw new PackageSelectionError("جمع مبلغ خدمات از سقف مجاز بیشتر است.");
  return {id:selected[0].id,name:selected.map(item=>item.name).join(" + "),price,requiresLabs:selected.some(item=>item.requiresLabs),items:selected};
}
