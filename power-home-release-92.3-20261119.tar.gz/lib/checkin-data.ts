import { z } from "zod";
import type { ClientPlan, Client, Exercise } from "./coach-data";
export const POSES = { front: "روبه‌رو", back: "پشت", side: "بغل", front_double: "جفت بازو از جلو", back_double: "جفت بازو از پشت" } as const;
export type Pose = keyof typeof POSES;
export const METRICS = { weight: "وزن (کیلوگرم)", height: "قد (سانتی‌متر)", waist: "دور کمر (سانتی‌متر)", arm: "دور بازو (سانتی‌متر)" } as const;
const number = (max: number) => z.number().finite().positive().max(max).nullable();
export const measurementsSchema = z.object({ weight: number(500), height: number(250), waist: number(300), arm: number(150) });
export const dateSchema = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(v => !isNaN(Date.parse(v)) && new Date(v).toISOString().slice(0,10) === v);
export type Measurements = z.infer<typeof measurementsSchema>;
export type Checkin = { id: string; clientId: string; recordType?: "baseline" | "archive"; date: string; createdAt: string; folderName?: string; measurements: Measurements; notes: string; plan: ClientPlan; client: Client; exercises: Exercise[]; photos: Partial<Record<Pose, string>> };
export function previousExerciseIds(records: Checkin[]) {
  const latest = records.filter((record) => record.recordType !== "baseline").sort((a,b) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt))[0];
  return new Set(latest?.plan.workoutDays.flatMap(d => d.exercises.map(e => e.exerciseId)) ?? []);
}
