export type MedicationDefinition = {
  id: string;
  nameFa: string;
  nameEn: string;
  group: "pct" | "bodybuilding";
  category: string;
  aliases?: string;
};

const medication = (id:string,nameFa:string,nameEn:string,group:"pct"|"bodybuilding",category:string,aliases=""):MedicationDefinition => ({id,nameFa,nameEn,group,category,aliases});

export const MEDICATION_CATEGORIES = ["همه","ریکاوری و PCT","کنترل استروژن","کنترل پرولاکتین","تزریقی","خوراکی","هورمون و پپتید","چربی‌سوز و تیروئید","داروهای کمکی"];

export const MEDICATIONS: MedicationDefinition[] = [
  medication("hcg","اچ‌سی‌جی (HCG)","Human Chorionic Gonadotropin","pct","ریکاوری و PCT","گنادوتروپین اچ سی جی"),
  medication("clomiphene","کلومیفن سیترات","Clomiphene Citrate","pct","ریکاوری و PCT","کلومید"),
  medication("enclomiphene","انکلومیفن","Enclomiphene","pct","ریکاوری و PCT"),
  medication("tamoxifen","تاموکسیفن سیترات","Tamoxifen Citrate","pct","ریکاوری و PCT","نولوادکس"),
  medication("raloxifene","رالوکسیفن","Raloxifene","pct","ریکاوری و PCT"),
  medication("hmg","اچ‌ام‌جی (HMG)","Human Menopausal Gonadotropin","pct","ریکاوری و PCT","منوتروپین"),
  medication("anastrozole","آناستروزول","Anastrozole","pct","کنترل استروژن","آریمیدکس"),
  medication("letrozole","لتروزول","Letrozole","pct","کنترل استروژن","فمارا"),
  medication("exemestane","اگزمستان","Exemestane","pct","کنترل استروژن","آروماسین"),
  medication("cabergoline","کابرگولین","Cabergoline","pct","کنترل پرولاکتین","دوستینکس"),
  medication("pramipexole","پرامی‌پکسول","Pramipexole","pct","کنترل پرولاکتین"),
  medication("testosterone-enanthate","تستوسترون انانتات","Testosterone Enanthate","bodybuilding","تزریقی","تست انانتات"),
  medication("testosterone-cypionate","تستوسترون سیپیونات","Testosterone Cypionate","bodybuilding","تزریقی","تست سیپیونات"),
  medication("testosterone-propionate","تستوسترون پروپیونات","Testosterone Propionate","bodybuilding","تزریقی","تست پروپ"),
  medication("testosterone-sustanon","تستوسترون سوستانون","Sustanon / Testosterone Blend","bodybuilding","تزریقی","سوستانون"),
  medication("nandrolone-decanoate","ناندرولون دکانوات","Nandrolone Decanoate","bodybuilding","تزریقی","دکا"),
  medication("nandrolone-phenylpropionate","ناندرولون فنیل‌پروپیونات","Nandrolone Phenylpropionate","bodybuilding","تزریقی","NPP ان پی پی"),
  medication("boldenone","بولدنون آندسیلنات","Boldenone Undecylenate","bodybuilding","تزریقی","اکویی‌پویز"),
  medication("trenbolone-acetate","ترنبولون استات","Trenbolone Acetate","bodybuilding","تزریقی","ترن استات"),
  medication("trenbolone-enanthate","ترنبولون انانتات","Trenbolone Enanthate","bodybuilding","تزریقی","ترن انانتات"),
  medication("drostanolone-propionate","دروستانولون پروپیونات","Drostanolone Propionate","bodybuilding","تزریقی","مسترون پروپ"),
  medication("drostanolone-enanthate","دروستانولون انانتات","Drostanolone Enanthate","bodybuilding","تزریقی","مسترون انانتات"),
  medication("methenolone-enanthate","متنولون انانتات","Methenolone Enanthate","bodybuilding","تزریقی","پریموبولان"),
  medication("stanozolol","استانوزولول","Stanozolol","bodybuilding","خوراکی","وینسترول وین"),
  medication("oxandrolone","اکساندرولون","Oxandrolone","bodybuilding","خوراکی","آناوار"),
  medication("methandrostenolone","متاندروستنولون","Methandrostenolone","bodybuilding","خوراکی","دیانابول"),
  medication("oxymetholone","اکسی‌متولون","Oxymetholone","bodybuilding","خوراکی","آنادرول"),
  medication("turinabol","تورینابول","Chlorodehydromethyltestosterone","bodybuilding","خوراکی"),
  medication("fluoxymesterone","فلوکسی‌مسترون","Fluoxymesterone","bodybuilding","خوراکی","هالوتستین"),
  medication("mesterolone","مسترولون","Mesterolone","bodybuilding","خوراکی","پروویرون"),
  medication("growth-hormone","هورمون رشد","Somatropin / HGH","bodybuilding","هورمون و پپتید","سوماتروپین جی اچ"),
  medication("insulin","انسولین","Insulin","bodybuilding","هورمون و پپتید"),
  medication("igf1-lr3","آی‌جی‌اف ۱ ال‌آر۳","IGF-1 LR3","bodybuilding","هورمون و پپتید"),
  medication("clenbuterol","کلنبوترول","Clenbuterol","bodybuilding","چربی‌سوز و تیروئید","کلن"),
  medication("liothyronine","لیوتیرونین (T3)","Liothyronine T3","bodybuilding","چربی‌سوز و تیروئید","تی تری"),
  medication("levothyroxine","لووتیروکسین (T4)","Levothyroxine T4","bodybuilding","چربی‌سوز و تیروئید","تی فور"),
  medication("salbutamol","سالبوتامول","Salbutamol / Albuterol","bodybuilding","چربی‌سوز و تیروئید"),
  medication("semaglutide","سماگلوتاید","Semaglutide","bodybuilding","چربی‌سوز و تیروئید","اوزمپیک وگووی"),
  medication("tirzepatide","تیرزپاتاید","Tirzepatide","bodybuilding","چربی‌سوز و تیروئید","مانجارو"),
  medication("metformin","متفورمین","Metformin","bodybuilding","داروهای کمکی"),
  medication("telmisartan","تلمیسارتان","Telmisartan","bodybuilding","داروهای کمکی"),
  medication("rosuvastatin","روزوواستاتین","Rosuvastatin","bodybuilding","داروهای کمکی"),
  medication("ursodeoxycholic-acid","اورسودئوکسی‌کولیک اسید","Ursodeoxycholic Acid","bodybuilding","داروهای کمکی","اورسوفار"),
  medication("furosemide","فوروزماید","Furosemide","bodybuilding","داروهای کمکی","لازیکس"),
  medication("spironolactone","اسپیرونولاکتون","Spironolactone","bodybuilding","داروهای کمکی"),
];
