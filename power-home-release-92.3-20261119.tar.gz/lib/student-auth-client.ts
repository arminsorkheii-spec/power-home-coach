export function normalizeDigits(value:string){return value.replace(/[۰-۹]/g,d=>String("۰۱۲۳۴۵۶۷۸۹".indexOf(d))).replace(/[٠-٩]/g,d=>String("٠١٢٣٤٥٦٧٨٩".indexOf(d)));}
export function normalizePhone(value:string){let p=normalizeDigits(value).replace(/\D/g,"");if(p.startsWith("0098"))p="0"+p.slice(4);else if(p.startsWith("98"))p="0"+p.slice(2);return p;}
