import assert from 'node:assert/strict';
import test,{after} from 'node:test';
import {mkdtempSync} from 'node:fs';import {tmpdir} from 'node:os';import path from 'node:path';import {fileURLToPath} from 'node:url';import {randomUUID} from 'node:crypto';import {createServer} from 'vite';
const root=fileURLToPath(new URL('..',import.meta.url));process.env.APP_DATA_DIR=mkdtempSync(path.join(tmpdir(),'r923-'));process.env.APP_SESSION_SECRET='r923-fixture-session';
const vite=await createServer({appType:'custom',configFile:false,root,resolve:{alias:{'@':root}},server:{middlewareMode:true,hmr:false}});after(()=>vite.close());const load=p=>vite.ssrLoadModule(p);
const {database}=await load('/lib/raw-db.ts'),db=database();const auth=await load('/lib/password-auth.ts'),settings=await load('/app/api/sms/settings/route.ts'),login=await load('/app/api/student/login/route.ts'),notices=await load('/app/api/notifications/route.ts');
const {notificationTarget,coachDestination}=await load('/lib/notification-target.ts'),{createNotification}=await load('/lib/notifications.ts');
const cookie=`power_home_session=${await auth.createSessionToken()}`;
const request=(url,body,session=cookie,method='PATCH',role='coach',origin='https://coach.test')=>new Request('https://coach.test'+url,{method,headers:{host:'coach.test',origin,cookie:session,'content-type':'application/json','x-portal-role':role},...(body===undefined?{}:{body:JSON.stringify(body)})});
const loginConfig={loginEnabled:true,otpTemplateId:101,otpParameter:'PASSWORD'};

test('SMS login settings save independently and persist across read/login mode with missing notification fields',async()=>{
 const body={section:'login',settings:loginConfig};
 assert.equal((await settings.PATCH(request('/api/sms/settings',body,''))).status,403);
 assert.equal((await settings.PATCH(request('/api/sms/settings',body,cookie,'PATCH','coach','https://foreign.test'))).status,403);
 const missing=await settings.PATCH(request('/api/sms/settings',body));assert.equal(missing.status,400);assert.equal((await missing.json()).field,'apiKey');
 const saved=await settings.PATCH(request('/api/sms/settings',{section:'login',settings:{...loginConfig,apiKey:'mock-sms-api-key-r923'}}));assert.equal(saved.status,200);
 const data=await saved.json();assert.equal(data.settings.loginEnabled,true);assert.equal(data.settings.notificationsEnabled,false);assert.equal(data.settings.coachPhone,'');assert.equal(data.settings.lineNumber,'');assert.ok(!JSON.stringify(data).includes('mock-sms-api-key-r923'));
 assert.equal((await (await login.GET()).json()).smsEnabled,true);
 assert.equal((await (await settings.GET(request('/api/sms/settings',undefined,cookie,'GET'))).json()).settings.loginEnabled,true);
 const oldPassword=await login.POST(request('/api/student/login',{phone:'09123456789',password:'123456'},'','POST','student'));assert.equal(oldPassword.status,400);assert.equal((await oldPassword.json()).smsRequired,true);
});

test('outbound SMS validation returns actionable fields and never rolls back saved OTP settings',async()=>{
 const notification={section:'notifications',settings:{notificationsEnabled:true,lineNumber:'',coachPhone:'',notificationTemplateId:0,notificationParameter:'EVENT'}};
 let response=await settings.PATCH(request('/api/sms/settings',notification));assert.equal(response.status,400);assert.equal((await response.json()).field,'lineNumber');
 response=await settings.PATCH(request('/api/sms/settings',{...notification,settings:{...notification.settings,lineNumber:'300012345'}}));assert.equal(response.status,400);assert.equal((await response.json()).field,'coachPhone');
 assert.equal((await (await login.GET()).json()).smsEnabled,true);
 const forbidden=await settings.PATCH(request('/api/sms/settings',{section:'notifications',settings:{...notification.settings,loginEnabled:false}}));assert.equal(forbidden.status,400);
 assert.equal((await (await login.GET()).json()).smsEnabled,true);
});

test('notification destinations select the exact application, conversation or program and reject external coach targets',()=>{
 const id=randomUUID();
 assert.equal(notificationTarget('coach',{type:'payment_receipt',url:'/coach',application_id:id,actor_client_id:'client-1'}),`/coach?view=applications&client=client-1&application=${id}`);
 assert.equal(notificationTarget('coach',{type:'chat_message',actor_client_id:'client-1'}),'/coach?view=chat&client=client-1');
 assert.equal(notificationTarget('student',{type:'payment_receipt_sent',application_id:id}),`/student?section=request&application=${id}`);
 assert.equal(notificationTarget('student',{type:'program_delivered',application_id:id}),`/student?section=program&application=${id}`);
 assert.equal(notificationTarget('student',{type:'chat_message'}),'/student?section=chat');
 assert.equal(coachDestination('https://foreign.test/coach?view=chat'),null);assert.equal(coachDestination('/coach.evil?view=chat'),null);assert.equal(coachDestination('/coach?view=unknown'),null);
 assert.deepEqual(coachDestination(`/coach?view=applications&application=${id}&client=client-1`),{view:'applications',applicationId:id,clientId:'client-1'});
});

test('legacy notification URLs are repaired on read without altering their original database rows',async()=>{
 const id=randomUUID(),appId=randomUUID();
 db.prepare("INSERT INTO notification_events(id,recipient_role,actor_client_id,application_id,type,title,body,url,tag,created_at) VALUES(?,'coach',?,?,'payment_receipt','رسید','متن','/coach','legacy',?)").bind(id,'client-1',appId,new Date().toISOString()).run();
 const response=await notices.GET(request('/api/notifications',undefined,cookie,'GET'));const rows=(await response.json()).notifications;
 assert.equal(rows.find(n=>n.id===id).url,`/coach?view=applications&client=client-1&application=${appId}`);
 assert.equal(db.prepare('SELECT url FROM notification_events WHERE id=?').bind(id).first().url,'/coach');
 const made=await createNotification({role:'coach',actorClientId:'client-1',type:'chat_message',title:'پیام',body:'متن خصوصی',url:'/coach',tag:'new-chat'});
 assert.equal(db.prepare('SELECT url FROM notification_events WHERE id=?').bind(made.id).first().url,'/coach?view=chat&client=client-1');
});

test('student can purchase extra services while the original receipt is under review, without changing original payment or plan',async()=>{
 const register=await load('/app/api/register/route.ts'),orders=await load('/app/api/student/application/route.ts');
 const response=await register.POST(request('/api/register',{name:'شاگرد تست',phone:'09123339999',password:'123456',packageIds:['training']},'','POST','student'));assert.equal(response.status,200);
 const studentCookie=response.headers.get('set-cookie').split(';')[0],created=await response.json();
 db.prepare("UPDATE applications SET status='payment_review' WHERE id=?").bind(created.applicationId).run();
 const original=db.prepare('SELECT * FROM applications WHERE id=?').bind(created.applicationId).first();
 const before=await (await orders.GET(request('/api/student/application',undefined,studentCookie,'GET','student'))).json();assert.equal(before.canRequestAddon,true);assert.equal(before.canRequestNew,false);
 const extra=await orders.POST(request('/api/student/application',{packageIds:['nutrition','cycle'],addon:true,requestId:randomUUID()},studentCookie,'POST','student'));assert.equal(extra.status,200);
 const addition=await extra.json();assert.equal(addition.priceAmount,2300000);
 assert.deepEqual(db.prepare('SELECT * FROM applications WHERE id=?').bind(created.applicationId).first(),original);
 assert.equal(db.prepare('SELECT parent_application_id FROM applications WHERE id=?').bind(addition.applicationId).first().parent_application_id,created.applicationId);
});
