import assert from "node:assert/strict";
import test from "node:test";
import { spawn } from "node:child_process";
import { once } from "node:events";
import { createServer } from "node:net";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const developmentPreviewMeta =
  /<meta(?=[^>]*\bname=["']codex-preview["'])(?=[^>]*\bcontent=["']development["'])[^>]*>/i;

test("renders production Next.js HTML without development preview metadata", async () => {
  const socket = createServer();
  socket.listen(0, "127.0.0.1");
  await once(socket, "listening");
  const port = socket.address().port;
  await new Promise(resolve => socket.close(resolve));
  const dataDirectory = await mkdtemp(path.join(tmpdir(), "power-home-render-"));
  const server = spawn(process.execPath, [fileURLToPath(new URL("../.next/standalone/server.js", import.meta.url))], {
    env: { ...process.env, HOSTNAME: "127.0.0.1", PORT: String(port), APP_DATA_DIR: dataDirectory },
    stdio: ["ignore", "pipe", "pipe"],
  });
  let output = "";
  server.stdout.on("data", chunk => { output += chunk; });
  server.stderr.on("data", chunk => { output += chunk; });
  try {
    let response;
    const deadline = Date.now() + 15000;
    while (Date.now() < deadline) {
      assert.equal(server.exitCode, null, output);
      try { response = await fetch(`http://127.0.0.1:${port}/`); break; }
      catch { await new Promise(resolve => setTimeout(resolve, 100)); }
    }
    assert.ok(response, output);
    assert.equal(response.status, 200);
    assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);
    assert.doesNotMatch(await response.text(), developmentPreviewMeta);
  } finally {
    server.kill();
    if (server.exitCode === null) await once(server, "exit");
    await rm(dataDirectory, { recursive: true, force: true });
  }
});
