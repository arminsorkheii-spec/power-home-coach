import assert from "node:assert/strict";
import test, { after } from "node:test";
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import { createServer } from "vite";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("..", import.meta.url));
const dataDir = mkdtempSync(path.join(tmpdir(), "power-home-release90-"));
const legacy = new DatabaseSync(path.join(dataDir, "power-home.sqlite"));
legacy.exec(`
CREATE TABLE student_accounts(client_id TEXT PRIMARY KEY, phone TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,salt TEXT NOT NULL,revision TEXT NOT NULL,created_at TEXT,updated_at TEXT);
CREATE TABLE applications(id TEXT PRIMARY KEY,client_id TEXT NOT NULL,package_id TEXT NOT NULL,package_name TEXT NOT NULL,status TEXT NOT NULL,price_amount INTEGER,profile_json TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE billing_records(id TEXT PRIMARY KEY,application_id TEXT UNIQUE,client_id TEXT NOT NULL,package_id TEXT NOT NULL,package_name TEXT NOT NULL,list_amount INTEGER NOT NULL,discount_amount INTEGER NOT NULL,final_amount INTEGER NOT NULL,received_amount INTEGER NOT NULL,received_at TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE program_assignments(id TEXT PRIMARY KEY,client_id TEXT NOT NULL,template_id TEXT NOT NULL,program_number INTEGER NOT NULL,template_title TEXT NOT NULL,assigned_at TEXT NOT NULL,delivered_at TEXT);
CREATE UNIQUE INDEX idx_program_assignments_client_template ON program_assignments(client_id,template_id);
INSERT INTO student_accounts VALUES('c1','09120000000','h','s','r','2026-09-01','2026-09-01');
INSERT INTO applications VALUES('a1','c1','training','تمرین','writing',2000000,'{}','2026-09-01','2026-09-01');
INSERT INTO billing_records VALUES('b1','a1','c1','training','تمرین',2000000,500000,1500000,1000000,'2026-09-02','2026-09-01','2026-09-02');
`);
legacy.close();
process.env.APP_DATA_DIR = dataDir;

const vite = await createServer({ appType:"custom", configFile:false, root, resolve:{alias:{"@":root}}, server:{middlewareMode:true} });
after(async()=>vite.close());
const rawDb = await vite.ssrLoadModule("/lib/raw-db.ts");
const db = rawDb.database();

test("Release 90 migrates accounting without losing existing received money", () => {
  const columns = db.prepare("PRAGMA table_info(applications)").all().results.map((row)=>row.name);
  assert.ok(columns.includes("paid_at"));
  const events = db.prepare("SELECT id,amount_delta,note FROM billing_events ORDER BY id").all().results;
  assert.equal(events.length,1);
  assert.equal(events[0].id,"opening-b1");
  assert.equal(Number(events[0].amount_delta),1000000);
});

test("program assignment history permits an explicit repeated assignment after warning", () => {
  const index = db.prepare("SELECT sql FROM sqlite_master WHERE type='index' AND name='idx_program_assignments_client_template'").first();
  assert.ok(index?.sql);
  assert.ok(!/UNIQUE/i.test(index.sql));
  const now = new Date().toISOString();
  db.prepare("INSERT INTO program_assignments (id,client_id,template_id,program_number,template_title,assigned_at) VALUES (?,?,?,?,?,?)").bind("p1","c1","template-x",401,"برنامه حرفه‌ای",now).run();
  db.prepare("INSERT INTO program_assignments (id,client_id,template_id,program_number,template_title,assigned_at) VALUES (?,?,?,?,?,?)").bind("p2","c1","template-x",401,"برنامه حرفه‌ای",now).run();
  const count=db.prepare("SELECT COUNT(*) count FROM program_assignments WHERE client_id='c1' AND template_id='template-x'").first();
  assert.equal(Number(count.count),2);
});
