import assert from "node:assert/strict";
import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import test, { after } from "node:test";
import { fileURLToPath } from "node:url";

import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { createServer } from "vite";

const root = fileURLToPath(new URL("..", import.meta.url));
const vite = await createServer({
  appType: "custom",
  configFile: false,
  root,
  resolve: { alias: { "@": root } },
  server: { middlewareMode: true },
});

after(async () => {
  await vite.close();
});

async function readCssTree(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const contents = await Promise.all(
    entries.map(async (entry) => {
      const entryPath = path.join(directory, entry.name);
      if (entry.isDirectory()) {
        return readCssTree(entryPath);
      }
      return entry.name.endsWith(".css") ? readFile(entryPath, "utf8") : "";
    }),
  );
  return contents.join("\n");
}

test("emits production scrolling, safe-area and reduced-motion styles", async () => {
  const css = await readCssTree(path.join(root, ".next", "static"));

  assert.match(css, /--tw-enter-opacity/);
  assert.match(css, /scrollbar-width:\s*thin/);
  assert.match(css, /scrollbar-width:\s*none/);
  assert.match(css, /safe-area-inset-top/);
  assert.match(css, /safe-area-inset-bottom/);
  assert.match(css, /overflow-wrap:\s*anywhere/);
  assert.match(css, /prefers-reduced-motion:\s*reduce/);
});

test("forwards progress semantics to the primitive", async () => {
  const { Progress } = await vite.ssrLoadModule("/components/ui/progress.tsx");
  const html = renderToStaticMarkup(React.createElement(Progress, { value: 37 }));

  assert.match(html, /aria-valuenow="37"/);
  assert.match(html, /aria-valuetext="37%"/);
  assert.match(html, /data-state="loading"/);
});

test("emits chart themes for the starter's media dark mode", async () => {
  const { ChartStyle } = await vite.ssrLoadModule("/components/ui/chart.tsx");
  const html = renderToStaticMarkup(
    React.createElement(ChartStyle, {
      id: "contract",
      config: {
        latency: { theme: { light: "#ffffff", dark: "#000000" } },
      },
    }),
  );

  assert.match(html, /\[data-chart=contract\]/);
  assert.match(html, /@media \(prefers-color-scheme: dark\)/);
  assert.doesNotMatch(html, /\.dark/);
});

test("renders sidebar skeletons deterministically", async () => {
  const { SidebarMenuSkeleton } = await vite.ssrLoadModule(
    "/components/ui/sidebar.tsx",
  );
  const first = renderToStaticMarkup(React.createElement(SidebarMenuSkeleton));
  const second = renderToStaticMarkup(React.createElement(SidebarMenuSkeleton));

  assert.equal(first, second);
  assert.match(first, /--skeleton-width:70%/);
});

test("merges a selected exercise with the next row as a superset", async () => {
  const { groupExerciseRows, setTechniqueWithSuperset } = await vite.ssrLoadModule(
    "/lib/supersets.ts",
  );
  const rows = ["one", "two", "three"].map((rowId) => ({
    rowId,
    exerciseId: rowId,
    sets: "3",
    reps: "10",
    rest: "60",
    tempo: "کنترل‌شده",
    technique: "عادی",
    notes: "",
  }));

  const merged = setTechniqueWithSuperset(rows, "one", "سوپرست", "superset-test");
  assert.equal(merged[0].supersetId, "superset-test");
  assert.equal(merged[1].supersetId, "superset-test");
  assert.equal(merged[0].technique, "سوپرست");
  assert.equal(merged[1].technique, "سوپرست");
  assert.deepEqual(groupExerciseRows(merged).map((unit) => unit.items.length), [2, 1]);
});

test("changing either superset exercise back to normal separates both rows", async () => {
  const { setTechniqueWithSuperset } = await vite.ssrLoadModule("/lib/supersets.ts");
  const rows = ["one", "two"].map((rowId) => ({
    rowId,
    exerciseId: rowId,
    sets: "3",
    reps: "10",
    rest: "60",
    tempo: "کنترل‌شده",
    technique: "سوپرست",
    notes: "",
    supersetId: "superset-test",
  }));

  const separated = setTechniqueWithSuperset(rows, "two", "عادی", "unused");
  assert.equal(separated[0].supersetId, undefined);
  assert.equal(separated[1].supersetId, undefined);
  assert.equal(separated[0].technique, "عادی");
  assert.equal(separated[1].technique, "عادی");
});
