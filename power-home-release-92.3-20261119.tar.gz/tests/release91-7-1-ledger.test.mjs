import assert from "node:assert/strict";
import test, {after} from "node:test";
import {mkdtempSync} from "node:fs";
import {tmpdir} from "node:os";
import path from "node:path";
import {DatabaseSync} from "node:sqlite";
import {createServer} from "vite";
import {fileURLToPath} from "node:url";

const root=fileURLToPath(new URL("..",import.meta.url));
process.env.APP_DATA_DIR=mkdtempSync(path.join(tmpdir(),"power-home-r9171-"));
const seed=new DatabaseSync(path.join(process.env.APP_DATA_DIR,"power-home.sqlite"));
seed.exec(`
CREATE TABLE billing_records(id TEXT PRIMARY KEY,application_id TEXT UNIQUE,client_id TEXT NOT NULL,package_id TEXT NOT NULL,package_name TEXT NOT NULL,list_amount INTEGER NOT NULL,discount_amount INTEGER NOT NULL,final_amount INTEGER NOT NULL,received_amount INTEGER NOT NULL,received_at TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE billing_events(id TEXT PRIMARY KEY,billing_id TEXT NOT NULL,application_id TEXT,client_id TEXT NOT NULL,package_name TEXT NOT NULL,amount_delta INTEGER NOT NULL,event_at TEXT NOT NULL,note TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL,deleted_at TEXT,edited_at TEXT);
INSERT INTO billing_records VALUES('paid',NULL,'c1','training','training',800000,0,800000,400000,'2026-11-01','2026-11-01','2026-11-01');
INSERT INTO billing_records VALUES('deleted',NULL,'c2','training','training',800000,0,800000,100000,'2026-11-01','2026-11-01','2026-11-01');
INSERT INTO billing_records VALUES('legacy',NULL,'c3','training','training',800000,0,800000,200000,'2026-11-01','2026-11-01','2026-11-01');
INSERT INTO billing_events VALUES('actual-payment','paid',NULL,'c1','training',400000,'2026-11-01','actual payment','2026-11-01',NULL,NULL);
INSERT INTO billing_events VALUES('deleted-payment','deleted',NULL,'c2','training',100000,'2026-11-01','deleted event','2026-11-01','2026-11-02',NULL);
`);
seed.close();
const vite=await createServer({appType:"custom",configFile:false,root,resolve:{alias:{"@":root}},server:{middlewareMode:true}});
after(async()=>vite.close());
const {database}=await vite.ssrLoadModule("/lib/raw-db.ts");
const db=database();

test("restart preserves existing payment ledger without duplicating received income",()=>{
  assert.equal(db.prepare("SELECT count(*) n FROM billing_events WHERE billing_id='paid'").first().n,1);
  assert.equal(db.prepare("SELECT sum(amount_delta) n FROM billing_events WHERE billing_id='paid' AND deleted_at IS NULL").first().n,400000);
  assert.equal(db.prepare("SELECT received_amount n FROM billing_records WHERE id='paid'").first().n,400000);
});
test("restart does not resurrect deliberately deleted payment history",()=>{
  assert.equal(db.prepare("SELECT count(*) n FROM billing_events WHERE billing_id='deleted'").first().n,1);
  assert.equal(db.prepare("SELECT count(*) n FROM billing_events WHERE billing_id='deleted' AND deleted_at IS NULL").first().n,0);
});
test("legacy received balance without any ledger history still receives one opening entry",()=>{
  assert.equal(db.prepare("SELECT id,amount_delta FROM billing_events WHERE billing_id='legacy'").first().id,"opening-legacy");
  assert.equal(db.prepare("SELECT sum(amount_delta) n FROM billing_events WHERE billing_id='legacy'").first().n,200000);
});
