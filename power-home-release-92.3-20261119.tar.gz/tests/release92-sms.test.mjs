import assert from 'node:assert/strict';
import test,{after} from 'node:test';
import {mkdtempSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID} from 'node:crypto';
import {createServer} from 'vite';
const root=fileURLToPath(new URL('..',import.meta.url));
process.env.APP_DATA_DIR=mkdtempSync(path.join(tmpdir(),'power-home-sms-'));
process.env.APP_SESSION_SECRET='release92-test-secret-only';
process.env.APP_PASSWORD='coach-test-password';
const vite=await createServer({appType:'custom',configFile:false,root,resolve:{alias:{'@':root}},server:{middlewareMode:true}});
const originalFetch=global.fetch;
after(async()=>{global.fetch=originalFetch;await vite.close()});
const load=p=>vite.ssrLoadModule(p);
const sms=await load('/lib/sms.ts'),otp=await load('/lib/student-otp.ts');
const {database}=await load('/lib/raw-db.ts'),db=database();
const auth=await load('/lib/password-auth.ts');
const settings=await load('/app/api/sms/settings/route.ts');
const credit=await load('/app/api/sms/credit/route.ts');
const send=await load('/app/api/sms/send/route.ts');
const login=await load('/app/api/student/login/route.ts');
const applications=await load('/app/api/applications/route.ts');
const registration=await load('/app/api/register/route.ts');
const delivery=await load('/app/api/program-delivery/route.ts');
db.prepare('INSERT INTO coach_security(owner,password_hash,salt,revision) VALUES(?,?,?,?)').bind(auth.coachDataKey(),await auth.derivePassword('coach-test-password','test-salt'),'test-salt','test-revision').run();
const cookie=`power_home_session=${await auth.createSessionToken()}`;
const req=(url,body,method='POST',session=cookie,origin='https://coach.test')=>new Request(`https://coach.test${url}`,{method,headers:{host:'coach.test',origin,cookie:session,'content-type':'application/json'},...(body===undefined?{}:{body:JSON.stringify(body)})});
const key='test-api-key-never-a-real-secret';
const config={apiKey:key,loginEnabled:true,notificationsEnabled:true,otpTemplateId:123,otpParameter:'PASSWORD',notificationTemplateId:0,notificationParameter:'EVENT',coachPhone:'09121111111',lineNumber:'300012345',stageMessages:structuredClone(sms.DEFAULT_STAGE_MESSAGES)};
let calls=[];
function mock(mode='ok') {calls=[];global.fetch=async(url,options={})=>{assert.match(String(url),/^https:\/\/api\.sms\.ir\/v1\//);assert.equal(options.headers['X-API-KEY'],key);calls.push({url:String(url),body:options.body?JSON.parse(options.body):null});if(mode==='timeout')throw new Error('mock timeout');return Response.json({status:mode==='reject'?0:1,data:String(url).endsWith('/credit')?765:{messageId:1234,packId:'pack1',messageIds:[1234]}})}}
function account(id,phone){db.prepare('INSERT INTO student_accounts(client_id,phone,password_hash,salt,revision) VALUES(?,?,?,?,?)').bind(id,phone,'hash','salt','rev').run()}
account('sms-student','09123456789');
account('sms-student-two','09123456780');
function resetCodes(){db.prepare('DELETE FROM student_login_codes').run();db.prepare('DELETE FROM sms_rate_limits').run()}
const stages=()=>({stageMessages:structuredClone(sms.DEFAULT_STAGE_MESSAGES),...config});

test('SMS configuration is coach-only, encrypted, validates atomically, and credit test sends no SMS',async()=>{
  mock();
  assert.equal((await settings.GET(req('/api/sms/settings',undefined,'GET',''))).status,401);
  assert.equal((await settings.PUT(req('/api/sms/settings',config,'PUT','','https://coach.test'))).status,403);
  assert.equal((await settings.PUT(req('/api/sms/settings',config,'PUT',cookie,'https://foreign.test'))).status,403);
  assert.equal(sms.getSmsSettings().loginEnabled,false);
  assert.equal((await settings.PUT(req('/api/sms/settings',config,'PUT'))).status,200);
  const stored=db.prepare('SELECT * FROM sms_settings').first();
  assert.ok(!JSON.stringify(stored).includes(key));assert.ok(stored.encrypted_key.length>20);
  const publicSettings=await (await settings.GET(req('/api/sms/settings',undefined,'GET'))).json();
  assert.equal(publicSettings.settings.apiKeyConfigured,true);assert.ok(!JSON.stringify(publicSettings).includes(key));assert.ok(!JSON.stringify(publicSettings).includes(stored.encrypted_key));
  assert.equal((await settings.PUT(req('/api/sms/settings',{...config,lineNumber:''},'PUT'))).status,400);
  assert.equal(sms.getSmsSettings().lineNumber,config.lineNumber);
  assert.equal((await credit.GET(req('/api/sms/credit',undefined,'GET',''))).status,401);
  assert.equal((await (await credit.GET(req('/api/sms/credit',undefined,'GET'))).json()).credit,765);
  assert.deepEqual(calls.map(c=>c.url),['https://api.sms.ir/v1/credit']);
  const {apiKey,...withoutKey}=config; sms.saveSmsSettings(sms.smsSettingsSchema.parse(withoutKey));
  assert.equal(sms.getSmsSettings().apiKeyConfigured,true);
});

test('OTP normalizes phones, stores only HMAC, enforces cooldown and consumes code once',async()=>{
  mock();resetCodes();
  const issued=await otp.requestStudentCode('+98 9123456789','ip-one');
  assert.equal(issued.expiresIn,300);assert.equal(issued.retryAfter,60);assert.equal(calls.length,1);
  const code=calls[0].body.parameters[0].value;
  assert.equal(calls[0].body.mobile,'09123456789');assert.equal(calls[0].body.parameters[0].name,'PASSWORD');assert.match(code,/^\d{6}$/);
  const row=db.prepare('SELECT * FROM student_login_codes').first();assert.equal(row.ready,1);assert.notEqual(row.code_hash,code);assert.ok(!JSON.stringify(issued).includes(code));
  await assert.rejects(otp.requestStudentCode('09123456789','ip-one'),e=>e.status===429&&e.retryAfter>0);
  assert.equal(calls.length,1);
  const oldPassword=await login.POST(req('/api/student/login',{phone:'09123456789',password:'123456'},'POST',''));
  assert.equal(oldPassword.status,400);assert.equal((await oldPassword.json()).smsRequired,true);
  const response=await login.POST(req('/api/student/login',{phone:'09123456789',code,challengeId:issued.challengeId},'POST',''));
  assert.equal(response.status,200);assert.match(response.headers.get('set-cookie'),/HttpOnly; Secure; SameSite=Strict/);
  assert.throws(()=>otp.verifyStudentCode('09123456789',issued.challengeId,code,'ip-one'),e=>e.status===401);
  assert.equal(await auth.passwordMatches('coach-test-password'),true);
});

test('OTP limits wrong attempts, rejects expiry, conceals unknown accounts, and invalidates failed sends',async()=>{
  mock();resetCodes();
  let issued=await otp.requestStudentCode('09123456789','ip-two'),code=calls.at(-1).body.parameters[0].value;
  const wrong=code==='111111'?'222222':'111111';
  for(let i=0;i<5;i++)assert.throws(()=>otp.verifyStudentCode('09123456789',issued.challengeId,wrong,'ip-two'),e=>e.status===401);
  assert.throws(()=>otp.verifyStudentCode('09123456789',issued.challengeId,code,'ip-two'),e=>e.status===401);
  resetCodes();issued=await otp.requestStudentCode('09123456789','ip-three');code=calls.at(-1).body.parameters[0].value;
  db.prepare('UPDATE student_login_codes SET expires_at=0').run();
  assert.throws(()=>otp.verifyStudentCode('09123456789',issued.challengeId,code,'ip-three'),e=>e.status===401);
  mock();resetCodes();const unknown=await otp.requestStudentCode('09129999999','ip-four');assert.equal(calls.length,0);assert.equal(unknown.message,issued.message);assert.equal(unknown.expiresIn,issued.expiresIn);
  assert.throws(()=>otp.verifyStudentCode('09129999999',unknown.challengeId,'123456','ip-four'),e=>e.status===401);
  mock('reject');resetCodes();await assert.rejects(otp.requestStudentCode('09123456789','ip-five'),e=>e.status===503);
  const row=db.prepare('SELECT ready,code_hash FROM student_login_codes').first();assert.equal(row.ready,0);assert.equal(row.code_hash,'');
});

test('manual group SMS checks recipients, authorization and durable deduplication including timeout',async()=>{
  mock();const body={requestId:randomUUID(),clientIds:['sms-student','sms-student-two'],message:'تخفیف ویژه خانه قدرت'};
  assert.equal((await send.POST(req('/api/sms/send',body,'POST',''))).status,403);
  assert.equal((await send.POST(req('/api/sms/send',body,'POST',cookie,'https://foreign.test'))).status,403);
  assert.equal((await send.POST(req('/api/sms/send',{...body,clientIds:['missing']}))).status,400);
  assert.equal(calls.length,0);
  const results=await Promise.all([send.POST(req('/api/sms/send',body)),send.POST(req('/api/sms/send',body))]);
  assert.ok(results.every(r=>r.status===200));assert.equal(calls.length,1);assert.equal(calls[0].body.mobiles.length,2);assert.equal(calls[0].body.messageText,body.message);
  assert.equal((await send.POST(req('/api/sms/send',{...body,message:'متن متفاوت'}))).status,409);
  mock('timeout');const uncertain={...body,requestId:randomUUID()};
  assert.equal((await (await send.POST(req('/api/sms/send',uncertain))).json()).status,'unknown');
  assert.equal((await (await send.POST(req('/api/sms/send',uncertain))).json()).status,'unknown');assert.equal(calls.length,1);
});

test('a rejected manual SMS can be submitted as a fresh attempt while the old attempt stays deduplicated',async()=>{
  mock('reject');const rejected={requestId:randomUUID(),clientIds:['sms-student'],message:'اطلاعیه آزمایشی'};
  assert.equal((await (await send.POST(req('/api/sms/send',rejected))).json()).status,'failed');
  assert.equal(calls.length,1);
  mock();
  assert.equal((await (await send.POST(req('/api/sms/send',rejected))).json()).status,'failed');
  assert.equal(calls.length,0);
  assert.equal((await (await send.POST(req('/api/sms/send',{...rejected,requestId:randomUUID()}))).json()).status,'accepted');
  assert.equal(calls.length,1);
});

test('edited workflow templates fire at real stage changes once, disabled stages do not send',async()=>{
  mock();const conf=stages();conf.stageMessages=structuredClone(config.stageMessages);
  for(const [id,value]of Object.entries(conf.stageMessages))value.text=`${id}: {نام} / {سایت}`;
  sms.saveSmsSettings(sms.smsSettingsSchema.parse(conf));
  db.prepare('INSERT INTO coach_states(owner_email,payload) VALUES(?,?)').bind(auth.coachDataKey(),JSON.stringify({clients:[{id:'sms-student',name:'آرمین'}],plans:{}})).run();
  const id=randomUUID();db.prepare("INSERT INTO applications(id,client_id,package_id,package_name,status) VALUES(?,?,?,?,'payment_review')").bind(id,'sms-student','training','تمرین').run();
  for(const [status,label] of [['payment_approved','payment'],['writing','writing'],['delivered','delivered']]){
    const count=calls.length;
    const rs=await Promise.all([applications.PATCH(req('/api/applications',{id,status},'PATCH')),applications.PATCH(req('/api/applications',{id,status},'PATCH'))]);
    assert.ok(rs.some(r=>r.status===200));assert.equal(calls.length,count+1);
    assert.equal(calls.at(-1).body.messageText,`${label}: آرمین / https://arminsorkhei.ir/student`);
    assert.deepEqual(calls.at(-1).body.mobiles,['09123456789']);
    assert.equal((await applications.PATCH(req('/api/applications',{id,status},'PATCH'))).status,200);assert.equal(calls.length,count+1);
  }
  conf.stageMessages.writing.enabled=false;sms.saveSmsSettings(sms.smsSettingsSchema.parse(conf));
  const count=calls.length;await applications.PATCH(req('/api/applications',{id,status:'writing'},'PATCH'));assert.equal(calls.length,count);
  await sms.sendNotificationSms('coach-event','coach',null,'payment_receipt');assert.deepEqual(calls.at(-1).body.mobiles,[config.coachPhone]);
  const eventCalls=calls.length;await sms.sendNotificationSms('coach-event','coach',null,'payment_receipt');assert.equal(calls.length,eventCalls);
});

test('successful registration sends personalized welcome and actual program delivery uses edited template',async()=>{
  mock();sms.saveSmsSettings(sms.smsSettingsSchema.parse(config));
  const response=await registration.POST(req('/api/register',{name:'شاگرد تازه',phone:'09124444444',password:'123456',packageId:'training'},'POST',''));
  assert.equal(response.status,200);const registered=await response.json();
  const welcome=calls.find(c=>c.body?.mobiles?.includes('09124444444'));
  assert.ok(welcome);assert.match(welcome.body.messageText,/شاگرد تازه عزیز/);
  const clientId=db.prepare('SELECT client_id FROM applications WHERE id=?').bind(registered.applicationId).first().client_id;
  const row=db.prepare('SELECT payload FROM coach_states WHERE owner_email=?').bind(auth.coachDataKey()).first();
  const state=JSON.parse(row.payload);state.plans??={};state.plans[clientId]={title:'برنامه آزمایشی',workoutDays:[],nutrition:[],supplements:[]};
  db.prepare('UPDATE coach_states SET payload=? WHERE owner_email=?').bind(JSON.stringify(state),auth.coachDataKey()).run();
  const before=calls.length;const result=await delivery.POST(req('/api/program-delivery',{clientId}));
  assert.equal(result.status,200);assert.equal(calls.length,before+1);assert.match(calls.at(-1).body.messageText,/برنامه شما ارسال شد/);
});
