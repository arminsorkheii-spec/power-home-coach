import assert from "node:assert/strict";
import test, { after } from "node:test";
import { createServer } from "vite";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("..", import.meta.url));
const vite = await createServer({
  appType: "custom",
  configFile: false,
  root,
  resolve: { alias: { "@": root } },
  server: { middlewareMode: true },
});
after(async () => vite.close());

const templatesModule = await vite.ssrLoadModule("/lib/program-templates.ts");
const dataModule = await vite.ssrLoadModule("/lib/coach-data.ts");
const templates = templatesModule.BUILTIN_PROGRAM_TEMPLATES;
const exerciseIds = new Set(dataModule.EXERCISES.map((item) => item.id));

const expectedKinds = {
  "split-4": 100,
  "single-5": 100,
  "beginner-fullbody": 30,
  mass: 50,
  cut: 50,
  "back-friendly": 10,
  "beginner-4": 25,
  "beginner-5": 25,
  "professional-4": 50,
  "professional-5": 50,
};

test("program bank has 490 unique numbered templates", () => {
  assert.equal(templates.length, 490);
  const numbers = templates.map((item) => item.number);
  assert.equal(new Set(numbers).size, 490);
  assert.deepEqual([...numbers].sort((a, b) => a - b), Array.from({ length: 490 }, (_, index) => index + 1));
  for (const [kind, count] of Object.entries(expectedKinds)) {
    assert.equal(templates.filter((item) => item.kind === kind).length, count, kind);
  }
});

test("every template is non-empty, internally consistent and uses known exercises", () => {
  const signatures = new Set();
  for (const template of templates) {
    assert.equal(template.daysPerWeek, template.plan.workoutDays.length, `days ${template.number}`);
    assert.ok(template.plan.workoutDays.length > 0, `no days ${template.number}`);
    for (const day of template.plan.workoutDays) {
      assert.ok(day.exercises.length > 0, `empty day ${template.number}/${day.title}`);
      for (const exercise of day.exercises) {
        assert.ok(exerciseIds.has(exercise.exerciseId), `unknown ${exercise.exerciseId} in ${template.number}`);
      }
    }
    const signature = template.plan.workoutDays.map((day) => day.exercises.map((item) => item.exerciseId).join(",")).join("|");
    assert.ok(!signatures.has(signature), `duplicate program signature ${template.number}`);
    signatures.add(signature);
  }
});

test("exercise bank contains 300 unique movement profiles", () => {
  assert.equal(dataModule.EXERCISES.length, 300);
  assert.equal(exerciseIds.size, 300);
});

test("back-friendly templates exclude preset high axial-load and unsupported bent-row movements", () => {
  const forbidden = new Set([
    "barbell-squat","front-squat","smith-machine-back-squat","smith-machine-front-squat",
    "conventional-barbell-deadlift","romanian-deadlift","smith-romanian-deadlift","barbell-row",
    "smith-machine-bent-over-row","standing-barbell-overhead-press","barbell-good-morning",
  ]);
  for (const template of templates.filter((item) => item.kind === "back-friendly")) {
    for (const day of template.plan.workoutDays) {
      for (const exercise of day.exercises) assert.ok(!forbidden.has(exercise.exerciseId), `${exercise.exerciseId} in ${template.number}`);
    }
  }
});


test("every professional template includes all requested advanced methods", () => {
  for (const template of templates.filter((item) => item.kind === "professional-4" || item.kind === "professional-5")) {
    const techniques = template.plan.workoutDays.flatMap((day) => day.exercises.map((exercise) => String(exercise.technique)));
    assert.ok(techniques.some((value) => value.includes("دراپ")), `drop set missing ${template.number}`);
    assert.ok(techniques.some((value) => value.includes("سوپرست")), `superset missing ${template.number}`);
    assert.ok(techniques.some((value) => value.includes("FST-7")), `FST-7 missing ${template.number}`);
    assert.ok(techniques.some((value) => value.includes("نگاتیو")), `negative missing ${template.number}`);
  }
});
