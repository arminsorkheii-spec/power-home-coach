import assert from 'node:assert/strict';
import test,{after} from 'node:test';
import {mkdtempSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID} from 'node:crypto';
import {createServer} from 'vite';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
const root=fileURLToPath(new URL('..',import.meta.url));
process.env.APP_DATA_DIR=mkdtempSync(path.join(tmpdir(),'power-home-services-'));
process.env.APP_SESSION_SECRET='test-922-session-key';
const vite=await createServer({appType:'custom',configFile:false,root,resolve:{alias:{'@':root}},server:{middlewareMode:true,hmr:false}});
after(()=>vite.close());
const load=p=>vite.ssrLoadModule(p);
const {database}=await load('/lib/raw-db.ts'),db=database();
const registration=await load('/app/api/register/route.ts'),orders=await load('/app/api/student/application/route.ts');
const prices=await load('/lib/package-pricing.ts'),auth=await load('/lib/password-auth.ts');
const billing=await load('/app/api/billing/route.ts');
const req=(url,body,cookie='',method='POST',origin='https://coach.test')=>new Request('https://coach.test'+url,{method,headers:{host:'coach.test',origin,cookie,'content-type':'application/json'},...(body===undefined?{}:{body:JSON.stringify(body)})});
const base={name:'شاگرد ترکیبی',phone:'09123331111',password:'123456'};
let cookie,mainId,clientId;

test('combined registration charges server catalog sum, snapshots all services and rejects invalid combinations',async()=>{
 const response=await registration.POST(req('/api/register',{...base,packageIds:['training','cycle'],priceAmount:1}));
 assert.equal(response.status,200);const result=await response.json();mainId=result.applicationId;cookie=response.headers.get('set-cookie').split(';')[0];
 const expected=prices.getPackageById('training').price+prices.getPackageById('cycle').price;assert.equal(result.priceAmount,expected);
 const application=db.prepare('SELECT * FROM applications WHERE id=?').bind(mainId).first();clientId=application.client_id;
 assert.match(application.package_name,/تمرینی.*دارویی/);assert.deepEqual(JSON.parse(application.package_items_json).map(p=>p.id),['training','cycle']);assert.equal(application.parent_application_id,null);
 for(const ids of [[],['training','training'],['training','unknown'],['natural','cycle'],['professional','training']]){
  assert.equal((await registration.POST(req('/api/register',{...base,phone:'09123332222',packageIds:ids}))).status,400);
 }
 assert.equal(db.prepare('SELECT count(*) AS n FROM student_accounts').first().n,1);
});

test('a combined medical service still requires labs; students cannot downgrade a submitted request',async()=>{
 const profile={age:'30',gender:'مرد',height:'185',weight:'100',waist:'90',arm:'40',goal:'افزایش عضله',experience:'',trainingDays:'4',injuries:'',diseases:'',medications:'',allergies:'',supplements:'',sleep:'',activity:'',notes:''};
 for(const kind of ['front','side','back','front_double','back_double'])db.prepare('INSERT INTO application_uploads(id,application_id,client_id,kind,key,filename,content_type,size) VALUES(?,?,?,?,?,?,?,?)').bind(randomUUID(),mainId,clientId,kind,'fixture-'+kind,kind+'.jpg','image/jpeg',10).run();
 const r=await orders.PUT(req('/api/student/application',{profile,finalize:true},cookie,'PUT'));assert.equal(r.status,400);assert.match((await r.json()).error,/آزمایش/);
 db.prepare("UPDATE applications SET status='writing' WHERE id=?").bind(mainId).run();
 assert.equal((await orders.PUT(req('/api/student/application',{profile},cookie,'PUT'))).status,409);
});

test('additional service keeps old program and payment history intact, with separate invoice and retry-safe checkout',async()=>{
 db.prepare("INSERT INTO current_program_deliveries(client_id,plan_hash,delivered_at) VALUES(?,?,?)").bind(clientId,'original-program-hash',new Date().toISOString()).run();
 const previous=db.prepare('SELECT * FROM applications WHERE id=?').bind(mainId).first();
 const originalEvents=JSON.stringify(db.prepare('SELECT * FROM billing_events').all().results);
 const body={packageIds:['nutrition','supplements'],addon:true,requestId:randomUUID()};
 assert.equal((await orders.POST(req('/api/student/application',body))).status,401);
 assert.equal((await orders.POST(req('/api/student/application',body,cookie,'POST','https://foreign.test'))).status,403);
 const responses=await Promise.all([orders.POST(req('/api/student/application',body,cookie)),orders.POST(req('/api/student/application',body,cookie))]);
 assert.ok(responses.every(r=>r.status===200));const values=await Promise.all(responses.map(r=>r.json()));assert.ok(values.every(v=>v.applicationId===body.requestId));
 const created=db.prepare('SELECT * FROM applications WHERE id=?').bind(body.requestId).first();assert.equal(created.parent_application_id,mainId);assert.equal(created.price_amount,1600000);
 assert.deepEqual(db.prepare('SELECT * FROM applications WHERE id=?').bind(mainId).first(),previous);
 assert.equal(JSON.stringify(db.prepare('SELECT * FROM billing_events').all().results),originalEvents);
 assert.equal(db.prepare('SELECT plan_hash FROM current_program_deliveries WHERE client_id=?').bind(clientId).first().plan_hash,'original-program-hash');
 assert.equal(db.prepare('SELECT count(*) AS n FROM applications').first().n,2);
 assert.equal((await orders.POST(req('/api/student/application',{...body,packageIds:['training']},cookie))).status,409);
 // An unresolved checkout must not be bypassed by clicking "add service" again.
 assert.equal((await orders.POST(req('/api/student/application',{...body,requestId:randomUUID()},cookie))).status,409);
 const read=await (await orders.GET(req('/api/student/application',undefined,cookie,'GET'))).json();assert.equal(read.application.id,body.requestId);assert.equal(read.applications.length,2);
});

test('coach accounting preserves all service names and stored price snapshot when editing a combined order',async()=>{
 const coachCookie=`power_home_session=${await auth.createSessionToken()}`;
 const quote=prices.quotePackages(['training','cycle']);
 const r=await billing.PUT(req('/api/billing',{applicationId:mainId,clientId,packageId:'training',packageIds:['training','cycle'],packageName:quote.name,listAmount:quote.price,discountAmount:100000,receivedAmount:0},coachCookie,'PUT'));
 assert.equal(r.status,200);
 const record=(await r.json()).record;assert.equal(record.final_amount,quote.price-100000);assert.match(record.package_name,/تمرینی.*دارویی/);
 assert.deepEqual(JSON.parse(db.prepare('SELECT package_items_json FROM applications WHERE id=?').bind(mainId).first().package_items_json).map(p=>p.id),['training','cycle']);
});

test('multi-service choices render accessible checkboxes and combined total',async()=>{
 const {PackageChoices}=await load('/components/package-choices.tsx');
 const html=renderToStaticMarkup(React.createElement(PackageChoices,{packages:prices.getPackages(),selected:['training','cycle'],onChange:()=>{}}));
 assert.equal((html.match(/type="checkbox"/g)||[]).length,7);assert.equal((html.match(/checked=""/g)||[]).length,2);assert.match(html,/جمع خدمات انتخابی/);
});

test('delivering the parent order does not complete or bypass the pending additional-service checkout',async()=>{
 const delivery=await load('/app/api/program-delivery/route.ts');
 const coachCookie=`power_home_session=${await auth.createSessionToken()}`;
 const addon=db.prepare('SELECT id FROM applications WHERE parent_application_id=?').bind(mainId).first();
 assert.ok(addon);
 const response=await delivery.POST(req('/api/program-delivery',{clientId,applicationId:mainId},coachCookie));assert.equal(response.status,200);
 assert.equal(db.prepare('SELECT status FROM applications WHERE id=?').bind(mainId).first().status,'delivered');
 assert.equal(db.prepare('SELECT status FROM applications WHERE id=?').bind(addon.id).first().status,'draft');
 const payload=await (await orders.GET(req('/api/student/application',undefined,cookie,'GET'))).json();assert.equal(payload.canRequestNew,false);
 assert.equal((await orders.POST(req('/api/student/application',{packageIds:['training']},cookie))).status,409);
});
