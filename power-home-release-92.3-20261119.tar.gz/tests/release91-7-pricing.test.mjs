import assert from "node:assert/strict";
import test, {after} from "node:test";
import {mkdtempSync} from "node:fs";
import {tmpdir} from "node:os";
import path from "node:path";
import {fileURLToPath} from "node:url";
import {DatabaseSync} from "node:sqlite";
import {createServer} from "vite";
import {renderToStaticMarkup} from "react-dom/server";
import React from "react";

const root=fileURLToPath(new URL("..",import.meta.url));
process.env.APP_DATA_DIR=mkdtempSync(path.join(tmpdir(),"power-home-r917-"));
process.env.APP_SESSION_SECRET="test-session-secret-release917";
const vite=await createServer({appType:"custom",configFile:false,root,resolve:{alias:{"@":root}},server:{middlewareMode:true}});
after(async()=>vite.close());
const catalog=await vite.ssrLoadModule("/app/api/packages/route.ts");
const auth=await vite.ssrLoadModule("/lib/password-auth.ts");
const {database}=await vite.ssrLoadModule("/lib/raw-db.ts");
const registration=await vite.ssrLoadModule("/app/api/register/route.ts");
const renewal=await vite.ssrLoadModule("/app/api/student/application/route.ts");
const coachCookie=`power_home_session=${await auth.createSessionToken()}`;
const request=(route,body,cookie=coachCookie,origin="https://coach.test")=>new Request(`https://coach.test${route}`,{method:"POST",headers:{host:"coach.test",origin,"content-type":"application/json",cookie},body:JSON.stringify(body)});
const put=(body,cookie=coachCookie,origin)=>catalog.PUT(request("/api/packages",body,cookie,origin));

test("catalog edits are authorized, durable, atomic and apply to both new and returning students",async()=>{
  const initial=await (await catalog.GET()).json();
  assert.equal(initial.packages.length,7);
  const prices=initial.packages.map(item=>({id:item.id,price:item.price+12345}));
  assert.equal((await put({prices},"")).status,403);
  assert.equal((await put({prices},coachCookie,"https://foreign.test")).status,403);
  assert.deepEqual((await (await catalog.GET()).json()).packages,initial.packages);
  assert.equal((await put({prices})).status,200);
  const disk=new DatabaseSync(path.join(process.env.APP_DATA_DIR,"power-home.sqlite"));
  assert.equal(disk.prepare("SELECT price FROM package_prices WHERE package_id='training'").get().price,812345);
  disk.close();
  for (const invalid of [
    prices.map((p,i)=>i===0?{...p,price:-1}:p),
    prices.map((p,i)=>i===0?{...p,price:1.5}:p),
    prices.map((p,i)=>i===0?{...p,price:2000000001}:p),
    prices.map((p,i)=>i===0?{...p,price:"800"}:p),
    prices.map((p,i)=>i===0?{...p,id:"unknown"}:p),
    prices.map((p,i)=>i===0?prices[1]:p),
    prices.slice(1),
  ]) assert.equal((await put({prices:invalid})).status,400);
  assert.equal((await (await catalog.GET()).json()).packages.find(p=>p.id==="training").price,812345);
  const response=await registration.POST(request("/api/register",{name:"شاگرد آزمایشی",phone:"09123456789",password:"123456",packageId:"training"},""));
  assert.equal(response.status,200);
  const created=await response.json();
  assert.equal(created.priceAmount,812345);
  const studentCookie=response.headers.get("set-cookie").split(";")[0];
  const db=database();
  const first=db.prepare("SELECT * FROM applications WHERE id=?").bind(created.applicationId).first();
  assert.equal(first.price_amount,812345);
  assert.equal((await put({prices},studentCookie)).status,403);
  const nextPrices=prices.map(p=>({...p,price:p.price+100000}));
  assert.equal((await put({prices:nextPrices})).status,200);
  assert.equal(db.prepare("SELECT price_amount FROM applications WHERE id=?").bind(first.id).first().price_amount,812345);
  assert.equal((await renewal.POST(request("/api/student/application",{packageId:"training"},studentCookie))).status,409);
  db.prepare("UPDATE applications SET status='delivered' WHERE id=?").bind(first.id).run();
  const renewed=await renewal.POST(request("/api/student/application",{packageId:"training",priceAmount:1},studentCookie));
  assert.equal(renewed.status,200);
  const next=await renewed.json();
  assert.equal(next.priceAmount,912345);
  assert.equal(db.prepare("SELECT price_amount FROM applications WHERE id=?").bind(next.applicationId).first().price_amount,912345);
  assert.equal(db.prepare("SELECT price_amount FROM applications WHERE id=?").bind(first.id).first().price_amount,812345);
});

test("payment details render the supplied card, bank and holder with a copy control",async()=>{
  const {PaymentDetails}=await vite.ssrLoadModule("/components/payment-details.tsx");
  const html=renderToStaticMarkup(React.createElement(PaymentDetails));
  assert.match(html,/6219 8619 8827 0095/);
  assert.match(html,/dir="ltr"/);
  assert.match(html,/بلو بانک/);
  assert.match(html,/علیرضا سرخه/);
  assert.match(html,/کپی شماره کارت/);
});
