import { coachDataKey, sensitiveSession } from "@/lib/password-auth";
import { database } from "@/lib/raw-db";
import { getExerciseBucket } from "@/lib/storage";
import { studentIdFromRequest } from "@/lib/student-auth";
export async function GET(request:Request,{params}:{params:Promise<{id:string}>}) {
  try {
    const coach = await sensitiveSession(request);
    const studentId = await studentIdFromRequest(request);
    if(!coach && !studentId) return new Response(null,{status:401,headers:{"cache-control":"no-store"}});
    const {id}=await params;
    const photo=await database().prepare("SELECT p.key,c.client_id FROM body_photos p JOIN checkins c ON c.id=p.checkin_id WHERE p.id=? AND p.owner=?").bind(id,coachDataKey()).first<{key:string;client_id:string}>();
    if(photo && !coach && photo.client_id!==studentId) return new Response(null,{status:404});
    if(!photo) return new Response(null,{status:404});
    const object=await getExerciseBucket().get(photo.key);
    if(!object) return new Response(null,{status:404});
    return new Response(object.body,{headers:{"content-type":object.httpMetadata?.contentType??"image/jpeg","cache-control":"private, no-store","x-content-type-options":"nosniff","content-disposition":"inline"}});
  }catch{return new Response(null,{status:503});}
}
