import { coachDataKey, sensitiveSession } from "@/lib/password-auth";
import { database, sameOrigin } from "@/lib/raw-db";
import { POSES } from "@/lib/checkin-data";
import { getExerciseBucket } from "@/lib/storage";
export async function POST(request:Request) {
  try {
    if(!sameOrigin(request) || !(await sensitiveSession(request))) return new Response(null,{status:403});
    const form=await request.formData(); const file=form.get("image"); const recordId=form.get("checkinId"); const pose=form.get("pose");
    if(form.get("consent")!=="yes" || typeof pose!=="string" || !Object.hasOwn(POSES,pose) || typeof recordId!=="string" || !(file instanceof File)) return new Response(null,{status:400});
    if(file.size<1 || file.size>8*1024*1024 || !["image/jpeg","image/png","image/webp"].includes(file.type)) return Response.json({error:"عکس JPG، PNG یا WebP تا ۸ مگابایت انتخاب کنید."},{status:400});
    const record=await database().prepare("SELECT id FROM checkins WHERE id=? AND owner=?").bind(recordId,coachDataKey()).first();
    if(!record) return new Response(null,{status:404});
    const bytes=await file.arrayBuffer(); const b=new Uint8Array(bytes);
    const valid=(file.type==="image/jpeg" && b[0]===255 && b[1]===216 && b[2]===255)||(file.type==="image/png" && b[0]===137 && b[1]===80 && b[2]===78 && b[3]===71)||(file.type==="image/webp" && new TextDecoder().decode(b.slice(0,4))==="RIFF" && new TextDecoder().decode(b.slice(8,12))==="WEBP");
    if(!valid) return new Response(null,{status:415});
    const previous=await database().prepare("SELECT id,key FROM body_photos WHERE owner=? AND checkin_id=? AND pose=?").bind(coachDataKey(),recordId,pose).first<{id:string;key:string}>();
    const id=crypto.randomUUID(); const key=`body-photos/${id}`;
    await getExerciseBucket().put(key,bytes,{httpMetadata:{contentType:file.type}});
    try {
      if(previous)await database().prepare("UPDATE body_photos SET id=?,key=? WHERE owner=? AND checkin_id=? AND pose=?").bind(id,key,coachDataKey(),recordId,pose).run();
      else await database().prepare("INSERT INTO body_photos (id, owner, checkin_id, pose, key) VALUES (?, ?, ?, ?, ?)").bind(id,coachDataKey(),recordId,pose,key).run();
    } catch { await getExerciseBucket().delete(key); return Response.json({error:"این نما قبلاً ثبت شده؛ سوابق را دوباره بارگیری کنید."},{status:409}); }
    if(previous)await getExerciseBucket().delete(previous.key);
    return Response.json({url:`/api/body-photos/${id}`});
  }catch{return Response.json({error:"آپلود عکس انجام نشد؛ می‌توانید دوباره تلاش کنید."},{status:503});}
}

export async function DELETE(request:Request){
  try{
    if(!sameOrigin(request)||!(await sensitiveSession(request)))return new Response(null,{status:403});
    const body=await request.json() as {checkinId?:unknown;pose?:unknown};
    if(typeof body.checkinId!=="string"||typeof body.pose!=="string"||!Object.hasOwn(POSES,body.pose))return new Response(null,{status:400});
    const photo=await database().prepare("SELECT key FROM body_photos WHERE owner=? AND checkin_id=? AND pose=?").bind(coachDataKey(),body.checkinId,body.pose).first<{key:string}>();
    if(!photo)return new Response(null,{status:404});
    await database().prepare("DELETE FROM body_photos WHERE owner=? AND checkin_id=? AND pose=?").bind(coachDataKey(),body.checkinId,body.pose).run();
    await getExerciseBucket().delete(photo.key);
    return Response.json({ok:true});
  }catch{return Response.json({error:"حذف عکس انجام نشد."},{status:400});}
}
