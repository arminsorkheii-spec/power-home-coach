import { pushPublicKey } from "@/lib/push-notifications";
export async function GET(){const publicKey=pushPublicKey();return publicKey?Response.json({publicKey},{headers:{"cache-control":"no-store"}}):Response.json({error:"اعلان هنوز تنظیم نشده است."},{status:503});}
