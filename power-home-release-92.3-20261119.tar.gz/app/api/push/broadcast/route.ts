import { z } from "zod";
import { sensitiveSession } from "@/lib/password-auth";
import { sameOrigin } from "@/lib/raw-db";
import { sendPush } from "@/lib/push-notifications";

const schema=z.object({
  title:z.string().trim().min(2).max(60),
  body:z.string().trim().min(3).max(240),
});

export async function POST(request:Request){
  if(!sameOrigin(request)||!(await sensitiveSession(request)))return new Response(null,{status:403});
  try{
    const message=schema.parse(await request.json());
    const result=await sendPush("student",null,{...message,url:"/student",tag:`coach-${Date.now()}`});
    if(!result.configured)return Response.json({error:"سرویس اعلان هنوز تنظیم نشده است."},{status:503});
    return Response.json(result,{headers:{"cache-control":"no-store"}});
  }catch(error){
    return Response.json({error:error instanceof z.ZodError?"عنوان و متن اعلان را کامل وارد کنید.":"ارسال اعلان انجام نشد."},{status:400});
  }
}
