import { requestHasValidSession } from "@/lib/password-auth";
import { getExerciseBucket } from "@/lib/storage";

type RouteContext = { params: Promise<{ key: string }> };

function safeKey(value: string) {
  return /^[0-9a-f-]+\.(jpg|png|webp)$/i.test(value) ? value : null;
}

export async function GET(request: Request, context: RouteContext) {
  if (!(await requestHasValidSession(request))) {
    return new Response("Unauthorized", { status: 401 });
  }
  const { key: rawKey } = await context.params;
  const key = safeKey(rawKey);
  if (!key) return new Response("Not found", { status: 404 });

  const object = await getExerciseBucket().get(`exercise-images/${key}`);
  if (!object) return new Response("Not found", { status: 404 });

  const headers = new Headers();
  object.writeHttpMetadata(headers);
  headers.set("etag", object.httpEtag);
  headers.set("cache-control", "private, max-age=86400");
  headers.set("x-content-type-options", "nosniff");
  return new Response(object.body, { headers });
}

export async function DELETE(request: Request, context: RouteContext) {
  if (!(await requestHasValidSession(request))) {
    return Response.json({ error: "ورود با رمز لازم است." }, { status: 401 });
  }
  const { key: rawKey } = await context.params;
  const key = safeKey(rawKey);
  if (!key) return Response.json({ error: "عکس پیدا نشد." }, { status: 404 });
  await getExerciseBucket().delete(`exercise-images/${key}`);
  return Response.json({ ok: true });
}
