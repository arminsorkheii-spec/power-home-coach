import { requestHasValidSession } from "@/lib/password-auth";
import { getExerciseBucket } from "@/lib/storage";

const MAX_IMAGE_BYTES = 8 * 1024 * 1024;
const EXTENSIONS: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
};

export async function POST(request: Request) {
  if (!(await requestHasValidSession(request))) {
    return Response.json({ error: "ورود با رمز لازم است." }, { status: 401 });
  }

  try {
    const form = await request.formData();
    const image = form.get("image");
    if (!(image instanceof File)) {
      return Response.json({ error: "یک عکس انتخاب کنید." }, { status: 400 });
    }
    const extension = EXTENSIONS[image.type];
    if (!extension) {
      return Response.json({ error: "فرمت عکس باید JPG، PNG یا WebP باشد." }, { status: 415 });
    }
    if (image.size <= 0 || image.size > MAX_IMAGE_BYTES) {
      return Response.json({ error: "حجم عکس باید کمتر از ۸ مگابایت باشد." }, { status: 413 });
    }

    const key = `${crypto.randomUUID()}.${extension}`;
    await getExerciseBucket().put(`exercise-images/${key}`, await image.arrayBuffer(), {
      httpMetadata: { contentType: image.type },
      customMetadata: { originalName: image.name.slice(0, 120) },
    });

    return Response.json({ key, url: `/api/exercise-images/${key}` }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : "ذخیره عکس انجام نشد.";
    return Response.json({ error: message }, { status: 500 });
  }
}
