import { z } from "zod";
import { requestHasValidSession } from "@/lib/password-auth";
import { database, sameOrigin } from "@/lib/raw-db";
import { getSmsSettings, saveSmsSettings, smsSettingsSchema, SmsSettingsError } from "@/lib/sms";
export async function GET(request:Request){
  if(!await requestHasValidSession(request))return new Response(null,{status:401});
  const deliveries=database().prepare("SELECT role,status,substr(phone,1,4)||'***'||substr(phone,-4) AS phone,updated_at FROM sms_deliveries ORDER BY updated_at DESC LIMIT 20").all().results;
  return Response.json({settings:getSmsSettings(),deliveries},{headers:{"cache-control":"no-store"}});
}
export async function PUT(request:Request){
  if(!sameOrigin(request)||!await requestHasValidSession(request))return new Response(null,{status:403});
  try{
    const body=smsSettingsSchema.parse(await request.json());
    return Response.json({ok:true,settings:saveSmsSettings(body)},{headers:{"cache-control":"no-store"}});
  }catch(e){
    if(e instanceof SmsSettingsError)return Response.json({error:e.message,field:e.field},{status:400,headers:{"cache-control":"no-store"}});
    return Response.json({error:e instanceof z.ZodError?"تنظیمات پیامک را کامل و درست وارد کنید.":"ذخیره انجام نشد؛ کلید API، شناسه قالب‌ها و شماره مربی را بررسی کنید."},{status:400,headers:{"cache-control":"no-store"}});
  }
}

// Login and outbound notifications save independently: incomplete notification
// fields must never prevent saving a valid OTP configuration.
export async function PATCH(request:Request){
 if(!sameOrigin(request)||!await requestHasValidSession(request))return new Response(null,{status:403});
 try{
  const body=z.object({section:z.enum(["login","notifications"]),settings:z.record(z.unknown())}).strict().parse(await request.json());
  const selected=body.section==="login"?smsSettingsSchema.pick({apiKey:true,loginEnabled:true,otpTemplateId:true,otpParameter:true}):smsSettingsSchema.pick({apiKey:true,notificationsEnabled:true,lineNumber:true,coachPhone:true,notificationTemplateId:true,notificationParameter:true,stageMessages:true});
  const patch=selected.parse(body.settings);
  const {apiKeyConfigured,...previous}=getSmsSettings();void apiKeyConfigured;
  return Response.json({ok:true,settings:saveSmsSettings(smsSettingsSchema.parse({...previous,...patch}))},{headers:{"cache-control":"no-store"}});
 }catch(e){
  const field=e instanceof SmsSettingsError?e.field:e instanceof z.ZodError?String(e.issues[0]?.path.at(-1)??""):"";
  const error=e instanceof SmsSettingsError?e.message:e instanceof z.ZodError?"تنظیمات این بخش را کامل و درست وارد کنید.":"ذخیره تنظیمات انجام نشد؛ دوباره تلاش کنید.";
  return Response.json({error,field},{status:400,headers:{"cache-control":"no-store"}});
 }
}
