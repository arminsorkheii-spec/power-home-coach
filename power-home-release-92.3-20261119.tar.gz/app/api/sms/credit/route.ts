import { requestHasValidSession } from "@/lib/password-auth";
import { smsCredit } from "@/lib/sms";
export async function GET(request:Request){
  if(!await requestHasValidSession(request))return new Response(null,{status:401});
  try{return Response.json(await smsCredit(),{headers:{"cache-control":"no-store"}});}
  catch{return Response.json({error:"اتصال به SMS.ir برقرار نشد؛ کلید API ذخیره‌شده و دسترسی پنل را بررسی کنید."},{status:502,headers:{"cache-control":"no-store"}});}
}
