import { createHash } from "node:crypto";
import { z } from "zod";
import { requestHasValidSession } from "@/lib/password-auth";
import { database, sameOrigin } from "@/lib/raw-db";
import { getSmsSettings, sendBulkSms, SmsSendError } from "@/lib/sms";
import { normalizePhone } from "@/lib/student-auth";
const schema=z.object({requestId:z.string().uuid(),clientIds:z.array(z.string().min(1).max(120)).min(1).max(100),message:z.string().trim().min(1).max(1200)}).strict();
const headers={"cache-control":"no-store"};
export async function GET(request:Request){
  if(!await requestHasValidSession(request))return new Response(null,{status:401});
  return Response.json({campaigns:database().prepare("SELECT request_id,message,recipient_count,status,created_at FROM sms_campaigns ORDER BY created_at DESC LIMIT 10").all().results},{headers});
}
export async function POST(request:Request){
  if(!sameOrigin(request)||!await requestHasValidSession(request))return new Response(null,{status:403});
  try{
    const body=schema.parse(await request.json()),ids=[...new Set(body.clientIds)].sort(),db=database();
    const settings=getSmsSettings();
    if(!settings.apiKeyConfigured||Number(settings.lineNumber)<=0||!Number.isSafeInteger(Number(settings.lineNumber)))return Response.json({error:"کلید API و خط ارسال را ابتدا در تنظیمات ذخیره کنید."},{status:503,headers});
    const rows=db.prepare(`SELECT phone FROM student_accounts WHERE client_id IN (${ids.map(()=>"?").join(",")})`).bind(...ids).all<{phone:string}>().results;
    if(rows.length!==ids.length)return Response.json({error:"یکی از گیرنده‌ها معتبر نیست؛ فهرست شاگردان را تازه‌سازی کنید."},{status:400,headers});
    const phones=[...new Set(rows.map(r=>normalizePhone(r.phone)))];
    if(phones.some(p=>!/^09\d{9}$/.test(p)))return Response.json({error:"شماره موبایل یکی از گیرنده‌ها معتبر نیست."},{status:400,headers});
    const hash=createHash("sha256").update(JSON.stringify([ids,body.message])).digest("hex"),now=new Date().toISOString();
    const inserted=db.prepare("INSERT OR IGNORE INTO sms_campaigns (request_id,payload_hash,message,recipient_count,status,created_at,updated_at) VALUES (?,?,?,?,'pending',?,?)").bind(body.requestId,hash,body.message,phones.length,now,now).run();
    if(!Number(inserted.changes)){
      const old=db.prepare("SELECT payload_hash,status,recipient_count FROM sms_campaigns WHERE request_id=?").bind(body.requestId).first<{payload_hash:string;status:string;recipient_count:number}>()!;
      if(old.payload_hash!==hash)return Response.json({error:"شناسه ارسال تکراری است؛ یک پیام جدید بسازید."},{status:409,headers});
      return Response.json({status:old.status,count:old.recipient_count,repeated:true},{headers});
    }
    try{
      const result=await sendBulkSms(phones,body.message);
      db.prepare("UPDATE sms_campaigns SET status='accepted',pack_id=?,updated_at=? WHERE request_id=?").bind(result.packId,new Date().toISOString(),body.requestId).run();
      return Response.json({status:"accepted",count:phones.length},{headers});
    }catch(e){
      const status=e instanceof SmsSendError&&e.uncertain?"unknown":"failed";
      db.prepare("UPDATE sms_campaigns SET status=?,updated_at=? WHERE request_id=?").bind(status,new Date().toISOString(),body.requestId).run();
      return Response.json({status,count:phones.length},{headers});
    }
  }catch{return Response.json({error:"متن پیامک و گیرنده‌ها را درست وارد کنید؛ حداکثر ۱۰۰ نفر در هر ارسال."},{status:400,headers});}
}
