import { z } from "zod";
import { blankPlan, DEFAULT_STATE, type CoachState } from "@/lib/coach-data";
import { coachDataKey } from "@/lib/password-auth";
import { quotePackages, PackageSelectionError } from "@/lib/package-pricing";
import { database, sameOrigin } from "@/lib/raw-db";
import { createStudentSession, deriveStudentPassword, normalizeDigits, normalizePhone, studentSessionCookie } from "@/lib/student-auth";
import { createNotification } from "@/lib/notifications";

const schema = z.object({
  name: z.string().trim().min(2).max(80),
  phone: z.string().max(30),
  password: z.string().min(1).max(20),
  packageId: z.string().max(40).optional(),
  packageIds: z.array(z.string().max(40)).min(1).max(7).optional(),
});

export async function POST(request: Request) {
  if (!sameOrigin(request)) return new Response(null, { status: 403 });
  try {
    const data = schema.parse(await request.json());
    const phone = normalizePhone(data.phone);
    const password = normalizeDigits(data.password).replace(/\D/g, "");
    const selectedPackage = quotePackages(data.packageIds ?? (data.packageId ? [data.packageId] : []));
    if (!/^09\d{9}$/.test(phone) || !/^\d{6}$/.test(password) || !selectedPackage) return Response.json({ error: "شماره موبایل، رمز ۶ رقمی یا پکیج معتبر نیست." }, { status: 400 });
    const db = database();
    const previous = await db.prepare("SELECT client_id FROM student_accounts WHERE phone=?").bind(phone).first<{ client_id: string }>();
    if (previous) return Response.json({ error: "این شماره قبلاً ثبت شده؛ از صفحه ورود شاگرد وارد شوید." }, { status: 409 });

    const clientId = crypto.randomUUID();
    const applicationId = crypto.randomUUID();
    const salt = crypto.randomUUID();
    const revision = crypto.randomUUID();
    const passwordHash = await deriveStudentPassword(password, salt);
    const now = new Date().toISOString();
    const stateRow = await db.prepare("SELECT payload FROM coach_states WHERE owner_email=?").bind(coachDataKey()).first<{ payload: string }>();
    const state = stateRow ? JSON.parse(stateRow.payload) as CoachState : JSON.parse(JSON.stringify(DEFAULT_STATE)) as CoachState;
    state.clients.push({ id: clientId, name: data.name, phone, goal: selectedPackage.name, notes: "ثبت‌نام آنلاین؛ فرم اولیه در بخش درخواست‌ها" });
    state.plans[clientId] = blankPlan();
    state.syncRevision = Math.max(Date.now(), Number(state.syncRevision ?? 0) + 1);

    await db.batch([
      db.prepare("INSERT INTO student_accounts (client_id,phone,password_hash,salt,revision,created_at,updated_at) VALUES (?,?,?,?,?,?,?)").bind(clientId, phone, passwordHash, salt, revision, now, now),
      db.prepare("INSERT INTO applications (id,client_id,package_id,package_name,status,price_amount,profile_json,created_at,updated_at,package_items_json) VALUES (?,?,?,?,?,?,?,?,?,?)").bind(applicationId, clientId, selectedPackage.id, selectedPackage.name, "draft", selectedPackage.price, JSON.stringify({ name: data.name }), now, now, JSON.stringify(selectedPackage.items)),
    ]);
    try {
      await db.prepare("INSERT INTO coach_states (owner_email,payload,updated_at) VALUES (?,?,?) ON CONFLICT(owner_email) DO UPDATE SET payload=excluded.payload, updated_at=excluded.updated_at").bind(coachDataKey(), JSON.stringify(state), now).run();
    } catch (stateError) {
      console.error("student_registration_state_sync_failed", stateError);
    }
    await createNotification({role:"coach",actorClientId:clientId,applicationId,type:"registration",title:"ثبت‌نام جدید",body:`${data.name} ثبت‌نام کرد و ${selectedPackage.name} را انتخاب کرد.`,url:"/coach",tag:`register-${applicationId}`});
    await createNotification({role:"student",clientId,applicationId,type:"welcome",title:"خوش آمدی",body:"ثبت‌نامت با موفقیت انجام شد.",url:"/student",tag:`welcome-${applicationId}`});
    const token = await createStudentSession(clientId, revision);
    return Response.json({ ok: true, applicationId, priceAmount: selectedPackage.price }, { headers: { "set-cookie": studentSessionCookie(token), "cache-control": "no-store" } });
  } catch (error) {
    if(error instanceof PackageSelectionError)return Response.json({error:error.message},{status:400});
    console.error("student_registration_failed", error);
    const message = error instanceof z.ZodError ? "نام، موبایل و رمز ۶ رقمی را درست وارد کنید." : "ثبت‌نام انجام نشد؛ دوباره تلاش کنید.";
    return Response.json({ error: message }, { status: error instanceof z.ZodError ? 400 : 500 });
  }
}
