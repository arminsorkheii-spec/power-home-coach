import { sensitiveSession } from "@/lib/password-auth";
import { database, sameOrigin } from "@/lib/raw-db";
import { getExerciseBucket } from "@/lib/storage";

const PHOTO_KINDS = new Set(["front", "side", "back", "front_double", "back_double"]);
const KINDS = new Set([...PHOTO_KINDS, "receipt"]);

function validImage(type: string, bytes: Uint8Array) {
  return (type === "image/jpeg" && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255) ||
    (type === "image/png" && bytes[0] === 137 && bytes[1] === 80 && bytes[2] === 78 && bytes[3] === 71) ||
    (type === "image/webp" && new TextDecoder().decode(bytes.slice(0, 4)) === "RIFF" && new TextDecoder().decode(bytes.slice(8, 12)) === "WEBP");
}

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!sameOrigin(request) || !(await sensitiveSession(request))) return new Response(null, { status: 403 });
  try {
    const { id: applicationId } = await params;
    const form = await request.formData();
    const file = form.get("file");
    const kind = form.get("kind");
    if (!(file instanceof File) || typeof kind !== "string" || !KINDS.has(kind)) return new Response(null, { status: 400 });
    const allowed = PHOTO_KINDS.has(kind) ? ["image/jpeg", "image/png", "image/webp"] : ["image/jpeg", "image/png", "image/webp", "application/pdf"];
    if (!allowed.includes(file.type) || file.size < 1 || file.size > 8 * 1024 * 1024) {
      return Response.json({ error: "تصویر یا PDF معتبر تا ۸ مگابایت انتخاب کنید." }, { status: 400 });
    }
    const bytes = new Uint8Array(await file.arrayBuffer());
    const validPdf = file.type === "application/pdf" && new TextDecoder().decode(bytes.slice(0, 5)) === "%PDF-";
    if (!validImage(file.type, bytes) && !validPdf) return Response.json({ error: "فایل انتخاب‌شده معتبر نیست." }, { status: 415 });
    const db = database();
    const application = await db.prepare("SELECT client_id FROM applications WHERE id=?").bind(applicationId).first<{ client_id: string }>();
    if (!application) return new Response(null, { status: 404 });
    const previous = await db.prepare("SELECT id,key FROM application_uploads WHERE application_id=? AND kind=?").bind(applicationId, kind).first<{ id: string; key: string }>();
    const uploadId = crypto.randomUUID();
    const key = `student-applications/${application.client_id}/${applicationId}/${uploadId}`;
    await getExerciseBucket().put(key, bytes, { httpMetadata: { contentType: file.type }, customMetadata: { originalName: file.name, kind, uploadedBy: "coach" } });
    await db.batch([
      ...(previous ? [db.prepare("DELETE FROM application_uploads WHERE id=?").bind(previous.id)] : []),
      db.prepare("INSERT INTO application_uploads (id,application_id,client_id,kind,key,filename,content_type,size,created_at) VALUES (?,?,?,?,?,?,?,?,?)").bind(uploadId, applicationId, application.client_id, kind, key, file.name.slice(0, 180), file.type, file.size, new Date().toISOString()),
    ]);
    if (previous) await getExerciseBucket().delete(previous.key).catch(() => undefined);
    return Response.json({ ok: true, id: uploadId });
  } catch {
    return Response.json({ error: "ثبت عکس توسط مربی انجام نشد؛ دوباره تلاش کنید." }, { status: 503 });
  }
}
