import {
  DEFAULT_STATE,
  FAT_LOSS_58_CLIENT,
  FAT_LOSS_58_CLIENT_ID,
  FAT_LOSS_58_PLAN,
  FAT_LOSS_58_SEED,
  MEHRAD_KIAN_PLAN,
  MEHRAD_KIAN_SEED,
  MOHAMMAD_ZAREH_CLIENT,
  MOHAMMAD_ZAREH_CLIENT_ID,
  MOHAMMAD_ZAREH_PLAN,
  MOHAMMAD_ZAREH_SEED,
  type CoachState,
} from "@/lib/coach-data";
import { coachDataKey, requestHasValidSession } from "@/lib/password-auth";
import { database } from "@/lib/raw-db";

const MAX_STATE_SIZE = 8_000_000;

async function ownerKey(request: Request) {
  return (await requestHasValidSession(request)) ? coachDataKey() : null;
}

function errorMessage(error: unknown) {
  const message = error instanceof Error ? error.message : "خطای ناشناخته";
  if (message.includes("no such table")) {
    return "پایگاه داده هنوز آماده نشده است. چند لحظه بعد دوباره تلاش کنید.";
  }
  return message;
}

function cloneDefaultState() {
  return JSON.parse(JSON.stringify(DEFAULT_STATE)) as CoachState;
}

function ensureSeededPrograms(value: unknown): { state: CoachState; changed: boolean } {
  if (!value || typeof value !== "object") {
    const state = cloneDefaultState();
    state.activeClientId = MOHAMMAD_ZAREH_CLIENT_ID;
    return { state, changed: true };
  }

  const candidate = value as Partial<CoachState>;
  if (
    candidate.version !== 1 ||
    !Array.isArray(candidate.clients) ||
    !candidate.plans ||
    typeof candidate.plans !== "object" ||
    typeof candidate.activeClientId !== "string"
  ) {
    throw new Error("اطلاعات ذخیره‌شده پنل معتبر نیست.");
  }

  const state = candidate as CoachState;
  const seeds = [
    { seed: FAT_LOSS_58_SEED, clientId: FAT_LOSS_58_CLIENT_ID, client: FAT_LOSS_58_CLIENT, plan: FAT_LOSS_58_PLAN },
    { seed: MOHAMMAD_ZAREH_SEED, clientId: MOHAMMAD_ZAREH_CLIENT_ID, client: MOHAMMAD_ZAREH_CLIENT, plan: MOHAMMAD_ZAREH_PLAN },
  ];
  let clients = state.clients;
  let plans = state.plans;
  let seededPrograms = state.seededPrograms ?? [];
  const deletedClientIds = state.deletedClientIds ?? [];
  let changed = false;
  let activateMohammad = false;

  for (const item of seeds) {
    if (deletedClientIds.includes(item.clientId)) continue;
    const hasSeed = seededPrograms.includes(item.seed);
    const hasClient = clients.some((client) => client.id === item.clientId);
    const hasPlan = Boolean(plans[item.clientId]);
    if (hasSeed && hasClient && hasPlan) continue;
    changed = true;
    if (!hasClient) clients = [...clients, item.client];
    if (!hasSeed || !hasPlan) plans = { ...plans, [item.clientId]: item.plan };
    if (!hasSeed) seededPrograms = [...seededPrograms, item.seed];
    if (item.clientId === MOHAMMAD_ZAREH_CLIENT_ID) activateMohammad = true;
  }

  const mehrad = clients.find((client) =>
    client.phone.replace(/\D/g, "") === "09198321003" || client.name.includes("مهراد کیان"),
  );
  if (mehrad && !seededPrograms.includes(MEHRAD_KIAN_SEED)) {
    plans = { ...plans, [mehrad.id]: MEHRAD_KIAN_PLAN };
    seededPrograms = [...seededPrograms, MEHRAD_KIAN_SEED];
    changed = true;
  }

  const normalizedOptionals = !Array.isArray(state.customProgramTemplates) || !state.programUsage || !state.exerciseImageOverrides;
  if (!changed && !normalizedOptionals) return { state, changed: false };
  if (normalizedOptionals) changed = true;

  return {
    changed: true,
    state: {
      ...state,
      activeClientId: activateMohammad ? MOHAMMAD_ZAREH_CLIENT_ID : state.activeClientId,
      clients,
      plans,
      seededPrograms,
      deletedClientIds,
      customExercises: Array.isArray(state.customExercises) ? state.customExercises : [],
      customProgramTemplates: Array.isArray(state.customProgramTemplates) ? state.customProgramTemplates : [],
      programUsage: state.programUsage && typeof state.programUsage === "object" ? state.programUsage : {},
      exerciseImageOverrides: state.exerciseImageOverrides && typeof state.exerciseImageOverrides === "object" ? state.exerciseImageOverrides : {},
    },
  };
}

async function saveState(owner: string, state: CoachState) {
  const payload = JSON.stringify(state);
  await database()
    .prepare("INSERT INTO coach_states (owner_email, payload) VALUES (?, ?) ON CONFLICT(owner_email) DO UPDATE SET payload=excluded.payload, updated_at=CURRENT_TIMESTAMP")
    .bind(owner, payload)
    .run();
}

export async function GET(request: Request) {
  const owner = await ownerKey(request);
  if (!owner) {
    return Response.json({ error: "ورود با رمز لازم است." }, { status: 401 });
  }

  try {
    const row = await database()
      .prepare("SELECT payload FROM coach_states WHERE owner_email = ?")
      .bind(owner)
      .first<{ payload: string }>();

    const ensured = ensureSeededPrograms(row ? JSON.parse(row.payload) : null);
    if (ensured.changed) await saveState(owner, ensured.state);

    return Response.json(
      { state: ensured.state },
      { headers: { "cache-control": "no-store" } },
    );
  } catch (error) {
    return Response.json({ error: errorMessage(error) }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  const owner = await ownerKey(request);
  if (!owner) {
    return Response.json({ error: "ورود با رمز لازم است." }, { status: 401 });
  }

  try {
    const body = (await request.json()) as { state?: unknown; revision?: number };
    if (!body.state || typeof body.state !== "object") {
      return Response.json({ error: "اطلاعات برنامه معتبر نیست." }, { status: 400 });
    }

    const payload = JSON.stringify(body.state);
    if (payload.length > MAX_STATE_SIZE) {
      return Response.json({ error: "حجم برنامه بیش از حد مجاز است." }, { status: 413 });
    }

    const db = database();
    const currentRow = await db.prepare("SELECT payload FROM coach_states WHERE owner_email = ?").bind(owner).first<{ payload: string }>();
    const current = currentRow ? ensureSeededPrograms(JSON.parse(currentRow.payload)).state : null;
    const incoming = ensureSeededPrograms(body.state).state;
    const requestedRevision = Number.isFinite(body.revision) ? Math.max(0, Math.trunc(body.revision!)) : Date.now();
    const currentRevision = Number(current?.syncRevision ?? 0);

    // A slower, older autosave must never overwrite a newer program revision.
    if (current && requestedRevision <= currentRevision) {
      return Response.json({ ok: true, stale: true, revision: currentRevision }, { headers: { "cache-control": "no-store" } });
    }

    // Preserve server-side clients/programs created by registration or another API while the coach page was open.
    let merged = incoming;
    if (current) {
      const deleted = new Set(incoming.deletedClientIds ?? []);
      const incomingIds = new Set(incoming.clients.map((client) => client.id));
      const preservedClients = current.clients.filter((client) => !incomingIds.has(client.id) && !deleted.has(client.id));
      const preservedPlans = Object.fromEntries(
        Object.entries(current.plans).filter(([clientId]) => !incoming.plans[clientId] && !deleted.has(clientId)),
      );
      merged = {
        ...incoming,
        clients: [...incoming.clients, ...preservedClients],
        plans: { ...preservedPlans, ...incoming.plans },
      };
    }
    merged = { ...merged, syncRevision: requestedRevision };

    const ensured = ensureSeededPrograms(merged);
    const ensuredPayload = JSON.stringify(ensured.state);
    if (ensuredPayload.length > MAX_STATE_SIZE) {
      return Response.json({ error: "حجم برنامه بیش از حد مجاز است." }, { status: 413 });
    }
    await saveState(owner, ensured.state);

    return Response.json({ ok: true, revision: requestedRevision }, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    return Response.json({ error: errorMessage(error) }, { status: 500 });
  }
}
