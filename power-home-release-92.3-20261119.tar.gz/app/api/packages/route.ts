import { z } from "zod";
import { PACKAGES } from "@/lib/packages";
import { getPackages } from "@/lib/package-pricing";
import { database, sameOrigin } from "@/lib/raw-db";
import { requestHasValidSession } from "@/lib/password-auth";

export const dynamic = "force-dynamic";
const headers = { "cache-control": "no-store" };
const schema = z.object({ prices: z.array(z.object({
  id: z.string(), price: z.number().int().min(0).max(2_000_000_000),
}).strict()).length(PACKAGES.length) }).strict();

export async function GET() {
  return Response.json({ packages: getPackages() }, { headers });
}

export async function PUT(request: Request) {
  if (!sameOrigin(request) || !(await requestHasValidSession(request))) return new Response(null, {status:403});
  try {
    const { prices } = schema.parse(await request.json());
    const ids = new Set(prices.map(item => item.id));
    if (ids.size !== PACKAGES.length || PACKAGES.some(item => !ids.has(item.id))) {
      return Response.json({error:"فهرست پکیج‌ها معتبر نیست."},{status:400,headers});
    }
    const db = database();
    const now = new Date().toISOString();
    db.batch(prices.map(item => db.prepare("INSERT INTO package_prices (package_id,price,updated_at) VALUES (?,?,?) ON CONFLICT(package_id) DO UPDATE SET price=excluded.price,updated_at=excluded.updated_at").bind(item.id,item.price,now)));
    return Response.json({ok:true,packages:getPackages()},{headers});
  } catch {
    return Response.json({error:"قیمت‌ها باید عدد صحیح بین صفر تا دو میلیارد تومان باشند؛ ذخیره انجام نشد."},{status:400,headers});
  }
}
