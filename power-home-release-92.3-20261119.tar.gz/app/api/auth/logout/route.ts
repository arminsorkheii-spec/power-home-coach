import { clearedSessionCookie } from "@/lib/password-auth";

export async function POST() {
  return Response.json(
    { ok: true },
    {
      headers: {
        "cache-control": "no-store",
        "set-cookie": clearedSessionCookie(),
      },
    },
  );
}
