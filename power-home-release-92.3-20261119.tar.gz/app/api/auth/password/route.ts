import { allowPasswordAttempt, coachDataKey, createSessionToken, derivePassword, getSecurity, passwordMatches, requestHasValidSession, sessionCookie } from "@/lib/password-auth";
import { database, sameOrigin } from "@/lib/raw-db";
export async function GET(request: Request) {
  if (!(await requestHasValidSession(request))) return new Response(null,{status:401});
  return Response.json({configured:Boolean(await getSecurity())},{headers:{"cache-control":"no-store"}});
}
export async function POST(request: Request) {
  if (!sameOrigin(request) || !(await requestHasValidSession(request))) return new Response(null,{status:403});
  try {
    if (!(await allowPasswordAttempt(request))) return Response.json({error:"۱۵ دقیقه بعد دوباره تلاش کنید."},{status:429});
    const {currentPassword, newPassword} = await request.json();
    if (typeof currentPassword !== "string" || currentPassword.length>128 || typeof newPassword !== "string" || newPassword.length<14 || newPassword.length>128 || /^\d+$/.test(newPassword) || new Set(newPassword).size<6) return Response.json({error:"رمز جدید حداقل ۱۴ کاراکتر، با حروف و چند کاراکتر متفاوت باشد."},{status:400});
    if (!(await passwordMatches(currentPassword))) return Response.json({error:"رمز فعلی درست نیست."},{status:401});
    const salt=crypto.randomUUID(); const revision=crypto.randomUUID();
    await database().prepare("INSERT INTO coach_security (owner, password_hash, salt, revision) VALUES (?, ?, ?, ?) ON CONFLICT(owner) DO UPDATE SET password_hash=excluded.password_hash, salt=excluded.salt, revision=excluded.revision").bind(coachDataKey(),await derivePassword(newPassword,salt),salt,revision).run();
    return Response.json({ok:true},{headers:{"cache-control":"no-store","set-cookie":sessionCookie(await createSessionToken())}});
  } catch { return Response.json({error:"تغییر رمز انجام نشد؛ دوباره تلاش کنید."},{status:503}); }
}
