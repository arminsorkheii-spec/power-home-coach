import { allowPasswordAttempt, createSessionToken, passwordMatches, sessionCookie } from "@/lib/password-auth";
import { sameOrigin } from "@/lib/raw-db";

export async function POST(request: Request) {
  if (!sameOrigin(request)) return new Response(null, {status:403});
  try {
    if (!(await allowPasswordAttempt(request))) return Response.json({error:"تلاش‌های زیاد؛ ۱۵ دقیقه بعد دوباره امتحان کنید."}, {status:429});
    const payload = (await request.json()) as { password?: unknown };
    if (typeof payload.password !== "string" || payload.password.length > 128) {
      return Response.json({ error: "رمز معتبر نیست." }, { status: 400 });
    }

    if (!(await passwordMatches(payload.password))) {
      return Response.json(
        { error: "رمز واردشده درست نیست." },
        { status: 401, headers: { "cache-control": "no-store" } },
      );
    }

    const token = await createSessionToken();
    return Response.json(
      { ok: true },
      {
        headers: {
          "cache-control": "no-store",
          "set-cookie": sessionCookie(token),
        },
      },
    );
  } catch {
    return Response.json({ error: "ورود انجام نشد؛ دوباره تلاش کنید." }, { status: 400 });
  }
}
