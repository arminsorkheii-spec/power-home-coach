import { z } from "zod";
import { coachDataKey, sensitiveSession } from "@/lib/password-auth";
import { database, sameOrigin } from "@/lib/raw-db";
import { getExerciseBucket } from "@/lib/storage";
import type { CoachState } from "@/lib/coach-data";
import { normalizePhone } from "@/lib/student-auth";


const patchSchema = z.object({
  name: z.string().trim().min(1).max(100),
  phone: z.string().max(30),
  goal: z.string().max(500),
  notes: z.string().max(3000),
  initialMeasurements: z.object({
    weight: z.number().finite().min(0).max(500).nullable().optional(),
    height: z.number().finite().min(0).max(250).nullable().optional(),
    waist: z.number().finite().min(0).max(300).nullable().optional(),
    arm: z.number().finite().min(0).max(150).nullable().optional(),
  }).optional(),
});

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!sameOrigin(request) || !(await sensitiveSession(request))) return new Response(null, { status: 403 });
  try {
    const { id: clientId } = await params;
    const body = patchSchema.parse(await request.json());
    const db = database();
    const row = await db.prepare("SELECT payload FROM coach_states WHERE owner_email=?").bind(coachDataKey()).first<{ payload: string }>();
    if (!row) return new Response(null, { status: 404 });
    const state = JSON.parse(row.payload) as CoachState;
    const current = state.clients.find((client) => client.id === clientId);
    if (!current) return new Response(null, { status: 404 });

    const account = await db.prepare("SELECT client_id FROM student_accounts WHERE client_id=?").bind(clientId).first();
    const normalizedPhone = body.phone.trim() ? normalizePhone(body.phone) : "";
    if (account && !/^09\d{9}$/.test(normalizedPhone)) return Response.json({ error: "برای شاگردی که ورود فعال دارد، شماره موبایل باید معتبر باشد." }, { status: 400 });

    const cleanMeasurement=(value:number|null|undefined)=>value&&value>0?value:null;
    const nextClient = { ...current, name: body.name, phone: normalizedPhone || body.phone.trim(), goal: body.goal.trim(), notes: body.notes.trim(), initialMeasurements: body.initialMeasurements ? {weight:cleanMeasurement(body.initialMeasurements.weight),height:cleanMeasurement(body.initialMeasurements.height),waist:cleanMeasurement(body.initialMeasurements.waist),arm:cleanMeasurement(body.initialMeasurements.arm)} : current.initialMeasurements };
    const nextState: CoachState = { ...state, syncRevision: Math.max(Date.now(), Number(state.syncRevision ?? 0) + 1), clients: state.clients.map((client) => client.id === clientId ? nextClient : client) };
    const statements = [
      db.prepare("UPDATE coach_states SET payload=?,updated_at=CURRENT_TIMESTAMP WHERE owner_email=?").bind(JSON.stringify(nextState), coachDataKey()),
      db.prepare("UPDATE applications SET profile_json=json_set(COALESCE(NULLIF(profile_json,''),'{}'),'$.name',?),updated_at=CURRENT_TIMESTAMP WHERE client_id=?").bind(nextClient.name, clientId),
    ];
    if (account) statements.push(db.prepare("UPDATE student_accounts SET phone=?,updated_at=CURRENT_TIMESTAMP WHERE client_id=?").bind(normalizedPhone, clientId));
    db.batch(statements);
    return Response.json({ ok: true, client: nextClient });
  } catch (error) {
    const message = error instanceof z.ZodError ? "مشخصات شاگرد معتبر نیست." : error instanceof Error && error.message.includes("UNIQUE") ? "این شماره موبایل برای شاگرد دیگری ثبت شده است." : "ویرایش مشخصات شاگرد انجام نشد.";
    return Response.json({ error: message }, { status: 400 });
  }
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!sameOrigin(request) || !(await sensitiveSession(request))) return new Response(null, { status: 403 });
  try {
    const { id: clientId } = await params;
    const db = database();
    const row = await db.prepare("SELECT payload FROM coach_states WHERE owner_email=?").bind(coachDataKey()).first<{ payload: string }>();
    if (!row) return new Response(null, { status: 404 });
    const state = JSON.parse(row.payload) as CoachState;
    if (!state.clients.some((client) => client.id === clientId)) return new Response(null, { status: 404 });
    if (state.clients.length <= 1) return Response.json({ error: "آخرین شاگرد پنل را نمی‌توان حذف کرد." }, { status: 409 });
    const uploadRows = await db.prepare("SELECT key FROM application_uploads WHERE client_id=?").bind(clientId).all<{ key: string }>();
    const photoRows = await db.prepare("SELECT b.key FROM body_photos b JOIN checkins c ON c.id=b.checkin_id WHERE c.client_id=? AND c.owner=?").bind(clientId, coachDataKey()).all<{ key: string }>();
    const currentPhotoRows = await db.prepare("SELECT key FROM client_body_photos WHERE client_id=? AND owner=?").bind(clientId, coachDataKey()).all<{key:string}>();
    const clients = state.clients.filter((client) => client.id !== clientId);
    const plans = { ...state.plans };
    delete plans[clientId];
    const nextState: CoachState = { ...state, syncRevision: Math.max(Date.now(), Number(state.syncRevision ?? 0) + 1), clients, plans, activeClientId: state.activeClientId === clientId ? clients[0].id : state.activeClientId, deletedClientIds: [...new Set([...(state.deletedClientIds ?? []), clientId])] };
    await db.batch([
      db.prepare("DELETE FROM body_photos WHERE checkin_id IN (SELECT id FROM checkins WHERE client_id=? AND owner=?)").bind(clientId, coachDataKey()),
      db.prepare("DELETE FROM client_body_photos WHERE client_id=? AND owner=?").bind(clientId, coachDataKey()),
      db.prepare("DELETE FROM checkins WHERE client_id=? AND owner=?").bind(clientId, coachDataKey()),
      db.prepare("DELETE FROM application_uploads WHERE client_id=?").bind(clientId),
      db.prepare("DELETE FROM billing_events WHERE client_id=?").bind(clientId),
      db.prepare("DELETE FROM billing_records WHERE client_id=?").bind(clientId),
      db.prepare("DELETE FROM program_assignments WHERE client_id=?").bind(clientId),
      db.prepare("DELETE FROM chat_messages WHERE client_id=?").bind(clientId),
      db.prepare("DELETE FROM payments WHERE client_id=?").bind(clientId),
      db.prepare("DELETE FROM applications WHERE client_id=?").bind(clientId),
      db.prepare("DELETE FROM push_subscriptions WHERE client_id=?").bind(clientId),
      db.prepare("DELETE FROM student_accounts WHERE client_id=?").bind(clientId),
      db.prepare("UPDATE coach_states SET payload=?,updated_at=CURRENT_TIMESTAMP WHERE owner_email=?").bind(JSON.stringify(nextState), coachDataKey()),
    ]);
    await Promise.allSettled([...uploadRows.results, ...photoRows.results, ...currentPhotoRows.results].map((item) => getExerciseBucket().delete(item.key)));
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "حذف کامل شاگرد انجام نشد." }, { status: 500 });
  }
}
