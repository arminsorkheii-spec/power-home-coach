import { database, sameOrigin } from "@/lib/raw-db";
import { studentIdFromRequest } from "@/lib/student-auth";
import { getExerciseBucket } from "@/lib/storage";
import { createNotification } from "@/lib/notifications";

const PHOTO_KINDS = new Set(["front", "side", "back", "front_double", "back_double"]);
const KINDS = new Set([...PHOTO_KINDS, "lab", "receipt"]);

export async function POST(request: Request) {
  if (!sameOrigin(request)) return new Response(null, { status: 403 });
  const clientId = await studentIdFromRequest(request);
  if (!clientId) return Response.json({ error: "ورود شاگرد لازم است." }, { status: 401 });
  try {
    const form = await request.formData();
    const file = form.get("file");
    const kind = form.get("kind");
    if (!(file instanceof File) || typeof kind !== "string" || !KINDS.has(kind)) return new Response(null, { status: 400 });
    const allowed = PHOTO_KINDS.has(kind) ? ["image/jpeg", "image/png", "image/webp"] : ["image/jpeg", "image/png", "image/webp", "application/pdf"];
    if (!allowed.includes(file.type) || file.size < 1 || file.size > 8 * 1024 * 1024) return Response.json({ error: "فایل معتبر تا ۸ مگابایت انتخاب کنید." }, { status: 400 });
    const bytes = await file.arrayBuffer();
    const b = new Uint8Array(bytes);
    const valid = (file.type === "image/jpeg" && b[0] === 255 && b[1] === 216 && b[2] === 255) ||
      (file.type === "image/png" && b[0] === 137 && b[1] === 80 && b[2] === 78 && b[3] === 71) ||
      (file.type === "image/webp" && new TextDecoder().decode(b.slice(0, 4)) === "RIFF" && new TextDecoder().decode(b.slice(8, 12)) === "WEBP") ||
      (file.type === "application/pdf" && new TextDecoder().decode(b.slice(0, 5)) === "%PDF-");
    if (!valid) return new Response(null, { status: 415 });
    const db = database();
    const application = await db.prepare("SELECT id,package_name,profile_json FROM applications WHERE client_id=? ORDER BY created_at DESC LIMIT 1").bind(clientId).first<{ id: string;package_name:string;profile_json:string }>();
    if (!application) return new Response(null, { status: 404 });
    if (PHOTO_KINDS.has(kind)) {
      const previous = await db.prepare("SELECT id,key FROM application_uploads WHERE application_id=? AND kind=?").bind(application.id, kind).first<{ id: string; key: string }>();
      if (previous) { await getExerciseBucket().delete(previous.key); await db.prepare("DELETE FROM application_uploads WHERE id=?").bind(previous.id).run(); }
    }
    const id = crypto.randomUUID();
    const key = `student-applications/${clientId}/${application.id}/${id}`;
    await getExerciseBucket().put(key, bytes, { httpMetadata: { contentType: file.type }, customMetadata: { originalName: file.name, kind } });
    await db.prepare("INSERT INTO application_uploads (id,application_id,client_id,kind,key,filename,content_type,size,created_at) VALUES (?,?,?,?,?,?,?,?,?)").bind(id, application.id, clientId, kind, key, file.name.slice(0, 180), file.type, file.size, new Date().toISOString()).run();
    if (kind === "receipt") {
      await db.prepare("UPDATE applications SET status='payment_review',updated_at=? WHERE id=?").bind(new Date().toISOString(), application.id).run();
      const profile=JSON.parse(application.profile_json||"{}") as {name?:string};
      await createNotification({role:"coach",actorClientId:clientId,applicationId:application.id,type:"payment_receipt",title:"رسید پرداخت جدید",body:`${profile.name||"یک شاگرد"} برای ${application.package_name} رسید فرستاد.`,url:"/coach",tag:`receipt-${application.id}-${id}`});
      await createNotification({role:"student",clientId,actorClientId:clientId,applicationId:application.id,type:"payment_receipt_sent",title:"رسید پرداخت ارسال شد",body:"رسیدت دریافت شد و برای بررسی مربی ارسال شد.",url:"/student",tag:`receipt-sent-${application.id}-${id}`});
    }
    return Response.json({ ok: true, id, size: file.size });
  } catch {
    return Response.json({ error: "آپلود انجام نشد؛ دوباره تلاش کنید." }, { status: 503 });
  }
}
