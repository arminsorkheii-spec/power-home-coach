import { sameOrigin } from "@/lib/raw-db";
import { clearedStudentCookie } from "@/lib/student-auth";

export async function POST(request: Request) {
  if (!sameOrigin(request)) return new Response(null, { status: 403 });
  return Response.json({ ok: true }, { headers: { "set-cookie": clearedStudentCookie(), "cache-control": "no-store" } });
}
