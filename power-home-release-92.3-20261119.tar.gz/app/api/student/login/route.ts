import { allowPasswordAttempt } from "@/lib/password-auth";
import { sameOrigin, database } from "@/lib/raw-db";
import { createStudentSession, deriveStudentPassword, normalizeDigits, normalizePhone, safeEqual, studentSessionCookie } from "@/lib/student-auth";
import { smsLoginEnabled } from "@/lib/sms";
import { OtpError, requestIp, verifyStudentCode } from "@/lib/student-otp";

export async function GET(){return Response.json({smsEnabled:smsLoginEnabled()},{headers:{"cache-control":"no-store"}});}

export async function POST(request: Request) {
  if (!sameOrigin(request)) return new Response(null, { status: 403 });
  try {
    if(smsLoginEnabled()){
      const body=await request.json() as {phone?:unknown;code?:unknown;challengeId?:unknown};
      if(typeof body.phone!=="string"||body.phone.length>30||typeof body.code!=="string"||body.code.length>12||typeof body.challengeId!=="string")return Response.json({error:"شماره موبایل و کد پیامکی را وارد کنید.",smsRequired:true},{status:400});
      const account=verifyStudentCode(body.phone,body.challengeId,normalizeDigits(body.code),requestIp(request));
      const token=await createStudentSession(account.client_id,account.revision);
      return Response.json({ok:true},{headers:{"cache-control":"no-store","set-cookie":studentSessionCookie(token)}});
    }
    if (!(await allowPasswordAttempt(request))) return Response.json({ error: "تلاش‌های زیاد؛ ۱۵ دقیقه بعد دوباره امتحان کنید." }, { status: 429 });
    const body = (await request.json()) as { phone?: unknown; password?: unknown };
    if (typeof body.phone !== "string" || typeof body.password !== "string") return Response.json({ error: "شماره موبایل و رمز را کامل وارد کنید." }, { status: 400 });
    const phone = normalizePhone(body.phone);
    const password = normalizeDigits(body.password).replace(/\D/g, "");
    if (!/^09\d{9}$/.test(phone) || !/^\d{6}$/.test(password)) return Response.json({ error: "شماره موبایل یا رمز ۶ رقمی معتبر نیست." }, { status: 400 });
    const account = await database().prepare("SELECT client_id, password_hash, salt, revision FROM student_accounts WHERE phone = ?").bind(phone).first<{ client_id: string; password_hash: string; salt: string; revision: string }>();
    if (!account || !safeEqual(await deriveStudentPassword(password, account.salt), account.password_hash)) return Response.json({ error: "شماره موبایل یا همان رمز ۶ رقمی زمان ثبت‌نام درست نیست." }, { status: 401 });
    const token = await createStudentSession(account.client_id, account.revision);
    return Response.json({ ok: true }, { headers: { "cache-control": "no-store", "set-cookie": studentSessionCookie(token) } });
  } catch(error) {
    if(error instanceof OtpError)return Response.json({error:error.message},{status:error.status,headers:{"cache-control":"no-store",...(error.retryAfter?{"retry-after":String(error.retryAfter)}:{})}});
    return Response.json({ error: "ورود انجام نشد؛ دوباره تلاش کنید." }, { status: 400 });
  }
}
