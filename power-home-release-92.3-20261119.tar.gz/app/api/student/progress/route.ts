import { coachDataKey } from "@/lib/password-auth";
import { database } from "@/lib/raw-db";
import { studentIdFromRequest } from "@/lib/student-auth";
import type { ClientPlan, Exercise } from "@/lib/coach-data";

export async function GET(request: Request) {
  const clientId = await studentIdFromRequest(request);
  if (!clientId) return Response.json({ error: "ورود شاگرد لازم است." }, { status: 401 });
  try {
    const db = database();
    const rows = await db.prepare("SELECT id,date,payload FROM checkins WHERE owner=? AND client_id=? ORDER BY date ASC,created_at ASC").bind(coachDataKey(), clientId).all<{ id:string;date:string;payload:string }>();
    const records = await Promise.all(rows.results.map(async row => {
      const parsed = JSON.parse(row.payload) as { recordType?:"baseline"|"archive"; folderName?:string; measurements?: Record<string,number|null>; notes?:string; plan?:ClientPlan; exercises?:Exercise[] };
      const photos = await db.prepare("SELECT id,pose FROM body_photos WHERE owner=? AND checkin_id=?").bind(coachDataKey(),row.id).all<{id:string;pose:string}>();
      return { id:row.id,date:row.date,recordType:parsed.recordType,folderName:parsed.folderName,measurements:parsed.measurements??{},notes:parsed.notes??"",title:parsed.plan?.title??"برنامه",plan:parsed.plan,exercises:parsed.exercises??[],photos:Object.fromEntries(photos.results.map(p=>[p.pose,`/api/body-photos/${p.id}`])) };
    }));
    return Response.json({ records }, { headers: { "cache-control":"no-store" } });
  } catch { return Response.json({ error:"دریافت روند پیشرفت انجام نشد." },{status:500}); }
}
