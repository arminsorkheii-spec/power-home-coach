import { z } from "zod";
import { coachDataKey, sensitiveSession } from "@/lib/password-auth";
import { database, sameOrigin } from "@/lib/raw-db";
import { dateSchema, measurementsSchema } from "@/lib/checkin-data";
import { getExerciseBucket } from "@/lib/storage";
const text = z.string().max(10000);
const row = z.object({rowId:text,exerciseId:text,sets:text,reps:text,rest:text,tempo:text,technique:text,notes:text,supersetId:text.optional()});
const schema=z.object({id:z.string().uuid(), clientId:z.string().min(1).max(100), date:dateSchema, measurements:measurementsSchema, notes:text,
  client:z.object({id:text,name:text,phone:text,goal:text,notes:text}),
  plan:z.object({title:text,workoutDays:z.array(z.object({id:text,title:text,focus:text,exercises:z.array(row).max(100)})).max(30),nutritionGoals:z.object({calories:text,protein:text,carbs:text,fat:text}),nutritionMeals:z.array(z.object({id:text,title:text,time:text,foods:text,notes:text})).max(50),supplementItems:z.array(z.object({id:text,supplementId:text,name:text,dose:text,timing:text,frequency:text,notes:text})).max(100).optional().default([]),medicationItems:z.array(z.object({id:text,medicationId:text,name:text,group:z.enum(["pct","bodybuilding"]),dose:text,timing:text,frequency:text,startWeek:text,endWeek:text,notes:text})).max(100).optional().default([])}),
  exercises:z.array(z.object({id:text,nameFa:text,nameEn:text,category:text,image:z.string().startsWith("/").refine(v=>!v.startsWith("//")),custom:z.boolean().optional()})).max(1000)
});
export async function GET(request: Request) {
  try {
    if (!(await sensitiveSession(request))) return Response.json({error:"ابتدا رمز اختصاصی را تنظیم کنید."},{status:403});
    const clientId=new URL(request.url).searchParams.get("clientId");
    if(!clientId) return new Response(null,{status:400});
    const rows=await database().prepare("SELECT id, date, created_at FROM checkins WHERE owner=? AND client_id=? ORDER BY date DESC, created_at DESC").bind(coachDataKey(),clientId).all();
    const id=new URL(request.url).searchParams.get("id");
    if(!id) return Response.json({records:rows.results},{headers:{"cache-control":"no-store"}});
    const record=await database().prepare("SELECT payload FROM checkins WHERE owner=? AND client_id=? AND id=?").bind(coachDataKey(),clientId,id).first<{payload:string}>();
    if(!record) return new Response(null,{status:404});
    const photos=await database().prepare("SELECT id, pose FROM body_photos WHERE owner=? AND checkin_id=?").bind(coachDataKey(),id).all<{id:string;pose:string}>();
    return Response.json({record:{...JSON.parse(record.payload),photos:Object.fromEntries(photos.results.map((p:{id:string;pose:string})=>[p.pose,`/api/body-photos/${p.id}`]))}},{headers:{"cache-control":"no-store"}});
  } catch {return Response.json({error:"دریافت سوابق انجام نشد."},{status:503});}
}
export async function POST(request: Request) {
  try {
    if(!sameOrigin(request) || !(await sensitiveSession(request))) return new Response(null,{status:403});
    const raw=await request.text(); if(raw.length>500000) return new Response(null,{status:413});
    const data=schema.parse(JSON.parse(raw));
    if(data.client.id!==data.clientId) return new Response(null,{status:400});
    const state=await database().prepare("SELECT payload FROM coach_states WHERE owner_email=?").bind(coachDataKey()).first<{payload:string}>();
    if(!state || !JSON.parse(state.payload).clients.some((c:{id:string})=>c.id===data.clientId)) return Response.json({error:"ابتدا ذخیره آنلاین پرونده شاگرد را کامل کنید."},{status:409});
    const record={...data,recordType:"archive" as const,createdAt:new Date().toISOString()};
    await database().prepare("INSERT INTO checkins (id, owner, client_id, date, payload, created_at) VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT(id) DO NOTHING").bind(data.id,coachDataKey(),data.clientId,data.date,JSON.stringify(record),record.createdAt).run();
    return Response.json({ok:true,id:data.id});
  } catch(e) {return Response.json({error:e instanceof z.ZodError ? "تاریخ یا اندازه‌ها معتبر نیستند؛ مقادیر مثبت وارد کنید." : "ثبت دوره انجام نشد؛ دوباره تلاش کنید."},{status:400});}
}

const folderActionSchema = z.object({
  id: z.string().uuid(),
  clientId: z.string().min(1).max(100),
  folderName: z.string().trim().min(1).max(80).optional(),
  plan: schema.shape.plan.optional(),
  exercises: schema.shape.exercises.optional(),
});

export async function PATCH(request: Request) {
  try {
    if (!sameOrigin(request) || !(await sensitiveSession(request))) return new Response(null, { status: 403 });
    const data = folderActionSchema.parse(await request.json());
    if (!data.folderName && !data.plan) return Response.json({ error: "تغییرات پرونده را وارد کنید." }, { status: 400 });
    const db = database();
    const row = await db.prepare("SELECT payload FROM checkins WHERE owner=? AND client_id=? AND id=?").bind(coachDataKey(), data.clientId, data.id).first<{ payload: string }>();
    if (!row) return new Response(null, { status: 404 });
    const payload = JSON.parse(row.payload) as Record<string, unknown>;
    if (data.plan && payload.recordType !== "archive") return Response.json({error:"فقط برنامه‌های بایگانی‌شده قابل ویرایش هستند."},{status:409});
    const modified = { ...payload, ...(data.folderName ? {folderName:data.folderName} : {}), ...(data.plan ? {plan:data.plan,exercises:data.exercises??payload.exercises,editedAt:new Date().toISOString()} : {}) };
    await db.prepare("UPDATE checkins SET payload=? WHERE owner=? AND client_id=? AND id=?").bind(JSON.stringify(modified), coachDataKey(), data.clientId, data.id).run();
    return Response.json({ ok: true, folderName: modified.folderName });
  } catch (error) {
    return Response.json({ error: error instanceof z.ZodError ? "اسم پرونده معتبر نیست." : "ویرایش پرونده انجام نشد." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  try {
    if (!sameOrigin(request) || !(await sensitiveSession(request))) return new Response(null, { status: 403 });
    const data = folderActionSchema.pick({ id:true,clientId:true }).parse(await request.json());
    const db = database();
    const record = await db.prepare("SELECT id FROM checkins WHERE owner=? AND client_id=? AND id=?").bind(coachDataKey(), data.clientId, data.id).first<{ id: string }>();
    if (!record) return new Response(null, { status: 404 });
    const photos = await db.prepare("SELECT key FROM body_photos WHERE owner=? AND checkin_id=?").bind(coachDataKey(), data.id).all<{ key: string }>();
    await db.batch([
      db.prepare("DELETE FROM body_photos WHERE owner=? AND checkin_id=?").bind(coachDataKey(), data.id),
      db.prepare("DELETE FROM checkins WHERE owner=? AND client_id=? AND id=?").bind(coachDataKey(), data.clientId, data.id),
    ]);
    await Promise.allSettled(photos.results.map((photo) => getExerciseBucket().delete(photo.key)));
    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ error: error instanceof z.ZodError ? "پرونده معتبر نیست." : "حذف پرونده انجام نشد." }, { status: 400 });
  }
}
