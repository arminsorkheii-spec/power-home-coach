import { sensitiveSession } from "@/lib/password-auth";
import { database } from "@/lib/raw-db";
import { studentIdFromRequest } from "@/lib/student-auth";
import { getExerciseBucket } from "@/lib/storage";

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const studentId = await studentIdFromRequest(request);
    const coach = await sensitiveSession(request);
    if (!studentId && !coach) return new Response(null, { status: 401 });
    const { id } = await params;
    const row = await database().prepare("SELECT key,client_id,content_type,filename FROM application_uploads WHERE id=?").bind(id).first<{ key: string; client_id: string; content_type: string; filename: string }>();
    if (!row || (!coach && row.client_id !== studentId)) return new Response(null, { status: 404 });
    const object = await getExerciseBucket().get(row.key);
    if (!object) return new Response(null, { status: 404 });
    const safeName = row.filename.replace(/[\r\n"\\]/g, "_");
    return new Response(object.body, { headers: { "content-type": row.content_type, "content-disposition": `${row.content_type === "application/pdf" ? "attachment" : "inline"}; filename="${safeName}"`, "cache-control": "private, no-store", "x-content-type-options": "nosniff" } });
  } catch { return new Response(null, { status: 503 }); }
}
