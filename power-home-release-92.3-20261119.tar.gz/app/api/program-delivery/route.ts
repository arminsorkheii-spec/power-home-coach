import { z } from "zod";
import { programDigest } from "@/lib/program-delivery";
import { coachDataKey, requestHasValidSession } from "@/lib/password-auth";
import { database, sameOrigin } from "@/lib/raw-db";
import { createNotification } from "@/lib/notifications";
import { EXERCISES, type CoachState } from "@/lib/coach-data";

const schema=z.object({clientId:z.string().min(1).max(120),applicationId:z.string().uuid().optional()});
const numberOrNull=(value:unknown)=>{const n=typeof value==="string"?Number(value.replace(/,/g,"")):Number(value);return Number.isFinite(n)&&n>0?n:null;};

export async function POST(request:Request){
  if(!sameOrigin(request)||!(await requestHasValidSession(request)))return new Response(null,{status:403});
  try{
    const {clientId,applicationId}=schema.parse(await request.json());
    const db=database();
    const stateRow=await db.prepare("SELECT payload FROM coach_states WHERE owner_email=?").bind(coachDataKey()).first<{payload:string}>();
    if(!stateRow)return Response.json({error:"ابتدا برنامه را روی سرور ذخیره کنید."},{status:409});
    const state=JSON.parse(stateRow.payload) as CoachState;
    const client=state.clients.find(item=>item.id===clientId);
    const plan=state.plans[clientId];
    if(!client||!plan)return Response.json({error:"پرونده یا برنامه شاگرد پیدا نشد."},{status:404});
    const now=new Date().toISOString();
    const application=await db.prepare(applicationId?"SELECT id,package_name,profile_json,status FROM applications WHERE client_id=? AND id=?":"SELECT id,package_name,profile_json,status FROM applications WHERE client_id=? ORDER BY created_at DESC,rowid DESC LIMIT 1").bind(...(applicationId?[clientId,applicationId]:[clientId])).first<{id:string;package_name:string;profile_json:string;status:string}>();

    if(applicationId&&!application)return Response.json({error:"درخواست انتخابی متعلق به این شاگرد نیست."},{status:404});

    // Build every persistent delivery change first and commit it atomically. This prevents a
    // half-delivered state (for example: application says delivered but baseline/history failed).
    const statements=application
      ? [db.prepare("UPDATE applications SET status='delivered',updated_at=? WHERE id=?").bind(now,application.id)]
      : [];

    // The first delivered program seeds progress from the intake automatically.
    const existingBaseline=await db.prepare("SELECT id FROM checkins WHERE owner=? AND client_id=? AND json_extract(payload,'$.recordType')='baseline' LIMIT 1").bind(coachDataKey(),clientId).first();
    let baselineScheduled=false;
    if(!existingBaseline){
      const profile=application?JSON.parse(application.profile_json||"{}") as Record<string,unknown>:{};
      const manual=client.initialMeasurements??{};
      const measurements={
        weight:numberOrNull(profile.weight)??numberOrNull(manual.weight),
        height:numberOrNull(profile.height)??numberOrNull(manual.height),
        waist:numberOrNull(profile.waist)??numberOrNull(manual.waist),
        arm:numberOrNull(profile.arm)??numberOrNull(manual.arm),
      };
      if(Object.values(measurements).some(value=>value!==null)){
        const usedIds=new Set(plan.workoutDays.flatMap(day=>day.exercises.map(item=>item.exerciseId)));
        const exercises=[...EXERCISES,...(state.customExercises??[])].filter(exercise=>usedIds.has(exercise.id));
        const id=crypto.randomUUID();
        const date=now.slice(0,10);
        const payload={id,clientId,date,createdAt:now,recordType:"baseline",folderName:"اطلاعات شروع",measurements,notes:"ثبت خودکار اطلاعات اولیه هنگام اولین ارسال برنامه",client,plan,exercises};
        statements.push(db.prepare("INSERT INTO checkins (id,owner,client_id,date,payload,created_at) VALUES (?,?,?,?,?,?)").bind(id,coachDataKey(),clientId,date,JSON.stringify(payload),now));
        baselineScheduled=true;
      }
    }

    const programHash=programDigest(plan);
    statements.push(db.prepare(`INSERT INTO current_program_deliveries (client_id,plan_hash,delivered_at) VALUES (?,?,?) ON CONFLICT(client_id) DO UPDATE SET plan_hash=excluded.plan_hash,delivered_at=excluded.delivered_at`).bind(clientId,programHash,now));
    if(plan.sourceTemplateId && plan.coachProgramNumber){
      statements.push(db.prepare(`INSERT INTO program_assignments (id,client_id,template_id,program_number,template_title,assigned_at,delivered_at) VALUES (?,?,?,?,?,?,?)`)
        .bind(crypto.randomUUID(),clientId,plan.sourceTemplateId,plan.coachProgramNumber,plan.title||"برنامه",now,now));
    }
    if(statements.length)db.batch(statements);
    const baselineCreated=baselineScheduled;
    const notification=await createNotification({role:"student",clientId,applicationId:application?.id??null,type:"program_delivered",title:"مربی برنامه‌ات را فرستاد 💪",body:`${plan.title||application?.package_name||"برنامه اختصاصی"} آماده است؛ وارد پنل شو و برنامه‌ها را ببین.`,url:"/student",tag:`program-${clientId}-${Date.now()}`});
    const push=notification.push;
    return Response.json({ok:true,push,applicationUpdated:Boolean(application),baselineCreated},{headers:{"cache-control":"no-store"}});
  }catch(error){return Response.json({error:error instanceof z.ZodError?"شاگرد معتبر نیست.":"ارسال برنامه انجام نشد."},{status:400});}
}

export async function GET(request:Request){
 if(!(await requestHasValidSession(request)))return new Response(null,{status:401});
 const clientId=new URL(request.url).searchParams.get("clientId");
 if(!clientId)return Response.json({error:"شاگرد انتخاب نشده است."},{status:400});
 const db=database();
 const row=await db.prepare("SELECT payload FROM coach_states WHERE owner_email=?").bind(coachDataKey()).first<{payload:string}>();
 const plan=row?(JSON.parse(row.payload) as CoachState).plans[clientId]:null;
 const delivery=await db.prepare("SELECT plan_hash FROM current_program_deliveries WHERE client_id=?").bind(clientId).first<{plan_hash:string}>();
 return Response.json({delivered:Boolean(plan&&delivery?.plan_hash===programDigest(plan))},{headers:{"cache-control":"no-store"}});
}
export async function DELETE(request:Request){
 if(!sameOrigin(request)||!(await requestHasValidSession(request)))return new Response(null,{status:403});
 try{const {clientId}=schema.parse(await request.json());
   database().prepare("DELETE FROM current_program_deliveries WHERE client_id=?").bind(clientId).run();
   return Response.json({ok:true});
 }catch{return Response.json({error:"حذف وضعیت برنامه انجام نشد."},{status:400});}
}
