import { requestHasValidSession, coachDataKey } from "@/lib/password-auth";
import { database, sameOrigin } from "@/lib/raw-db";
import { randomBytes, createHash } from "node:crypto";

async function clientExists(id:string){
 const row=await database().prepare("SELECT payload FROM coach_states WHERE owner_email=?").bind(coachDataKey()).first<{payload:string}>();
 if(!row)return false;
 try{return Boolean((JSON.parse(row.payload) as {clients?:{id:string}[]}).clients?.some(client=>client.id===id));}catch{return false;}
}
const valid=(v:unknown):v is string=>typeof v==="string"&&v.length>0&&v.length<120;
export async function GET(request:Request){
 if(!(await requestHasValidSession(request)))return new Response(null,{status:401});
 const clientId=new URL(request.url).searchParams.get("clientId");
 if(!valid(clientId))return Response.json({error:"شاگرد انتخاب نشده است."},{status:400});
 const link=await database().prepare("SELECT created_at,expires_at FROM student_magic_links WHERE client_id=?").bind(clientId).first<{created_at:string;expires_at:string}>();
 return Response.json({active:Boolean(link&&new Date(link.expires_at).getTime()>Date.now()),createdAt:link?.created_at??null,expiresAt:link?.expires_at??null},{headers:{"cache-control":"no-store"}});
}
export async function POST(request:Request){
 if(!sameOrigin(request)||!(await requestHasValidSession(request)))return new Response(null,{status:403});
 try{
  const {clientId}=await request.json() as {clientId:unknown};
  if(!valid(clientId)||!(await clientExists(clientId)))return Response.json({error:"شاگرد پیدا نشد."},{status:404});
  const db=database();const token=randomBytes(32).toString("base64url");const hash=createHash("sha256").update(token).digest("hex");
  const revision=crypto.randomUUID();const now=new Date().toISOString();const expiresAt=new Date(Date.now()+90*86400000).toISOString();
  const account=await db.prepare("SELECT client_id FROM student_accounts WHERE client_id=?").bind(clientId).first();
  const statements=[db.prepare(`INSERT INTO student_magic_links (client_id,token_hash,session_revision,expires_at,created_at) VALUES (?,?,?,?,?) ON CONFLICT(client_id) DO UPDATE SET token_hash=excluded.token_hash,session_revision=excluded.session_revision,expires_at=excluded.expires_at,created_at=excluded.created_at`)
   .bind(clientId,hash,revision,expiresAt,now)];
  if(!account){
    // Internal placeholder has no usable phone/password. Later the coach can associate
    // a real number; existing password accounts never change.
    statements.push(db.prepare("INSERT INTO student_accounts (client_id,phone,password_hash,salt,revision,created_at,updated_at) VALUES (?,?,?,?,?,?,?)")
      .bind(clientId,`link-${crypto.randomUUID()}`,randomBytes(32).toString("hex"),crypto.randomUUID(),crypto.randomUUID(),now,now));
  }
  db.batch(statements);
  const url=new URL(request.url);
  return Response.json({ok:true,url:`${url.origin}/api/student-links/enter?token=${encodeURIComponent(token)}`,expiresAt},{headers:{"cache-control":"no-store","referrer-policy":"no-referrer"}});
 }catch(error){console.error("create_student_link_failed",error);return Response.json({error:"ساخت لینک شاگرد انجام نشد."},{status:400});}
}
export async function DELETE(request:Request){
 if(!sameOrigin(request)||!(await requestHasValidSession(request)))return new Response(null,{status:403});
 const body=await request.json().catch(()=>null) as {clientId?:unknown}|null;
 if(!valid(body?.clientId))return Response.json({error:"شاگرد معتبر نیست."},{status:400});
 await database().prepare("DELETE FROM student_magic_links WHERE client_id=?").bind(body.clientId).run();
 return Response.json({ok:true});
}
