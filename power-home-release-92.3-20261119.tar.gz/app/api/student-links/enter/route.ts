import { createHash } from "node:crypto";
import { database } from "@/lib/raw-db";
import { createStudentSession, studentSessionCookie } from "@/lib/student-auth";

export async function GET(request:Request){
 const incoming=new URL(request.url);
 const token=incoming.searchParams.get("token")||"";
 if(!/^[A-Za-z0-9_-]{40,60}$/.test(token))return Response.redirect(new URL("/student?link=invalid",incoming.origin),303);
 const tokenHash=createHash("sha256").update(token).digest("hex");
 const link=await database().prepare("SELECT client_id,session_revision,expires_at FROM student_magic_links WHERE token_hash=?")
  .bind(tokenHash).first<{client_id:string;session_revision:string;expires_at:string}>();
 if(!link||new Date(link.expires_at).getTime()<=Date.now())return Response.redirect(new URL("/student?link=expired",incoming.origin),303);
 const account=await database().prepare("SELECT client_id FROM student_accounts WHERE client_id=?").bind(link.client_id).first();
 if(!account)return Response.redirect(new URL("/student?link=invalid",incoming.origin),303);
 const session=await createStudentSession(link.client_id,link.session_revision);
 return new Response(null,{status:303,headers:{"location":"/student","set-cookie":studentSessionCookie(session),"cache-control":"no-store","referrer-policy":"no-referrer"}});
}
