import { z } from "zod";
import { requestHasValidSession } from "@/lib/password-auth";
import { database, sameOrigin } from "@/lib/raw-db";

const schema=z.object({
  clientId:z.string().min(1).max(120),
  templateId:z.string().min(1).max(160),
  programNumber:z.number().int().positive(),
  templateTitle:z.string().trim().min(1).max(200),
  force:z.boolean().optional().default(false),
});

export async function GET(request:Request){
  if(!(await requestHasValidSession(request)))return new Response(null,{status:401});
  const clientId=new URL(request.url).searchParams.get("clientId");
  if(!clientId)return Response.json({error:"شاگرد انتخاب نشده است."},{status:400});
  const rows=await database().prepare("SELECT * FROM program_assignments WHERE client_id=? AND delivered_at IS NOT NULL ORDER BY assigned_at DESC").bind(clientId).all();
  return Response.json({assignments:rows.results},{headers:{"cache-control":"no-store"}});
}

export async function POST(request:Request){
  if(!sameOrigin(request)||!(await requestHasValidSession(request)))return new Response(null,{status:403});
  try{
    const data=schema.parse(await request.json());
    const db=database();
    const previous=await db.prepare("SELECT id,assigned_at,delivered_at FROM program_assignments WHERE client_id=? AND template_id=? ORDER BY assigned_at DESC LIMIT 1").bind(data.clientId,data.templateId).first<{id:string;assigned_at:string;delivered_at:string|null}>();
    if(previous&&!data.force)return Response.json({error:"این برنامه قبلاً برای این شاگرد ثبت شده است.",duplicate:true,previous},{status:409});
    const now=new Date().toISOString();
    await db.prepare(`INSERT INTO program_assignments (id,client_id,template_id,program_number,template_title,assigned_at) VALUES (?,?,?,?,?,?)`).bind(crypto.randomUUID(),data.clientId,data.templateId,data.programNumber,data.templateTitle,now).run();
    return Response.json({ok:true,duplicate:Boolean(previous)});
  }catch(error){return Response.json({error:error instanceof z.ZodError?"اطلاعات برنامه معتبر نیست.":"ثبت سابقه برنامه انجام نشد."},{status:400});}
}
