import { coachDataKey, sensitiveSession } from "@/lib/password-auth";
import { database } from "@/lib/raw-db";
import { studentIdFromRequest } from "@/lib/student-auth";
import { getExerciseBucket } from "@/lib/storage";

export async function GET(request:Request,{params}:{params:Promise<{id:string}>}){
  try{
    const coach=await sensitiveSession(request),studentId=await studentIdFromRequest(request);
    if(!coach&&!studentId)return new Response(null,{status:401});
    const {id}=await params;
    const photo=await database().prepare("SELECT key,client_id FROM client_body_photos WHERE id=? AND owner=?").bind(id,coachDataKey()).first<{key:string;client_id:string}>();
    if(!photo||(!coach&&photo.client_id!==studentId))return new Response(null,{status:404});
    const object=await getExerciseBucket().get(photo.key);
    if(!object)return new Response(null,{status:404});
    return new Response(object.body,{headers:{"content-type":object.httpMetadata?.contentType??"image/jpeg","cache-control":"private, no-store","x-content-type-options":"nosniff","content-disposition":"inline"}});
  }catch{return new Response(null,{status:503});}
}
