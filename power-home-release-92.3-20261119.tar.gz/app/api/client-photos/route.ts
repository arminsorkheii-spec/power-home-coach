import { coachDataKey, sensitiveSession } from "@/lib/password-auth";
import { database, sameOrigin } from "@/lib/raw-db";
import { POSES } from "@/lib/checkin-data";
import { getExerciseBucket } from "@/lib/storage";

async function clientExists(clientId:string){
  const row=await database().prepare("SELECT payload FROM coach_states WHERE owner_email=?").bind(coachDataKey()).first<{payload:string}>();
  if(!row)return false;
  try{return Boolean((JSON.parse(row.payload) as {clients?:Array<{id:string}>}).clients?.some(client=>client.id===clientId));}catch{return false;}
}

export async function GET(request:Request){
  if(!(await sensitiveSession(request)))return new Response(null,{status:401});
  const clientId=new URL(request.url).searchParams.get("clientId")??"";
  if(!clientId)return new Response(null,{status:400});
  const rows=await database().prepare("SELECT id,pose FROM client_body_photos WHERE owner=? AND client_id=?").bind(coachDataKey(),clientId).all<{id:string;pose:string}>();
  return Response.json({photos:Object.fromEntries(rows.results.map(photo=>[photo.pose,`/api/client-photos/${photo.id}`]))},{headers:{"cache-control":"no-store"}});
}

export async function POST(request:Request){
  try{
    if(!sameOrigin(request)||!(await sensitiveSession(request)))return new Response(null,{status:403});
    const form=await request.formData();
    const file=form.get("image"),clientId=form.get("clientId"),pose=form.get("pose");
    if(form.get("consent")!=="yes"||typeof clientId!=="string"||typeof pose!=="string"||!Object.hasOwn(POSES,pose)||!(file instanceof File))return new Response(null,{status:400});
    if(!(await clientExists(clientId)))return new Response(null,{status:404});
    if(file.size<1||file.size>8*1024*1024||!["image/jpeg","image/png","image/webp"].includes(file.type))return Response.json({error:"عکس JPG، PNG یا WebP تا ۸ مگابایت انتخاب کنید."},{status:400});
    const bytes=await file.arrayBuffer(),b=new Uint8Array(bytes);
    const valid=(file.type==="image/jpeg"&&b[0]===255&&b[1]===216&&b[2]===255)||(file.type==="image/png"&&b[0]===137&&b[1]===80&&b[2]===78&&b[3]===71)||(file.type==="image/webp"&&new TextDecoder().decode(b.slice(0,4))==="RIFF"&&new TextDecoder().decode(b.slice(8,12))==="WEBP");
    if(!valid)return new Response(null,{status:415});
    const db=database();
    const previous=await db.prepare("SELECT id,key FROM client_body_photos WHERE owner=? AND client_id=? AND pose=?").bind(coachDataKey(),clientId,pose).first<{id:string;key:string}>();
    const id=crypto.randomUUID(),key=`body-photos/${id}`;
    await getExerciseBucket().put(key,bytes,{httpMetadata:{contentType:file.type}});
    if(previous)await db.prepare("UPDATE client_body_photos SET id=?,key=?,created_at=CURRENT_TIMESTAMP WHERE owner=? AND client_id=? AND pose=?").bind(id,key,coachDataKey(),clientId,pose).run();
    else await db.prepare("INSERT INTO client_body_photos (id,owner,client_id,pose,key) VALUES (?,?,?,?,?)").bind(id,coachDataKey(),clientId,pose,key).run();
    if(previous)await getExerciseBucket().delete(previous.key);
    return Response.json({url:`/api/client-photos/${id}`});
  }catch{return Response.json({error:"آپلود عکس انجام نشد؛ دوباره تلاش کنید."},{status:503});}
}

export async function DELETE(request:Request){
  try{
    if(!sameOrigin(request)||!(await sensitiveSession(request)))return new Response(null,{status:403});
    const body=await request.json() as {clientId?:unknown;pose?:unknown};
    if(typeof body.clientId!=="string"||typeof body.pose!=="string"||!Object.hasOwn(POSES,body.pose))return new Response(null,{status:400});
    const photo=await database().prepare("SELECT key FROM client_body_photos WHERE owner=? AND client_id=? AND pose=?").bind(coachDataKey(),body.clientId,body.pose).first<{key:string}>();
    if(!photo)return new Response(null,{status:404});
    await database().prepare("DELETE FROM client_body_photos WHERE owner=? AND client_id=? AND pose=?").bind(coachDataKey(),body.clientId,body.pose).run();
    await getExerciseBucket().delete(photo.key);
    return Response.json({ok:true});
  }catch{return Response.json({error:"حذف عکس انجام نشد."},{status:400});}
}
