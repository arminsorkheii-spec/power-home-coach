import { z } from "zod";
import { requestHasValidSession } from "@/lib/password-auth";
import { database, sameOrigin } from "@/lib/raw-db";

const idSchema = z.string().min(1).max(120);
const changeSchema = z.object({
  id: idSchema,
  amount: z.number().int().min(-2_000_000_000).max(2_000_000_000),
  note: z.string().trim().max(300),
  eventAt: z.string().datetime({offset:true}),
  reason: z.string().trim().min(3).max(300),
});
const deleteSchema = z.object({id:idSchema,reason:z.string().trim().min(3).max(300)});
type LedgerEvent = {id:string;billing_id:string;application_id:string|null;amount_delta:number;event_at:string;note:string;deleted_at:string|null};
type Billing = {id:string;application_id:string|null;received_amount:number;final_amount:number};

async function modify(request:Request, remove:boolean) {
  if (!sameOrigin(request)) return Response.json({error:"درخواست نامعتبر است."},{status:403});
  if (!(await requestHasValidSession(request))) return Response.json({error:"ورود مربی لازم است."},{status:401});
  try {
    const data=remove?deleteSchema.parse(await request.json()):changeSchema.parse(await request.json());
    const db=database();
    const event=await db.prepare("SELECT id,billing_id,application_id,amount_delta,event_at,note,deleted_at FROM billing_events WHERE id=? LIMIT 1")
      .bind(data.id).first<LedgerEvent>();
    if (!event || event.deleted_at) return Response.json({error:"این تراکنش وجود ندارد یا قبلاً حذف شده."},{status:404});
    const bill=await db.prepare("SELECT id,application_id,received_amount,final_amount FROM billing_records WHERE id=?")
      .bind(event.billing_id).first<Billing>();
    if (!bill) return Response.json({error:"پرونده مالی مرتبط پیدا نشد."},{status:409});
    const nextAmount=remove?0:(data as z.infer<typeof changeSchema>).amount;
    const nextNote=remove?event.note:(data as z.infer<typeof changeSchema>).note;
    const nextEventAt=remove?event.event_at:(data as z.infer<typeof changeSchema>).eventAt;
    const delta=nextAmount-Number(event.amount_delta);
    const nextReceived=Number(bill.received_amount)+delta;
    if (nextReceived<0 || nextReceived>Number(bill.final_amount)) {
      return Response.json({error:"اصلاح این تراکنش دریافتی شاگرد را منفی یا بیشتر از مبلغ نهایی می‌کند. ابتدا مبلغ پکیج یا سایر تراکنش‌ها را بررسی کنید."},{status:409});
    }
    const now=new Date().toISOString();
    const revision=remove?"delete":"edit";
    const queries=[
      db.prepare(`INSERT INTO billing_event_audit (id,event_id,billing_id,action,old_amount,new_amount,old_event_at,new_event_at,old_note,new_note,reason,changed_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`)
        .bind(crypto.randomUUID(),event.id,event.billing_id,revision,event.amount_delta,nextAmount,event.event_at,nextEventAt,event.note,nextNote,data.reason,now),
      db.prepare(`UPDATE billing_events SET amount_delta=?,event_at=?,note=?,edited_at=?,deleted_at=? WHERE id=? AND deleted_at IS NULL`)
        .bind(nextAmount,nextEventAt,nextNote,now,remove?now:null,event.id),
      db.prepare(`UPDATE billing_records SET received_amount=?,received_at=?,updated_at=? WHERE id=?`)
        .bind(nextReceived,nextReceived>0?now:null,now,bill.id),
    ];
    if (bill.application_id) {
      queries.push(db.prepare("UPDATE applications SET paid_at=?,updated_at=? WHERE id=?")
        .bind(nextReceived>0?now:null,now,bill.application_id));
    }
    db.batch(queries);
    return Response.json({ok:true,billingId:bill.id,receivedAmount:nextReceived});
  } catch(error) {
    console.error("billing_entry_correction_failed",error);
    return Response.json({error:error instanceof z.ZodError?"مقدار، تاریخ یا دلیل اصلاح معتبر نیست.":"ویرایش تراکنش انجام نشد."},{status:400});
  }
}
export async function PATCH(request:Request){return modify(request,false)}
export async function DELETE(request:Request){return modify(request,true)}
