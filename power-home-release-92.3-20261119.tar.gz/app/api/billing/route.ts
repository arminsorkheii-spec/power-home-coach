import { z } from "zod";
import { requestHasValidSession } from "@/lib/password-auth";
import { database, sameOrigin } from "@/lib/raw-db";
import { getPackageById, quotePackages } from "@/lib/package-pricing";

const money = z.number().int().min(0).max(2_000_000_000);
const updateSchema = z.object({
  id: z.string().min(1).max(120).optional(),
  clientId: z.string().min(1).max(120),
  applicationId: z.string().min(1).max(120).nullable().optional(),
  packageId: z.string().min(1).max(60),
  packageIds:z.array(z.string().max(40)).min(1).max(7).optional(),
  packageName: z.string().trim().min(1).max(120).optional(),
  listAmount: money,
  discountAmount: money,
  receivedAmount: money,
  profile: z.record(z.string(), z.string().max(3000)).optional(),
});

export async function GET(request: Request) {
  if (!(await requestHasValidSession(request))) return new Response(null, { status: 401 });
  const url = new URL(request.url);
  const clientId = url.searchParams.get("clientId");
  const applicationId = url.searchParams.get("applicationId");
  const db = database();
  if (applicationId) {
    const record = await db.prepare("SELECT * FROM billing_records WHERE application_id=? LIMIT 1").bind(applicationId).first<Record<string, unknown>>();
    return Response.json({ record: record ?? null }, { headers: { "cache-control": "no-store" } });
  }
  if (!clientId) return Response.json({ error: "شاگرد انتخاب نشده است." }, { status: 400 });
  const rows = await db.prepare("SELECT * FROM billing_records WHERE client_id=? ORDER BY created_at DESC, updated_at DESC").bind(clientId).all<Record<string, unknown>>();
  return Response.json({ records: rows.results, record: rows.results[0] ?? null }, { headers: { "cache-control": "no-store" } });
}

export async function PUT(request: Request) {
  if (!sameOrigin(request) || !(await requestHasValidSession(request))) return new Response(null, { status: 403 });
  try {
    const data = updateSchema.parse(await request.json());
    const combined=data.packageIds?quotePackages(data.packageIds):null;
    if(combined)data.packageId=combined.id;
    const selected = combined??getPackageById(data.packageId);
    const packageName = data.packageName?.trim() || selected?.name || data.packageId;
    const listAmount = Math.max(0, data.listAmount);
    const discountAmount = Math.min(Math.max(0, data.discountAmount), listAmount);
    const finalAmount = Math.max(0, listAmount - discountAmount);
    const receivedAmount = Math.min(Math.max(0, data.receivedAmount), finalAmount);
    const now = new Date().toISOString();
    const db = database();

    type Existing = { id:string; received_amount:number; received_at:string|null };
    let existing: Existing | null = null;
    if (data.applicationId) existing = await db.prepare("SELECT id,received_amount,received_at FROM billing_records WHERE application_id=?").bind(data.applicationId).first<Existing>();
    if (!existing && data.id) existing = await db.prepare("SELECT id,received_amount,received_at FROM billing_records WHERE id=?").bind(data.id).first<Existing>();
    if (!existing && !data.applicationId) existing = await db.prepare("SELECT id,received_amount,received_at FROM billing_records WHERE client_id=? AND application_id IS NULL ORDER BY created_at DESC LIMIT 1").bind(data.clientId).first<Existing>();

    const id = existing?.id ?? data.id ?? crypto.randomUUID();
    const previousReceived = Math.max(0, Number(existing?.received_amount ?? 0));
    const delta = receivedAmount - previousReceived;
    const nextReceivedAt = receivedAmount <= 0 ? null : delta !== 0 ? now : (existing?.received_at ?? now);
    const statements = [];

    if (existing) {
      statements.push(db.prepare(`UPDATE billing_records SET package_id=?,package_name=?,list_amount=?,discount_amount=?,final_amount=?,received_amount=?,received_at=?,updated_at=? WHERE id=?`)
        .bind(data.packageId,packageName,listAmount,discountAmount,finalAmount,receivedAmount,nextReceivedAt,now,id));
    } else {
      statements.push(db.prepare(`INSERT INTO billing_records (id,application_id,client_id,package_id,package_name,list_amount,discount_amount,final_amount,received_amount,received_at,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`)
        .bind(id,data.applicationId??null,data.clientId,data.packageId,packageName,listAmount,discountAmount,finalAmount,receivedAmount,nextReceivedAt,now,now));
    }

    if (delta !== 0) {
      statements.push(db.prepare(`INSERT INTO billing_events (id,billing_id,application_id,client_id,package_name,amount_delta,event_at,note,created_at) VALUES (?,?,?,?,?,?,?,?,?)`)
        .bind(crypto.randomUUID(),id,data.applicationId??null,data.clientId,packageName,delta,now,delta>0?"دریافت وجه":"اصلاح مبلغ دریافتی",now));
    }

    if (data.applicationId) {
      if(combined){
        const previous=db.prepare("SELECT package_items_json FROM applications WHERE id=?").bind(data.applicationId).first<{package_items_json:string}>();
        const previousIds=(JSON.parse(previous?.package_items_json||"[]") as {id:string}[]).map(item=>item.id).sort();
        if(JSON.stringify(previousIds)!==JSON.stringify(combined.items.map(item=>item.id).sort()))statements.push(db.prepare("UPDATE applications SET package_items_json=? WHERE id=?").bind(JSON.stringify(combined.items),data.applicationId));
      }
      if (data.profile) {
        statements.push(db.prepare("UPDATE applications SET package_id=?,package_name=?,price_amount=?,paid_at=?,profile_json=?,updated_at=? WHERE id=?")
          .bind(data.packageId,packageName,finalAmount,receivedAmount>0?nextReceivedAt:null,JSON.stringify(data.profile),now,data.applicationId));
      } else {
        statements.push(db.prepare("UPDATE applications SET package_id=?,package_name=?,price_amount=?,paid_at=?,updated_at=? WHERE id=?")
          .bind(data.packageId,packageName,finalAmount,receivedAmount>0?nextReceivedAt:null,now,data.applicationId));
      }
    }

    db.batch(statements);
    const record = await db.prepare("SELECT * FROM billing_records WHERE id=?").bind(id).first();
    return Response.json({ ok:true, record, receivedDelta:delta });
  } catch (error) {
    console.error("billing_update_failed", error);
    return Response.json({ error: error instanceof z.ZodError ? "مقادیر حسابداری معتبر نیستند." : "ذخیره حسابداری انجام نشد." }, { status: 400 });
  }
}
