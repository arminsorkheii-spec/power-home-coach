import { sensitiveSession } from "@/lib/password-auth";
import { database } from "@/lib/raw-db";

export async function GET(request: Request) {
  if (!(await sensitiveSession(request))) return new Response(null, { status: 401 });

  try {
    const clientId = new URL(request.url).searchParams.get("clientId")?.trim() ?? "";
    if (!clientId || clientId.length > 200) {
      return Response.json({ error: "شناسه شاگرد معتبر نیست." }, { status: 400 });
    }

    const db = database();
    const rows = await db.prepare(`
      SELECT a.id, a.client_id, a.package_name, a.status, a.price_amount,
             a.profile_json, a.created_at, a.updated_at, s.phone
      FROM applications a
      JOIN student_accounts s ON s.client_id = a.client_id
      WHERE a.client_id = ?
      ORDER BY a.created_at ASC
    `).bind(clientId).all<Record<string, unknown>>();

    if (!rows.results.length) return Response.json({ application: null, applications: [] }, { headers: { "cache-control": "no-store" } });

    const applications = await Promise.all(rows.results.map(async (application) => {
      const uploads = await db.prepare(`
        SELECT id, kind, filename, size, created_at
        FROM application_uploads
        WHERE application_id = ?
        ORDER BY created_at ASC
      `).bind(application.id).all<Record<string, unknown>>();
      return {
        ...application,
        profile: JSON.parse(String(application.profile_json || "{}")),
        uploads: uploads.results,
      };
    }));

    return Response.json({
      application: applications[0],
      applications,
    }, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    console.error("client_intake_fetch_failed", error);
    return Response.json({ error: "دریافت سابقه ثبت‌نام انجام نشد." }, { status: 500 });
  }
}
