import { cookies } from "next/headers";
import { CoachApp } from "@/components/coach-app";
import { CoachLogin } from "@/components/coach-login";
import { PackageCatalogProvider } from "@/components/package-catalog";
import { getPackages } from "@/lib/package-pricing";
import { SESSION_COOKIE_NAME, verifySessionToken } from "@/lib/password-auth";

export const dynamic = "force-dynamic";
export default async function CoachPage() {
  const cookieStore = await cookies();
  const authenticated = await verifySessionToken(cookieStore.get(SESSION_COOKIE_NAME)?.value);
  return authenticated ? <PackageCatalogProvider packages={getPackages()}><CoachApp coachName="آرمین سرخه‌ای" /></PackageCatalogProvider> : <CoachLogin />;
}
