import { PasswordGate } from "@/components/password-gate";
import { getPackages } from "@/lib/package-pricing";

export const dynamic = "force-dynamic";
export default function Home() { return <PasswordGate initialPackages={getPackages()} />; }
