import type { Metadata, Viewport } from "next";
import "./globals.css";
import { MobileFormViewport } from "@/components/mobile-form-viewport";

export const metadata: Metadata = {
  title: "کوچینگ بدنسازی آرمین سرخه‌ای",
  description: "انتخاب پکیج کوچینگ، مشاهده رزومه و ورود به پنل اختصاصی آرمین سرخه‌ای",
  manifest: "/manifest.webmanifest",
  applicationName: "Armin Sorkhei Coach",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "Armin Sorkhei",
  },
  icons: {
    icon: "/as-favicon.png",
    shortcut: "/as-favicon.png",
    apple: "/as-apple-touch-icon.png",
  },
};

export const viewport: Viewport = {
  themeColor: "#090a0b",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl">
      <body className="antialiased"><MobileFormViewport />{children}</body>
    </html>
  );
}
