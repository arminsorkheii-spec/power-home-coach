import { cookies } from "next/headers";
import { StudentLogin } from "@/components/student-login";
import { StudentPortal } from "@/components/student-portal";
import { STUDENT_SESSION_COOKIE, verifyStudentSession } from "@/lib/student-auth";
import { smsLoginEnabled } from "@/lib/sms";

export const dynamic = "force-dynamic";
export default async function StudentPage() {
  const cookieStore = await cookies();
  const clientId = await verifyStudentSession(cookieStore.get(STUDENT_SESSION_COOKIE)?.value);
  return clientId ? <StudentPortal /> : <StudentLogin initialSmsEnabled={smsLoginEnabled()} />;
}
