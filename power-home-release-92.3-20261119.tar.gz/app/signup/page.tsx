import { RegistrationFlow } from "@/components/registration-flow";
import { getPackages } from "@/lib/package-pricing";
import { packageById } from "@/lib/packages";

export const dynamic = "force-dynamic";

export default async function SignupPage({ searchParams }: { searchParams: Promise<{ package?: string; new?: string; addon?:string }> }) {
  const query = await searchParams;
  return <RegistrationFlow initialPackages={getPackages()} initialPackage={packageById(query.package ?? "")?.id ?? "natural"} newRequest={query.new === "1"||query.addon === "1"} addon={query.addon === "1"} />;
}
