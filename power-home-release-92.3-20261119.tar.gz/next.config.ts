import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  headers: async () => [
    {
      source: "/",
      headers: [{ key: "Cache-Control", value: "no-store, max-age=0, must-revalidate" }],
    },
    {
      source: "/coach",
      headers: [{ key: "Cache-Control", value: "no-store, max-age=0, must-revalidate" }],
    },
    {
      source: "/student",
      headers: [{ key: "Cache-Control", value: "no-store, max-age=0, must-revalidate" }],
    },
    {
      source: "/signup",
      headers: [{ key: "Cache-Control", value: "no-store, max-age=0, must-revalidate" }],
    },
    {
      source: "/sw.js",
      headers: [
        { key: "Cache-Control", value: "no-store, no-cache, max-age=0, must-revalidate" },
        { key: "Service-Worker-Allowed", value: "/" },
      ],
    },
  ],
};

export default nextConfig;
