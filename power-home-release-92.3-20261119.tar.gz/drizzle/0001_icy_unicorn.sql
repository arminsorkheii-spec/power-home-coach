CREATE TABLE `body_photos` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`checkin_id` text NOT NULL,
	`pose` text NOT NULL,
	`key` text NOT NULL,
	FOREIGN KEY (`checkin_id`) REFERENCES `checkins`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_body_photos_checkin_pose` ON `body_photos` (`owner`,`checkin_id`,`pose`);--> statement-breakpoint
CREATE TABLE `checkins` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`client_id` text NOT NULL,
	`date` text NOT NULL,
	`payload` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_checkins_owner_client_date` ON `checkins` (`owner`,`client_id`,`date`);--> statement-breakpoint
CREATE TABLE `coach_security` (
	`owner` text PRIMARY KEY NOT NULL,
	`password_hash` text NOT NULL,
	`salt` text NOT NULL,
	`revision` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `login_attempts` (
	`key` text PRIMARY KEY NOT NULL,
	`count` integer NOT NULL,
	`reset_at` integer NOT NULL
);
