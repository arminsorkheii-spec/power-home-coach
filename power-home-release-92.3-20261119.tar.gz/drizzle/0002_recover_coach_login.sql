DELETE FROM `coach_security`;
--> statement-breakpoint
DELETE FROM `login_attempts`;
