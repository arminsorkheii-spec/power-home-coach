CREATE TABLE `application_uploads` (
	`id` text PRIMARY KEY NOT NULL,
	`application_id` text NOT NULL,
	`client_id` text NOT NULL,
	`kind` text NOT NULL,
	`key` text NOT NULL,
	`filename` text NOT NULL,
	`content_type` text NOT NULL,
	`size` integer NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`application_id`) REFERENCES `applications`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `idx_application_uploads_application` ON `application_uploads` (`application_id`);--> statement-breakpoint
CREATE INDEX `idx_application_uploads_client_kind` ON `application_uploads` (`client_id`,`kind`);--> statement-breakpoint
CREATE TABLE `applications` (
	`id` text PRIMARY KEY NOT NULL,
	`client_id` text NOT NULL,
	`package_id` text NOT NULL,
	`package_name` text NOT NULL,
	`status` text DEFAULT 'draft' NOT NULL,
	`price_amount` integer,
	`profile_json` text DEFAULT '{}' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`client_id`) REFERENCES `student_accounts`(`client_id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `applications_client_id_unique` ON `applications` (`client_id`);--> statement-breakpoint
CREATE INDEX `idx_applications_status_updated` ON `applications` (`status`,`updated_at`);