DROP INDEX `applications_client_id_unique`;--> statement-breakpoint
CREATE INDEX `idx_applications_client_created` ON `applications` (`client_id`,`created_at`);