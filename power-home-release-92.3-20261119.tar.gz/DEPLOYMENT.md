# Power Home Coach — Iran VPS deployment

The production stack is a standalone Next.js server behind Caddy. Application data is stored in `./data`; Caddy obtains and renews HTTPS certificates automatically.

## Server prerequisites

- Ubuntu 24.04
- Docker Engine with the Compose plugin
- TCP ports 22, 80 and 443 open
- `arminsorkhei.ir`, `www.arminsorkhei.ir` and `app.arminsorkhei.ir` A records pointing to `85.208.255.212`

## Start

1. Copy this repository and the migrated `data` directory to `/opt/power-home-coach`.
2. Create `.env` from `.env.example`, preserving file mode `600`.
3. Run `bash scripts/install-server.sh`.
4. Verify with `docker compose ps` and `curl -I https://arminsorkhei.ir`.

Back up the entire `/opt/power-home-coach/data` directory. It contains both the SQLite database and private uploads.
