import { sql } from "drizzle-orm";
import { sqliteTable, text, integer, index, uniqueIndex } from "drizzle-orm/sqlite-core";

export const coachSecurity = sqliteTable("coach_security", {
  owner: text("owner").primaryKey(),
  passwordHash: text("password_hash").notNull(),
  salt: text("salt").notNull(),
  revision: text("revision").notNull(),
});
export const loginAttempts = sqliteTable("login_attempts", {
  key: text("key").primaryKey(),
  count: integer("count").notNull(),
  resetAt: integer("reset_at").notNull(),
});
export const checkins = sqliteTable("checkins", {
  id: text("id").primaryKey(), owner: text("owner").notNull(),
  clientId: text("client_id").notNull(), date: text("date").notNull(),
  payload: text("payload").notNull(), createdAt: text("created_at").notNull(),
}, (t) => [index("idx_checkins_owner_client_date").on(t.owner, t.clientId, t.date)]);
export const bodyPhotos = sqliteTable("body_photos", {
  id: text("id").primaryKey(), owner: text("owner").notNull(),
  checkinId: text("checkin_id").notNull().references(() => checkins.id),
  pose: text("pose").notNull(), key: text("key").notNull(),
}, (t) => [uniqueIndex("idx_body_photos_checkin_pose").on(t.owner, t.checkinId, t.pose)]);

export const coachStates = sqliteTable("coach_states", {
  ownerEmail: text("owner_email").primaryKey(),
  payload: text("payload").notNull(),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const studentAccounts = sqliteTable("student_accounts", {
  clientId: text("client_id").primaryKey(),
  phone: text("phone").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  salt: text("salt").notNull(),
  revision: text("revision").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const applications = sqliteTable("applications", {
  id: text("id").primaryKey(),
  clientId: text("client_id").notNull().references(() => studentAccounts.clientId),
  packageId: text("package_id").notNull(),
  packageName: text("package_name").notNull(),
  status: text("status").notNull().default("draft"),
  priceAmount: integer("price_amount"),
  paidAt: text("paid_at"),
  profileJson: text("profile_json").notNull().default("{}"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (t) => [
  index("idx_applications_status_updated").on(t.status, t.updatedAt),
  index("idx_applications_client_created").on(t.clientId, t.createdAt),
]);

export const applicationUploads = sqliteTable("application_uploads", {
  id: text("id").primaryKey(),
  applicationId: text("application_id").notNull().references(() => applications.id),
  clientId: text("client_id").notNull(),
  kind: text("kind").notNull(),
  key: text("key").notNull(),
  filename: text("filename").notNull(),
  contentType: text("content_type").notNull(),
  size: integer("size").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (t) => [
  index("idx_application_uploads_application").on(t.applicationId),
  index("idx_application_uploads_client_kind").on(t.clientId, t.kind),
]);

export const pushSubscriptions = sqliteTable("push_subscriptions", {
  id: text("id").primaryKey(),
  role: text("role").notNull(),
  clientId: text("client_id"),
  endpoint: text("endpoint").notNull().unique(),
  p256dh: text("p256dh").notNull(),
  auth: text("auth").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (t) => [index("idx_push_subscriptions_role_client").on(t.role, t.clientId)]);


export const billingRecords = sqliteTable("billing_records", {
  id: text("id").primaryKey(),
  applicationId: text("application_id").unique(),
  clientId: text("client_id").notNull(),
  packageId: text("package_id").notNull(),
  packageName: text("package_name").notNull(),
  listAmount: integer("list_amount").notNull().default(0),
  discountAmount: integer("discount_amount").notNull().default(0),
  finalAmount: integer("final_amount").notNull().default(0),
  receivedAmount: integer("received_amount").notNull().default(0),
  receivedAt: text("received_at"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (t) => [index("idx_billing_records_client").on(t.clientId), index("idx_billing_records_updated").on(t.updatedAt)]);

export const billingEvents = sqliteTable("billing_events", {
  id: text("id").primaryKey(),
  billingId: text("billing_id").notNull(),
  applicationId: text("application_id"),
  clientId: text("client_id").notNull(),
  packageName: text("package_name").notNull(),
  amountDelta: integer("amount_delta").notNull(),
  eventAt: text("event_at").notNull(),
  note: text("note").notNull().default(""),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (t) => [index("idx_billing_events_event_at").on(t.eventAt), index("idx_billing_events_client").on(t.clientId,t.eventAt), index("idx_billing_events_billing").on(t.billingId)]);

export const programAssignments = sqliteTable("program_assignments", {
  id: text("id").primaryKey(), clientId: text("client_id").notNull(), templateId: text("template_id").notNull(),
  programNumber: integer("program_number").notNull(), templateTitle: text("template_title").notNull(), assignedAt: text("assigned_at").notNull(), deliveredAt: text("delivered_at"),
}, (t) => [index("idx_program_assignments_client_template").on(t.clientId,t.templateId), index("idx_program_assignments_client_assigned").on(t.clientId,t.assignedAt)]);
