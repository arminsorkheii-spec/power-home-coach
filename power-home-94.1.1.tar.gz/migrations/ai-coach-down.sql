-- DESTRUCTIVE to AI records only. Export AI drafts/usage/consent audit first. Never auto-run.
DROP TABLE IF EXISTS ai_golden_rules;
DROP TABLE IF EXISTS ai_draft_versions;
DROP TABLE IF EXISTS ai_drafts;
DROP TABLE IF EXISTS ai_jobs;
DROP TABLE IF EXISTS ai_settings;
DROP TABLE IF EXISTS ai_systems;
DROP TABLE IF EXISTS ai_consent_events;
DROP TABLE IF EXISTS ai_consents;
