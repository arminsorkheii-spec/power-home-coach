-- Additive opt-in migration. Test on a disposable copy first; production requires explicit owner approval and backup.
CREATE TABLE IF NOT EXISTS ai_consents(client_id TEXT PRIMARY KEY,version TEXT NOT NULL,data_allowed INTEGER NOT NULL,photos_allowed INTEGER NOT NULL,medical_allowed INTEGER NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS ai_consent_events(id TEXT PRIMARY KEY,client_id TEXT NOT NULL,payload TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS ai_systems(id TEXT PRIMARY KEY,owner TEXT NOT NULL,payload TEXT NOT NULL,approved INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS ai_settings(owner TEXT PRIMARY KEY,payload TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS ai_jobs(id TEXT PRIMARY KEY,owner TEXT NOT NULL,client_id TEXT NOT NULL,month TEXT NOT NULL,fingerprint TEXT NOT NULL,status TEXT NOT NULL,model TEXT NOT NULL,usage TEXT,cost_usd REAL,rate_snapshot TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,UNIQUE(owner,fingerprint));
CREATE TABLE IF NOT EXISTS ai_drafts(id TEXT PRIMARY KEY,owner TEXT NOT NULL,client_id TEXT NOT NULL,parent_id TEXT,request_id TEXT NOT NULL,revision INTEGER NOT NULL,status TEXT NOT NULL,payload TEXT NOT NULL,base_hash TEXT NOT NULL,approved_hash TEXT,applied_revision INTEGER,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS ai_draft_versions(id TEXT PRIMARY KEY,draft_id TEXT NOT NULL,revision INTEGER NOT NULL,payload TEXT NOT NULL,event TEXT NOT NULL,created_at TEXT NOT NULL,UNIQUE(draft_id,revision));
CREATE TABLE IF NOT EXISTS ai_golden_rules(id TEXT PRIMARY KEY,owner TEXT NOT NULL,source_draft_id TEXT NOT NULL,payload TEXT NOT NULL,created_at TEXT NOT NULL);
