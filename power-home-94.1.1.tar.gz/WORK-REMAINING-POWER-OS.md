POWER HOME COACH 94.0.0 — athlete progress and workout tools
Production build and 162 tests passed on 2026-11-22.

Added inside existing sections, preserving navigation and graphic theme:
- encrypted per-day body measurements, cut/bulk/maintenance, weekly mean weight;
- Persian-month image report with existing front/side/back protected photos;
- actual-data athlete card, passport and history export, independent-account access;
- personal workouts, per-set RIR/RPE, duration/volume, plate calculator and record animation;
- per-account durable offline pending-set queue with ordered retries and conflict retention;
- video slow motion, persisted lines/2D angles and protected AAC voice feedback;
- muscle-specific records/history, volume/intensity, reported sleep;
- explicitly shared injury/food/performance preferences and coach rule-based warnings;
- sports expense categories and charts in existing private budget tools;
- default-disabled periodic body/readiness reminders and inactive-athlete coach alerts, no SMS;
- readiness battery visualization (self-report estimate).

Limits: offline support is connection-loss recovery in an already-open workout, not fresh offline page loading. The existing licensed anatomical model appearance has not been changed. Readiness is an estimate, not a physiological measurement. No AI API, fabricated scores, or guaranteed perpetual service. Automatic program delivery remains an explicit coach action. Reminder rules start disabled.

Open separate issue: SMS.ir template 836836 delivers literal #CODE#; provider template/parameter still requires inspection. No SMS configuration altered or real SMS tests sent in this release.

Additional requested refinements still pending: upgraded athletic 3D appearance, fresh offline application startup, ready-for-delivery/revision workflow counters, and post-login visual review.
