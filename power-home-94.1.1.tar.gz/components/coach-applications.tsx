"use client";
import {useAutoRefresh} from "@/hooks/use-auto-refresh";
import {notifyDataUpdated} from "@/lib/auto-refresh";

import { PowerGraphicIcon } from "@/components/power-graphic-icon";
import { PackageChoices } from "@/components/package-choices";
import { usePackages } from "@/components/package-catalog";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  Camera,
  Check,
  ChevronLeft,
  ClipboardList,
  ExternalLink,
  FileText,
  LoaderCircle,
  ImagePlus,
  RefreshCw,
  Search,
  Send,
  UserRound,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PhotoGallery } from "@/components/photo-gallery";


type Upload = { id: string; kind: string; filename: string; content_type: string };
type Application = {
  id: string;
  client_id: string;
  name: string;
  phone: string;
  package_id: string;
  package_items_json?:string;
  parent_application_id?:string|null;
  package_name: string;
  status: string;
  price_amount: number | null;
  updated_at: string;
  profile: Record<string, string>;
  uploads: Upload[];
  billing: { id:string; list_amount:number; discount_amount:number; final_amount:number; received_amount:number } | null;
};

const STATUS_LABELS: Record<string, string> = {
  draft: "درخواست جدید",
  awaiting_payment: "در انتظار پرداخت",
  payment_review: "در حال بررسی پرداخت",
  payment_approved: "پرداخت تأیید شد",
  writing: "در حال نوشتن برنامه",
  ready: "در حال نوشتن برنامه",
  delivered: "برنامه ارسال شده",
};

const TIMELINE = [
  { key: "draft", label: "درخواست" },
  { key: "payment_review", label: "بررسی پرداخت" },
  { key: "payment_approved", label: "تأیید پرداخت" },
  { key: "writing", label: "نوشتن برنامه" },
  { key: "delivered", label: "ارسال برنامه" },
];

const STATUS_RANK: Record<string, number> = {
  draft: 0,
  awaiting_payment: 0,
  payment_review: 1,
  payment_approved: 2,
  writing: 3,
  ready: 3,
  delivered: 4,
};

const PROFILE_LABELS: Record<string, string> = {
  age: "سن",
  height: "قد",
  weight: "وزن",
  waist: "دور کمر",
  arm: "دور بازو",
  goal: "هدف",
  experience: "سابقه تمرین",
  trainingDays: "روزهای تمرین",
  injuries: "آسیب‌دیدگی",
  diseases: "بیماری",
  medications: "داروها",
  allergies: "حساسیت غذایی",
  supplements: "مکمل فعلی",
  sleep: "خواب",
  activity: "فعالیت روزانه",
  notes: "توضیحات",
};

const POSE_NAMES: Record<string, string> = {
  front: "روبه‌رو",
  side: "بغل",
  back: "پشت",
  front_double: "جفت بازو جلو",
  back_double: "جفت بازو پشت",
};

async function compressImage(file: File, targetBytes = 450 * 1024) {
  if (!file.type.startsWith("image/")) return { file, originalSize: file.size };
  const bitmap = await createImageBitmap(file);
  const canvas = document.createElement("canvas");
  let scale = Math.min(1, 1280 / Math.max(bitmap.width, bitmap.height));
  let quality = .72;
  let blob: Blob | null = null;
  for (let attempt = 0; attempt < 7; attempt++) {
    canvas.width = Math.max(1, Math.round(bitmap.width * scale));
    canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    const context = canvas.getContext("2d");
    if (!context) throw new Error("مرورگر امکان کم‌حجم‌کردن عکس را ندارد.");
    context.fillStyle = "#fff";
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    blob = await new Promise<Blob>((resolve, reject) => canvas.toBlob((value) => value ? resolve(value) : reject(new Error("compression")), "image/jpeg", quality));
    if (blob.size <= targetBytes) break;
    if (quality > .48) quality -= .08;
    else scale *= .82;
  }
  bitmap.close();
  if (!blob) throw new Error("کم‌حجم‌کردن عکس انجام نشد.");
  return { file: new File([blob], file.name.replace(/\.[^.]+$/, "") + ".jpg", { type: "image/jpeg" }), originalSize: file.size };
}

type Props = { initialApplicationId?:string; onOpenClient: (clientId: string) => void };

export function CoachApplications({ onOpenClient,initialApplicationId="" }: Props) {
  const [archived,setArchived]=useState(false);
  const [items, setItems] = useState<Application[]>([]);
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [expanded, setExpanded] = useState("");
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all");
  const [photoBusy, setPhotoBusy] = useState("");
  const [photoMessage, setPhotoMessage] = useState<Record<string, string>>({});

  const load = () => {
    setError("");
    return fetch(`/api/applications${archived?"?archived=1":""}`, { cache: "no-store",signal:AbortSignal.timeout(15000) })
      .then(async (response) => {
        const data = await response.json();
        if (!response.ok) throw new Error(data.error);
        setItems(data.applications);
      })
      .catch((reason) => setError(reason instanceof Error ? reason.message : "دریافت درخواست‌ها انجام نشد."));
  };

  useEffect(() => { void load(); }, [archived]);
  useAutoRefresh(load,{intervalMs:20000,enabled:!busy});
  const lastFocusedApplication=useRef("");
  useEffect(()=>{if(initialApplicationId){setExpanded(initialApplicationId);setFilter("all");setQuery("");}},[initialApplicationId]);
  useEffect(()=>{if(initialApplicationId&&lastFocusedApplication.current!==initialApplicationId&&items.some(item=>item.id===initialApplicationId)){lastFocusedApplication.current=initialApplicationId;document.getElementById(`request-${initialApplicationId}`)?.scrollIntoView({block:"start"})}},[initialApplicationId,items]);

  const removeRequest=async(id:string)=>{
    if(!archived&&!window.confirm("این درخواست از فهرست حذف شود؟ حساب شاگرد، برنامه‌ها و سوابق حسابداری باقی می‌مانند. از حذف‌شده‌ها می‌توانی بازگردانی کنی."))return;
    setBusy(id);setError("");
    try{const r=await fetch("/api/applications",{method:"DELETE",headers:{"content-type":"application/json"},body:JSON.stringify({id,restore:archived})});if(!r.ok)throw Error("انجام نشد؛ دوباره امتحان کن.");setExpanded("");await load();notifyDataUpdated();}
    catch(e){setError(e instanceof Error?e.message:"انجام نشد.");}finally{setBusy("");}
  };
  const update = async (id: string, status: string) => {
    setBusy(id);
    setError("");
    try {
      const response = await fetch("/api/applications", {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ id, status }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "تغییر وضعیت انجام نشد.");
      void load();notifyDataUpdated();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "تغییر وضعیت انجام نشد.");
    } finally {
      setBusy("");
    }
  };

  const deliver = async (application: Application) => {
    if (!window.confirm(`برنامه «${application.name}» برای شاگرد ارسال شود؟`)) return;
    setBusy(application.id); setError("");
    try {
      const response = await fetch("/api/program-delivery", { method:"POST", headers:{"content-type":"application/json"}, body:JSON.stringify({clientId:application.client_id,applicationId:application.id}) });
      const data = await response.json() as { error?:string };
      if (!response.ok) throw new Error(data.error ?? "ارسال برنامه انجام نشد.");
      void load();notifyDataUpdated();
    } catch (reason) { setError(reason instanceof Error ? reason.message : "ارسال برنامه انجام نشد."); }
    finally { setBusy(""); }
  };

  const uploadPhoto = async (applicationId: string, kind: string, file?: File) => {
    if (!file) return;
    const key = `${applicationId}:${kind}`;
    setPhotoBusy(key);
    setPhotoMessage((current) => ({ ...current, [applicationId]: "" }));
    try {
      const compressed = await compressImage(file, kind === "receipt" ? 700 * 1024 : 450 * 1024);
      const form = new FormData();
      form.append("file", compressed.file);
      form.append("kind", kind);
      const response = await fetch(`/api/applications/${applicationId}/photos`, { method: "POST", body: form });
      const result = await response.json() as { error?: string };
      if (!response.ok) throw new Error(result.error ?? "ثبت عکس انجام نشد.");
      const sizeMessage = file.type.startsWith("image/") ? ` عکس از ${Math.ceil(compressed.originalSize / 1024).toLocaleString("fa-IR")} به ${Math.ceil(compressed.file.size / 1024).toLocaleString("fa-IR")} کیلوبایت کم‌حجم شد.` : "";
      setPhotoMessage((current) => ({ ...current, [applicationId]: `فایل در همین پرونده ثبت شد و شاگرد هم آن را می‌بیند.${sizeMessage}` }));
      void load();notifyDataUpdated();
    } catch (reason) {
      setPhotoMessage((current) => ({ ...current, [applicationId]: reason instanceof Error ? reason.message : "ثبت عکس انجام نشد." }));
    } finally {
      setPhotoBusy("");
    }
  };

  const counts = useMemo(() => ({
    all: items.length,
    new: items.filter((item) => STATUS_RANK[item.status] === 0).length,
    payment: items.filter((item) => item.status === "payment_review").length,
    writing: items.filter((item) => item.status === "payment_approved" || item.status === "writing" || item.status === "ready").length,
    ready: items.filter((item) => item.status === "delivered").length,
  }), [items]);

  const visible = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return items.filter((item) => {
      const matchesQuery = `${item.name} ${item.phone} ${item.package_name}`.toLowerCase().includes(needle);
      const matchesFilter = filter === "all"
        || (filter === "new" && STATUS_RANK[item.status] === 0)
        || (filter === "payment" && item.status === "payment_review")
        || (filter === "writing" && (item.status === "payment_approved" || item.status === "writing" || item.status === "ready"))
        || (filter === "ready" && item.status === "delivered");
      return matchesQuery && matchesFilter;
    });
  }, [filter, items, query]);

  const filters = [
    { key: "all", label: "همه", count: counts.all },
    { key: "new", label: "جدید", count: counts.new },
    { key: "payment", label: "بررسی پرداخت", count: counts.payment },
    { key: "writing", label: "در حال نوشتن", count: counts.writing },
    { key: "ready", label: "ارسال شده", count: counts.ready },
  ];

  return <section className="request-board" dir="rtl">
    <div className="request-board-head">
      <div><p>مدیریت درخواست‌ها</p><h1><PowerGraphicIcon name="orders" size={46} /> درخواست‌های شاگردان</h1><span>وضعیت هر شاگرد را ببینید و فقط در صورت نیاز جزئیات پرونده را باز کنید.</span></div>
      <Button variant="outline" size="icon" onClick={load} aria-label="بارگیری دوباره"><RefreshCw /></Button>
    </div>

    <Button variant="outline" onClick={()=>{setArchived(!archived);setExpanded("");setFilter("all")}}>{archived?"بازگشت به درخواست‌ها":"درخواست‌های حذف‌شده"}</Button>
    <div className="request-stats">
      {filters.slice(1).map((item) => <button type="button" key={item.key} data-request-tone={item.key} aria-pressed={filter === item.key} onClick={() => setFilter(item.key)} className={filter === item.key ? "active" : ""}><small>{item.label}</small><strong>{item.count.toLocaleString("fa-IR")}</strong></button>)}
    </div>

    <div className="request-tools">
      <div className="request-search"><Search /><Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="جست‌وجوی نام، موبایل یا نوع برنامه" /></div>
      <div className="request-filters">{filters.map((item) => <button type="button" key={item.key} data-request-tone={item.key} aria-pressed={filter === item.key} className={filter === item.key ? "active" : ""} onClick={() => setFilter(item.key)}>{item.label} <b>{item.count.toLocaleString("fa-IR")}</b></button>)}</div>
    </div>

    {error && <p className="request-error" role="alert">{error}</p>}
    <div className="request-list">
      {visible.map((application) => {
        const isOpen = expanded === application.id;
        const currentRank = STATUS_RANK[application.status] ?? 0;
        const profileRows = Object.entries(PROFILE_LABELS).filter(([key]) => application.profile?.[key]);
        const photos = application.uploads.filter((upload) => POSE_NAMES[upload.kind]);
        const documents = application.uploads.filter((upload) => !POSE_NAMES[upload.kind]);
        const receipt = documents.find((upload) => upload.kind === "receipt");
        return <article id={`request-${application.id}`} key={application.id} className={isOpen ? "open" : ""}>
          <div className="request-summary">
            <div className="request-avatar">{application.name.slice(0, 1)}</div>
            <div className="request-person"><strong>{application.name}</strong><span>{application.phone} · {application.parent_application_id?"افزودن خدمت · ":""}{application.package_name}</span></div>
            <span data-status={application.status} className={`request-status request-status-badge status-${application.status}`}><i aria-hidden="true" />{STATUS_LABELS[application.status] ?? application.status}</span>
            <time>{new Date(application.updated_at).toLocaleDateString("fa-IR")}</time>
            <Button variant="outline" onClick={() => setExpanded(isOpen ? "" : application.id)}>جزئیات <ChevronLeft className={isOpen ? "rotate" : ""} /></Button>
          </div>

          {isOpen && <div className="request-details">
            <Button variant="outline" disabled={busy===application.id} onClick={()=>void removeRequest(application.id)}>{archived?"بازگردانی درخواست":"حذف درخواست"}</Button>
            {!archived&&<>
            {application.status === "payment_review" && <div className="request-payment-received"><div><strong>رسید پرداخت دریافت شد</strong><span>فیش داخل همین صفحه باز می‌شود؛ بعد از بررسی، پرداخت را تأیید کنید.</span></div><div>{receipt?.content_type?.startsWith("image/")?<PhotoGallery images={[{src:`/api/application-files/${receipt.id}?v=${application.updated_at}`,label:"رسید پرداخت",caption:`${application.name} · ${application.package_name}`}]} trigger={<><FileText/> مشاهده فیش</>}/>:receipt&&<a href={`/api/application-files/${receipt.id}`} target="_blank" rel="noreferrer"><FileText/> مشاهده فیش PDF</a>}<Button disabled={busy === application.id} onClick={() => update(application.id, "payment_approved")}>{busy === application.id?<LoaderCircle className="animate-spin"/>:<Check/>} تأیید پرداخت و ثبت دریافت در حسابداری</Button></div></div>}
            <div className="request-detail-label">روند درخواست</div>
            <div className="request-timeline">
              {TIMELINE.map((step, index) => <button type="button" key={step.key} data-status={step.key} disabled={busy === application.id || (step.key === "delivered" && application.status === "delivered")} onClick={() => step.key === "delivered" ? void deliver(application) : void update(application.id, step.key === "draft" ? "awaiting_payment" : step.key)} className={index <= currentRank ? "done" : ""}><i>{busy === application.id && index === currentRank ? <LoaderCircle className="animate-spin" /> : index <= currentRank ? <Check /> : index + 1}</i><span>{step.label}</span></button>)}
            </div>
            {application.status === "payment_approved" && <Button disabled={busy === application.id} onClick={() => update(application.id, "writing")} className="h-14 w-full rounded-2xl border border-blue-500/25 bg-blue-500/[.08] text-base font-black text-blue-200 hover:bg-blue-500/[.12]"><Check /> شروع نوشتن برنامه + اعلان شاگرد</Button>}
            {(application.status === "writing" || application.status === "ready") && <Button disabled={busy === application.id} onClick={() => void deliver(application)} className="h-14 w-full rounded-2xl bg-amber-500 text-base font-black text-black shadow-[0_14px_34px_rgba(174,184,196,.20)] hover:bg-amber-400">{busy === application.id ? <LoaderCircle className="animate-spin" /> : <Send />} ارسال برنامه به شاگرد + نوتیفیکیشن</Button>}
            {application.status === "delivered" && <div className="flex min-h-14 items-center justify-center gap-2 rounded-2xl border border-emerald-500/25 bg-emerald-500/[.08] px-4 font-bold text-emerald-400"><Check className="size-5" /> برنامه برای شاگرد ارسال شد</div>}

            <div className="request-details-head"><div><h3>مشخصات و فایل‌های شاگرد</h3><p>پکیج، مشخصات و حسابداری این درخواست از همین‌جا قابل ویرایش است.</p></div><Button onClick={() => onOpenClient(application.client_id)}><UserRound /> باز کردن پرونده برنامه‌ها</Button></div>
            <ApplicationEditor application={application} onSaved={load} />

            {profileRows.length > 0 && <dl className="request-profile-grid">{profileRows.map(([key, label]) => <div key={key}><dt>{label}</dt><dd>{application.profile[key]}</dd></div>)}</dl>}
            <div className="request-photos"><h4><Camera/> عکس‌های شروع این درخواست</h4>{photos.length > 0 && <PhotoGallery images={photos.map((upload) => ({ src: `/api/application-files/${upload.id}?v=${application.updated_at}`, label: POSE_NAMES[upload.kind], caption: application.name, key: upload.kind }))} onReplace={(image,file)=>uploadPhoto(application.id,image.key??"",file)} />}<div className="coach-photo-editor">{Object.entries(POSE_NAMES).map(([kind,label])=>{const exists=photos.some((upload)=>upload.kind===kind);const key=`${application.id}:${kind}`;return <label key={kind} className={photoBusy===key?"busy":""}><input type="file" accept="image/*" disabled={Boolean(photoBusy)} onChange={(event)=>{void uploadPhoto(application.id,kind,event.target.files?.[0]);event.currentTarget.value="";}}/><span>{photoBusy===key?<LoaderCircle className="animate-spin"/>:<ImagePlus/>}{exists?"تعویض":"افزودن"} {label}</span></label>;})}</div>{photoMessage[application.id]&&<p className="coach-photo-message">{photoMessage[application.id]}</p>}</div>
            <div className="request-receipt"><h4><FileText/> رسید پرداخت</h4>{receipt?.content_type?.startsWith("image/")&&<PhotoGallery images={[{src:`/api/application-files/${receipt.id}?v=${application.updated_at}`,label:"رسید پرداخت",caption:`${application.name} · ${application.package_name}`,key:"receipt"}]} onReplace={(image,file)=>uploadPhoto(application.id,image.key??"receipt",file)}/>}<label className="receipt-upload"><input type="file" accept="image/*,application/pdf" disabled={Boolean(photoBusy)} onChange={(event)=>{void uploadPhoto(application.id,"receipt",event.target.files?.[0]);event.currentTarget.value="";}}/><span>{photoBusy===`${application.id}:receipt`?<LoaderCircle className="animate-spin"/>:<ImagePlus/>}{receipt?"تعویض رسید پرداخت":"آپلود رسید پرداخت"}</span></label>{receipt?.content_type==="application/pdf"&&<a className="receipt-pdf" href={`/api/application-files/${receipt.id}`} target="_blank" rel="noreferrer"><FileText/> مشاهده رسید PDF <ExternalLink/></a>}</div>
            {documents.some((upload)=>upload.kind!=="receipt") && <div className="request-documents"><h4>مدارک دیگر</h4><div>{documents.filter((upload)=>upload.kind!=="receipt").map((upload) => <a key={upload.id} href={`/api/application-files/${upload.id}`} target="_blank" rel="noreferrer"><FileText />{upload.kind === "lab" ? "آزمایش" : upload.filename}<ExternalLink /></a>)}</div></div>}
          </>} </div>}
        </article>;
      })}
      {visible.length === 0 && <div className="request-empty">درخواستی با این مشخصات پیدا نشد.</div>}
    </div>
  </section>;
}


function toman(value:number){return `${Math.max(0,Number(value||0)).toLocaleString("fa-IR")} تومان`;}
function ApplicationEditor({application,onSaved}:{application:Application;onSaved:()=>void}){
  const { packages: PACKAGES, packageById } = usePackages();
  const initialPackage=packageById(application.package_id);
  const [packageIds,setPackageIds]=useState<string[]>(()=>{const items=JSON.parse(application.package_items_json||"[]") as {id:string}[];return items.length?items.map(item=>item.id):[application.package_id||"training"]});
  const packageId=packageIds[0]??application.package_id;
  const [profile,setProfile]=useState<Record<string,string>>({...application.profile});
  const [listAmount,setListAmount]=useState(Number(application.billing?.list_amount??application.price_amount??initialPackage?.price??0));
  const [discount,setDiscount]=useState(Number(application.billing?.discount_amount??0));
  const [received,setReceived]=useState(Number(application.billing?.received_amount??0));
  const [saving,setSaving]=useState(false); const [message,setMessage]=useState("");
  const finalAmount=Math.max(0,listAmount-Math.min(discount,listAmount)); const balance=Math.max(0,finalAmount-Math.min(received,finalAmount));
  const choosePackages=(ids:string[])=>{setPackageIds(ids);setListAmount(PACKAGES.filter(p=>ids.includes(p.id)).reduce((n,p)=>n+p.price,0));};
  const save=async()=>{setSaving(true);setMessage("");try{
    const selected=packageById(packageId);
    const billResponse=await fetch("/api/billing",{method:"PUT",headers:{"content-type":"application/json"},body:JSON.stringify({applicationId:application.id,clientId:application.client_id,packageId,packageIds,packageName:PACKAGES.filter(p=>packageIds.includes(p.id)).map(p=>p.name).join(" + "),listAmount:Math.max(0,Math.round(listAmount)),discountAmount:Math.max(0,Math.round(discount)),receivedAmount:Math.max(0,Math.round(received)),profile})});
    const billData=await billResponse.json() as {error?:string}; if(!billResponse.ok)throw new Error(billData.error??"ویرایش پرونده و حسابداری انجام نشد.");
    setMessage("تغییرات پرونده و حسابداری ذخیره شد.");onSaved();
  }catch(e){setMessage(e instanceof Error?e.message:"ذخیره انجام نشد.");}finally{setSaving(false)}};
  return <section className="request-editor">
    <div className="request-detail-label">ویرایش پرونده و حسابداری</div>
    <div className="request-edit-grid">
      <PackageChoices packages={PACKAGES} selected={packageIds} onChange={choosePackages} disabled={saving}/>
      <label><span>مبلغ اصلی</span><Input type="number" inputMode="numeric" min={0} value={listAmount} onChange={e=>setListAmount(Number(e.target.value)||0)}/></label>
      <label><span>تخفیف</span><Input type="number" inputMode="numeric" min={0} value={discount} onChange={e=>setDiscount(Number(e.target.value)||0)}/></label>
      <label><span>وجه دریافتی واقعی</span><Input type="number" inputMode="numeric" min={0} value={received} onChange={e=>setReceived(Number(e.target.value)||0)}/></label>
    </div>
    <div className="request-money-summary"><div><span>مبلغ نهایی</span><strong>{toman(finalAmount)}</strong></div><div><span>دریافتی</span><strong>{toman(Math.min(received,finalAmount))}</strong></div><div><span>مانده</span><strong>{toman(balance)}</strong></div></div>
    <div className="request-profile-editor">{Object.entries(PROFILE_LABELS).map(([key,label])=><label key={key}><span>{label}</span>{["goal","experience","injuries","diseases","medications","allergies","supplements","activity","notes"].includes(key)?<Textarea value={profile[key]??""} onChange={e=>setProfile({...profile,[key]:e.target.value})}/>:<Input value={profile[key]??""} onChange={e=>setProfile({...profile,[key]:e.target.value})}/>}</label>)}</div>
    <div className="request-editor-actions"><Button onClick={()=>void save()} disabled={saving||!packageIds.length}>{saving?<LoaderCircle className="animate-spin"/>:<Check/>} ذخیره همه تغییرات</Button>{message&&<span>{message}</span>}</div>
  </section>;
}
