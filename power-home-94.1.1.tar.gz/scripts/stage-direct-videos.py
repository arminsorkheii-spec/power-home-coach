"""Stage pinned, reviewed direct clips before the live application is stopped."""
import hashlib,json,pathlib,re,subprocess,sys
manifest,stage,image=sys.argv[1:];stage=pathlib.Path(stage);stage.mkdir(parents=True,exist_ok=True)
records=json.loads(pathlib.Path(manifest).read_text());results=[]
for i,v in enumerate(records,1):
 name=v['file'];assert re.fullmatch(r'[-a-z0-9]+\.mp4',name)
 assert v['url'].startswith(('https://raw.githubusercontent.com/namnq/workout-free-videos/','https://wger.de/media/exercise-video/','https://ymove.app/api/free/'))
 original=stage/(name+'.original');output=stage/name
 subprocess.run(['curl','-4','--http1.1','-fLsS','--retry','2','--connect-timeout','20','--max-time','180',v['url'],'-o',str(original)],check=True)
 assert hashlib.sha256(original.read_bytes()).hexdigest()==v['sourceSha256'], 'source checksum mismatch: '+name
 subprocess.run(['docker','run','--rm','--network','none','--user','0:0','-v',str(stage)+':/work','--entrypoint','ffmpeg',image,'-y','-v','error','-i','/work/'+original.name,'-map','0:v:0','-an','-vf',"scale='min(1280,iw)':'min(720,ih)':force_original_aspect_ratio=decrease:force_divisible_by=2",'-c:v','libx264','-preset','fast','-crf','26','-pix_fmt','yuv420p','-movflags','+faststart','/work/'+name],check=True)
 probe=json.loads(subprocess.check_output(['docker','run','--rm','--network','none','-v',str(stage)+':/work:ro','--entrypoint','ffprobe',image,'-v','error','-show_streams','-show_format','-of','json','/work/'+name]));stream=probe['streams'][0]
 assert stream['codec_name']=='h264' and stream['pix_fmt']=='yuv420p' and stream['height']<=720
 assert abs(float(probe['format']['duration'])-v['duration'])<0.5,'duration mismatch: '+name
 output.chmod(0o644);results.append({'file':name,'sha256':hashlib.sha256(output.read_bytes()).hexdigest()})
 original.unlink();print('DIRECT VIDEO VERIFIED',str(i)+'/'+str(len(records)),name,flush=True)
(stage/'verified-assets.json').write_text(json.dumps(results,indent=2)+'\n')
