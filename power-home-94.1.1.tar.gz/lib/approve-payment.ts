import {database} from "./raw-db";
import {getPackageById} from "./package-pricing";
// Call inside the same transaction as the application status update.
export function recordApprovedPayment(application:{id:string;client_id:string;package_id:string;package_name:string;price_amount:number|null},now:string){
 const db=database();
 const existing=db.prepare("SELECT * FROM billing_records WHERE application_id=?").bind(application.id).first<{id:string;final_amount:number;received_at:string|null}>();
 const finalAmount=existing?.final_amount??application.price_amount??getPackageById(application.package_id)?.price;
 if(typeof finalAmount!=="number"||!Number.isSafeInteger(finalAmount)||finalAmount<0)throw Error("مبلغ درخواست مشخص نیست؛ ابتدا مبلغ را وارد کنید.");
 const id=existing?.id??crypto.randomUUID();
 const received=existing?Number(db.prepare("SELECT coalesce(sum(amount_delta),0) total FROM billing_events WHERE billing_id=? AND deleted_at IS NULL").bind(id).first<{total:number}>()?.total??0):0;
 const delta=Math.max(0,finalAmount-received),total=received+delta;
 const at=delta>0?now:existing?.received_at??(total>0?now:null);
 if(existing)db.prepare("UPDATE billing_records SET received_amount=?,received_at=?,updated_at=? WHERE id=?").bind(total,at,now,id).run();
 else db.prepare("INSERT INTO billing_records(id,application_id,client_id,package_id,package_name,list_amount,discount_amount,final_amount,received_amount,received_at,created_at,updated_at) VALUES(?,?,?,?,?,?,0,?,?,?,?,?)").bind(id,application.id,application.client_id,application.package_id,application.package_name,finalAmount,finalAmount,total,at,now,now).run();
 if(delta>0)db.prepare("INSERT INTO billing_events(id,billing_id,application_id,client_id,package_name,amount_delta,event_at,note,created_at) VALUES(?,?,?,?,?,?,?,?,?)").bind(crypto.randomUUID(),id,application.id,application.client_id,application.package_name,delta,now,"دریافت وجه با تأیید پرداخت درخواست",now).run();
 db.prepare("UPDATE applications SET paid_at=? WHERE id=?").bind(at,application.id).run();
 return delta;
}
