import { normalizeDigits } from "./student-auth-client";
import { database } from "./raw-db";

export const SESSION_COOKIE_NAME = "power_home_session";
const SESSION_AGE_SECONDS = 60 * 60 * 24 * 30;

function runtimeEnv() {
  return process.env;
}

function toHex(value: ArrayBuffer) {
  return Array.from(new Uint8Array(value))
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("");
}

function safeEqual(left: string, right: string) {
  if (left.length !== right.length) return false;
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) {
    difference |= left.charCodeAt(index) ^ right.charCodeAt(index);
  }
  return difference === 0;
}

export async function sha256(value: string) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return toHex(digest);
}

async function sign(value: string) {
  const secret = runtimeEnv().APP_SESSION_SECRET;
  if (!secret) return "";
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  return toHex(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(value)));
}

export async function passwordMatches(password: string) {
  const security = await getSecurity();
  if (security) {
    const latin=normalizeDigits(password);
    const variants=new Set([password,latin,latin.replace(/\d/g,d=>"۰۱۲۳۴۵۶۷۸۹"[Number(d)]),latin.replace(/\d/g,d=>"٠١٢٣٤٥٦٧٨٩"[Number(d)])]);
    for(const value of variants) if(safeEqual(await derivePassword(value,security.salt),security.password_hash))return true;
    return false;
  }
  const expectedPassword = runtimeEnv().APP_PASSWORD;
  if (!expectedPassword) return false;
  return safeEqual(await sha256(normalizeDigits(password)), await sha256(normalizeDigits(expectedPassword)));
}

export async function createSessionToken() {
  const expiresAt = Math.floor(Date.now() / 1000) + SESSION_AGE_SECONDS;
  const security = await getSecurity();
  const payload = `${security?.revision ?? "v1"}.${expiresAt}`;
  const signature = await sign(payload);
  return `${payload}.${signature}`;
}

export async function verifySessionToken(token?: string | null) {
  if (!token) return false;
  const [version, expires, signature, extra] = token.split(".");
  const security = await getSecurity();
  if (extra || version !== (security?.revision ?? "v1") || !expires || !signature) return false;
  const expiresAt = Number(expires);
  if (!Number.isFinite(expiresAt) || expiresAt <= Math.floor(Date.now() / 1000)) return false;
  const expectedSignature = await sign(`${version}.${expires}`);
  return Boolean(expectedSignature) && safeEqual(signature, expectedSignature);
}

function sessionFromCookieHeader(cookieHeader: string | null) {
  if (!cookieHeader) return null;
  for (const part of cookieHeader.split(";")) {
    const [name, ...rest] = part.trim().split("=");
    if (name === SESSION_COOKIE_NAME) return rest.join("=");
  }
  return null;
}

export async function requestHasValidSession(request: Request) {
  return verifySessionToken(sessionFromCookieHeader(request.headers.get("cookie")));
}

export function coachDataKey() {
  return runtimeEnv().COACH_DATA_KEY ?? "arminsorkheii@gmail.com";
}

export function sessionCookie(token: string) {
  return `${SESSION_COOKIE_NAME}=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${SESSION_AGE_SECONDS}`;
}

export function clearedSessionCookie() {
  return `${SESSION_COOKIE_NAME}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`;
}

export async function getSecurity() {
  return database().prepare("SELECT password_hash, salt, revision FROM coach_security WHERE owner = ?").bind(coachDataKey()).first<{password_hash:string; salt:string; revision:string}>();
}
export async function derivePassword(password: string, salt: string) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  return toHex(await crypto.subtle.deriveBits({name:"PBKDF2", hash:"SHA-256", salt:new TextEncoder().encode(salt), iterations:100000}, key, 256));
}
export async function sensitiveSession(request: Request) {
  return Boolean(await getSecurity()) && await requestHasValidSession(request);
}
export async function allowPasswordAttempt(request: Request) {
  const forwarded = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim();
  const ip = request.headers.get("cf-connecting-ip") ?? forwarded ?? "unknown";
  const key = await sha256(`${coachDataKey()}:${ip}`);
  const now = Math.floor(Date.now()/1000);
  const row = await database().prepare("INSERT INTO login_attempts (key, count, reset_at) VALUES (?, 1, ?) ON CONFLICT(key) DO UPDATE SET count = CASE WHEN reset_at <= ? THEN 1 ELSE count + 1 END, reset_at = CASE WHEN reset_at <= ? THEN ? ELSE reset_at END RETURNING count").bind(key, now+900, now, now, now+900).first<{count:number}>();
  return Boolean(row && row.count <= 10);
}
