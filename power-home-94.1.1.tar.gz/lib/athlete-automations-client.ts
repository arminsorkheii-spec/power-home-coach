export type AthleteAutomation={bodyEnabled:boolean;bodyDays:number;readinessEnabled:boolean;readinessDays:number;inactiveEnabled:boolean;inactiveDays:number};
export const DEFAULT_AUTOMATION:AthleteAutomation={bodyEnabled:false,bodyDays:30,readinessEnabled:false,readinessDays:1,inactiveEnabled:false,inactiveDays:7};
