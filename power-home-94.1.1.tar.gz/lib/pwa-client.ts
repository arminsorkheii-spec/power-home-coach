export const APP_RELEASE = "94.1.1";

export function bounded<T>(operation: Promise<T>, milliseconds = 12000): Promise<T> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("زمان انتظار تمام شد؛ دوباره تلاش کنید.")), milliseconds);
    operation.then(resolve, reject).finally(() => clearTimeout(timer));
  });
}

let registration: Promise<ServiceWorkerRegistration> | undefined;
export function appServiceWorker() {
  if (!registration) {
    registration = bounded(navigator.serviceWorker.register(`/sw.js?v=${APP_RELEASE}`, { updateViaCache: "none" }))
      .catch(error => { registration = undefined; throw error; });
  }
  return registration;
}

export function portalFetch(url: string, options: RequestInit = {}) {
  return fetch(url, { ...options, signal: AbortSignal.timeout(12000) }).then(response=>{if(response.ok&&!["GET","HEAD"].includes((options.method??"GET").toUpperCase())&&typeof window!=='undefined')window.dispatchEvent(new Event('power-data-updated'));return response});
}
