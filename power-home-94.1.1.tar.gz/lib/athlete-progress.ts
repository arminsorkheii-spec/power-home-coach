import {z} from 'zod';
import {weekStart} from './tracking-dates';
export const BODY_FIELDS=[['weight','وزن','کیلوگرم'],['armLeft','بازوی چپ','سانتی‌متر'],['armRight','بازوی راست','سانتی‌متر'],['thighLeft','ران چپ','سانتی‌متر'],['thighRight','ران راست','سانتی‌متر'],['waist','کمر','سانتی‌متر'],['chest','سینه','سانتی‌متر'],['calfLeft','ساق چپ','سانتی‌متر'],['calfRight','ساق راست','سانتی‌متر']] as const;
export type BodyField=typeof BODY_FIELDS[number][0];
const circumference=z.number().finite().min(5).max(300).nullable();
export const measurementsSchema=z.object({weight:z.number().finite().min(20).max(400).nullable(),armLeft:circumference,armRight:circumference,thighLeft:circumference,thighRight:circumference,waist:circumference,chest:circumference,calfLeft:circumference,calfRight:circumference}).strict().refine(v=>Object.values(v).some(n=>n!==null),'حداقل یک مقدار وارد کن.');
export const phaseLabels={cut:'کات',bulk:'حجم',maintenance:'نگهداری'};
export type BodyEntry={date:string;measurements:Record<BodyField,number|null>;phase:keyof typeof phaseLabels;notes:string};
export function weeklyWeights(rows:{date:string;weight:number|null}[]){const byDay=new Map<string,number>();for(const row of rows)if(row.weight!==null&&Number.isFinite(row.weight))byDay.set(row.date,row.weight);const weeks=new Map<string,number[]>();for(const [date,value] of byDay){const week=weekStart(date);weeks.set(week,[...(weeks.get(week)??[]),value])}return [...weeks].sort(([a],[b])=>a.localeCompare(b)).map(([week,values])=>({week,average:Math.round(values.reduce((n,v)=>n+v,0)/values.length*100)/100,days:values.length}))}
export function pairedDifference(left:number|null|undefined,right:number|null|undefined){return left!=null&&right!=null?Math.round(Math.abs(left-right)*10)/10:null}
export function bodyChange(rows:BodyEntry[]){if(rows.length<2)return null;const result:Partial<Record<BodyField,number>>={};for(const [key]of BODY_FIELDS){const valid=rows.filter(r=>r.measurements[key]!==null).sort((a,b)=>a.date.localeCompare(b.date));if(valid.length>1)result[key]=Math.round((valid.at(-1)!.measurements[key]!-valid[0].measurements[key]!)*10)/10}return result}
