export const SUPPLEMENTAL_MALE_VIDEO_CATALOG = {
  "cc0-dumbbell-hammer-preacher-curl": {
    "id": "cc0-dumbbell-hammer-preacher-curl",
    "name": "Hammer Preacher Curl",
    "file": "cc0-dumbbell-hammer-preacher-curl.mp4",
    "attribution": "namnq/workout-free-videos · CC0-1.0",
    "sourceUrl": "https://github.com/namnq/workout-free-videos",
    "licenseUrl": null
  },
  "cc0-seated-barbell-wrist-curl": {
    "id": "cc0-seated-barbell-wrist-curl",
    "name": "Seated Wrist Curl",
    "file": "cc0-seated-barbell-wrist-curl.mp4",
    "attribution": "namnq/workout-free-videos · CC0-1.0",
    "sourceUrl": "https://github.com/namnq/workout-free-videos",
    "licenseUrl": null
  },
  "cc0-reverse-grip-barbell-curl": {
    "id": "cc0-reverse-grip-barbell-curl",
    "name": "Reverse-Grip EZ Curl",
    "file": "cc0-reverse-grip-barbell-curl.mp4",
    "attribution": "namnq/workout-free-videos · CC0-1.0",
    "sourceUrl": "https://github.com/namnq/workout-free-videos",
    "licenseUrl": null
  },
  "cc0-machine-t-bar-row": {
    "id": "cc0-machine-t-bar-row",
    "name": "Chest-Supported T-Bar Row",
    "file": "cc0-machine-t-bar-row.mp4",
    "attribution": "namnq/workout-free-videos · CC0-1.0",
    "sourceUrl": "https://github.com/namnq/workout-free-videos",
    "licenseUrl": null
  },
  "cc0-bent-over-row": {
    "id": "cc0-bent-over-row",
    "name": "Barbell Bent-Over Row",
    "file": "cc0-bent-over-row.mp4",
    "attribution": "namnq/workout-free-videos · CC0-1.0",
    "sourceUrl": "https://github.com/namnq/workout-free-videos",
    "licenseUrl": null
  },
  "cc0-good-mornings": {
    "id": "cc0-good-mornings",
    "name": "Good Morning",
    "file": "cc0-good-mornings.mp4",
    "attribution": "namnq/workout-free-videos · CC0-1.0",
    "sourceUrl": "https://github.com/namnq/workout-free-videos",
    "licenseUrl": null
  },
  "cc0-cable-hip-abduction": {
    "id": "cc0-cable-hip-abduction",
    "name": "Cable Hip Abduction",
    "file": "cc0-cable-hip-abduction.mp4",
    "attribution": "namnq/workout-free-videos · CC0-1.0",
    "sourceUrl": "https://github.com/namnq/workout-free-videos",
    "licenseUrl": null
  },
  "ymove-7d31d648-432b-4edd-97bc-afc2a3e9e59a": {
    "id": "ymove-7d31d648-432b-4edd-97bc-afc2a3e9e59a",
    "name": "Barbell Deadlift",
    "file": "ymove-7d31d648-432b-4edd-97bc-afc2a3e9e59a.mp4",
    "attribution": "YMove · YMove free commercial samples (in-app use; no standalone library redistribution)",
    "sourceUrl": "https://ymove.app/free-exercise-videos",
    "licenseUrl": null
  },
  "ymove-3901065d-a926-4d63-9306-0f14eb731d7c": {
    "id": "ymove-3901065d-a926-4d63-9306-0f14eb731d7c",
    "name": "Hammer Curls",
    "file": "ymove-3901065d-a926-4d63-9306-0f14eb731d7c.mp4",
    "attribution": "YMove · YMove free commercial samples (in-app use; no standalone library redistribution)",
    "sourceUrl": "https://ymove.app/free-exercise-videos",
    "licenseUrl": null
  },
  "ymove-c76f5f15-aa4e-4a92-a321-520fd6396bc1": {
    "id": "ymove-c76f5f15-aa4e-4a92-a321-520fd6396bc1",
    "name": "Single Arm Dumbbell Row - Legs apart",
    "file": "ymove-c76f5f15-aa4e-4a92-a321-520fd6396bc1.mp4",
    "attribution": "YMove · YMove free commercial samples (in-app use; no standalone library redistribution)",
    "sourceUrl": "https://ymove.app/free-exercise-videos",
    "licenseUrl": null
  },
  "ymove-e7429dd5-c049-40af-9fc1-1605ca00cbdd": {
    "id": "ymove-e7429dd5-c049-40af-9fc1-1605ca00cbdd",
    "name": "Lying Cable Leg Curl",
    "file": "ymove-e7429dd5-c049-40af-9fc1-1605ca00cbdd.mp4",
    "attribution": "YMove · YMove free commercial samples (in-app use; no standalone library redistribution)",
    "sourceUrl": "https://ymove.app/free-exercise-videos",
    "licenseUrl": null
  },
  "ymove-3e96fcc6-7397-4387-ac5b-92569bd670e5": {
    "id": "ymove-3e96fcc6-7397-4387-ac5b-92569bd670e5",
    "name": "Seated Machine Chest Press",
    "file": "ymove-3e96fcc6-7397-4387-ac5b-92569bd670e5.mp4",
    "attribution": "YMove · YMove free commercial samples (in-app use; no standalone library redistribution)",
    "sourceUrl": "https://ymove.app/free-exercise-videos",
    "licenseUrl": null
  },
  "ymove-f03c074c-398c-4c33-abd9-980ec883fdbd": {
    "id": "ymove-f03c074c-398c-4c33-abd9-980ec883fdbd",
    "name": "Cable Bicep Curl rope",
    "file": "ymove-f03c074c-398c-4c33-abd9-980ec883fdbd.mp4",
    "attribution": "YMove · YMove free commercial samples (in-app use; no standalone library redistribution)",
    "sourceUrl": "https://ymove.app/free-exercise-videos",
    "licenseUrl": null
  },
  "wger-7": {
    "id": "wger-7",
    "name": "Bent-over Lateral Raises",
    "file": "wger-7.mp4",
    "attribution": "Goulart · CC-BY-SA 4 · تبدیل به H.264؛ بدون صدا",
    "sourceUrl": "https://wger.de/api/v2/video/7/",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0/deed.en"
  },
  "wger-11": {
    "id": "wger-11",
    "name": "Shoulder Press, on Machine",
    "file": "wger-11.mp4",
    "attribution": "Goulart · CC-BY-SA 4 · تبدیل به H.264؛ بدون صدا",
    "sourceUrl": "https://wger.de/api/v2/video/11/",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0/deed.en"
  },
  "wger-17": {
    "id": "wger-17",
    "name": "Benchpress Dumbbells",
    "file": "wger-17.mp4",
    "attribution": "Goulart · CC-BY-SA 4 · تبدیل به H.264؛ بدون صدا",
    "sourceUrl": "https://wger.de/api/v2/video/17/",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0/deed.en"
  },
  "wger-33": {
    "id": "wger-33",
    "name": "Dumbbell Lunges Walking",
    "file": "wger-33.mp4",
    "attribution": "Goulart · CC-BY-SA 4 · تبدیل به H.264؛ بدون صدا",
    "sourceUrl": "https://wger.de/api/v2/video/33/",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0/deed.en"
  },
  "wger-34": {
    "id": "wger-34",
    "name": "Barbell Lunges Walking",
    "file": "wger-34.mp4",
    "attribution": "Goulart · CC-BY-SA 4 · تبدیل به H.264؛ بدون صدا",
    "sourceUrl": "https://wger.de/api/v2/video/34/",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0/deed.en"
  },
  "wger-42": {
    "id": "wger-42",
    "name": "Squats on Multipress",
    "file": "wger-42.mp4",
    "attribution": "Goulart · CC-BY-SA 4 · تبدیل به H.264؛ بدون صدا",
    "sourceUrl": "https://wger.de/api/v2/video/42/",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0/deed.en"
  },
  "wger-44": {
    "id": "wger-44",
    "name": "Leg Press",
    "file": "wger-44.mp4",
    "attribution": "Goulart · CC-BY-SA 4 · تبدیل به H.264؛ بدون صدا",
    "sourceUrl": "https://wger.de/api/v2/video/44/",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0/deed.en"
  },
  "wger-50": {
    "id": "wger-50",
    "name": "Biceps Curl With Cable",
    "file": "wger-50.mp4",
    "attribution": "Goulart · CC-BY-SA 4 · تبدیل به H.264؛ بدون صدا",
    "sourceUrl": "https://wger.de/api/v2/video/50/",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0/deed.en"
  },
  "wger-53": {
    "id": "wger-53",
    "name": "Preacher Curls",
    "file": "wger-53.mp4",
    "attribution": "Goulart · CC-BY-SA 4 · تبدیل به H.264؛ بدون صدا",
    "sourceUrl": "https://wger.de/api/v2/video/53/",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0/deed.en"
  },
  "wger-68": {
    "id": "wger-68",
    "name": "Shrugs on Multipress",
    "file": "wger-68.mp4",
    "attribution": "Goulart · CC-BY-SA 4 · تبدیل به H.264؛ بدون صدا",
    "sourceUrl": "https://wger.de/api/v2/video/68/",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0/deed.en"
  },
  "wger-70": {
    "id": "wger-70",
    "name": "Pull Ups on Machine",
    "file": "wger-70.mp4",
    "attribution": "Goulart · CC-BY-SA 4 · تبدیل به H.264؛ بدون صدا",
    "sourceUrl": "https://wger.de/api/v2/video/70/",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0/deed.en"
  },
  "wger-72": {
    "id": "wger-72",
    "name": "Hip Thrust",
    "file": "wger-72.mp4",
    "attribution": "Goulart · CC-BY-SA 4 · تبدیل به H.264؛ بدون صدا",
    "sourceUrl": "https://wger.de/api/v2/video/72/",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0/deed.en"
  },
  "wger-78": {
    "id": "wger-78",
    "name": "Facepull",
    "file": "wger-78.mp4",
    "attribution": "Goulart · CC-BY-SA 4 · تبدیل به H.264؛ بدون صدا",
    "sourceUrl": "https://wger.de/api/v2/video/78/",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0/deed.en"
  },
  "cc0-military-press": {
    "id": "cc0-military-press",
    "name": "Standing Barbell Overhead Press",
    "file": "cc0-military-press.mp4",
    "attribution": "namnq/workout-free-videos · CC0-1.0",
    "sourceUrl": "https://github.com/namnq/workout-free-videos",
    "licenseUrl": null
  },
  "wger-13": {
    "id": "wger-13",
    "name": "Seated Calf Raise Machine",
    "file": "wger-13.mp4",
    "attribution": "Goulart · CC-BY-SA 4 · تبدیل به H.264؛ بدون صدا",
    "sourceUrl": "https://wger.de/api/v2/video/13/",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0/deed.en"
  }
} as const;
