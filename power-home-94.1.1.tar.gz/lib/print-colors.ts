/** PDF iframes do not inherit the application's theme variables. Keep print colors
 * fixed to the original paper palette, independently of the active day/night theme. */
export function resolvePrintColors(css:string){
 return css.replace(/var\(--ph-tone-(\d{1,3})_(\d{1,4})\)/g,(token,shade,opacity)=>{
  const value=Number(shade),alpha=Number(opacity)/1000;
  if(value>255||alpha>1)return token;
  return `rgba(${value}, ${value}, ${value}, ${alpha})`;
 });
}
