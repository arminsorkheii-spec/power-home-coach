import {mealFoodText} from "./food-catalog";
import {z} from "zod";
import {database} from "@/lib/raw-db";
import {coachDataKey} from "@/lib/password-auth";
import {programDigest} from "@/lib/program-delivery";
import {type CoachState,type ClientPlan,EXERCISES} from "@/lib/coach-data";
export const habitGoalSchema=z.object({waterMl:z.number().int().min(0).max(10000),sleepHours:z.number().min(0).max(24),steps:z.number().int().min(0).max(100000),adherence:z.number().int().min(0).max(100)}).strict();
export const DEFAULT_HABIT_GOALS={waterMl:2000,sleepHours:8,steps:8000,adherence:80};
export function today(){return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Tehran',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date())}
export const trackingDate=z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(value=>{const d=new Date(value+'T00:00:00Z');return Number.isFinite(d.getTime())&&d.toISOString().slice(0,10)===value&&value>='2020-01-01'&&d.getTime()<=Date.now()+86400000},'تاریخ معتبر نیست.');
export {weekStart} from './tracking-dates';
import {weekStart} from './tracking-dates';
export function trackingState(){const row=database().prepare('SELECT payload FROM coach_states WHERE owner_email=?').bind(coachDataKey()).first<{payload:string}>();return row?JSON.parse(row.payload) as CoachState:null}
export function publishedPlan(clientId:string){const state=trackingState(),plan=state?.plans[clientId];const delivery=database().prepare('SELECT plan_hash FROM current_program_deliveries WHERE client_id=?').bind(clientId).first<{plan_hash:string}>();return plan&&delivery?.plan_hash===programDigest(plan)?plan:null}
export function habitsFor(plan:ClientPlan|null){const parsed=habitGoalSchema.safeParse({...DEFAULT_HABIT_GOALS,...plan?.habitGoals});return {goals:parsed.success?parsed.data:DEFAULT_HABIT_GOALS,meals:(plan?.nutritionMeals??[]).map(m=>({...m,foods:mealFoodText(m)}))}}
export function exerciseCatalog(clientId:string){
 const state=trackingState();
 if(!state?.clients.some(client=>client.id===clientId)){if(!database().prepare('SELECT client_id FROM student_accounts WHERE client_id=?').bind(clientId).first())return [];return EXERCISES.map(({id,nameFa,nameEn,category})=>({id,nameFa,nameEn,category}));}
 const items=new Map([...EXERCISES,...state.customExercises].map(item=>[item.id,item]));
 return [...items.values()].map(({id,nameFa,nameEn,category})=>({id,nameFa,nameEn,category}));
}
export function activeClient(clientId:string){return trackingState()?.clients.some(client=>client.id===clientId)??false}
export type Term={id:string;client_id:string;application_id:string|null;title:string;started_at:string;expires_at:string;duration_days:number;remind_days:number;reminders_enabled:number;active:number};
export function termSummary(row:Term,now=Date.now()){const daysLeft=Math.ceil((new Date(row.expires_at).getTime()-now)/86400000);return {...row,daysLeft,status:daysLeft<=0?'expired':daysLeft<=row.remind_days?'near':'active'}}
