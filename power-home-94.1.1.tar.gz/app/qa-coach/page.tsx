'use client';
import {CoachApp} from '@/components/coach-app';
export default function Preview(){return <CoachApp coachName="پیش‌نمایش پنل مربی"/>}
