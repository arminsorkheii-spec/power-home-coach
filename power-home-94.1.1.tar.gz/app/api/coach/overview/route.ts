import { notificationTarget, type NoticeTarget } from "@/lib/notification-target";
import { database, sameOrigin } from "@/lib/raw-db";
import { requestHasValidSession } from "@/lib/password-auth";

export async function GET(request: Request) {
  if (!(await requestHasValidSession(request))) return Response.json({ error: "ورود مربی لازم است." }, { status: 401 });
  const db = database();
  const [applications, months, transactions, unreconciled, unread, notifications, notificationCount] = await Promise.all([
    db.prepare(`SELECT a.id,a.client_id,a.package_name,a.status,a.price_amount,a.paid_at,a.created_at,a.updated_at,
      COALESCE(json_extract(a.profile_json,'$.name'),'شاگرد') name
      FROM applications a WHERE NOT EXISTS(SELECT 1 FROM application_archives x WHERE x.application_id=a.id) ORDER BY a.updated_at DESC LIMIT 20`).all(),
    db.prepare(`SELECT substr(event_at,1,7) month,
      SUM(CASE WHEN amount_delta>0 THEN 1 ELSE 0 END) payments,
      COUNT(DISTINCT CASE WHEN amount_delta>0 THEN client_id END) students,
      SUM(amount_delta) total
      FROM billing_events WHERE deleted_at IS NULL
      GROUP BY substr(event_at,1,7) ORDER BY month DESC LIMIT 12`).all(),
    db.prepare(`SELECT e.id,e.billing_id,COALESCE(e.application_id,'') application_id,e.client_id,e.amount_delta amount,e.event_at paid_at,e.package_name,e.note,
      COALESCE(json_extract(a.profile_json,'$.name'),'شاگرد') name
      FROM billing_events e
      LEFT JOIN applications a ON a.id=e.application_id
      WHERE e.deleted_at IS NULL
      ORDER BY e.event_at DESC,e.created_at DESC LIMIT 80`).all(),
    db.prepare(`SELECT b.id,b.client_id,b.package_name,b.received_amount,
      COALESCE(SUM(e.amount_delta),0) ledger_amount
      FROM billing_records b LEFT JOIN billing_events e ON e.billing_id=b.id AND e.deleted_at IS NULL
      GROUP BY b.id HAVING b.received_amount<>COALESCE(SUM(e.amount_delta),0)
      ORDER BY b.updated_at DESC LIMIT 30`).all(),
    db.prepare("SELECT COUNT(*) count FROM chat_messages WHERE sender_role='student' AND read_at IS NULL").first<{count:number}>(),
    db.prepare("SELECT id,type,title,body,url,tag,read_at,created_at,actor_client_id,application_id FROM notification_events WHERE recipient_role='coach' ORDER BY created_at DESC LIMIT 60").all(),
    db.prepare("SELECT COUNT(*) count FROM notification_events WHERE recipient_role='coach' AND read_at IS NULL").first<{count:number}>(),
  ]);
  // Names for manually-added billing rows come from coach state.
  let stateNames=new Map<string,string>();
  try{
    const stateRow=await db.prepare("SELECT payload FROM coach_states LIMIT 1").first<{payload:string}>();
    const clients=stateRow?JSON.parse(stateRow.payload).clients??[]:[];
    stateNames=new Map(clients.map((c:{id:string;name:string})=>[c.id,c.name]));
  }catch{/* accounting still works without display-name enrichment */}
  const enrichedTransactions=(transactions.results as Array<Record<string,unknown>>).map((row)=>({...row,name:String(row.name||"")==="شاگرد"?(stateNames.get(String(row.client_id))??"شاگرد"):row.name}));
  return Response.json({ applications: applications.results, months: months.results, transactions: enrichedTransactions, billingIssues: unreconciled.results, notifications: (notifications.results as (NoticeTarget&Record<string,unknown>)[]).map(item=>({...item,url:notificationTarget("coach",item)})), unreadChat: unread?.count??0, unreadNotifications: notificationCount?.count??0 }, { headers: { "cache-control": "no-store" } });
}

export async function POST(request: Request) {
  if (!sameOrigin(request)) return new Response(null,{status:403});
  if (!(await requestHasValidSession(request))) return new Response(null,{status:401});
  return Response.json({ok:true});
}
