import { recordApprovedPayment } from "@/lib/approve-payment";
import { z } from "zod";
import { coachDataKey, sensitiveSession } from "@/lib/password-auth";
import { database, sameOrigin } from "@/lib/raw-db";
import { getPackageById } from "@/lib/package-pricing";
import { createNotification } from "@/lib/notifications";

const editableProfile = z.record(z.string(), z.string().max(3000)).optional();
const patchSchema = z.object({
  id: z.string().uuid(),
  status: z.enum(["draft","awaiting_payment","payment_review","payment_approved","writing","delivered"]).optional(),
  priceAmount: z.number().int().min(0).max(2_000_000_000).nullable().optional(),
  packageId: z.string().max(60).optional(),
  packageName: z.string().trim().max(120).optional(),
  profile: editableProfile,
});

export async function GET(request: Request) {
  if (!(await sensitiveSession(request))) return new Response(null,{status:401});
  try {
    const db=database();
    const archived=new URL(request.url).searchParams.get("archived")==="1";
    const rows=await db.prepare(`SELECT a.*,s.phone FROM applications a JOIN student_accounts s ON s.client_id=a.client_id WHERE ${archived?"":"NOT "}EXISTS(SELECT 1 FROM application_archives x WHERE x.application_id=a.id) ORDER BY a.updated_at DESC`).all<Record<string,unknown>>();
    const state=await db.prepare("SELECT payload FROM coach_states WHERE owner_email=?").bind(coachDataKey()).first<{payload:string}>();
    const names=new Map<string,string>((state?JSON.parse(state.payload).clients:[]).map((c:{id:string;name:string})=>[c.id,c.name]));
    const applications=await Promise.all(rows.results.map(async row=>{
      const uploads=await db.prepare("SELECT id,kind,filename,content_type,size FROM application_uploads WHERE application_id=? ORDER BY created_at").bind(row.id).all();
      const profile=JSON.parse(String(row.profile_json||"{}")) as {name?:string};
      const billing=await db.prepare("SELECT * FROM billing_records WHERE application_id=? LIMIT 1").bind(row.id).first<Record<string,unknown>>();
      return {...row,name:names.get(String(row.client_id))??profile.name??"شاگرد",profile,uploads:uploads.results,billing:billing??null};
    }));
    return Response.json({applications},{headers:{"cache-control":"no-store"}});
  }catch{return Response.json({error:"دریافت درخواست‌ها انجام نشد."},{status:500});}
}

export async function PATCH(request:Request){
  if(!sameOrigin(request)||!(await sensitiveSession(request)))return new Response(null,{status:403});
  try{
    const body=patchSchema.parse(await request.json());
    const db=database();
    const application=await db.prepare("SELECT id,client_id,package_id,package_name,status,profile_json,price_amount FROM applications WHERE id=?").bind(body.id).first<{id:string;client_id:string;package_id:string;package_name:string;status:string;profile_json:string;price_amount:number|null}>();
    if(!application)return new Response(null,{status:404});
    const selected=body.packageId?getPackageById(body.packageId):null;
    const nextPackageId=body.packageId??application.package_id;
    const nextPackageName=body.packageName?.trim()||selected?.name||application.package_name;
    const nextPrice=body.priceAmount!==undefined?body.priceAmount:(body.packageId&&selected?selected.price:application.price_amount);
    const previousProfile=JSON.parse(application.profile_json||"{}") as Record<string,string>;
    const nextProfile=body.profile?{...previousProfile,...body.profile}:previousProfile;
    const nextStatus=body.status??application.status;
    const now=new Date().toISOString();
    db.transaction(()=>{
    if(db.prepare("SELECT 1 FROM application_archives WHERE application_id=?").bind(body.id).first())throw Error("این درخواست حذف شده است.");
    const updated=db.prepare("UPDATE applications SET package_id=?,package_name=?,status=?,price_amount=?,profile_json=?,updated_at=? WHERE id=? AND status=?")
      .bind(nextPackageId,nextPackageName,nextStatus,nextPrice,JSON.stringify(nextProfile),now,body.id,application.status).run();
    if(!Number(updated.changes))throw Error("وضعیت درخواست تغییر کرده است؛ فهرست را تازه‌سازی کنید.");
    if(body.status==="payment_approved")recordApprovedPayment({...application,package_id:nextPackageId,package_name:nextPackageName,price_amount:nextPrice},now);
    });

    if (body.status && body.status !== application.status) {
      const statusNotice:Record<string,{type:string;title:string;body:string}> = {
        awaiting_payment:{type:"awaiting_payment",title:"درخواستت ثبت شد",body:"پرونده آماده مرحله پرداخت است؛ وضعیت را از پنل شاگرد دنبال کن."},
        payment_review:{type:"payment_review",title:"رسید پرداخت در حال بررسی است",body:"رسیدت دریافت شده و مربی در حال بررسی آن است."},
        payment_approved:{type:"payment_approved",title:"رسید پرداخت تأیید شد",body:"پرداختت توسط مربی تأیید شد؛ پرونده آماده شروع نگارش برنامه است."},
        writing:{type:"program_writing",title:"نوشتن برنامه شروع شد",body:"مربی نوشتن برنامه اختصاصی تو را شروع کرده است."},
        delivered:{type:"program_delivered",title:"مربی برنامه‌ات را فرستاد",body:"برنامه جدیدت در پنل شاگرد قابل مشاهده است."},
      };
      const notice=statusNotice[body.status];
      if(notice) await createNotification({role:"student",clientId:application.client_id,applicationId:body.id,type:notice.type,title:notice.title,body:notice.body,url:"/student",tag:`status-${body.id}-${body.status}`});
    }
    return Response.json({ok:true});
  }catch(error){
    return Response.json({error:error instanceof z.ZodError?"اطلاعات ویرایش معتبر نیست.":"به‌روزرسانی درخواست انجام نشد."},{status:400});
  }
}

export async function DELETE(request:Request){
 if(!sameOrigin(request)||!(await sensitiveSession(request)))return new Response(null,{status:403});
 try{const {id,restore}=z.object({id:z.string().uuid(),restore:z.boolean().optional()}).parse(await request.json());const db=database();
 if(!db.prepare("SELECT id FROM applications WHERE id=?").bind(id).first())return new Response(null,{status:404});
 if(restore)db.prepare("DELETE FROM application_archives WHERE application_id=?").bind(id).run();
 else db.prepare("INSERT OR IGNORE INTO application_archives(application_id,archived_at) VALUES(?,?)").bind(id,new Date().toISOString()).run();
 return Response.json({ok:true});
 }catch{return Response.json({error:"حذف یا بازگردانی درخواست انجام نشد."},{status:400});}
}
