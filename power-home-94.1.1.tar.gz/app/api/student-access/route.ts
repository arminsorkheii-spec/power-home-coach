import { coachDataKey, requestHasValidSession } from "@/lib/password-auth";
import { database, sameOrigin } from "@/lib/raw-db";
import { deriveStudentPassword, normalizeDigits, normalizePhone } from "@/lib/student-auth";

async function clientExists(clientId: string) {
  const row = await database().prepare("SELECT payload FROM coach_states WHERE owner_email = ?").bind(coachDataKey()).first<{ payload: string }>();
  if (!row) return false;
  const state = JSON.parse(row.payload) as { clients?: Array<{ id: string }> };
  return Boolean(state.clients?.some((client) => client.id === clientId));
}

export async function GET(request: Request) {
  if (!(await requestHasValidSession(request))) return Response.json({ error: "ورود مربی لازم است." }, { status: 401 });
  const clientId = new URL(request.url).searchParams.get("clientId") ?? "";
  const account = await database().prepare("SELECT phone, updated_at FROM student_accounts WHERE client_id = ?").bind(clientId).first<{ phone: string; updated_at: string }>();
  return Response.json({ account: account?.phone.startsWith("link-") ? null : account ?? null }, { headers: { "cache-control": "no-store" } });
}

export async function PUT(request: Request) {
  if (!sameOrigin(request)) return new Response(null, { status: 403 });
  if (!(await requestHasValidSession(request))) return Response.json({ error: "ورود مربی لازم است." }, { status: 401 });
  try {
    const body = (await request.json()) as { clientId?: unknown; phone?: unknown; password?: unknown };
    if (typeof body.clientId !== "string" || typeof body.phone !== "string" || typeof body.password !== "string") return Response.json({ error: "اطلاعات دسترسی کامل نیست." }, { status: 400 });
    const phone = normalizePhone(body.phone);
    if (!/^09\d{9}$/.test(phone)) return Response.json({ error: "شماره موبایل معتبر نیست." }, { status: 400 });
    if (!(await clientExists(body.clientId))) return Response.json({ error: "شاگرد پیدا نشد." }, { status: 404 });
    const existing = await database().prepare("SELECT client_id,phone FROM student_accounts WHERE client_id=?").bind(body.clientId).first<{client_id:string;phone:string}>();
    if (existing && !existing.phone.startsWith("link-")) {
      await database().prepare("UPDATE student_accounts SET phone=?,updated_at=CURRENT_TIMESTAMP WHERE client_id=?").bind(phone,body.clientId).run();
      return Response.json({ ok:true,phone,passwordPreserved:true }, { headers:{"cache-control":"no-store"} });
    }
    const password=normalizeDigits(body.password);
    if (!/^\d{6}$/.test(password)) return Response.json({ error: "رمز شاگرد باید دقیقاً ۶ رقم باشد." }, { status: 400 });
    const salt = crypto.randomUUID();
    const passwordHash = await deriveStudentPassword(password, salt);
    const revision = crypto.randomUUID();
    await database().prepare("INSERT INTO student_accounts (client_id, phone, password_hash, salt, revision) VALUES (?, ?, ?, ?, ?) ON CONFLICT(client_id) DO UPDATE SET phone = excluded.phone, password_hash = excluded.password_hash, salt = excluded.salt, revision = excluded.revision, updated_at = CURRENT_TIMESTAMP").bind(body.clientId, phone, passwordHash, salt, revision).run();
    return Response.json({ ok: true, phone }, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    const message = error instanceof Error && error.message.includes("UNIQUE") ? "این شماره برای شاگرد دیگری ثبت شده است." : "ساخت دسترسی انجام نشد.";
    return Response.json({ error: message }, { status: 400 });
  }
}
