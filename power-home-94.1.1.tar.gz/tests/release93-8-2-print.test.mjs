import test,{after} from 'node:test';import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';import {createServer} from 'vite';import postcss from 'postcss';
const vite=await createServer({configFile:false,appType:'custom',server:{middlewareMode:true,hmr:false}});after(()=>vite.close());
const {resolvePrintColors}=await vite.ssrLoadModule('/lib/print-colors.ts');
test('isolated PDF frames resolve the paper palette without inherited theme variables',()=>{
 assert.equal(resolvePrintColors('border:1px solid var(--ph-tone-234_1000);background:var(--ph-tone-17_1000);color:var(--ph-tone-255_1000)'), 'border:1px solid rgba(234, 234, 234, 1);background:rgba(17, 17, 17, 1);color:rgba(255, 255, 255, 1)');
 assert.equal(resolvePrintColors('color:var(--ph-tone-100_125);stroke:#68ac88'),'color:rgba(100, 100, 100, 0.125);stroke:#68ac88');
});
test('all shipped print rules keep borders and backgrounds in the standalone PDF stylesheet',async()=>{
 const ast=postcss.parse(await readFile(new URL('../app/globals.css',import.meta.url),'utf8')),rules=[];ast.walkAtRules('media',r=>{if(r.params.includes('print'))rules.push(...r.nodes.map(n=>n.toString()))});
 const css=resolvePrintColors(rules.join('\n'));
 assert.doesNotMatch(css,/var\(--ph-tone-/);assert.match(css,/\.print-brand[^}]*background:\s*rgba\(17, 17, 17, 1\)/);
 assert.match(css,/\.print-meal,\.print-supplement\{border:1px solid #d6d6d6!important/);
 assert.match(css,/\.print-exercise\{border:1px solid #d0d0d0!important/);
 assert.match(await readFile(new URL('../lib/pdf-export.ts',import.meta.url),'utf8'),/return resolvePrintColors\(rules.join/);
});
