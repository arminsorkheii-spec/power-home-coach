import type {GenerationRequest} from './contracts';
type Training=GenerationRequest['training'];
export function selectedMethods(t:Training){return t.methodIds??[t.methodId];}
export function dayMethodRules(t:Training,index:number){
 const methodId=t.dayMethodIds?.[index]??t.methodId;
 if(!t.methodIds)return {methodId,maxSets:t.maxSets,restSeconds:t.restSeconds};
 return {methodId,maxSets:['method-0','method-1'].includes(methodId)?1:methodId==='method-2'?Math.max(7,t.maxSets):methodId==='method-3'?Math.max(10,t.maxSets):t.maxSets,restSeconds:methodId==='method-2'?(t.restSeconds>=30&&t.restSeconds<=45?t.restSeconds:45):t.restSeconds};
}
export function toggleTrainingMethod(t:Training,id:string):Training{
 const before=selectedMethods(t),methodIds=before.includes(id)?before.filter(v=>v!==id):[...before,id];
 if(!methodIds.length)return t;
 const dayMethodIds=Array.from({length:t.sessions},(_,i)=>{const previous=t.dayMethodIds?.[i]??t.methodId;return methodIds.includes(previous)?previous:methodIds[0]});
 // Assign a newly selected system to a visible day; the coach can change every assignment.
 if(!before.includes(id)){const index=dayMethodIds.findIndex((v,i)=>dayMethodIds.indexOf(v)!==i);if(index>=0)dayMethodIds[index]=id;}
 return {...t,methodId:methodIds[0],methodIds,dayMethodIds};
}
