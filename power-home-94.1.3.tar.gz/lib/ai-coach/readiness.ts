import {requestSchema,type GenerationRequest} from './contracts';
type Connection={configured?:boolean;keyConfigured?:boolean;enabled?:boolean;model?:string;settings?:{rateModel:string;rateCheckedAt:string;inputUsdPerMillion:number;outputUsdPerMillion:number}};
export function generationBlockers(r:GenerationRequest,meta:Connection){
 const reasons:string[]=[];
 if(meta.keyConfigured===false)reasons.push('کلید API ثبت نشده است؛ آن را در «اتصال AI و کلید API» ذخیره کن.');
 if(!meta.model)reasons.push('نام مدل AI هنوز تنظیم نشده است.');
 if(meta.configured&&!meta.enabled)reasons.push('در «تنظیمات مصرف و فعال‌سازی AI»، تولید برنامه را فعال کن.');
 const s=meta.settings;if(meta.configured&&s&&(s.rateModel!==meta.model||!s.rateCheckedAt||s.inputUsdPerMillion<=0||s.outputUsdPerMillion<=0))reasons.push('نرخ مصرف همین مدل را در «تنظیمات مصرف و فعال‌سازی AI» ثبت کن.');
 if(!r.engines.length)reasons.push('حداقل یکی از بخش‌های تمرین، غذا یا مکمل را انتخاب کن.');
 if(!r.profile.reviewed)reasons.push('تیک بررسی مشخصات، تجهیزات و محدودیت‌های شاگرد را بزن.');
 for(const [k,label,min,max] of [['age','سن',18,85],['weight','وزن',30,300],['height','قد',120,230]] as const)if(!Number.isFinite(r.profile[k])||r.profile[k]<min||r.profile[k]>max)reasons.push(`${label} شاگرد را کامل کن؛ مقدار مجاز ${min} تا ${max} است.`);
 if(r.engines.includes('training')&&!r.training.allowedExerciseIds.length)reasons.push('گزینه استفاده از بانک حرکات سایت را انتخاب کن یا حرکات مجاز را از تنظیمات بیشتر مشخص کن.');
 if(r.engines.includes('nutrition')&&!r.nutrition.allowedFoodIds.length)reasons.push('گزینه استفاده از بانک غذای سایت را انتخاب کن یا غذاهای مجاز را از تنظیمات بیشتر مشخص کن.');
 const medical=[r.profile.injuries,r.profile.medicalConditions,r.profile.medications,r.profile.allergies,r.profile.digestion].some(v=>v.trim()&&!/^(ندارم|ندارد|خیر|هیچ|none|no|-)$/i.test(v.trim()));
 if(medical&&!r.allowMedical)reasons.push('برای درنظرگرفتن محدودیت‌های سلامت، گزینه استفاده از اطلاعات سلامت را انتخاب کن.');
 if(!reasons.length){const result=requestSchema.safeParse({...r,requestId:r.requestId||'00000000-0000-4000-8000-000000000000'});if(!result.success)reasons.push(result.error.issues[0]?.message??'اطلاعات فرم را کامل کن.');}
 return reasons;
}
