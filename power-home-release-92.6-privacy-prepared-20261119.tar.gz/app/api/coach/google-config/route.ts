import {requestHasValidSession} from '@/lib/password-auth';
import {sameOrigin} from '@/lib/raw-db';
import {googlePublicSettings,googleSettingsSchema,saveGoogleSettings} from '@/lib/google-config';
const headers={'cache-control':'no-store'};
export async function GET(request:Request){if(!await requestHasValidSession(request))return new Response(null,{status:401,headers});try{return Response.json(googlePublicSettings(),{headers})}catch{return Response.json({error:'خواندن تنظیمات گوگل انجام نشد.'},{status:500,headers})}}
export async function PUT(request:Request){if(!sameOrigin(request)||!await requestHasValidSession(request))return new Response(null,{status:403,headers});try{const text=await request.text();if(text.length>4096)return new Response(null,{status:413,headers});const value=googleSettingsSchema.parse(JSON.parse(text));return Response.json({ok:true,...saveGoogleSettings(value)},{headers})}catch(error){return Response.json({error:error instanceof Error&&error.message==='google_secret_required'?'برای شناسه جدید، کلید محرمانه متناظر را نیز وارد کنید.':'ذخیره انجام نشد؛ Client ID و Client secret را دقیق و کامل از گوگل کپی کنید.'},{status:400,headers})}}
