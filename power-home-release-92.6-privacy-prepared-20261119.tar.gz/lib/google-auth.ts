import {createHash,createHmac,randomBytes,timingSafeEqual} from 'node:crypto';
import {createRemoteJWKSet,jwtVerify} from 'jose';
import {database} from '@/lib/raw-db';
import {googleCredentials,googlePublicSettings} from '@/lib/google-config';
export const GOOGLE_FLOW_COOKIE='__Host-power_home_google_flow',GOOGLE_SIGNUP_COOKIE='__Host-power_home_google_signup';
export function googleConfigured(){try{return googlePublicSettings().configured}catch{return false}}
export function googleOrigin(){const url=new URL(process.env.APP_ORIGIN??'https://arminsorkhei.ir');if(url.protocol!=='https:'||url.pathname!=='/'||url.search||url.hash)throw new Error('google_configuration');return url.origin}
export function googleRedirect(){return googleOrigin()+'/api/student/google/callback'}
function mac(value:string){const secret=process.env.APP_SESSION_SECRET;if(!secret)throw new Error('google_configuration');return createHmac('sha256',secret).update(value).digest('base64url')}
export function tokenHash(value:string){return createHash('sha256').update(value).digest('hex')}
export function cookieFrom(request:Request,name:string){return (request.headers.get('cookie')??'').split(';').map(v=>v.trim()).find(v=>v.startsWith(name+'='))?.slice(name.length+1)??''}
export function authCookie(name:string,value:string,age:number){return `${name}=${value}; Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age=${age}`}
export type GoogleFlow={state:string;nonce:string;verifier:string;expires:number;linkClientId?:string;linkRevision?:string};
export function makeGoogleFlow(link?:{clientId:string;revision:string}){const flow:GoogleFlow={state:randomBytes(32).toString('base64url'),nonce:randomBytes(32).toString('base64url'),verifier:randomBytes(48).toString('base64url'),expires:Date.now()+600000,...(link?{linkClientId:link.clientId,linkRevision:link.revision}:{})};const payload=Buffer.from(JSON.stringify(flow)).toString('base64url');return {flow,cookie:payload+'.'+mac(payload)}}
export function readGoogleFlow(value:string,state:string){try{if(value.length>3000||state.length>100)return null;const [payload,signature,extra]=value.split('.'),expected=mac(payload);if(extra||!signature||signature.length!==expected.length||!timingSafeEqual(Buffer.from(signature),Buffer.from(expected)))return null;const flow=JSON.parse(Buffer.from(payload,'base64url').toString()) as GoogleFlow;if(flow.expires<Date.now()||flow.state!==state||!flow.verifier||!flow.nonce)return null;return flow}catch{return null}}
const keys=createRemoteJWKSet(new URL('https://www.googleapis.com/oauth2/v3/certs'),{timeoutDuration:10000});
export async function verifyGoogleToken(token:string,nonce:string){const {payload}=await jwtVerify(token,keys,{issuer:['https://accounts.google.com','accounts.google.com'],audience:googleCredentials().clientId,algorithms:['RS256'],requiredClaims:['exp','iat','sub','email','nonce']});if(payload.nonce!==nonce||(payload.azp!==undefined&&payload.azp!==googleCredentials().clientId)||payload.email_verified!==true||typeof payload.sub!=='string'||!payload.sub||payload.sub.length>255||typeof payload.email!=='string'||payload.email.length>254||!payload.email.includes('@'))throw new Error('google_identity');return {subject:payload.sub,email:payload.email,name:typeof payload.name==='string'?payload.name.slice(0,80):''}}
export type GoogleSignup={token_hash:string;subject:string;email:string;name:string;expires_at:number};
export function pendingGoogleSignup(token:string){if(!token||token.length>100)return null;return database().prepare('SELECT * FROM google_registration_proofs WHERE token_hash=? AND expires_at>?').bind(tokenHash(token),Date.now()).first<GoogleSignup>()}
