"use client";
import {useEffect,useState,type FormEvent} from 'react';
type Status={configured:boolean;clientId:string;secretConfigured:boolean;redirectUri:string|null};
export function GoogleSetupStatus(){
 const [status,setStatus]=useState<Status|null>(null),[clientId,setClientId]=useState('947137980751-bc0knaopgpt8ce781p0ngt31105j2ver.apps.googleusercontent.com'),[secret,setSecret]=useState(''),[busy,setBusy]=useState(false),[message,setMessage]=useState(''),[failed,setFailed]=useState(false);
 useEffect(()=>{fetch('/api/coach/google-config',{cache:'no-store'}).then(async r=>{if(!r.ok)throw Error();const value=await r.json() as Status;setStatus(value);if(value.clientId)setClientId(value.clientId)}).catch(()=>{setFailed(true);setMessage('خواندن تنظیمات گوگل انجام نشد؛ صفحه را دوباره باز کنید.')})},[]);
 async function save(event:FormEvent){event.preventDefault();setBusy(true);setMessage('');setFailed(false);try{const response=await fetch('/api/coach/google-config',{method:'PUT',headers:{'content-type':'application/json'},body:JSON.stringify({clientId:clientId.trim(),...(secret.trim()?{clientSecret:secret.trim()}:{})})});const value=await response.json() as Status&{error?:string};if(!response.ok)throw Error(value.error??'ذخیره انجام نشد.');setStatus(value);setClientId(value.clientId);setSecret('');setMessage('تنظیمات گوگل ذخیره شد. برای تأیید اتصال، ورود با گوگل را آزمایش کنید.')}catch(e){setFailed(true);setMessage(e instanceof Error?e.message:'ذخیره انجام نشد.')}finally{setBusy(false)}}
 return <section className="google-setup-status" id="google-settings"><h2>ورود شاگرد با گوگل</h2><p>شناسه و کلید را از Google Cloud کپی و در کادرهای زیر جای‌گذاری کن؛ به کنسول سرور نیازی نیست.</p>
 <form onSubmit={save} className="google-settings-form" autoComplete="off">
 <label htmlFor="google-client-id">شناسه گوگل (Client ID)</label><input id="google-client-id" dir="ltr" type="text" value={clientId} onChange={e=>setClientId(e.target.value)} autoComplete="off" autoCapitalize="none" spellCheck={false} maxLength={255} required disabled={busy}/>
 <label htmlFor="google-client-secret">کلید محرمانه (Client secret)</label><input id="google-client-secret" dir="ltr" type="password" value={secret} onChange={e=>setSecret(e.target.value)} autoComplete="new-password" autoCapitalize="none" spellCheck={false} maxLength={512} required={!status?.secretConfigured} disabled={busy} placeholder={status?.secretConfigured?'کلید ذخیره شده؛ برای حفظ آن این کادر را خالی بگذار':'GOCSPX-…'}/>
 <small>کلید با رمزنگاری روی سرور ذخیره می‌شود و دوباره به مرورگر برگردانده نمی‌شود. برای تغییر Client ID، کلید متناظر را هم وارد کن.</small>
 <button type="submit" disabled={busy||!status}>{busy?'در حال ذخیره…':'ذخیره تنظیمات گوگل'}</button>
 </form><p role="status" aria-live="polite" className={failed?'register-error':''}>{message}</p>
 {status&&<p>{status.configured?'تنظیمات ذخیره شده است؛ ورود واقعی هنوز باید آزمایش شود.':'اتصال هنوز کامل نشده است.'}</p>}
 {status?.redirectUri&&<p>آدرس بازگشت در Google Cloud: <bdi>{status.redirectUri}</bdi></p>}
 {status?.configured&&<a href="/api/student/google/start" target="_blank" rel="noreferrer">آزمایش ورود با گوگل</a>}
 <small>شاگرد قدیمی باید گوگل را از داخل حساب خودش به پرونده قبلی متصل کند.</small></section>
}
