"use client";

import {GoogleSignInButton} from "@/components/google-sign-in-button";
import { SignupPhoneVerification } from "@/components/signup-phone-verification";
import { PackageChoices } from "@/components/package-choices";
import { PaymentDetails } from "@/components/payment-details";
import { usePackages } from "@/components/package-catalog";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { ArrowLeft, ArrowRight, Camera, Check, FileHeart, FlaskConical, LoaderCircle, LockKeyhole, Phone, Upload, UserRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { PACKAGES as DEFAULT_PACKAGES, type Package, formatPrice } from "@/lib/packages";

const POSES = [
  { id: "front", label: "روبه‌رو", hint: "صاف، دست‌ها کنار بدن", guide: "/guides/pose-front.webp" },
  { id: "side", label: "بغل", hint: "پهلو کامل رو به دوربین", guide: "/guides/pose-side.webp" },
  { id: "back", label: "پشت", hint: "پشت به دوربین، دست‌ها کنار بدن", guide: "/guides/pose-back.webp" },
  { id: "front_double", label: "جفت بازو از جلو", hint: "بازوها بالا و آرنج‌ها هم‌سطح", guide: "/guides/pose-front-double.webp" },
  { id: "back_double", label: "جفت بازو از پشت", hint: "پشت به دوربین و جفت بازو", guide: "/guides/pose-back-double.webp" },
] as const;

type Profile = { age:string; gender:string; height:string; weight:string; waist:string; arm:string; goal:string; experience:string; trainingDays:string; injuries:string; diseases:string; medications:string; allergies:string; supplements:string; sleep:string; activity:string; notes:string };
const EMPTY: Profile = { age:"",gender:"مرد",height:"",weight:"",waist:"",arm:"",goal:"",experience:"",trainingDays:"",injuries:"",diseases:"",medications:"",allergies:"",supplements:"",sleep:"",activity:"",notes:"" };
type UploadRow = { id:string;kind:string;filename:string;size:number };

async function compressImage(file: File, targetBytes = 450 * 1024) {
  if (!file.type.startsWith("image/")) return { file, originalSize: file.size };
  const bitmap = await createImageBitmap(file);
  const canvas = document.createElement("canvas");
  let scale = Math.min(1, 1280 / Math.max(bitmap.width, bitmap.height));
  let quality = .72;
  let blob: Blob | null = null;
  for (let attempt = 0; attempt < 7; attempt++) {
    canvas.width = Math.max(1, Math.round(bitmap.width * scale));
    canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    const context = canvas.getContext("2d");
    if (!context) throw new Error("مرورگر امکان فشرده‌سازی عکس را ندارد.");
    context.fillStyle = "#fff";
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    blob = await new Promise<Blob>((resolve, reject) => canvas.toBlob((value) => value ? resolve(value) : reject(new Error("compression")), "image/jpeg", quality));
    if (blob.size <= targetBytes) break;
    if (quality > .48) quality -= .08;
    else scale *= .82;
  }
  bitmap.close();
  if (!blob) throw new Error("فشرده‌سازی عکس انجام نشد.");
  return { file: new File([blob], file.name.replace(/\.[^.]+$/, "") + ".jpg", { type: "image/jpeg" }), originalSize: file.size };
}

export function RegistrationFlow({ initialPackage, newRequest = false, addon = false, initialPackages = DEFAULT_PACKAGES, initialSmsEnabled = false,initialGoogleProfile }: { initialPackage: string; newRequest?: boolean; addon?: boolean; initialPackages?:readonly Package[];initialSmsEnabled?:boolean;initialGoogleProfile?:{name:string;email:string} }) {
  const { packages: PACKAGES, packageById, loading: pricesLoading, error: pricesError } = usePackages(initialPackages);
  const [selectedIds,setSelectedIds]=useState<string[]>(addon?[]:[initialPackage]);
  const [smsMode,setSmsMode]=useState(initialSmsEnabled),[registrationToken,setRegistrationToken]=useState("");
  const googleMode=Boolean(initialGoogleProfile);
  const needsVerification=smsMode&&!newRequest&&!googleMode;
  const [requestId,setRequestId]=useState("");
  useEffect(()=>setRequestId(crypto.randomUUID()),[]);
  const [applicationPrice,setApplicationPrice]=useState<number|null|undefined>(undefined);
  const [step,setStep]=useState(1); const [registered,setRegistered]=useState(false);
  const [account,setAccount]=useState({name:initialGoogleProfile?.name??"",phone:"",password:"",packageId:initialPackage});
  const [profile,setProfile]=useState<Profile>(EMPTY); const [uploads,setUploads]=useState<UploadRow[]>([]);
  const [compression,setCompression]=useState<Record<string,{before:number;after:number}>>({});
  const [busy,setBusy]=useState(false); const [uploading,setUploading]=useState(""); const [error,setError]=useState("");
  const selected=useMemo(()=>{const items=PACKAGES.filter(p=>selectedIds.includes(p.id));return {name:items.map(p=>p.name).join(" + "),price:items.reduce((n,p)=>n+p.price,0),requiresLabs:items.some(p=>p.requiresLabs)}},[selectedIds,PACKAGES]);
  const uploadedKinds=new Set(uploads.map(item=>item.kind));

  useEffect(()=>{ fetch("/api/student/application",{cache:"no-store"}).then(async r=>{if(!r.ok)return;const data=await r.json() as {application:{package_id:string;package_items_json?:string;price_amount:number|null;profile?:Profile;status:string};uploads:UploadRow[]};setApplicationPrice(data.application.price_amount);setRegistered(true);setProfile({...EMPTY,...data.application.profile});if(newRequest){setUploads([]);setStep(1);return;}setAccount(v=>({...v,packageId:data.application.package_id}));const saved=JSON.parse(data.application.package_items_json||"[]") as {id:string}[];setSelectedIds(saved.length?saved.map(item=>item.id):[data.application.package_id]);setUploads(data.uploads);setStep(data.application.status==="draft"?2:4);}).catch(()=>{}); },[newRequest]);

  const register=async()=>{setBusy(true);setError("");try{const r=await fetch("/api/register",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({...account,authMethod:googleMode?"google":"phone",...(needsVerification?{password:undefined,registrationToken}:{}),packageIds:selectedIds})});const d=await r.json() as {error?:string;priceAmount:number;verificationRequired?:boolean};if(!r.ok){if(d.verificationRequired){setSmsMode(true);setRegistrationToken("");}throw new Error(d.error);}setApplicationPrice(d.priceAmount);setRegistered(true);setStep(2);}catch(e){setError(e instanceof Error?e.message:"ثبت‌نام انجام نشد.");}finally{setBusy(false);}};
  const createNewRequest=async()=>{setBusy(true);setError("");try{const r=await fetch("/api/student/application",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({packageIds:selectedIds,addon,requestId})});const d=await r.json() as {error?:string;priceAmount:number};if(!r.ok)throw new Error(d.error);setApplicationPrice(d.priceAmount);setRegistered(true);setUploads([]);setStep(2);}catch(e){setError(e instanceof Error?e.message:"درخواست جدید ساخته نشد.");}finally{setBusy(false);}};
  const saveProfile=async(finalize=false)=>{setBusy(true);setError("");try{const r=await fetch("/api/student/application",{method:"PUT",headers:{"content-type":"application/json"},body:JSON.stringify({profile,finalize})});const d=await r.json() as {error?:string};if(!r.ok)throw new Error(d.error);setStep(finalize?4:3);}catch(e){setError(e instanceof Error?e.message:"ذخیره انجام نشد.");}finally{setBusy(false);}};
  const upload=async(file:File|undefined,kind:string)=>{if(!file)return;setUploading(kind);setError("");try{const result=await compressImage(file,kind==="lab"?900*1024:450*1024);const compressed=result.file;const form=new FormData();form.append("file",compressed);form.append("kind",kind);const r=await fetch("/api/student/application-upload",{method:"POST",body:form});const d=await r.json() as {id?:string;size?:number;error?:string};if(!r.ok||!d.id)throw new Error(d.error);setUploads(v=>[...v.filter(x=>kind==="lab"||x.kind!==kind),{id:d.id!,kind,filename:compressed.name,size:d.size??compressed.size}]);if(file.type.startsWith("image/"))setCompression(v=>({...v,[kind]:{before:result.originalSize,after:d.size??compressed.size}}));}catch(e){setError(e instanceof Error?e.message:"آپلود انجام نشد.");}finally{setUploading("");}};

  return <main className="register-page" dir="rtl"><header className="register-header"><Link href="/" className="student-brand"><span>AS</span><div><strong>آرمین سرخه‌ای</strong><small>ONLINE COACHING</small></div></Link><Link className="register-back-link" href={newRequest?"/student":"/"}><ArrowRight/> {newRequest?"بازگشت به پنل":"بازگشت"}</Link></header>
    <div className="register-shell"><div className="register-progress">{["حساب","مشخصات","مدارک","هزینه"].map((label,i)=><div key={label} className={step>=i+1?"active":""}><span>{step>i+1?<Check/>:i+1}</span><small>{label}</small></div>)}</div>
      {step===1&&<section className="register-card"><div className="register-title"><UserRound/><div><p>مرحله ۱ از ۴</p><h1>{addon?"افزودن خدمت به برنامه فعلی":newRequest?"درخواست برنامه جدید":"ساخت حساب شاگرد"}</h1><span>{addon?"فقط خدمات جدید را انتخاب کن؛ برنامه فعلی و سوابق پرداختت حفظ می‌شوند.":newRequest?"خدمات دوره جدید را انتخاب کن؛ اطلاعات و عکس‌های این دوره جداگانه ثبت می‌شوند.":googleMode?"حساب گوگل تأیید شده؛ مشخصات و خدماتت را انتخاب کن.":smsMode?"ابتدا شماره موبایل را با کد پیامکی تأیید کن؛ نیازی به رمز ثابت نیست.":"برای پیگیری برنامه، شماره موبایل و یک رمز ۶ رقمی ثبت کن."}</span></div></div>
        {!newRequest&&!googleMode&&<GoogleSignInButton/>}
        {googleMode&&<div className="signup-google-confirmed"><p>حساب گوگل تأیید شد: <bdi>{initialGoogleProfile?.email}</bdi></p><p>قبلاً شاگرد بودی؟ ابتدا وارد پرونده قبلی شو و گوگل را از داخل همان پنل متصل کن.</p><a href="/student">ورود به پرونده قبلی</a> · <a href="/signup?auth=phone">ثبت‌نام با شماره موبایل</a></div>}
        {needsVerification&&<SignupPhoneVerification phone={account.phone} verified={Boolean(registrationToken)} disabled={busy} onPhoneChange={phone=>{setAccount({...account,phone});setRegistrationToken("");setError("");}} onVerified={setRegistrationToken}/>}
        {(!needsVerification||registrationToken)&&<PackageChoices packages={addon?PACKAGES.filter(p=>p.id!=="natural"&&p.id!=="professional"):PACKAGES} selected={selectedIds} disabled={busy||pricesLoading} onChange={ids=>{setSelectedIds(ids);setRequestId(crypto.randomUUID());}}/>}
        {!newRequest&&(!needsVerification||registrationToken)&&<div className="register-grid"><label>نام و نام خانوادگی<Input value={account.name} onChange={e=>setAccount({...account,name:e.target.value})} placeholder="مثلاً محمد زارع"/></label>{!needsVerification&&!googleMode&&<><label>شماره موبایل<div className="register-input-icon"><Phone/><Input inputMode="tel" value={account.phone} onChange={e=>setAccount({...account,phone:e.target.value})} placeholder="09xxxxxxxxx"/></div></label><label>رمز ۶ رقمی<div className="register-input-icon"><LockKeyhole/><Input inputMode="numeric" maxLength={6} value={account.password} onChange={e=>setAccount({...account,password:e.target.value.replace(/[۰-۹]/g,d=>String("۰۱۲۳۴۵۶۷۸۹".indexOf(d))).replace(/[٠-٩]/g,d=>String("٠١٢٣٤٥٦٧٨٩".indexOf(d))).replace(/\D/g,"")})} placeholder="••••••"/></div></label></>}</div>}
        {pricesError&&<p className="register-error" role="alert">{pricesError} <button type="button" onClick={()=>window.location.reload()}>تلاش دوباره</button></p>}{error&&<p className="register-error">{error}</p>}<Button onClick={newRequest?createNewRequest:register} disabled={busy||pricesLoading||Boolean(pricesError)||!selectedIds.length||(newRequest&&!requestId)||(needsVerification&&!registrationToken)} className="register-next">{busy?<LoaderCircle className="animate-spin"/>:<ArrowLeft/>} {newRequest?"شروع ثبت اطلاعات جدید":"ثبت‌نام و ادامه"}</Button></section>}
      {step===2&&registered&&<section className="register-card"><div className="register-title"><FileHeart/><div><p>مرحله ۲ از ۴</p><h1>اطلاعات بدنی و سابقه</h1><span>اطلاعات دقیق‌تر یعنی برنامه دقیق‌تر و ایمن‌تر.</span></div></div>
        <div className="register-grid three">{[["سن","age"],["قد (سانتی‌متر)","height"],["وزن (کیلوگرم)","weight"],["دور کمر","waist"],["دور بازو","arm"],["تعداد روز تمرین","trainingDays"],["میانگین خواب","sleep"]].map(([label,key])=><label key={key}>{label}<Input value={profile[key as keyof Profile]} onChange={e=>setProfile({...profile,[key]:e.target.value})}/></label>)}<label>جنسیت<select value={profile.gender} onChange={e=>setProfile({...profile,gender:e.target.value})}><option>مرد</option><option>زن</option></select></label></div>
        <div className="register-grid">{[["هدف دقیق","goal"],["سابقه تمرینی","experience"],["شغل و میزان فعالیت روزانه","activity"],["آسیب‌دیدگی یا محدودیت حرکتی","injuries"],["بیماری یا سابقه پزشکی","diseases"],["داروهای مصرفی","medications"],["حساسیت غذایی","allergies"],["مکمل‌های فعلی","supplements"],["توضیحات تکمیلی","notes"]].map(([label,key])=><label key={key}>{label}<Textarea value={profile[key as keyof Profile]} onChange={e=>setProfile({...profile,[key]:e.target.value})} placeholder="اگر ندارید بنویسید: ندارم"/></label>)}</div>
        {error&&<p className="register-error">{error}</p>}<div className="register-actions"><span/><Button onClick={()=>saveProfile(false)} disabled={busy}>{busy?<LoaderCircle className="animate-spin"/>:<ArrowLeft/>} ذخیره و ادامه</Button></div></section>}
      {step===3&&<section className="register-card wide"><div className="register-title"><Camera/><div><p>مرحله ۳ از ۴</p><h1>{addon?"مدارک خدمت جدید":"عکس‌های ارزیابی بدن"}</h1><span>نور روبه‌رو، دوربین هم‌ارتفاع کمر و تمام بدن داخل کادر باشد. عکس‌ها روی گوشی فشرده می‌شوند. {addon&&"عکس‌های این درخواست اختیاری‌اند؛ سوابق قبلی نزد مربی محفوظ است."}</span></div></div>
        <div className="pose-grid">{POSES.map(p=><article key={p.id} className={uploadedKinds.has(p.id)?"done":""}><div className="pose-guide"><img src={p.guide} alt={`نمونه حالت ${p.label}`}/></div><h3>{p.label}</h3><p>{p.hint}</p><label className="upload-button">{uploading===p.id?<LoaderCircle className="animate-spin"/>:uploadedKinds.has(p.id)?<Check/>:<Upload/>}{uploadedKinds.has(p.id)?"تعویض از گالری":"انتخاب از گالری"}<input type="file" accept="image/*" onChange={e=>{void upload(e.target.files?.[0],p.id);e.target.value="";}}/></label>{uploads.find(x=>x.kind===p.id)&&<small>{compression[p.id]?`${Math.ceil(compression[p.id].before/1024).toLocaleString("fa-IR")} ← ${Math.ceil(compression[p.id].after/1024).toLocaleString("fa-IR")} کیلوبایت`:`${Math.ceil((uploads.find(x=>x.kind===p.id)?.size??0)/1024).toLocaleString("fa-IR")} کیلوبایت`}</small>}</article>)}</div>
        <div className="lab-upload"><FlaskConical/><div><h3>آزمایش‌ها {selected.requiresLabs?"(الزامی)":"(اختیاری)"}</h3><p>عکس واضح یا PDF آزمایش؛ برای پکیج VIP، سایکل و PCT الزامی است.</p></div><label className="upload-button">{uploading==="lab"?<LoaderCircle className="animate-spin"/>:<Upload/>} افزودن آزمایش<input type="file" accept="image/*,application/pdf" onChange={e=>upload(e.target.files?.[0],"lab")}/></label><span>{uploads.filter(x=>x.kind==="lab").length.toLocaleString("fa-IR")} فایل</span></div>
        {error&&<p className="register-error">{error}</p>}<div className="register-actions"><Button variant="outline" onClick={()=>setStep(2)}><ArrowRight/> قبل</Button><Button onClick={()=>saveProfile(true)} disabled={busy}>{busy?<LoaderCircle className="animate-spin"/>:<ArrowLeft/>} ثبت نهایی و مشاهده هزینه</Button></div></section>}
      {step===4&&<section className="register-card payment-card"><div className="payment-check"><Check/></div><p>درخواست با موفقیت ثبت شد</p><h1>{selected.name}</h1><div className="payment-price"><span>هزینه برنامه</span><strong>{formatPrice(applicationPrice===undefined?selected.price:applicationPrice)}</strong></div><div className="payment-status"><span>۱</span><div><strong>پرونده تکمیل شد</strong><small>بعد از تأیید پرداخت، برنامه وارد مرحله نگارش می‌شود.</small></div></div>
        {applicationPrice!==null?<div className="receipt-box"><PaymentDetails/><h3>ارسال رسید پرداخت</h3><label className="upload-button">{uploading==="receipt"?<LoaderCircle className="animate-spin"/>:<Upload/>} آپلود رسید<input type="file" accept="image/*,application/pdf" onChange={e=>upload(e.target.files?.[0],"receipt")}/></label>{uploadedKinds.has("receipt")&&<small>رسید ارسال شد و در انتظار بررسی است.</small>}</div>:<p className="medical-note">هزینه این خدمت پس از بررسی آزمایش‌ها و شرایط پزشکی توسط مربی اعلام می‌شود.</p>}
        <div className="register-actions"><a className="register-panel-link" href="/student">ورود به پنل و پیگیری وضعیت <ArrowLeft/></a></div></section>}
    </div></main>;
}
