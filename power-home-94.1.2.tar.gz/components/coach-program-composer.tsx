'use client';
import {useState,type ReactNode} from 'react';
import {AiCoachBuilder} from './ai-coach-builder';
import type {Client,ClientPlan} from '@/lib/coach-data';
import type {GenerationRequest} from '@/lib/ai-coach/contracts';
export function CoachProgramComposer({clients,client,programTab,onClient,onTransfer,children}:{clients:Client[];client:Client;programTab:string;onClient:(id:string)=>void;onTransfer:(plan:ClientPlan,engines:GenerationRequest['engines'])=>void;children:ReactNode}){
 const [mode,setMode]=useState<'manual'|'ai'|null>(null),[aiOpened,setAiOpened]=useState(false);
 return <><section className="composer-choice" aria-label="انتخاب روش برنامه‌نویسی"><h2>برنامه را چطور بنویسیم؟</h2><label>شاگرد<select value={client.id} onChange={e=>onClient(e.target.value)}>{clients.map(c=><option value={c.id} key={c.id}>{c.name}</option>)}</select></label><div className="composer-modes">{([['manual','نوشتن دستی','خودم برنامه را می‌نویسم'],['ai','نوشتن با AI','اول خواسته‌های من، بعد پیش‌نویس']] as const).map(([id,title,detail])=><button type="button" key={id} aria-pressed={mode===id} onClick={()=>{setMode(id);if(id==='ai')setAiOpened(true)}}><strong>{title}</strong><small>{detail}</small></button>)}</div><p>{mode?'هر زمان می‌توانی روش را عوض کنی؛ پیش‌نویس AI تا تأیید تو جای برنامه فعلی را نمی‌گیرد.':'شاگرد و روش را انتخاب کن تا برنامه‌نویسی شروع شود.'}</p></section>
 <div hidden={mode!=='manual'}>{children}</div>
 {aiOpened&&<div hidden={mode!=='ai'}><AiCoachBuilder clientId={client.id} initialEngine={programTab==='nutrition'?'nutrition':programTab==='supplements'?'supplements':'training'} onManual={()=>setMode('manual')} onTransfer={(plan,engines)=>{onTransfer(plan,engines);setMode('manual')}}/></div>}
 </>;
}
