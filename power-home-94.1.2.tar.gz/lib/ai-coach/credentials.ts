import {z} from 'zod/v4';
import {coachDataKey} from '@/lib/password-auth';
import {aiDb,encode,decode} from './store';
export const credentialsSchema=z.object({apiKey:z.string().trim().min(20).max(512).regex(/^sk-[A-Za-z0-9_-]+$/).optional(),model:z.string().trim().min(1).max(120).regex(/^[A-Za-z0-9._:-]+$/)}).strict();
export function aiCredentials(){
 const row=aiDb().prepare('SELECT payload FROM ai_credentials WHERE owner=?').bind(coachDataKey()).first<{payload:string}>();
 const saved=row?decode<{apiKey:string;model:string}>(row.payload):null;
 return {apiKey:saved?.apiKey??process.env.OPENAI_API_KEY??'',model:saved?.model??process.env.AI_COACH_MODEL??''};
}
export function publicAiConnection(){const c=aiCredentials();return {keyConfigured:Boolean(c.apiKey),configured:Boolean(c.apiKey&&c.model),model:c.model};}
export function saveAiCredentials(input:unknown){const v=credentialsSchema.parse(input),previous=aiCredentials();if(!v.apiKey&&!previous.apiKey)throw Error('کلید API را وارد کن.');aiDb().prepare('INSERT INTO ai_credentials(owner,payload) VALUES(?,?) ON CONFLICT(owner) DO UPDATE SET payload=excluded.payload').bind(coachDataKey(),encode({apiKey:v.apiKey??previous.apiKey,model:v.model})).run();return publicAiConnection();}
