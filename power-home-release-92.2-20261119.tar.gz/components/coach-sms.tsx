"use client";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { LoaderCircle, RefreshCw, Save, Send } from "lucide-react";
type StageMessage={enabled:boolean;text:string};
type StageKey="welcome"|"payment"|"writing"|"delivered";
const STAGES:{id:StageKey;label:string;trigger:string}[]=[{id:"welcome",label:"ثبت‌نام اولیه و خوش‌آمدگویی",trigger:"پس از ثبت‌نام موفق شاگرد"},{id:"payment",label:"تأیید فیش واریزی",trigger:"پس از تأیید پرداخت توسط مربی"},{id:"writing",label:"مربی در حال نوشتن برنامه",trigger:"با تغییر وضعیت به در حال نوشتن"},{id:"delivered",label:"مربی برنامه را ارسال کرد",trigger:"پس از ارسال برنامه به شاگرد"}];
type Settings={apiKeyConfigured:boolean;loginEnabled:boolean;notificationsEnabled:boolean;otpTemplateId:number;otpParameter:string;notificationTemplateId:number;notificationParameter:string;coachPhone:string;lineNumber:string;stageMessages:Record<StageKey,StageMessage>};
type Recipient={id:string;name:string;phone:string};
type Campaign={request_id:string;message:string;recipient_count:number;status:string;created_at:string};
const EMPTY:Settings={apiKeyConfigured:false,loginEnabled:false,notificationsEnabled:false,otpTemplateId:0,otpParameter:"CODE",notificationTemplateId:0,notificationParameter:"EVENT",coachPhone:"",lineNumber:"",stageMessages:{welcome:{enabled:true,text:"{نام} عزیز، به سایت آرمین سرخه‌ای خوش آمدی. ثبت‌نامت با موفقیت انجام شد.\n{سایت}"},payment:{enabled:true,text:"{نام} عزیز، فیش واریزی شما توسط مربی تأیید شد.\n{سایت}"},writing:{enabled:true,text:"{نام} عزیز، مربی در حال نوشتن برنامه اختصاصی شماست.\n{سایت}"},delivered:{enabled:true,text:"{نام} عزیز، برنامه شما ارسال شد؛ برای مشاهده وارد پنل شوید.\n{سایت}"}}};
const STATUS:Record<string,string>={accepted:"پذیرفته‌شده توسط SMS.ir",pending:"در حال پردازش",unknown:"نتیجه نامشخص؛ پیش از ارسال جدید گزارش پنل را بررسی کنید",failed:"درخواست ارسال ناموفق بود",sent:"پذیرفته‌شده توسط SMS.ir",sending:"در حال ارسال"};
export function CoachSms(){
  const [settings,setSettings]=useState<Settings>(EMPTY),[key,setKey]=useState("");
  const [recipients,setRecipients]=useState<Recipient[]>([]),[history,setHistory]=useState<Campaign[]>([]);
  const [deliveries,setDeliveries]=useState<{role:string;phone:string;status:string;updated_at:string}[]>([]);
  const [pane,setPane]=useState("settings"),[loading,setLoading]=useState(true),[busy,setBusy]=useState("");
  const [feedback,setFeedback]=useState(""),[search,setSearch]=useState(""),[selected,setSelected]=useState<string[]>([]),[text,setText]=useState("");
  const [requestId,setRequestId]=useState("");const [sent,setSent]=useState(false);
  const [credit,setCredit]=useState<{credit:number|null;unit:string;checkedAt:string}|null>(null);
  const load=async()=>{
    setLoading(true);setFeedback("");
    try{
      const responses=await Promise.all(["/api/sms/settings","/api/sms/recipients","/api/sms/send"].map(url=>fetch(url,{cache:"no-store",signal:AbortSignal.timeout(15000)})));
      if(responses.some(r=>!r.ok))throw new Error("دریافت تنظیمات پیامک انجام نشد؛ دوباره تلاش کنید.");
      const [a,b,c]=await Promise.all(responses.map(r=>r.json()));setSettings(a.settings);setDeliveries(a.deliveries);setRecipients(b.recipients);setHistory(c.campaigns);
    }catch(e){setFeedback(e instanceof Error?e.message:"دریافت اطلاعات انجام نشد.")}finally{setLoading(false)}
  };
  useEffect(()=>{setRequestId(crypto.randomUUID());void load()},[]);
  const save=async()=>{setBusy("save");setFeedback("");try{
    const {apiKeyConfigured,...body}=settings;void apiKeyConfigured;
    const r=await fetch("/api/sms/settings",{method:"PUT",headers:{"content-type":"application/json"},body:JSON.stringify({...body,...(key.trim()?{apiKey:key.trim()}: {})}),signal:AbortSignal.timeout(15000)});
    const d=await r.json();if(!r.ok)throw new Error(d.error);setSettings(d.settings);setKey("");setCredit(null);setFeedback("تنظیمات پیامک ذخیره شد.");
  }catch(e){setFeedback(e instanceof Error?e.message:"ذخیره انجام نشد.")}finally{setBusy("")}};
  const checkCredit=async()=>{setBusy("credit");setFeedback("");try{
    const r=await fetch("/api/sms/credit",{cache:"no-store",signal:AbortSignal.timeout(15000)}),d=await r.json();if(!r.ok)throw new Error(d.error);setCredit(d);setFeedback("اتصال به SMS.ir برقرار است. پیامک واقعی ارسال نشد.");
  }catch(e){setCredit(null);setFeedback(e instanceof Error?e.message:"تست اتصال انجام نشد.")}finally{setBusy("")}};
  const editMessage=()=>{setSent(false);setRequestId(crypto.randomUUID());setFeedback("")};
  const choose=(id:string)=>{editMessage();setSelected(v=>v.includes(id)?v.filter(x=>x!==id):v.length<100?[...v,id]:v)};
  const send=async()=>{if(busy||sent||!selected.length||!text.trim()||!requestId)return;setBusy("send");setFeedback("");try{
    const r=await fetch("/api/sms/send",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({requestId,clientIds:selected,message:text}),signal:AbortSignal.timeout(20000)});
    const d=await r.json();if(!r.ok)throw new Error(d.error);setFeedback(`${STATUS[d.status]??d.status} · ${Number(d.count).toLocaleString("fa-IR")} گیرنده`);setSent(d.status==="accepted"||d.status==="unknown"||d.status==="pending");
    const h=await fetch("/api/sms/send",{cache:"no-store"});if(h.ok)setHistory((await h.json()).campaigns);
  }catch(e){setFeedback((e instanceof Error?e.message:"ارتباط قطع شد.")+" اگر نتیجه نامشخص است، گزارش SMS.ir را پیش از ارسال جدید بررسی کنید.")}finally{setBusy("")}};
  const filtered=recipients.filter(r=>`${r.name} ${r.phone}`.includes(search));
  return <section className="coach-sms" dir="rtl"><h1>مدیریت پیامک</h1><p>ورود پیامکی، اعلان‌ها و ارسال دلخواه به شاگردان</p>
    <div className="sms-toolbar"><Button variant={pane==="settings"?"default":"outline"} onClick={()=>setPane("settings")}>تنظیمات اتصال</Button><Button variant={pane==="send"?"default":"outline"} onClick={()=>setPane("send")}>ارسال پیامک دلخواه</Button><Button variant="outline" disabled={Boolean(busy)||loading} onClick={()=>void load()}><RefreshCw/> تازه‌سازی</Button></div>
    <div className="sms-credit"><div><strong>موجودی SMS.ir</strong><p>{credit?(credit.credit===null?"اتصال برقرار شد؛ مقدار موجودی در پاسخ قابل تشخیص نبود.":`${credit.credit.toLocaleString("fa-IR")} — ${credit.unit}`):"برای مشاهده موجودی، اتصال را بررسی کنید."}</p>{credit&&<small>آخرین بررسی: {new Date(credit.checkedAt).toLocaleString("fa-IR")}</small>}</div><Button disabled={loading||Boolean(busy)||!settings.apiKeyConfigured} onClick={()=>void checkCredit()}>{busy==="credit"?<LoaderCircle className="animate-spin"/>:<RefreshCw/>} تست اتصال و موجودی</Button></div>
    {feedback&&<p className="sms-feedback" role="status">{feedback}</p>}
    {loading?<p>در حال دریافت اطلاعات…</p>:pane==="settings"?<>
      <div className="sms-settings-grid">
        <label>کلید API خصوصی<Input type="password" autoComplete="off" value={key} onChange={e=>setKey(e.target.value)} dir="ltr" placeholder={settings.apiKeyConfigured?"کلید ذخیره شده؛ برای حفظ آن خالی بگذارید":"کلید API پنل SMS.ir"}/><small>کلید موجود نمایش داده نمی‌شود و روی سرور رمزگذاری می‌شود.</small></label>
        <label>شماره خط ارسال پیامک‌های خودکار و دلخواه<Input value={settings.lineNumber} inputMode="numeric" dir="ltr" onChange={e=>setSettings({...settings,lineNumber:e.target.value.replace(/\D/g,"")})}/></label>
        <label>شناسه قالب ورود<Input type="number" min={0} value={settings.otpTemplateId||""} onChange={e=>setSettings({...settings,otpTemplateId:Number(e.target.value)||0})}/></label>
        <label>نام متغیر کد در قالب ورود<Input value={settings.otpParameter} dir="ltr" onChange={e=>setSettings({...settings,otpParameter:e.target.value})}/><small>نام دقیق متغیر قالب فعلی، مثلاً CODE یا PASSWORD، بدون #</small></label>
        <label>شناسه قالب اعلان<Input type="number" min={0} value={settings.notificationTemplateId||""} onChange={e=>setSettings({...settings,notificationTemplateId:Number(e.target.value)||0})}/></label>
        <label>نام متغیر قالب اعلان<Input value={settings.notificationParameter} dir="ltr" onChange={e=>setSettings({...settings,notificationParameter:e.target.value})}/></label>
        <label>شماره موبایل مربی برای اعلان‌ها<Input type="tel" value={settings.coachPhone} dir="ltr" onChange={e=>setSettings({...settings,coachPhone:e.target.value})}/></label>
      </div>
      <label className="sms-switch"><input type="checkbox" checked={settings.loginEnabled} onChange={e=>setSettings({...settings,loginEnabled:e.target.checked})}/> ورود شاگرد با شماره و کد پیامکی فعال شود</label>
      <label className="sms-switch"><input type="checkbox" checked={settings.notificationsEnabled} onChange={e=>setSettings({...settings,notificationsEnabled:e.target.checked})}/> اعلان‌های مربی و شاگرد علاوه بر سایت و Push، پیامک هم شوند</label>
      <h2>متن پیامک‌های خودکار مراحل</h2><p>نام شاگرد با {"{نام}"} و آدرس پنل با {"{سایت}"} جایگزین می‌شود. این متن‌ها با خط ارسال متنی فرستاده می‌شوند.</p><div className="sms-settings-grid">{STAGES.map(stage=><section className="sms-history" key={stage.id}><strong>{stage.label}</strong><small className="block">{stage.trigger}</small><label className="sms-switch"><input type="checkbox" checked={settings.stageMessages[stage.id].enabled} onChange={e=>setSettings({...settings,stageMessages:{...settings.stageMessages,[stage.id]:{...settings.stageMessages[stage.id],enabled:e.target.checked}}})}/> فعال</label><Textarea rows={5} maxLength={1200} value={settings.stageMessages[stage.id].text} onChange={e=>setSettings({...settings,stageMessages:{...settings.stageMessages,[stage.id]:{...settings.stageMessages[stage.id],text:e.target.value}}})}/></section>)}</div><p>ورود مربی با رمز فعلی حفظ می‌شود. قالب اعلان باید نام متغیر انتخابی و آدرس ثابت arminsorkhei.ir را داشته باشد.</p>
      <Button disabled={Boolean(busy)} onClick={()=>void save()}>{busy==="save"?<LoaderCircle className="animate-spin"/>:<Save/>} ذخیره تنظیمات</Button>
      <h2>پیامک‌های اعلان اخیر</h2>{deliveries.map((d,i)=><p key={i}>{d.role==="coach"?"مربی":"شاگرد"} · <bdi>{d.phone}</bdi> · {STATUS[d.status]??d.status}</p>)}{!deliveries.length&&<p>هنوز اعلان پیامکی ثبت نشده است.</p>}
    </>:<>
      <label className="sms-message-label">متن پیامک تخفیف، مناسبت یا اطلاعیه<Textarea maxLength={1200} rows={5} value={text} disabled={Boolean(busy)} onChange={e=>{editMessage();setText(e.target.value)}} placeholder="متن دلخواهت را بنویس…"/></label>
      <p>{text.length.toLocaleString("fa-IR")} کاراکتر · {selected.length.toLocaleString("fa-IR")} گیرنده؛ هزینه با تعرفه پنل محاسبه می‌شود.</p>
      <div className="sms-toolbar"><Input aria-label="جستجوی گیرنده" placeholder="جستجوی نام یا شماره…" value={search} onChange={e=>setSearch(e.target.value)}/><Button variant="outline" disabled={Boolean(busy)} onClick={()=>{editMessage();setSelected(filtered.slice(0,100).map(r=>r.id))}}>انتخاب فهرست نمایش‌داده‌شده</Button><Button variant="ghost" disabled={Boolean(busy)} onClick={()=>{editMessage();setSelected([])}}>پاک‌کردن انتخاب‌ها</Button></div>
      <div className="sms-recipients">{filtered.map(r=><label key={r.id}><input type="checkbox" disabled={Boolean(busy)} checked={selected.includes(r.id)} onChange={()=>choose(r.id)}/><strong>{r.name}</strong><bdi>{r.phone}</bdi></label>)}{!filtered.length&&<p>گیرنده‌ای پیدا نشد.</p>}</div>
      <Button disabled={Boolean(busy)||sent||!selected.length||!text.trim()||!settings.apiKeyConfigured||!settings.lineNumber} onClick={()=>void send()}>{busy==="send"?<LoaderCircle className="animate-spin"/>:<Send/>} ارسال پیامک به {selected.length.toLocaleString("fa-IR")} نفر</Button>
      {sent&&<Button variant="outline" className="mr-3" onClick={()=>{editMessage();setText("")}}>نوشتن پیام جدید</Button>}
      <h2>سابقه ارسال‌های دلخواه</h2>{history.map(h=><article className="sms-history" key={h.request_id}><p>{h.message}</p><small>{h.recipient_count.toLocaleString("fa-IR")} نفر · {STATUS[h.status]??h.status} · {new Date(h.created_at).toLocaleString("fa-IR")}</small></article>)}{!history.length&&<p>هنوز ارسال دلخواهی ثبت نشده است.</p>}
    </>}
  </section>;
}
