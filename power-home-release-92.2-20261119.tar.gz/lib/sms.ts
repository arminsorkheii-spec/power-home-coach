import { createCipheriv, createDecipheriv, createHash, randomBytes } from "node:crypto";
import { z } from "zod";
import { database } from "@/lib/raw-db";
import { normalizePhone } from "@/lib/student-auth";

const parameter = z.string().trim().min(1).max(40).regex(/^[\p{L}\p{N}_-]+$/u);
export const DEFAULT_STAGE_MESSAGES={
  welcome:{enabled:true,text:"{نام} عزیز، به سایت آرمین سرخه‌ای خوش آمدی. ثبت‌نامت با موفقیت انجام شد.\n{سایت}"},
  payment:{enabled:true,text:"{نام} عزیز، فیش واریزی شما توسط مربی تأیید شد.\n{سایت}"},
  writing:{enabled:true,text:"{نام} عزیز، مربی در حال نوشتن برنامه اختصاصی شماست.\n{سایت}"},
  delivered:{enabled:true,text:"{نام} عزیز، برنامه شما ارسال شد؛ برای مشاهده وارد پنل شوید.\n{سایت}"},
};
const stage=z.object({enabled:z.boolean(),text:z.string().trim().min(1).max(1200)}).strict();
export const smsSettingsSchema = z.object({
  apiKey:z.string().trim().min(10).max(512).regex(/^[^\r\n]+$/).optional(),
  loginEnabled:z.boolean(), notificationsEnabled:z.boolean(),
  otpTemplateId:z.number().int().min(0).max(2_147_483_647), otpParameter:parameter,
  notificationTemplateId:z.number().int().min(0).max(2_147_483_647), notificationParameter:parameter,
  coachPhone:z.string().max(30),
  lineNumber:z.string().trim().regex(/^\d{0,16}$/).default(""),
  stageMessages:z.object({welcome:stage,payment:stage,writing:stage,delivered:stage}).strict().default(DEFAULT_STAGE_MESSAGES),
}).strict();
export type SmsSettings = Omit<z.infer<typeof smsSettingsSchema>,"apiKey">;
const DEFAULT:SmsSettings={loginEnabled:false,notificationsEnabled:false,otpTemplateId:0,otpParameter:"CODE",notificationTemplateId:0,notificationParameter:"EVENT",coachPhone:"",lineNumber:"",stageMessages:DEFAULT_STAGE_MESSAGES};
function secretKey() {
  if(!process.env.APP_SESSION_SECRET)throw new Error("sms_configuration");
  return createHash("sha256").update(process.env.APP_SESSION_SECRET).digest();
}
function encrypt(value:string) {
  const iv=randomBytes(12), cipher=createCipheriv("aes-256-gcm",secretKey(),iv);
  const bytes=Buffer.concat([cipher.update(value,"utf8"),cipher.final()]);
  return [iv,cipher.getAuthTag(),bytes].map(x=>x.toString("base64url")).join(".");
}
function decrypt(value:string) {
  const [iv,tag,bytes]=value.split(".").map(x=>Buffer.from(x,"base64url"));
  const cipher=createDecipheriv("aes-256-gcm",secretKey(),iv);cipher.setAuthTag(tag);
  return Buffer.concat([cipher.update(bytes),cipher.final()]).toString("utf8");
}
function apiKey(){const row=stored();if(!row?.encrypted_key)throw new Error("sms_configuration");return decrypt(row.encrypted_key);}
function stored() {
  return database().prepare("SELECT payload,encrypted_key FROM sms_settings WHERE id='smsir'").first<{payload:string;encrypted_key:string}>();
}
export function getSmsSettings() {
  const row=stored();
  return { ...DEFAULT,...(row?JSON.parse(row.payload) as SmsSettings:{}),apiKeyConfigured:Boolean(row?.encrypted_key) };
}
export function smsLoginEnabled(){return getSmsSettings().loginEnabled;}
export function saveSmsSettings(value:z.infer<typeof smsSettingsSchema>) {
  const {apiKey,...settings}=value;
  settings.coachPhone=normalizePhone(settings.coachPhone);
  const key=apiKey?encrypt(apiKey):(stored()?.encrypted_key??"");
  if((settings.loginEnabled||settings.notificationsEnabled)&&!key)throw new Error("کلید API را وارد کنید.");
  if(settings.loginEnabled&&!settings.otpTemplateId)throw new Error("شناسه قالب ورود را وارد کنید.");
  const validLine=Number.isSafeInteger(Number(settings.lineNumber))&&Number(settings.lineNumber)>0;
  if(settings.notificationsEnabled&&(!validLine||!/^09\d{9}$/.test(settings.coachPhone)))throw new Error("خط ارسال پیامک خودکار و شماره موبایل مربی را کامل کنید.");
  database().prepare("INSERT INTO sms_settings (id,payload,encrypted_key,updated_at) VALUES ('smsir',?,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,encrypted_key=excluded.encrypted_key,updated_at=excluded.updated_at")
    .bind(JSON.stringify(settings),key,new Date().toISOString()).run();
  return getSmsSettings();
}
export class SmsSendError extends Error {
  constructor(public readonly uncertain:boolean){super("sms_send_failed");}
}
export async function smsCredit() {
  const row=stored();
  if(!row?.encrypted_key)throw new Error("sms_configuration");
  const response=await fetch("https://api.sms.ir/v1/credit",{
    headers:{"X-API-KEY":decrypt(row.encrypted_key),"Accept":"application/json"},
    redirect:"error",signal:AbortSignal.timeout(10_000),cache:"no-store",
  });
  if(!response.ok)throw new Error("sms_connection_failed");
  const result=await response.json() as {status:number;data:unknown};
  if(result.status!==1)throw new Error("sms_connection_failed");
  // Keep provider units explicit; do not invent a Rial/Toman conversion.
  const credit=typeof result.data==="number"?result.data:(result.data&&typeof result.data==="object"?Number((result.data as {credit?:unknown}).credit):NaN);
  return {connected:true,credit:Number.isFinite(credit)?credit:null,unit:"واحد اعتبار پنل SMS.ir",checkedAt:new Date().toISOString()};
}
export async function sendBulkSms(phones:string[],text:string) {
  const line=Number(getSmsSettings().lineNumber);
  if(!Number.isSafeInteger(line)||line<=0)throw new SmsSendError(false);
  let key:string;
  try{key=apiKey();}catch{throw new SmsSendError(false);}
  let response:Response;
  try{
    response=await fetch("https://api.sms.ir/v1/send/bulk",{
      method:"POST",redirect:"error",signal:AbortSignal.timeout(15_000),
      headers:{"X-API-KEY":key,"Accept":"application/json","Content-Type":"application/json"},
      body:JSON.stringify({lineNumber:line,messageText:text,mobiles:phones,sendDateTime:null}),
    });
  }catch{throw new SmsSendError(true);}
  if(!response.ok)throw new SmsSendError(response.status>=500);
  let data:{status:number;data?:{packId?:string;messageIds?:number[]}};
  try{data=await response.json();}catch{throw new SmsSendError(true);}
  if(data.status!==1)throw new SmsSendError(false);
  return {packId:data.data?.packId??null,messageIds:data.data?.messageIds??[]};
}
export async function sendSmsTemplate(phone:string,templateId:number,name:string,value:string) {
  const row=stored();
  if(!row?.encrypted_key||!templateId)throw new SmsSendError(false);
  let key:string;
  try{key=decrypt(row.encrypted_key);}catch{throw new SmsSendError(false);}
  let response:Response;
  try {
    response=await fetch("https://api.sms.ir/v1/send/verify/",{
      method:"POST",redirect:"error",signal:AbortSignal.timeout(10_000),
      headers:{"X-API-KEY":key,"Accept":"application/json","Content-Type":"application/json"},
      body:JSON.stringify({mobile:normalizePhone(phone),templateId,parameters:[{name,value}]}),
    });
  }catch{throw new SmsSendError(true);}
  if(!response.ok)throw new SmsSendError(response.status>=500);
  let data:{status:number;data?:{messageId?:number}};
  try{data=await response.json();}catch{throw new SmsSendError(true);}
  if(data.status!==1)throw new SmsSendError(false);
  return data.data?.messageId?.toString()??null;
}
const EVENTS:Record<string,string>={registration:"ثبت‌نام جدید",program_request:"درخواست برنامه",request_completed:"تکمیل پرونده",payment_received:"رسید پرداخت",payment_receipt:"رسید پرداخت جدید",payment_receipt_sent:"رسید پرداخت دریافت شد",payment_review:"بررسی پرداخت",payment_approved:"تأیید پرداخت",awaiting_payment:"در انتظار پرداخت",program_writing:"نگارش برنامه",program_delivered:"ارسال برنامه",chat_message:"پیام جدید",message:"پیام جدید"};
export async function sendNotificationSms(id:string,role:"coach"|"student",clientId:string|null,type:string) {
  const settings=getSmsSettings();
  if(!settings.notificationsEnabled)return {status:"disabled"};
  const stageId=role==="student"?({welcome:"welcome",payment_approved:"payment",program_writing:"writing",program_delivered:"delivered"} as const)[type as "welcome"|"payment_approved"|"program_writing"|"program_delivered"]:undefined;
  const stageMessage=stageId?settings.stageMessages[stageId]:undefined;
  if(stageMessage&&!stageMessage.enabled)return {status:"stage_disabled"};
  const phone=role==="coach"?settings.coachPhone:(clientId?database().prepare("SELECT phone FROM student_accounts WHERE client_id=?").bind(clientId).first<{phone:string}>()?.phone:undefined);
  if(!phone||!/^09\d{9}$/.test(normalizePhone(phone)))return {status:"no_recipient"};
  const db=database();
  const reservation=db.prepare("INSERT OR IGNORE INTO sms_deliveries (notification_id,role,phone,status,updated_at) VALUES (?,?,?,'sending',?)").bind(id,role,normalizePhone(phone),new Date().toISOString()).run();
  if(!Number(reservation.changes))return {status:"duplicate"};
  try{
    let messageId:string|null;
    if(stageMessage){
      const state=db.prepare("SELECT payload FROM coach_states WHERE owner_email=?").bind(process.env.COACH_DATA_KEY??"arminsorkheii@gmail.com").first<{payload:string}>();
      const clients=state?(JSON.parse(state.payload) as {clients?:{id:string;name:string}[]}).clients??[]:[];
      const name=clients.find(c=>c.id===clientId)?.name??"ورزشکار";
      const text=stageMessage.text.replaceAll("{نام}",name).replaceAll("{سایت}","https://arminsorkhei.ir/student");
      const sent=await sendBulkSms([normalizePhone(phone)],text);messageId=sent.messageIds[0]?.toString()??sent.packId;
    }else if(settings.notificationTemplateId){
      messageId=await sendSmsTemplate(phone,settings.notificationTemplateId,settings.notificationParameter,EVENTS[type]??"اعلان جدید در پنل");
    }else{
      const sent=await sendBulkSms([normalizePhone(phone)],`${EVENTS[type]??"اعلان جدید در پنل"}\nhttps://arminsorkhei.ir/${role==="coach"?"coach":"student"}`);messageId=sent.messageIds[0]?.toString()??sent.packId;
    }
    db.prepare("UPDATE sms_deliveries SET status='sent',message_id=?,updated_at=? WHERE notification_id=?").bind(messageId,new Date().toISOString(),id).run();
    return {status:"sent"};
  }catch(error){
    const status=error instanceof SmsSendError&&error.uncertain?"unknown":"failed";
    db.prepare("UPDATE sms_deliveries SET status=?,updated_at=? WHERE notification_id=?").bind(status,new Date().toISOString(),id).run();
    return {status};
  }
}
