import { database } from "@/lib/raw-db";
import { sendPush } from "@/lib/push-notifications";
import { sendNotificationSms } from "@/lib/sms";

export type NotificationRole = "coach" | "student";
export type NotificationInput = {
  role: NotificationRole;
  clientId?: string | null;
  actorClientId?: string | null;
  applicationId?: string | null;
  type: string;
  title: string;
  body: string;
  url: string;
  tag: string;
};

export async function createNotification(input: NotificationInput) {
  const db = database();
  const id = crypto.randomUUID();
  const now = new Date().toISOString();
  await db.prepare(`INSERT INTO notification_events
    (id,recipient_role,recipient_client_id,actor_client_id,application_id,type,title,body,url,tag,created_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?)`)
    .bind(id,input.role,input.clientId??null,input.actorClientId??null,input.applicationId??null,input.type,input.title,input.body,input.url,input.tag,now).run();
  const [pushResult,smsResult]=await Promise.allSettled([
    sendPush(input.role,input.clientId??null,{title:input.title,body:input.body,url:input.url,tag:input.tag}),
    sendNotificationSms(id,input.role,input.clientId??null,input.type),
  ]);
  const push=pushResult.status==="fulfilled"?pushResult.value:{configured:false,total:0,sent:0,failed:0};
  const sms=smsResult.status==="fulfilled"?smsResult.value:{status:"failed"};
  return {id,createdAt:now,push,sms};
}
