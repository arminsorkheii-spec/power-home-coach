import { z } from "zod";
import { requestHasValidSession } from "@/lib/password-auth";
import { database, sameOrigin } from "@/lib/raw-db";
import { getSmsSettings, saveSmsSettings, smsSettingsSchema } from "@/lib/sms";
export async function GET(request:Request){
  if(!await requestHasValidSession(request))return new Response(null,{status:401});
  const deliveries=database().prepare("SELECT role,status,substr(phone,1,4)||'***'||substr(phone,-4) AS phone,updated_at FROM sms_deliveries ORDER BY updated_at DESC LIMIT 20").all().results;
  return Response.json({settings:getSmsSettings(),deliveries},{headers:{"cache-control":"no-store"}});
}
export async function PUT(request:Request){
  if(!sameOrigin(request)||!await requestHasValidSession(request))return new Response(null,{status:403});
  try{
    const body=smsSettingsSchema.parse(await request.json());
    return Response.json({ok:true,settings:saveSmsSettings(body)},{headers:{"cache-control":"no-store"}});
  }catch(e){
    return Response.json({error:e instanceof z.ZodError?"تنظیمات پیامک را کامل و درست وارد کنید.":"ذخیره انجام نشد؛ کلید API، شناسه قالب‌ها و شماره مربی را بررسی کنید."},{status:400,headers:{"cache-control":"no-store"}});
  }
}
