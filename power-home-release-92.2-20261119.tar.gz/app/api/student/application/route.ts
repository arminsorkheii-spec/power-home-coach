import { z } from "zod";
import { getPackageById, quotePackages, PackageSelectionError } from "@/lib/package-pricing";
import { database, sameOrigin } from "@/lib/raw-db";
import { studentIdFromRequest } from "@/lib/student-auth";
import { createNotification } from "@/lib/notifications";

const profileSchema = z.object({
  age: z.string().min(1).max(3), gender: z.string().max(20), height: z.string().min(1).max(10), weight: z.string().min(1).max(10), waist: z.string().max(10), arm: z.string().max(10),
  goal: z.string().min(2).max(500), experience: z.string().max(500), trainingDays: z.string().max(20), injuries: z.string().max(1000), diseases: z.string().max(1000),
  medications: z.string().max(1000), allergies: z.string().max(1000), supplements: z.string().max(1000), sleep: z.string().max(100), activity: z.string().max(500), notes: z.string().max(3000),
});

export async function GET(request: Request) {
  const clientId = await studentIdFromRequest(request);
  if (!clientId) return Response.json({ error: "ورود شاگرد لازم است." }, { status: 401 });
  const db = database();
  const rows = await db.prepare("SELECT * FROM applications WHERE client_id=? ORDER BY created_at ASC,rowid ASC").bind(clientId).all<Record<string, unknown> & { id: string; status: string; profile_json: string; created_at: string; parent_application_id:string|null;package_items_json:string }>();
  if (!rows.results.length) return Response.json({ error: "درخواستی پیدا نشد." }, { status: 404 });
  const applications = await Promise.all(rows.results.map(async (application) => {
    const uploads = await db.prepare("SELECT id,kind,filename,content_type,size,created_at FROM application_uploads WHERE application_id=? ORDER BY created_at").bind(application.id).all();
    return { ...application, profile: JSON.parse(String(application.profile_json || "{}")), uploads: uploads.results };
  }));
  const latest = applications[applications.length - 1];
  const delivery = await db.prepare("SELECT delivered_at FROM current_program_deliveries WHERE client_id=?").bind(clientId).first<{delivered_at:string}>();
  // Older coach-delivered plans can have a legacy application status not marked "delivered".
  const canRequestNew = latest.status === "delivered" || (!latest.parent_application_id&&(!latest.package_items_json||latest.package_items_json==="[]")&&Boolean(delivery?.delivered_at) && Date.parse(delivery!.delivered_at) >= Date.parse(String(latest.created_at)));
  return Response.json({ application: latest, uploads: latest.uploads, applications, canRequestNew }, { headers: { "cache-control": "no-store" } });
}

export async function POST(request: Request) {
  if (!sameOrigin(request)) return new Response(null, { status: 403 });
  const clientId = await studentIdFromRequest(request);
  if (!clientId) return Response.json({ error: "ابتدا وارد پنل شاگرد شوید." }, { status: 401 });
  try {
    const body = z.object({ packageId:z.string().max(40).optional(), packageIds:z.array(z.string().max(40)).min(1).max(7).optional(), addon:z.boolean().optional(), requestId:z.string().uuid().optional() }).parse(await request.json());
    const selectedPackage = quotePackages(body.packageIds ?? (body.packageId ? [body.packageId] : []));
    if(body.addon&&selectedPackage.items.some(item=>item.id==="natural"||item.id==="professional"))return Response.json({error:"برای افزودن خدمت، برنامه‌های مستقل را انتخاب کنید."},{status:400});
    if (!selectedPackage) return Response.json({ error: "پکیج انتخابی معتبر نیست." }, { status: 400 });
    const db = database();
    if(body.requestId){
      const repeated=db.prepare("SELECT client_id,package_items_json,price_amount,parent_application_id FROM applications WHERE id=?").bind(body.requestId).first<{client_id:string;package_items_json:string;price_amount:number;parent_application_id:string|null}>();
      if(repeated){
        const oldIds=(JSON.parse(repeated.package_items_json) as {id:string}[]).map(item=>item.id).sort();
        if(repeated.client_id!==clientId||Boolean(repeated.parent_application_id)!==Boolean(body.addon)||JSON.stringify(oldIds)!==JSON.stringify(selectedPackage.items.map(item=>item.id).sort()))return Response.json({error:"شناسه درخواست قبلاً استفاده شده است."},{status:409});
        return Response.json({ok:true,applicationId:body.requestId,priceAmount:repeated.price_amount,repeated:true});
      }
    }
    const latest = db.prepare("SELECT id,status,profile_json,created_at,parent_application_id,package_items_json FROM applications WHERE client_id=? ORDER BY created_at DESC,rowid DESC LIMIT 1").bind(clientId).first<{ id:string;status:string;profile_json:string;created_at:string;parent_application_id:string|null;package_items_json:string }>();
    if(body.addon&&!latest)return Response.json({error:"ابتدا درخواست برنامه اصلی را ثبت کنید."},{status:409});
    const delivery = db.prepare("SELECT delivered_at FROM current_program_deliveries WHERE client_id=?").bind(clientId).first<{delivered_at:string}>();
    // If an old application's status is stale, trust evidence of a delivery AFTER its creation.
    const latestCompleted = !latest || latest.status === "delivered" || (!latest.parent_application_id&&(!latest.package_items_json||latest.package_items_json==="[]")&&Boolean(delivery?.delivered_at) && Date.parse(delivery!.delivered_at) >= Date.parse(latest.created_at));
    // Preserve active requests and uploads; a renewal must not silently create duplicates.
    // One active checkout at a time. An extra service may be requested while
    // the parent program is being written; existing files and program stay intact.
    const addonAllowed=body.addon&&latest&&["payment_approved","writing","ready","delivered"].includes(latest.status);
    if (!latestCompleted&&!addonAllowed) {
      return Response.json({ error: "یک درخواست در جریان دارید. ابتدا آن را از پنل شاگرد پیگیری کنید." }, { status: 409 });
    }
    const previousProfile = latest ? JSON.parse(latest.profile_json || "{}") as Record<string, unknown> : {};
    const now = new Date().toISOString();
    const id = body.requestId ?? crypto.randomUUID();
    db.prepare("INSERT INTO applications (id,client_id,package_id,package_name,status,price_amount,profile_json,created_at,updated_at,package_items_json,parent_application_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)").bind(id, clientId, selectedPackage.id, selectedPackage.name, "draft", selectedPackage.price, JSON.stringify(previousProfile), now, now, JSON.stringify(selectedPackage.items),body.addon&&latest?(latest.parent_application_id??latest.id):null).run();
    await createNotification({role:"coach",actorClientId:clientId,applicationId:id,type:"program_request",title:"درخواست برنامه جدید",body:`${String(previousProfile.name || "یک شاگرد")} درخواست ${selectedPackage.name} را ثبت کرد.`,url:"/coach",tag:`request-${id}`});
    return Response.json({ ok:true, applicationId:id, priceAmount: selectedPackage.price });
  } catch (error) {
    if(error instanceof PackageSelectionError)return Response.json({error:error.message},{status:400});
    return Response.json({ error: error instanceof z.ZodError ? "پکیج انتخابی معتبر نیست." : "ساخت درخواست جدید انجام نشد." }, { status: 400 });
  }
}

export async function PUT(request: Request) {
  if (!sameOrigin(request)) return new Response(null, { status: 403 });
  const clientId = await studentIdFromRequest(request);
  if (!clientId) return Response.json({ error: "ورود شاگرد لازم است." }, { status: 401 });
  try {
    const body = z.object({ profile: profileSchema, finalize: z.boolean().optional() }).parse(await request.json());
    const db = database();
    const application = await db.prepare("SELECT id,package_id,package_items_json,parent_application_id,status,profile_json FROM applications WHERE client_id=? ORDER BY created_at DESC,rowid DESC LIMIT 1").bind(clientId).first<{ id: string; package_id: string; package_items_json:string; parent_application_id:string|null;status:string; profile_json:string }>();
    if (!application) return new Response(null, { status: 404 });
    if(!["draft","awaiting_payment"].includes(application.status))return Response.json({error:"این درخواست وارد مرحله بررسی شده و دیگر قابل تغییر نیست."},{status:409});
    if (body.finalize) {
      const kinds = await db.prepare("SELECT kind FROM application_uploads WHERE application_id=?").bind(application.id).all<{ kind: string }>();
      const available = new Set(kinds.results.map((item) => item.kind));
      const missing = ["front", "side", "back", "front_double", "back_double"].filter((kind) => !available.has(kind));
      const savedItems=JSON.parse(application.package_items_json||"[]") as {id:string;requiresLabs?:boolean}[];
      const selectedPackage = savedItems.length?{requiresLabs:savedItems.some(item=>item.requiresLabs||getPackageById(item.id)?.requiresLabs)}:getPackageById(application.package_id);
      if (missing.length&&!application.parent_application_id) return Response.json({ error: "هر پنج عکس بدنی را کامل آپلود کنید." }, { status: 400 });
      if (selectedPackage?.requiresLabs && !available.has("lab")) return Response.json({ error: "برای این پکیج آپلود آزمایش الزامی است." }, { status: 400 });
    }
    const status = body.finalize ? "awaiting_payment" : "draft";
    const now = new Date().toISOString();
    const previousProfile = JSON.parse(application.profile_json || "{}") as Record<string, unknown>;
    await db.prepare("UPDATE applications SET profile_json=?,status=?,updated_at=? WHERE id=? AND client_id=?").bind(JSON.stringify({ ...previousProfile, ...body.profile }), status, now, application.id, clientId).run();
    if (body.finalize) await createNotification({role:"coach",actorClientId:clientId,applicationId:application.id,type:"request_completed",title:"پرونده درخواست تکمیل شد",body:"اطلاعات و عکس‌های درخواست جدید آماده بررسی است.",url:"/coach",tag:`complete-${application.id}`});
    return Response.json({ ok: true, status });
  } catch (error) {
    return Response.json({ error: error instanceof z.ZodError ? "اطلاعات فرم معتبر نیست." : "ذخیره فرم انجام نشد." }, { status: 400 });
  }
}
