export type TrainingExercise={rowId:string;exerciseId:string;nameFa:string;nameEn:string;image:string;sets:string;reps:string;rest:string;tempo:string;technique:string;notes:string;supersetId?:string};
export type TrainingDay={id:string;title:string;focus:string;exercises:TrainingExercise[]};
export type TrainingSet={row_id:string;set_index:number;weight:number;reps:number;done:number;rir?:number|null;rpe?:number|null};
export type TrainingSession={id:string;date:string;day_id:string;day:TrainingDay;status:'active'|'completed';started_at:string;completed_at:string|null;sets:TrainingSet[]};
export type TrainingEvent={date:string;day_id:string|null;title:string;kind:'workout'|'rest'};
export type ReplacementRequest={id:string;client_id:string;clientName?:string;exercise_name:string;reason:string;message:string;status:string;response:string;alternative_name:string;created_at:string;updated_at:string};
export type TrainingData={ownerKey?:string;date:string;today:string;days:TrainingDay[];events:TrainingEvent[];sessions:TrainingSession[];previous:Record<string,{date:string;weight:number;reps:number;sets:number}>;requests:ReplacementRequest[];meals:{id:string;title:string;time:string;foods:string}[];habits:{completedMeals:string[];waterMl:number;sleepHours:number;steps:number}|null;goals:{waterMl:number;sleepHours:number;steps:number};weeklyDone:boolean};
