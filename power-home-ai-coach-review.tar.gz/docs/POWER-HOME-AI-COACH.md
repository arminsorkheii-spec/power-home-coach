# POWER HOME AI COACH — review before any production deployment

Baseline: verified `power-home-94.0.0.tar.gz`, SHA256 `42f639cea7a8b76970f17e806e37de6dca780ce59dc96f572e9203debdc8ca3b` and `install-9400.sh`. The GitHub root contains older partial source files; the verified full release archive is the baseline. This branch contains a full source archive and a readable patch against that release. It is NOT a separate application.

## Architecture

Next.js 16 / React 19 / TypeScript, existing SQLite adapter and coach/student session authentication, existing encrypted-payload helper, exercise/food bank, manual builder and PDF renderer. No new runtime dependency: the installed Zod package exposes its v4 entrypoint for Structured Outputs. Existing version94 raw-db initializer is unchanged.

Coach menu → AI Coach → choose engines/style/athlete constraints → explicit consent gate and selected references/photos → fixed OpenAI Responses endpoint, `store:false`, no tools, no automatic retries → strict schema plus business-rule validation → encrypted draft and append-only revisions → explicit coach approval of the current revision → transfer selected sections to the EXISTING manual builder → edit/save/send through the existing coach publication action. The AI endpoint does not call program-delivery, change coach_states, send a student message or auto-publish a plan.

**Manual programming remains fully available, even with no API key, no migration, a denied student consent or API outage.** AI transfer changes only selected training/nutrition/supplement sections; medication sections and unselected content stay intact. Both training/rest meal sets are retained in the draft; coach explicitly chooses which meal set to transfer. The existing v94 ClientPlan supports one meal schedule, so automatic switching between two daily schedules is deliberately not introduced.

Three modes: independent rejects archive and golden IDs; coach/hybrid send only selected, owner-scoped sample plans. Names/medical profiles/photos are not included in style references; references are reduced to exercise IDs, sets/reps/rest/techniques and structured foods. Legacy free-text meals are not mined because they may contain private notes. Golden templates/rules are saved only from an approved version and included in generation only when explicitly selected.

Split, method and technique are separate typed records. Custom systems have an explicit approved flag; generation rejects pending systems and type mismatches. Manual per-day split titles remain coach-controlled. The rotating three-on/one-off split can be described and reviewed, but v94's calendar assignment remains manual; this version does not silently turn a rolling cycle into a fixed weekly schedule.

Training validation checks permitted/forbidden/required catalog IDs, exact session count/day titles, max working sets, coach RIR/RPE/rest, allowed techniques, and the weekly frequency/set targets of up to three priority muscles, using the existing primary-muscle classifier. Secondary muscle contributions are not claimed as measured volume. Equipment suitability is narrowed by the coach's explicitly allowed exercise list; free-text equipment does not pretend to be an exhaustive equipment ontology.

Nutrition uses an editable Mifflin–St Jeor baseline, activity factor, explicit calorie delta/override, protein/fat per kg, and residual carbs. The model receives the estimates and selected catalog macros. Server calculates returned nutrients from trusted food IDs/grams, checks calorie/protein/fat/carb tolerances and approximate alternatives, and preserves raw/cooked catalog state. Weight trend and food budget are inputs for explanatory suggestions; there is no verified food-price feed or automatic trend-based calorie publication.

Supplements intentionally start with only creatine monohydrate and protein powder. Adult-only requests, reviewed safety information, and no reported medication/medical/injury/allergy/digestive concerns are required for dose suggestions. Otherwise an empty supplement list and professional review are required. Creatine is capped at5g/day; powder at40g/day and only with a recorded dietary protein shortfall. Product protein concentration and individual clinical suitability still require review. This is a conservative safety gate, NOT a complete drug-interaction checker or clinical prescribing system. No medication/hormone/steroid/stimulant protocols are supported in AI outputs. Existing manual medication functions are unchanged.

Visual requests accept only selected front/back/side photos belonging to that athlete, at most6, <=1MB each and3MB total. Existing protected weekly and archived-body photo storage is reused. No external URL fetching or identity/diagnosis/body-fat measurement tools. Qualitative observations have low/moderate confidence and limitations; numeric measurements from image observations are rejected. Image observations remain draft suggestions requiring human review.

## Consent, privacy and security

Student-owned `GET/PUT /api/student/ai-consent` records current disclosure version and separate data/photo/medical grants with a timestamped audit trail. Missing or revoked grants stop NEW transmissions. The grant is rechecked immediately before the provider call. Revocation cannot retract a request already sent. `store:false` is not a guarantee of zero retention for provider abuse monitoring; disclosure says this explicitly. No real student data or photos were sent during development/testing.

Coach routes require the existing coach session and same-origin writes. Client ownership, reference ownership, photo ownership, IDs, output schema, system approval and revision/hash checks are server-side. No API key readback, browser storage, GitHub inclusion or content logging. No model tools execute commands or fetch arbitrary URLs. Untrusted reference/image/text instructions are isolated as data; allowlists and output validation restrict damage, but prompt injection cannot be proven impossible. A coach must review every result.

Failures keep prior drafts. Provider rejection/refusal/invalid output never publishes. Actual API token usage and cached tokens, provider response/request IDs, rate snapshot and calculated USD are recorded when available. Dollar values are calculated from **operator-confirmed rates**, not a billing-provider invoice integration; they must be reconciled against the actual invoice. Unknown network outcomes retain a conservative budget reservation, block retries/concurrent calls, and require explicit operator invoice reconciliation. No fake zero-cost reporting. Monthly default50attempts includes regeneration/failures; total USD cap is separately configurable. Conservative image reservations may reject a request even when its eventual cost would be lower.

## Database and rollback

Additive, opt-in SQL in `migrations/ai-coach-up.sql`: `ai_consents`, `ai_consent_events`, `ai_systems`, `ai_settings`, `ai_jobs`, `ai_drafts`, `ai_draft_versions`, `ai_golden_rules`. Sensitive draft/system/golden payloads reuse encryption. Baseline tables and raw-db migration logic are untouched. `AI_COACH_SCHEMA=1` enables lazy idempotent schema creation only in AI endpoints; leave it unset on production until an approved deployment/migration plan exists.

For rollback: first disable AI (`AI_COACH_SCHEMA=0`), back up the database and export required AI audit/history; run `migrations/ai-coach-down.sql` ONLY on the intended copy. Down SQL deletes AI records, so it is never auto-run. Baseline manual programs, accounts and coach state are preserved. In production, prefer disabling the module and keeping audit tables rather than dropping them.

## Local-only testing and API setup

Use a fresh directory for APP_DATA_DIR; NEVER mount/copy a live credentials file or point this checkout at the production database. Install exact package-lock dependencies. Node22.13+ is required.

```bash
APP_DATA_DIR=/tmp/power-home-ai-dev AI_COACH_SCHEMA=1 npm run dev
npm run build
node --test tests/*.test.mjs
```

The test suite creates its own disposable SQLite directory and injects a fake provider. It does not consume paid API credit. The UI defaults to disabled until configuration and consent are present.

For an explicitly authorized real API smoke test, set `OPENAI_API_KEY` and `AI_COACH_MODEL` ONLY as server environment variables/secret manager values. Never prefix them NEXT_PUBLIC, put keys in query strings, commit them, or share them in chat. Choose a model supporting Responses vision + Structured Outputs; there is no hard-coded paid model. Optional `AI_COACH_MAX_OUTPUT_TOKENS` is clamped1000–16000. Coach settings must explicitly enable AI, match the configured model/rate model, confirm current token prices (including cached input), record the rate-check date, set monthly request/USD limits, and obtain the student's grants. Start with synthetic data and a small cap. ChatGPT Plus does not provide API credit.

No production deployment script is included or invoked for this AI change. No main merge is authorized.

## External documentation used

- OpenAI quickstart: https://developers.openai.com/api/docs/quickstart
- Structured Outputs: https://developers.openai.com/api/docs/guides/structured-outputs
- Responses: https://developers.openai.com/api/reference/resources/responses/methods/create
- Vision: https://developers.openai.com/api/docs/guides/images-vision
- ISSN creatine position: https://pmc.ncbi.nlm.nih.gov/articles/PMC5469049/
- ISSN protein position: https://doi.org/10.1186/s12970-017-0177-8

Remaining review limits: no real-provider quality/latency/billing smoke test, no exhaustive medical interaction database, and no authenticated mobile/Safari visual run yet. This must be treated as an implementation for review, not as a claim of clinically validated or production-approved AI.
