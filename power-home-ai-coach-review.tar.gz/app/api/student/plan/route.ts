import { programDigest } from "@/lib/program-delivery";
import { coachDataKey } from "@/lib/password-auth";
import { database } from "@/lib/raw-db";
import { studentIdFromRequest } from "@/lib/student-auth";
import { blankPlan, EXERCISES, type CoachState } from "@/lib/coach-data";

export async function GET(request: Request) {
  const clientId = await studentIdFromRequest(request);
  if (!clientId) return Response.json({ error: "ورود شاگرد لازم است." }, { status: 401 });
  try {
    const row = await database().prepare("SELECT payload FROM coach_states WHERE owner_email = ?").bind(coachDataKey()).first<{ payload: string }>();
    const state = row ? JSON.parse(row.payload) as CoachState : null;
    let client = state?.clients.find((item) => item.id === clientId);
    let plan = state?.plans[clientId];
    if (!client || !plan) {
      const registration = await database().prepare("SELECT a.package_name,a.profile_json,s.phone FROM applications a JOIN student_accounts s ON s.client_id=a.client_id WHERE a.client_id=? ORDER BY a.created_at DESC LIMIT 1").bind(clientId).first<{package_name:string;profile_json:string;phone:string}>();
      if (!registration) {
        const account=database().prepare('SELECT phone FROM student_accounts WHERE client_id=?').bind(clientId).first<{phone:string}>();
        if(!account)return new Response(null,{status:401});
        return Response.json({client:{id:clientId,name:'ورزشکار',phone:account.phone.startsWith('google:')?'':account.phone,goal:'مسیر ورزشی شخصی',notes:''},plan:blankPlan(),exercises:[],currentPhotos:{},currentDelivered:false},{headers:{'cache-control':'no-store'}});
      }
      const profile = JSON.parse(registration.profile_json || "{}") as { name?: string };
      client = { id: clientId, name: profile.name || "شاگرد", phone: registration.phone.startsWith("google:")?"":registration.phone, goal: registration.package_name, notes: "ثبت‌نام آنلاین" };
      plan = blankPlan();
    }
    const delivery = await database().prepare("SELECT plan_hash FROM current_program_deliveries WHERE client_id=?").bind(clientId).first<{plan_hash:string}>();
    const currentDelivered=Boolean(delivery?.plan_hash===programDigest(plan));
    const usedIds = new Set(plan.workoutDays.flatMap((day) => day.exercises.map((item) => item.exerciseId)));
    const exercises = [...EXERCISES, ...(state?.customExercises ?? [])].filter((exercise) => usedIds.has(exercise.id));
    const currentPhotoRows = await database().prepare("SELECT id,pose FROM client_body_photos WHERE owner=? AND client_id=?").bind(coachDataKey(),clientId).all<{id:string;pose:string}>();
    const currentPhotos=Object.fromEntries(currentPhotoRows.results.map(photo=>[photo.pose,`/api/client-photos/${photo.id}`]));
    const studentPlan = { ...plan };
    delete studentPlan.coachProgramNumber;
    delete studentPlan.sourceTemplateId;
    return Response.json({ client, plan: studentPlan, exercises, currentPhotos, currentDelivered }, { headers: { "cache-control": "no-store" } });
  } catch {
    return Response.json({ error: "دریافت برنامه انجام نشد." }, { status: 500 });
  }
}
