import assert from 'node:assert/strict';import test,{after} from 'node:test';import {mkdtempSync} from 'node:fs';import {tmpdir} from 'node:os';import path from 'node:path';import {fileURLToPath} from 'node:url';import {randomUUID} from 'node:crypto';import {createServer} from 'vite';
const root=fileURLToPath(new URL('..',import.meta.url));process.env.APP_DATA_DIR=mkdtempSync(path.join(tmpdir(),'r929-training-'));process.env.APP_SESSION_SECRET='fixture929-session';
const vite=await createServer({appType:'custom',configFile:false,root,resolve:{alias:{'@':root}},server:{middlewareMode:true,hmr:false}});after(()=>vite.close());const load=p=>vite.ssrLoadModule(p);const {database}=await load('/lib/raw-db.ts'),db=database(),auth=await load('/lib/password-auth.ts'),studentAuth=await load('/lib/student-auth.ts'),{blankPlan,EXERCISES}=await load('/lib/coach-data.ts'),{programDigest}=await load('/lib/program-delivery.ts'),track=await load('/lib/coaching-tracking.ts'),training=await load('/app/api/student/training/route.ts'),replacements=await load('/app/api/coach/exercise-replacements/route.ts'),{notificationTarget}=await load('/lib/notification-target.ts'),helpers=await load('/lib/training-client.ts');
const cookies={};for(const id of ['one','two']){db.prepare('INSERT INTO student_accounts(client_id,phone,password_hash,salt,revision) VALUES(?,?,?,?,?)').bind(id,id==='one'?'09121111111':'09122222222','hash','salt','rev').run();cookies[id]='armin_student_session='+await studentAuth.createStudentSession(id,'rev')}
const coach='power_home_session='+await auth.createSessionToken(),date=track.today(),past=helpers.shiftDate(date,-7),future=helpers.shiftDate(date,2);
const plan={...blankPlan(),title:'تمرین تست',nutritionMeals:[{id:'meal',title:'صبحانه',time:'۸',foods:'غذا',notes:''}],workoutDays:[{id:'day',title:'روز سینه',focus:'سینه',exercises:[{rowId:'row',exerciseId:EXERCISES[0].id,sets:'۳',reps:'۸–۱۰',rest:'۷۵ ثانیه',tempo:'کنترل‌شده',technique:'سوپرست',notes:'نکته مربی',supersetId:'pair'},{rowId:'row2',exerciseId:EXERCISES[1].id,sets:'2',reps:'10',rest:'1 دقیقه',tempo:'',technique:'',notes:'',supersetId:'pair'}]}]};
const state={version:1,activeClientId:'one',clients:[{id:'one',name:'شاگرد اول',phone:'09121111111'},{id:'two',name:'شاگرد دوم',phone:'09122222222'}],plans:{one:plan,two:structuredClone(plan)},customExercises:[]};const saveState=()=>db.prepare('INSERT INTO coach_states(owner_email,payload) VALUES(?,?) ON CONFLICT(owner_email) DO UPDATE SET payload=excluded.payload').bind(auth.coachDataKey(),JSON.stringify(state)).run();saveState();db.prepare('INSERT INTO current_program_deliveries(client_id,plan_hash,delivered_at) VALUES(?,?,?)').bind('one',programDigest(plan),new Date().toISOString()).run();
const req=(route,body,session=cookies.one,method='POST',origin='https://coach.test')=>new Request('https://coach.test'+route,{method,headers:{host:'coach.test',origin,cookie:session,'content-type':'application/json'},...(body===undefined?{}:{body:JSON.stringify(body)})});const post=(body,cookie=cookies.one,origin)=>training.POST(req('/api/student/training',body,cookie,'POST',origin));const get=(cookie=cookies.one,selected=date)=>training.GET(req('/api/student/training?date='+selected,undefined,cookie,'GET'));let sessionId,requestId;
test('training reads require ownership; only delivered plans are exposed and date keys validate',async()=>{
 assert.equal((await get('')).status,401);assert.equal((await get(cookies.one,'2026-02-30')).status,400);
 const own=await(await get()).json();assert.equal(own.days.length,1);assert.ok(own.days[0].exercises[0].image);assert.equal(own.days[0].exercises[0].technique,'سوپرست');assert.equal(own.meals[0].id,'meal');
 const other=await(await get(cookies.two)).json();assert.equal(other.days.length,0);assert.equal(other.meals.length,0);assert.equal(other.sessions.length,0);
});
test('personal calendar saves workouts and rest separately per student and allows future planning, not future execution',async()=>{
 assert.equal((await post({action:'schedule',date:future,dayId:'day',kind:'workout'},cookies.one,'https://evil.test')).status,403);
 assert.equal((await post({action:'schedule',date:future,dayId:'day',kind:'workout'})).status,200);
 assert.equal((await post({action:'schedule',date:future,dayId:'other-private-day',kind:'workout'})).status,400);
 assert.equal((await(await get()).json()).events.length,1);assert.equal((await(await get(cookies.two)).json()).events.length,0);
 assert.equal((await post({action:'schedule',date:future,dayId:null,kind:'rest'})).status,200);assert.equal((await(await get()).json()).events[0].kind,'rest');
 assert.equal((await post({action:'start',date:future,dayId:'day'})).status,400);
 assert.equal((await post({action:'unschedule',date:future})).status,200);assert.equal((await(await get()).json()).events.length,0);
});
test('start is retry safe; sets persist and neither a foreign session nor an invalid planned set can be edited',async()=>{
 assert.equal((await post({action:'start',date,dayId:'day'},cookies.two)).status,400);
 let r=await post({action:'start',date,dayId:'day'});assert.equal(r.status,200);sessionId=(await r.json()).session.id;
 r=await post({action:'start',date,dayId:'day'});assert.equal((await r.json()).session.id,sessionId);
 const body={action:'set',sessionId,rowId:'row',index:1,weight:100,reps:8,done:true};
 assert.equal((await post(body,cookies.two)).status,404);assert.equal((await post({...body,index:4})).status,400);assert.equal((await post({...body,rowId:'foreign-row'})).status,400);assert.equal((await post({...body,reps:0})).status,400);
 assert.equal((await post(body)).status,200);assert.equal((await post(body)).status,200);let own=await(await get()).json();assert.equal(own.sessions[0].sets.length,1);assert.equal(own.sessions[0].sets[0].done,1);assert.equal(db.prepare('SELECT count(*) AS n FROM exercise_results').first().n,0);
 assert.equal((await post({...body,done:false})).status,200);assert.equal((await post({action:'finish',sessionId})).status,400);assert.equal((await post(body)).status,200);
 assert.equal((await post({...body,index:2,weight:90,reps:10})).status,200);
});
test('replacement requests validate session ownership, deduplicate retries and pending requests, and notify the correct coach destination',async()=>{
 const body={action:'replace',id:randomUUID(),sessionId,rowId:'row',reason:'pain',message:'درد هنگام اجرا'};requestId=body.id;
 assert.equal((await post(body,cookies.two)).status,404);assert.equal((await post({...body,rowId:'missing'})).status,400);assert.equal((await post(body)).status,200);assert.equal((await post(body)).status,200);
 assert.equal((await post({...body,id:randomUUID()})).status,200);assert.equal(db.prepare('SELECT count(*) AS n FROM exercise_replacement_requests').first().n,1);
 assert.equal((await(await get(cookies.two)).json()).requests.length,0);
 const notice=db.prepare("SELECT * FROM notification_events WHERE type='exercise_replacement'").first();assert.equal(notice.actor_client_id,'one');assert.equal(notice.url,'/coach?view=client&client=one');
 assert.equal((await replacements.GET(req('/api/coach/exercise-replacements',undefined,cookies.one,'GET'))).status,401);
});
test('coach answers are authenticated, validated, delivered to the student and leave prescribed programs untouched',async()=>{
 const route='/api/coach/exercise-replacements',body={id:requestId,status:'answered',response:'این حرکت را فعلاً اجرا نکن؛ برای بررسی هماهنگ کن.',alternativeId:EXERCISES[1].id},before=JSON.stringify(state);
 assert.equal((await replacements.PATCH(req(route,body,cookies.one,'PATCH'))).status,403);assert.equal((await replacements.PATCH(req(route,body,coach,'PATCH','https://evil.test'))).status,403);
 assert.equal((await replacements.PATCH(req(route,{...body,alternativeId:'missing'},coach,'PATCH'))).status,400);
 assert.equal((await replacements.PATCH(req(route,body,coach,'PATCH'))).status,200);assert.equal((await replacements.PATCH(req(route,body,coach,'PATCH'))).status,409);
 const list=await(await replacements.GET(req(route+'?clientId=one',undefined,coach,'GET'))).json();assert.equal(list.requests[0].status,'answered');assert.equal(list.requests[0].alternative_name,EXERCISES[1].nameFa);
 assert.equal((await(await get()).json()).requests[0].response,body.response);assert.equal(JSON.stringify(state),before);
 const notice=db.prepare("SELECT * FROM notification_events WHERE type='exercise_replacement_answer'").first();assert.equal(notice.recipient_client_id,'one');assert.equal(notice.url,'/student?section=training');
 assert.equal((await(await replacements.GET(req(route+'?clientId=two',undefined,coach,'GET'))).json()).requests.length,0);
});
test('an active workout keeps its delivered snapshot after plan edits; finish posts each completed set exactly once',async()=>{
 state.plans.one.workoutDays[0].exercises[0].notes='تغییر ارسال‌نشده';saveState();
 const own=await(await get()).json();assert.equal(own.days.length,0);assert.equal(own.sessions[0].day.exercises[0].notes,'نکته مربی');
 assert.equal((await post({action:'finish',sessionId},cookies.two)).status,404);
 assert.equal((await post({action:'finish',sessionId})).status,200);assert.equal((await post({action:'finish',sessionId})).status,200);
 const results=db.prepare('SELECT * FROM exercise_results WHERE client_id=?').bind('one').all().results;assert.equal(results.length,2);assert.equal(results.reduce((n,r)=>n+r.sets,0),2);assert.equal(results[0].exercise_name,EXERCISES[0].nameFa);
 assert.equal((await post({action:'set',sessionId,rowId:'row',index:1,weight:110,reps:8,done:true})).status,409);
 assert.equal((await(await get()).json()).sessions[0].status,'completed');
 assert.equal((await post({action:'unschedule',date})).status,200);assert.equal((await(await get()).json()).sessions.length,1);
});
test('previous performance is scoped to the student and excludes the selected day, including manual logs',async()=>{
 db.prepare('INSERT INTO exercise_results(id,client_id,exercise_id,exercise_name,date,weight,reps,sets,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)').bind(randomUUID(),'one',EXERCISES[0].id,EXERCISES[0].nameFa,past,80,10,3,'',past+'T12:00:00Z').run();
 const own=await(await get()).json();assert.equal(own.previous[EXERCISES[0].id].weight,80);assert.equal(own.previous[EXERCISES[0].id].date,past);assert.equal((await(await get(cookies.two)).json()).previous[EXERCISES[0].id],undefined);
});
test('set counts, Persian rest durations and wall-clock countdown handle realistic input and background delays',()=>{
 assert.equal(helpers.plannedSets('۳ ست'),3);assert.equal(helpers.plannedSets('100'),20);assert.equal(helpers.restSeconds('۷۵ ثانیه'),75);assert.equal(helpers.restSeconds('۱.۵ دقیقه'),90);assert.equal(helpers.restSeconds('1:30'),90);assert.equal(helpers.restSeconds('۶۰–۹۰ ثانیه'),90);assert.equal(helpers.restSeconds('بدون استراحت'),0);assert.equal(helpers.remainingSeconds(100000,12000),88);assert.equal(helpers.remainingSeconds(100000,160000),0);
});
