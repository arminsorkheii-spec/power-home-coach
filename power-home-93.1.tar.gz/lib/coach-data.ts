export type Exercise = {
  id: string;
  nameFa: string;
  nameEn: string;
  category: string;
  image: string;
  custom?: boolean;
};

export type ProgramExercise = {
  rowId: string;
  exerciseId: string;
  nameFa?: string;
  nameEn?: string;
  sets: string;
  reps: string;
  rest: string;
  tempo: string;
  technique: string;
  notes: string;
  supersetId?: string;
};

export type WorkoutDay = {
  id: string;
  title: string;
  focus: string;
  exercises: ProgramExercise[];
};

export type Meal = {
  id: string;
  title: string;
  time: string;
  foods: string;
  notes: string;
};

export type SupplementPlanItem = {
  id: string;
  supplementId: string;
  name: string;
  dose: string;
  timing: string;
  frequency: string;
  notes: string;
};

export type MedicationPlanItem = {
  id: string;
  medicationId: string;
  name: string;
  group: "pct" | "bodybuilding";
  dose: string;
  timing: string;
  frequency: string;
  startWeek: string;
  endWeek: string;
  notes: string;
};

export type Client = {
  id: string;
  email?:string;
  name: string;
  phone: string;
  goal: string;
  notes: string;
  initialMeasurements?: { weight?: number | null; height?: number | null; waist?: number | null; arm?: number | null };
};

export type ClientPlan = {
  title: string;
  cycleId?:string;
  durationDays?: number;
  renewalReminderDays?: number;
  renewalRemindersEnabled?: boolean;
  habitGoals?: {waterMl:number;sleepHours:number;steps:number;adherence:number};
  coachProgramNumber?: number;
  sourceTemplateId?: string;
  workoutDays: WorkoutDay[];
  nutritionGoals: {
    calories: string;
    protein: string;
    carbs: string;
    fat: string;
  };
  nutritionMeals: Meal[];
  supplementItems?: SupplementPlanItem[];
  medicationItems?: MedicationPlanItem[];
};

export type CoachState = {
  version: 1;
  syncRevision?: number;
  activeClientId: string;
  clients: Client[];
  plans: Record<string, ClientPlan>;
  customExercises: Exercise[];
  seededPrograms?: string[];
  deletedClientIds?: string[];
  customProgramTemplates?: import("@/lib/program-templates").ProgramTemplate[];
  programUsage?: Record<string, number[]>;
  exerciseImageOverrides?: Record<string, string>;
};

export const EXERCISES: Exercise[] = [
  { id: "stationary-bike", nameFa: "دوچرخه ثابت", nameEn: "Stationary Bike", category: "هوازی", image: "/file.svg" },
  { id: "machine-chest-press", nameFa: "پرس سینه دستگاه دست موازی", nameEn: "Neutral-Grip Machine Chest Press", category: "سینه", image: "/exercises/machine-chest-press.webp" },
  { id: "standard-grip-machine-chest-press", nameFa: "پرس سینه دستگاه دست معمولی", nameEn: "Standard-Grip Machine Chest Press", category: "سینه", image: "/exercises/standard-grip-machine-chest-press.webp" },
  { id: "incline-dumbbell-press", nameFa: "پرس بالا سینه دمبل", nameEn: "Incline Dumbbell Press", category: "سینه", image: "/exercises/incline-dumbbell-press.webp" },
  { id: "barbell-bench-press", nameFa: "پرس سینه هالتر", nameEn: "Barbell Bench Press", category: "سینه", image: "/exercises/barbell-bench-press.webp" },
  { id: "dumbbell-bench-press", nameFa: "پرس سینه دمبل", nameEn: "Dumbbell Bench Press", category: "سینه", image: "/exercises/dumbbell-bench-press.webp" },
  { id: "incline-barbell-press", nameFa: "پرس بالا سینه هالتر", nameEn: "Incline Barbell Press", category: "سینه", image: "/exercises/incline-barbell-press.webp" },
  { id: "dumbbell-fly", nameFa: "فلای سینه دمبل", nameEn: "Dumbbell Fly", category: "سینه", image: "/exercises/dumbbell-fly.webp" },
  { id: "pec-deck", nameFa: "قفسه سینه دستگاه پروانه", nameEn: "Pec Deck", category: "سینه", image: "/exercises/pec-deck.webp" },
  { id: "cable-crossover", nameFa: "کراس اور سیم‌کش", nameEn: "Cable Crossover", category: "سینه", image: "/exercises/cable-crossover.webp" },
  { id: "incline-cable-fly", nameFa: "فلای بالا سینه سیم‌کش", nameEn: "Incline Cable Fly", category: "سینه", image: "/exercises/incline-cable-fly.webp" },
  { id: "smith-incline-press", nameFa: "پرس بالا سینه اسمیت", nameEn: "Smith Machine Incline Press", category: "سینه", image: "/exercises/smith-incline-press.webp" },
  { id: "chest-dip", nameFa: "دیپ پارالل با تمرکز سینه", nameEn: "Chest Dip", category: "سینه", image: "/exercises/chest-dip.webp" },
  { id: "pull-up", nameFa: "بارفیکس دست باز", nameEn: "Pull Up", category: "پشت", image: "/exercises/pull-up.webp" },
  { id: "neutral-grip-pull-up", nameFa: "بارفیکس دست خنثی", nameEn: "Neutral-Grip Pull Up", category: "پشت", image: "/exercises/neutral-grip-pull-up.webp" },
  { id: "barbell-row", nameFa: "زیربغل هالتر خم", nameEn: "Barbell Row", category: "پشت", image: "/exercises/barbell-row.webp" },
  { id: "one-arm-dumbbell-row", nameFa: "زیربغل دمبل تک‌دست", nameEn: "One Arm Dumbbell Row", category: "پشت", image: "/exercises/one-arm-dumbbell-row.webp" },
  { id: "wide-grip-lat-pulldown", nameFa: "لت سیم‌کش دست باز از جلو", nameEn: "Wide Grip Lat Pulldown", category: "پشت", image: "/exercises/wide-grip-lat-pulldown.webp" },
  { id: "t-bar-row", nameFa: "زیربغل تی‌بار دستگاه", nameEn: "Chest-Supported T-Bar Row", category: "پشت", image: "/exercises/t-bar-row.webp" },
  { id: "machine-high-row", nameFa: "زیربغل دستگاه H", nameEn: "Plate-Loaded High Row", category: "پشت", image: "/exercises/machine-high-row.webp" },
  { id: "straight-arm-cable-pulldown", nameFa: "پول‌اور سیم‌کش دست صاف", nameEn: "Straight-Arm Cable Pulldown", category: "پشت", image: "/exercises/straight-arm-cable-pulldown.webp" },
  { id: "dumbbell-lateral-raise", nameFa: "نشر جانب دمبل", nameEn: "Dumbbell Lateral Raise", category: "سرشانه", image: "/exercises/dumbbell-lateral-raise.webp" },
  { id: "single-arm-cable-lateral-raise", nameFa: "نشر جانب تک‌دست سیم‌کش", nameEn: "Single-Arm Cable Lateral Raise", category: "سرشانه", image: "/exercises/single-arm-cable-lateral-raise.webp" },
  { id: "dumbbell-shoulder-press", nameFa: "پرس سرشانه دمبل نشسته", nameEn: "Dumbbell Shoulder Press", category: "سرشانه", image: "/exercises/dumbbell-shoulder-press.webp" },
  { id: "reverse-dumbbell-fly", nameFa: "نشر خم دمبل", nameEn: "Reverse Dumbbell Fly", category: "سرشانه", image: "/exercises/reverse-dumbbell-fly.webp" },
  { id: "seated-dumbbell-rear-delt-raise", nameFa: "نشر خم دمبل نشسته", nameEn: "Seated Dumbbell Rear Delt Raise", category: "سرشانه", image: "/exercises/seated-dumbbell-rear-delt-raise.webp" },
  { id: "dumbbell-shrug", nameFa: "شراگ دمبل", nameEn: "Dumbbell Shrug", category: "سرشانه", image: "/exercises/dumbbell-shrug.webp" },
  { id: "machine-shoulder-press", nameFa: "پرس سرشانه دستگاه", nameEn: "Machine Shoulder Press", category: "سرشانه", image: "/exercises/machine-shoulder-press.webp" },
  { id: "reverse-pec-deck", nameFa: "فلای معکوس دستگاه", nameEn: "Reverse Pec Deck", category: "سرشانه", image: "/exercises/reverse-pec-deck.webp" },
  { id: "rope-triceps-pushdown", nameFa: "پشت بازو سیم‌کش طناب", nameEn: "Rope Triceps Pushdown", category: "بازو", image: "/exercises/rope-triceps-pushdown.webp" },
  { id: "barbell-curl", nameFa: "جلو بازو هالتر", nameEn: "Barbell Curl", category: "بازو", image: "/exercises/barbell-curl.webp" },
  { id: "dumbbell-curl", nameFa: "جلو بازو دمبل", nameEn: "Dumbbell Curl", category: "بازو", image: "/exercises/dumbbell-curl.webp" },
  { id: "hammer-curl", nameFa: "جلو بازو چکشی دمبل", nameEn: "Hammer Curl", category: "بازو", image: "/exercises/hammer-curl.webp" },
  { id: "preacher-curl", nameFa: "جلو بازو لاری هالتر EZ", nameEn: "Preacher Curl", category: "بازو", image: "/exercises/preacher-curl.webp" },
  { id: "incline-dumbbell-curl", nameFa: "جلو بازو دمبل روی میز شیبدار", nameEn: "Incline Dumbbell Curl", category: "بازو", image: "/exercises/incline-dumbbell-curl.webp" },
  { id: "concentration-curl", nameFa: "جلو بازو تمرکزی دمبل", nameEn: "Concentration Curl", category: "بازو", image: "/exercises/concentration-curl.webp" },
  { id: "reverse-ez-bar-curl", nameFa: "جلو بازو معکوس هالتر EZ", nameEn: "Reverse EZ-Bar Curl", category: "بازو", image: "/exercises/reverse-ez-bar-curl.webp" },
  { id: "overhead-dumbbell-triceps-extension", nameFa: "پشت بازو دمبل جفت‌دست بالای سر", nameEn: "Overhead Dumbbell Triceps Extension", category: "بازو", image: "/exercises/overhead-dumbbell-triceps-extension.webp" },
  { id: "overhead-rope-triceps-extension", nameFa: "پشت بازو طناب بالای سر", nameEn: "Overhead Rope Triceps Extension", category: "بازو", image: "/exercises/overhead-rope-triceps-extension.webp" },
  { id: "ez-bar-skullcrusher", nameFa: "پشت بازو هالتر EZ خوابیده", nameEn: "EZ Bar Skullcrusher", category: "بازو", image: "/exercises/ez-bar-skullcrusher.webp" },
  { id: "close-grip-bench-press", nameFa: "پرس سینه دست جمع هالتر", nameEn: "Close-Grip Bench Press", category: "بازو", image: "/exercises/close-grip-bench-press.webp" },
  { id: "dead-bug-legs", nameFa: "ددباگ پا", nameEn: "Dead Bug — Legs Only", category: "میان‌تنه", image: "/exercises/dead-bug-legs.webp" },
  { id: "chin-retraction", nameFa: "جمع کردن چانه", nameEn: "Chin Retraction", category: "اصلاحی", image: "/exercises/chin-retraction.webp" },
  { id: "neutral-lat-pulldown", nameFa: "لت سیم‌کش دست خنثی", nameEn: "Neutral-Grip Lat Pulldown", category: "پشت", image: "/exercises/neutral-lat-pulldown.webp" },
  { id: "seated-cable-row", nameFa: "قایقی سیم‌کش نشسته", nameEn: "Seated Cable Row", category: "پشت", image: "/exercises/seated-cable-row.webp" },
  { id: "cable-face-pull", nameFa: "فیس پول سیم‌کش", nameEn: "Cable Face Pull", category: "سرشانه", image: "/exercises/cable-face-pull.webp" },
  { id: "cable-curl", nameFa: "جلو بازو سیم‌کش", nameEn: "Cable Curl", category: "بازو", image: "/exercises/cable-curl.webp" },
  { id: "bird-dog", nameFa: "برد داگ", nameEn: "Bird Dog", category: "میان‌تنه", image: "/exercises/bird-dog.webp" },
  { id: "wall-slide", nameFa: "وال اسلاید", nameEn: "Wall Slide", category: "اصلاحی", image: "/exercises/wall-slide.webp" },
  { id: "leg-press", nameFa: "پرس پا خوابیده معمولی", nameEn: "45-Degree Leg Press — Standard Stance", category: "پا", image: "/exercises/leg-press.webp" },
  { id: "leg-press-wide-stance", nameFa: "پرس پا خوابیده پا باز", nameEn: "45-Degree Leg Press — Wide Stance", category: "پا", image: "/exercises/leg-press-wide-stance.webp" },
  { id: "leg-press-narrow-stance", nameFa: "پرس پا خوابیده پا جمع", nameEn: "45-Degree Leg Press — Narrow Stance", category: "پا", image: "/exercises/leg-press-narrow-stance.webp" },
  { id: "barbell-squat", nameFa: "اسکوات هالتر", nameEn: "Barbell Squat", category: "پا", image: "/exercises/barbell-squat.webp" },
  { id: "hack-squat", nameFa: "هاک اسکوات دستگاه", nameEn: "Hack Squat", category: "پا", image: "/exercises/hack-squat.webp" },
  { id: "romanian-deadlift", nameFa: "ددلیفت رومانیایی هالتر", nameEn: "Romanian Deadlift", category: "پا", image: "/exercises/romanian-deadlift.webp" },
  { id: "dumbbell-lunge", nameFa: "لانج دمبل", nameEn: "Dumbbell Lunge", category: "پا", image: "/exercises/dumbbell-lunge.webp" },
  { id: "bulgarian-split-squat", nameFa: "اسپلیت اسکوات بلغاری دمبل", nameEn: "Bulgarian Split Squat", category: "پا", image: "/exercises/bulgarian-split-squat.webp" },
  { id: "front-squat", nameFa: "اسکوات جلو هالتر", nameEn: "Barbell Front Squat", category: "پا", image: "/exercises/front-squat.webp" },
  { id: "single-leg-romanian-deadlift", nameFa: "ددلیفت رومانیایی تک‌پا دمبل", nameEn: "Single-Leg Romanian Deadlift", category: "پا", image: "/exercises/single-leg-romanian-deadlift.webp" },
  { id: "seated-leg-curl", nameFa: "پشت پا دستگاه نشسته", nameEn: "Seated Leg Curl", category: "پا", image: "/exercises/seated-leg-curl.webp" },
  { id: "lying-leg-curl", nameFa: "پشت پا دستگاه خوابیده", nameEn: "Lying Leg Curl", category: "پا", image: "/exercises/lying-leg-curl.webp" },
  { id: "leg-extension", nameFa: "جلو پا دستگاه", nameEn: "Leg Extension", category: "پا", image: "/exercises/leg-extension.webp" },
  { id: "glute-bridge", nameFa: "پل باسن", nameEn: "Glute Bridge", category: "پا", image: "/exercises/glute-bridge.webp" },
  { id: "barbell-hip-thrust", nameFa: "هیپ تراست هالتر", nameEn: "Barbell Hip Thrust", category: "پا", image: "/exercises/barbell-hip-thrust.webp" },
  { id: "cable-glute-kickback", nameFa: "کیک‌بک باسن سیم‌کش", nameEn: "Cable Glute Kickback", category: "پا", image: "/exercises/cable-glute-kickback.webp" },
  { id: "supported-calf-raise", nameFa: "ساق پا ایستاده با تکیه", nameEn: "Supported Calf Raise", category: "پا", image: "/exercises/supported-calf-raise.webp" },
  { id: "standing-calf-raise-machine", nameFa: "ساق پا دستگاه ایستاده", nameEn: "Standing Calf Raise Machine", category: "پا", image: "/exercises/standing-calf-raise-machine.webp" },
  { id: "seated-calf-raise", nameFa: "ساق پا دستگاه نشسته", nameEn: "Seated Calf Raise", category: "پا", image: "/exercises/seated-calf-raise.webp" },
  { id: "tibialis-raise", nameFa: "تیبیالیس رِیز کنار دیوار", nameEn: "Wall-Supported Tibialis Raise", category: "پا", image: "/exercises/tibialis-raise.webp" },
  { id: "kneeling-side-plank", nameFa: "ساید پلانک زانو زده", nameEn: "Kneeling Side Plank", category: "میان‌تنه", image: "/exercises/kneeling-side-plank.webp" },
  { id: "captains-chair-knee-raise", nameFa: "شکم خلبانی زانو خم", nameEn: "Captains Chair Knee Raise", category: "میان‌تنه", image: "/exercises/captains-chair-knee-raise.webp" },
  { id: "hanging-leg-raise", nameFa: "شکم خلبانی پا صاف", nameEn: "Hanging Straight-Leg Raise", category: "میان‌تنه", image: "/exercises/hanging-leg-raise.webp" },
  { id: "crunch", nameFa: "کرانچ شکم", nameEn: "Crunch", category: "میان‌تنه", image: "/exercises/crunch.webp" },
  { id: "forearm-plank", nameFa: "پلانک ساعد", nameEn: "Forearm Plank", category: "میان‌تنه", image: "/exercises/forearm-plank.webp" },
  { id: "kneeling-cable-crunch", nameFa: "کرانچ شکم سیم‌کش زانو زده", nameEn: "Kneeling Cable Crunch", category: "میان‌تنه", image: "/exercises/kneeling-cable-crunch.webp" },
  { id: "decline-dumbbell-press", nameFa: "پرس زیر سینه دمبل", nameEn: "Decline Dumbbell Press", category: "سینه", image: "/exercises/decline-dumbbell-press.webp" },
  { id: "underhand-lat-pulldown", nameFa: "لت سیم‌کش دست برعکس", nameEn: "Underhand Lat Pulldown", category: "پشت", image: "/exercises/underhand-lat-pulldown.webp" },
  { id: "dumbbell-pullover", nameFa: "پول‌اور دمبل روی نیمکت", nameEn: "Dumbbell Pullover", category: "پشت", image: "/exercises/dumbbell-pullover.webp" },
  { id: "arnold-press", nameFa: "پرس آرنولدی دمبل", nameEn: "Arnold Press", category: "سرشانه", image: "/exercises/arnold-press.webp" },
  { id: "spider-dumbbell-curl", nameFa: "جلو بازو اسپایدر دمبل", nameEn: "Spider Dumbbell Curl", category: "بازو", image: "/exercises/spider-dumbbell-curl.webp" },
  { id: "single-arm-cable-triceps-kickback", nameFa: "پشت بازو خم تک‌دست سیم‌کش", nameEn: "Single-Arm Cable Triceps Kickback", category: "بازو", image: "/exercises/single-arm-cable-triceps-kickback.webp" },
  { id: "goblet-squat", nameFa: "گابلت اسکوات دمبل", nameEn: "Dumbbell Goblet Squat", category: "پا", image: "/exercises/goblet-squat.webp" },
  { id: "assisted-nordic-hamstring-curl", nameFa: "پشت پا نوردیک کمکی", nameEn: "Assisted Nordic Hamstring Curl", category: "پا", image: "/exercises/assisted-nordic-hamstring-curl.webp" },
  { id: "seated-hip-abduction-machine", nameFa: "خارج ران دستگاه نشسته", nameEn: "Seated Hip Abduction Machine", category: "پا", image: "/exercises/seated-hip-abduction-machine.webp" },
  { id: "side-lying-hip-abduction", nameFa: "دور کردن ران خوابیده به پهلو", nameEn: "Side-Lying Hip Abduction", category: "اصلاحی", image: "/exercises/side-lying-hip-abduction.webp" },
  { id: "donkey-calf-raise", nameFa: "ساق پا خرک دستگاه", nameEn: "Donkey Calf Raise", category: "پا", image: "/exercises/donkey-calf-raise.webp" },
  { id: "ab-wheel-rollout", nameFa: "رول‌اوت چرخ شکم زانو زده", nameEn: "Kneeling Ab Wheel Rollout", category: "میان‌تنه", image: "/exercises/ab-wheel-rollout.webp" },
  { id: "pallof-press", nameFa: "پالوف پرس سیم‌کش", nameEn: "Standing Pallof Press", category: "میان‌تنه", image: "/exercises/pallof-press.webp" },
  { id: "smith-flat-bench-press", nameFa: "پرس سینه تخت اسمیت", nameEn: "Smith Machine Flat Bench Press", category: "سینه", image: "/exercises/smith-flat-bench-press.webp" },
  { id: "chest-supported-dumbbell-row", nameFa: "زیربغل دمبل روی میز شیب‌دار", nameEn: "Chest-Supported Incline Dumbbell Row", category: "پشت", image: "/exercises/chest-supported-dumbbell-row.webp" },
  { id: "single-arm-cable-front-raise", nameFa: "نشر جلو تک‌دست سیم‌کش", nameEn: "Single-Arm Cable Front Raise", category: "سرشانه", image: "/exercises/single-arm-cable-front-raise.webp" },
  { id: "single-arm-bayesian-cable-curl", nameFa: "جلو بازو بیزیَن تک‌دست سیم‌کش", nameEn: "Single-Arm Bayesian Cable Curl", category: "بازو", image: "/exercises/single-arm-bayesian-cable-curl.webp" },
  { id: "cross-body-hammer-curl", nameFa: "جلو بازو چکشی ضربدری", nameEn: "Alternating Cross-Body Hammer Curl", category: "بازو", image: "/exercises/cross-body-hammer-curl.webp" },
  { id: "reverse-grip-triceps-pushdown", nameFa: "پشت بازو سیم‌کش دست برعکس", nameEn: "Reverse-Grip Cable Triceps Pushdown", category: "بازو", image: "/exercises/reverse-grip-triceps-pushdown.webp" },
  { id: "dumbbell-step-up", nameFa: "استپ‌آپ دمبل", nameEn: "Dumbbell Step-Up", category: "پا", image: "/exercises/dumbbell-step-up.webp" },
  { id: "sumo-deadlift", nameFa: "ددلیفت سومو هالتر", nameEn: "Barbell Sumo Deadlift", category: "پا", image: "/exercises/sumo-deadlift.webp" },
  { id: "reverse-crunch", nameFa: "کرانچ معکوس", nameEn: "Reverse Crunch", category: "میان‌تنه", image: "/exercises/reverse-crunch.webp" },
  { id: "short-lever-copenhagen-plank", nameFa: "کپنهاگ پلانک اهرم کوتاه", nameEn: "Short-Lever Copenhagen Side Plank", category: "اصلاحی", image: "/exercises/short-lever-copenhagen-plank.webp" },
  { id: "high-to-low-cable-wood-chop", nameFa: "وودچاپ سیم‌کش از بالا", nameEn: "High-to-Low Cable Wood Chop", category: "میان‌تنه", image: "/exercises/high-to-low-cable-wood-chop.webp" },
  { id: "seated-dumbbell-wrist-curl", nameFa: "مچ دمبل نشسته کف دست بالا", nameEn: "Seated Dumbbell Wrist Curl", category: "بازو", image: "/exercises/seated-dumbbell-wrist-curl.webp" },
  { id: "prone-incline-y-raise", nameFa: "نشر Y خوابیده روی میز شیب‌دار", nameEn: "Prone Incline Bench Y Raise", category: "اصلاحی", image: "/exercises/prone-incline-y-raise.webp" },
  { id: "tall-kneeling-single-arm-cable-lat-pulldown", nameFa: "لت تک‌دست سیم‌کش زانو زده", nameEn: "Tall-Kneeling Single-Arm Cable Lat Pulldown", category: "پشت", image: "/exercises/tall-kneeling-single-arm-cable-lat-pulldown.webp" },
  { id: "standing-side-single-arm-cable-lat-pulldown", nameFa: "لت تک‌دست کنار دستگاه کراس", nameEn: "Standing Side Single-Arm Cable Lat Pulldown", category: "پشت", image: "/exercises/standing-side-single-arm-cable-lat-pulldown.webp" },
  { id: "seated-bench-single-arm-cable-lat-pulldown", nameFa: "لت تک‌دست نشسته روی نیمکت", nameEn: "Seated Bench Single-Arm Cable Lat Pulldown", category: "پشت", image: "/exercises/seated-bench-single-arm-cable-lat-pulldown.webp" },
  { id: "incline-dumbbell-fly", nameFa: "فلای بالا سینه دمبل", nameEn: "Incline Dumbbell Fly", category: "سینه", image: "/exercises/incline-dumbbell-fly.webp" },
  { id: "smith-reverse-lunge", nameFa: "لانج معکوس اسمیت", nameEn: "Smith Machine Reverse Lunge", category: "پا", image: "/exercises/smith-reverse-lunge.webp" },
  { id: "machine-preacher-curl", nameFa: "جلو بازو لاری دستگاه", nameEn: "Plate-Loaded Preacher Curl Machine", category: "بازو", image: "/exercises/machine-preacher-curl.webp" },
  { id: "plate-loaded-chest-supported-row", nameFa: "قایقی دستگاه صفحه‌ای با تکیه سینه", nameEn: "Plate-Loaded Chest-Supported Row", category: "پشت", image: "/exercises/plate-loaded-chest-supported-row.webp" },
  { id: "plate-loaded-pullover-machine", nameFa: "پول‌اور دستگاه صفحه‌ای", nameEn: "Plate-Loaded Pullover Machine", category: "پشت", image: "/exercises/plate-loaded-pullover-machine.webp" },
  { id: "smith-romanian-deadlift", nameFa: "ددلیفت رومانیایی اسمیت", nameEn: "Smith Machine Romanian Deadlift", category: "پا", image: "/exercises/smith-romanian-deadlift.webp" },
  { id: "seated-dumbbell-reverse-wrist-curl", nameFa: "مچ معکوس دمبل نشسته", nameEn: "Seated Dumbbell Reverse Wrist Curl", category: "بازو", image: "/exercises/seated-dumbbell-reverse-wrist-curl.webp" },
  { id: "standing-barbell-overhead-press", nameFa: "پرس سرشانه هالتر ایستاده", nameEn: "Standing Barbell Overhead Press", category: "سرشانه", image: "/exercises/standing-barbell-overhead-press.webp" },
  { id: "one-arm-dumbbell-triceps-kickback", nameFa: "پشت بازو کیک‌بک تک‌دست دمبل", nameEn: "One-Arm Dumbbell Triceps Kickback", category: "بازو", image: "/exercises/one-arm-dumbbell-triceps-kickback.webp" },
  { id: "seated-single-arm-dumbbell-front-raise", nameFa: "نشر جلو تک‌دست دمبل نشسته", nameEn: "Seated Single-Arm Dumbbell Front Raise", category: "سرشانه", image: "/exercises/seated-single-arm-dumbbell-front-raise.webp" },
  { id: "smith-close-grip-bench-press", nameFa: "پرس سینه دست جمع اسمیت", nameEn: "Smith Machine Close-Grip Bench Press", category: "بازو", image: "/exercises/smith-close-grip-bench-press.webp" },
  { id: "dumbbell-lateral-lunge", nameFa: "لانج جانب دمبل", nameEn: "Dumbbell Lateral Lunge", category: "پا", image: "/exercises/dumbbell-lateral-lunge.webp" },
  { id: "cable-pull-through", nameFa: "پول‌ترو سیم‌کش", nameEn: "Cable Pull-Through", category: "پا", image: "/exercises/cable-pull-through.webp" },
  { id: "barbell-drag-curl", nameFa: "جلو بازو درگ هالتر", nameEn: "Barbell Drag Curl", category: "بازو", image: "/exercises/barbell-drag-curl.webp" },
  { id: "decline-barbell-bench-press", nameFa: "پرس زیر سینه هالتر", nameEn: "Decline Barbell Bench Press", category: "سینه", image: "/exercises/decline-barbell-bench-press.webp" },
  { id: "barbell-good-morning", nameFa: "گود مورنینگ هالتر", nameEn: "Barbell Good Morning", category: "پا", image: "/exercises/barbell-good-morning.webp" },
  { id: "smith-machine-back-squat", nameFa: "اسکوات اسمیت", nameEn: "Smith Machine Back Squat", category: "پا", image: "/exercises/smith-machine-back-squat.webp" },
  { id: "machine-rear-delt-row", nameFa: "روئینگ پشت شانه دستگاه با تکیه سینه", nameEn: "Chest-Supported Rear Delt Row Machine", category: "سرشانه", image: "/exercises/machine-rear-delt-row.webp" },
  { id: "smith-standing-calf-raise", nameFa: "ساق پا ایستاده اسمیت", nameEn: "Smith Machine Standing Calf Raise", category: "پا", image: "/exercises/smith-standing-calf-raise.webp" },
  { id: "neutral-grip-dumbbell-bench-press", nameFa: "پرس سینه دمبل دست موازی", nameEn: "Neutral-Grip Dumbbell Bench Press", category: "سینه", image: "/exercises/neutral-grip-dumbbell-bench-press.webp" },
  { id: "plate-loaded-incline-chest-press", nameFa: "پرس بالا سینه دستگاه صفحه‌ای", nameEn: "Plate-Loaded Incline Chest Press", category: "سینه", image: "/exercises/plate-loaded-incline-chest-press.webp" },
  { id: "smith-machine-bent-over-row", nameFa: "زیربغل هالتر خم اسمیت", nameEn: "Smith Machine Bent-Over Row", category: "پشت", image: "/exercises/smith-machine-bent-over-row.webp" },
  { id: "cable-upright-row", nameFa: "کول سیم‌کش دست جمع", nameEn: "Cable Upright Row", category: "سرشانه", image: "/exercises/cable-upright-row.webp" },
  { id: "behind-back-barbell-wrist-curl", nameFa: "مچ هالتر از پشت ایستاده", nameEn: "Behind-the-Back Barbell Wrist Curl", category: "بازو", image: "/exercises/behind-back-barbell-wrist-curl.webp" },
  { id: "pendulum-squat", nameFa: "اسکوات پاندولی دستگاه", nameEn: "Pendulum Squat Machine", category: "پا", image: "/exercises/pendulum-squat.webp" },
  { id: "seated-hip-adduction-machine", nameFa: "داخل ران دستگاه نشسته", nameEn: "Seated Hip Adduction Machine", category: "پا", image: "/exercises/seated-hip-adduction-machine.webp" },
  { id: "hanging-knee-raise", nameFa: "بالا آوردن زانو از بارفیکس", nameEn: "Hanging Bent-Knee Raise", category: "میان‌تنه", image: "/exercises/hanging-knee-raise.webp" },
  { id: "decline-bench-sit-up", nameFa: "درازونشست روی میز شیب منفی", nameEn: "Decline Bench Sit-Up", category: "میان‌تنه", image: "/exercises/decline-bench-sit-up.webp" },
  { id: "resistance-band-pull-apart", nameFa: "باز کردن کش از جلو", nameEn: "Resistance Band Pull-Apart", category: "اصلاحی", image: "/exercises/resistance-band-pull-apart.webp" },
  { id: "plate-loaded-decline-chest-press", nameFa: "پرس زیر سینه دستگاه صفحه‌ای", nameEn: "Plate-Loaded Decline Chest Press", category: "سینه", image: "/exercises/plate-loaded-decline-chest-press.webp" },
  { id: "single-arm-landmine-row", nameFa: "زیربغل تک‌دست لندماین", nameEn: "Single-Arm Landmine Row", category: "پشت", image: "/exercises/single-arm-landmine-row.webp" },
  { id: "seated-dumbbell-lateral-raise", nameFa: "نشر جانب دمبل نشسته", nameEn: "Seated Dumbbell Lateral Raise", category: "سرشانه", image: "/exercises/seated-dumbbell-lateral-raise.webp" },
  { id: "seated-single-arm-overhead-dumbbell-triceps-extension", nameFa: "پشت بازو تک‌دست دمبل بالای سر نشسته", nameEn: "Seated Single-Arm Overhead Dumbbell Triceps Extension", category: "بازو", image: "/exercises/seated-single-arm-overhead-dumbbell-triceps-extension.webp" },
  { id: "dumbbell-hammer-preacher-curl", nameFa: "جلو بازو لاری چکشی دمبل", nameEn: "Dumbbell Hammer Preacher Curl", category: "بازو", image: "/exercises/dumbbell-hammer-preacher-curl.webp" },
  { id: "single-leg-leg-extension", nameFa: "جلو پا دستگاه تک‌پا", nameEn: "Single-Leg Leg Extension", category: "پا", image: "/exercises/single-leg-leg-extension.webp" },
  { id: "single-leg-45-degree-leg-press", nameFa: "پرس پا ۴۵ درجه تک‌پا", nameEn: "Single-Leg 45-Degree Leg Press", category: "پا", image: "/exercises/single-leg-45-degree-leg-press.webp" },
  { id: "dumbbell-sumo-squat", nameFa: "اسکوات سومو دمبل", nameEn: "Dumbbell Sumo Squat", category: "پا", image: "/exercises/dumbbell-sumo-squat.webp" },
  { id: "alternating-heel-taps", nameFa: "تاچ پاشنه تناوبی", nameEn: "Alternating Heel Taps", category: "میان‌تنه", image: "/exercises/alternating-heel-taps.webp" },
  { id: "standing-band-shoulder-external-rotation", nameFa: "چرخش خارجی شانه با کش ایستاده", nameEn: "Standing Band Shoulder External Rotation", category: "اصلاحی", image: "/exercises/standing-band-shoulder-external-rotation.webp" },
  { id: "standard-push-up", nameFa: "شنا سوئدی", nameEn: "Standard Push-Up", category: "سینه", image: "/exercises/standard-push-up.webp" },
  { id: "conventional-barbell-deadlift", nameFa: "ددلیفت هالتر معمولی", nameEn: "Conventional Barbell Deadlift", category: "پشت", image: "/exercises/conventional-barbell-deadlift.webp" },
  { id: "straight-bar-triceps-pushdown", nameFa: "پشت بازو سیم‌کش میله صاف", nameEn: "Straight-Bar Cable Triceps Pushdown", category: "بازو", image: "/exercises/straight-bar-triceps-pushdown.webp" },
  { id: "weight-plate-front-raise", nameFa: "نشر جلو صفحه", nameEn: "Weight-Plate Front Raise", category: "سرشانه", image: "/exercises/weight-plate-front-raise.webp" },
  { id: "45-degree-back-extension", nameFa: "فیله کمر ۴۵ درجه", nameEn: "45-Degree Back Extension", category: "پشت", image: "/exercises/45-degree-back-extension.webp" },
  { id: "seated-machine-lateral-raise", nameFa: "نشر جانب دستگاه نشسته", nameEn: "Seated Machine Lateral Raise", category: "سرشانه", image: "/exercises/seated-machine-lateral-raise.webp" },
  { id: "plate-loaded-belt-squat", nameFa: "بلت اسکوات دستگاه صفحه‌ای", nameEn: "Plate-Loaded Belt Squat", category: "پا", image: "/exercises/plate-loaded-belt-squat.webp" },
  { id: "standing-cable-hip-abduction", nameFa: "دورکردن پا سیم‌کش ایستاده", nameEn: "Standing Cable Hip Abduction", category: "پا", image: "/exercises/standing-cable-hip-abduction.webp" },
  { id: "standing-cable-pallof-press", nameFa: "پالوف پرس سیم‌کش ایستاده", nameEn: "Standing Cable Pallof Press", category: "میان‌تنه", image: "/exercises/standing-cable-pallof-press.webp" },
  { id: "seated-smith-shoulder-press", nameFa: "پرس سرشانه اسمیت نشسته", nameEn: "Seated Smith Machine Shoulder Press", category: "سرشانه", image: "/exercises/seated-smith-shoulder-press.webp" },
  { id: "dumbbell-squeeze-press", nameFa: "اسکوییز پرس دمبل", nameEn: "Dumbbell Squeeze Press", category: "سینه", image: "/exercises/dumbbell-squeeze-press.webp" },
  { id: "incline-dumbbell-hammer-curl", nameFa: "جلو بازو چکشی دمبل روی میز شیب‌دار", nameEn: "Incline Dumbbell Hammer Curl", category: "بازو", image: "/exercises/incline-dumbbell-hammer-curl.webp" },
  { id: "standing-barbell-shrug", nameFa: "شراگ هالتر ایستاده", nameEn: "Standing Barbell Shrug", category: "پشت", image: "/exercises/standing-barbell-shrug.webp" },
  { id: "smith-machine-bulgarian-split-squat", nameFa: "اسپلیت اسکوات بلغاری اسمیت", nameEn: "Smith Machine Bulgarian Split Squat", category: "پا", image: "/exercises/smith-machine-bulgarian-split-squat.webp" },
  { id: "decline-push-up", nameFa: "شنا سوئدی پا بالا", nameEn: "Decline Push-Up", category: "سینه", image: "/exercises/decline-push-up.webp" },
  { id: "single-leg-dumbbell-calf-raise", nameFa: "ساق پا تک‌پا دمبل ایستاده", nameEn: "Single-Leg Standing Dumbbell Calf Raise", category: "پا", image: "/exercises/single-leg-dumbbell-calf-raise.webp" },
  { id: "glute-ham-raise", nameFa: "گلوت هم رِیز دستگاه", nameEn: "Glute-Ham Raise", category: "پا", image: "/exercises/glute-ham-raise.webp" },
  { id: "seated-triceps-dip-machine", nameFa: "پشت بازو دیپ دستگاه نشسته", nameEn: "Seated Triceps Dip Machine", category: "بازو", image: "/exercises/seated-triceps-dip-machine.webp" },
  { id: "dumbbell-reverse-lunge", nameFa: "لانج معکوس دمبل", nameEn: "Dumbbell Reverse Lunge", category: "پا", image: "/exercises/dumbbell-reverse-lunge.webp" },
  { id: "standing-single-leg-curl-machine", nameFa: "پشت پا ایستاده تک‌پا دستگاه", nameEn: "Standing Single-Leg Curl Machine", category: "پا", image: "/exercises/standing-single-leg-curl-machine.webp" },
  { id: "stability-ball-crunch", nameFa: "کرانچ روی توپ", nameEn: "Stability-Ball Crunch", category: "میان‌تنه", image: "/exercises/stability-ball-crunch.webp" },
  { id: "open-book-thoracic-rotation", nameFa: "چرخش سینه‌ای کتاب‌باز", nameEn: "Side-Lying Open Book Thoracic Rotation", category: "اصلاحی", image: "/exercises/open-book-thoracic-rotation.webp" },
  { id: "standing-cable-rear-delt-fly", nameFa: "نشر پشت‌شانه سیم‌کش ایستاده", nameEn: "Standing Cable Rear-Delt Fly", category: "سرشانه", image: "/exercises/standing-cable-rear-delt-fly.webp" },
  { id: "scapular-push-up", nameFa: "شنا کتف", nameEn: "Scapular Push-Up", category: "اصلاحی", image: "/exercises/scapular-push-up.webp" },
  { id: "leg-press-calf-raise", nameFa: "ساق پا روی دستگاه پرس پا", nameEn: "45-Degree Leg Press Calf Raise", category: "پا", image: "/exercises/leg-press-calf-raise.webp" },
  { id: "full-side-plank-hip-lift", nameFa: "بالا آوردن لگن در پلانک پهلو", nameEn: "Full Side Plank Hip Lift", category: "میان‌تنه", image: "/exercises/full-side-plank-hip-lift.webp" },
  { id: "single-arm-dumbbell-bench-press", nameFa: "پرس سینه دمبل تک‌دست", nameEn: "Single-Arm Dumbbell Bench Press", category: "سینه", image: "/exercises/single-arm-dumbbell-bench-press.webp" },
  { id: "smith-machine-front-squat", nameFa: "فرانت اسکوات اسمیت", nameEn: "Smith Machine Front Squat", category: "پا", image: "/exercises/smith-machine-front-squat.webp" },
  { id: "prone-incline-bench-w-raise", nameFa: "حرکت W روی میز شیب‌دار", nameEn: "Prone Incline-Bench W Raise", category: "اصلاحی", image: "/exercises/prone-incline-bench-w-raise.webp" },
  { id: "cat-cow-spinal-mobility", nameFa: "حرکت گربه گاو", nameEn: "Cat-Cow Spinal Mobility", category: "اصلاحی", image: "/exercises/cat-cow-spinal-mobility.webp" },
  { id: "half-kneeling-landmine-press", nameFa: "پرس لندماین تک‌دست نیم‌زانو", nameEn: "Half-Kneeling Single-Arm Landmine Press", category: "سرشانه", image: "/exercises/half-kneeling-landmine-press.webp" },
  { id: "barbell-seal-row", nameFa: "سیل‌رو هالتر", nameEn: "Barbell Seal Row", category: "پشت", image: "/exercises/barbell-seal-row.webp" },
  { id: "close-grip-push-up", nameFa: "شنا سوئدی دست‌جمع", nameEn: "Close-Grip Push-Up", category: "بازو", image: "/exercises/close-grip-push-up.webp" },
  { id: "barbell-box-squat", nameFa: "باکس اسکوات هالتر", nameEn: "Barbell Box Squat", category: "پا", image: "/exercises/barbell-box-squat.webp" },
  { id: "band-overhead-shoulder-mobility-raise", nameFa: "بالا بردن کش برای موبیلیتی شانه", nameEn: "Band Overhead Shoulder Mobility Raise", category: "اصلاحی", image: "/exercises/band-overhead-shoulder-mobility-raise.webp" },
  { id: "plate-loaded-hip-thrust-machine", nameFa: "هیپ تراست دستگاه صفحه‌ای", nameEn: "Plate-Loaded Hip Thrust Machine", category: "پا", image: "/exercises/plate-loaded-hip-thrust-machine.webp" },
  { id: "medicine-ball-russian-twist", nameFa: "روسین توئیست با مدیسن‌بال", nameEn: "Medicine-Ball Russian Twist", category: "میان‌تنه", image: "/exercises/medicine-ball-russian-twist.webp" },
  { id: "standing-ez-bar-curl", nameFa: "جلو بازو هالتر EZ ایستاده", nameEn: "Standing EZ-Bar Curl", category: "بازو", image: "/exercises/standing-ez-bar-curl.webp" },
  { id: "double-high-cable-biceps-curl", nameFa: "جلو بازو فیگوری سیم‌کش دوطرفه", nameEn: "Double High-Cable Biceps Curl", category: "بازو", image: "/exercises/double-high-cable-biceps-curl.webp" },
  { id: "crossed-cable-lateral-raise", nameFa: "نشر جانب سیم‌کش ضربدری", nameEn: "Crossed-Cable Lateral Raise", category: "سرشانه", image: "/exercises/crossed-cable-lateral-raise.webp" },
  { id: "prone-incline-dumbbell-rear-delt-raise", nameFa: "نشر خم دمبل روی میز شیب‌دار", nameEn: "Prone Incline Dumbbell Rear-Delt Raise", category: "سرشانه", image: "/exercises/prone-incline-dumbbell-rear-delt-raise.webp" },
  { id: "smith-machine-shrug", nameFa: "شراگ اسمیت", nameEn: "Smith Machine Shrug", category: "سرشانه", image: "/exercises/smith-machine-shrug.webp" },
  { id: "bench-triceps-dip", nameFa: "دیپ پشت بازو روی نیمکت", nameEn: "Bench Triceps Dip", category: "بازو", image: "/exercises/bench-triceps-dip.webp" },
  { id: "rope-straight-arm-pulldown", nameFa: "پول‌اور سیم‌کش با طناب", nameEn: "Rope Straight-Arm Cable Pulldown", category: "پشت", image: "/exercises/rope-straight-arm-pulldown.webp" },
  { id: "low-to-high-cable-fly", nameFa: "کراس سیم‌کش از پایین به بالا", nameEn: "Low-to-High Cable Fly", category: "سینه", image: "/file.svg" },
  { id: "high-to-low-cable-fly", nameFa: "کراس سیم‌کش از بالا به پایین", nameEn: "High-to-Low Cable Fly", category: "سینه", image: "/file.svg" },
  { id: "flat-cable-fly", nameFa: "فلای سینه سیم‌کش افقی", nameEn: "Flat Cable Fly", category: "سینه", image: "/file.svg" },
  { id: "single-arm-cable-fly", nameFa: "فلای سینه سیم‌کش تک‌دست", nameEn: "Single-Arm Cable Fly", category: "سینه", image: "/file.svg" },
  { id: "single-arm-machine-chest-press", nameFa: "پرس سینه دستگاه تک‌دست", nameEn: "Single-Arm Machine Chest Press", category: "سینه", image: "/file.svg" },
  { id: "iso-lateral-chest-press", nameFa: "پرس سینه دستگاه ایزولترال", nameEn: "Iso-Lateral Chest Press", category: "سینه", image: "/file.svg" },
  { id: "hammer-strength-chest-press", nameFa: "پرس سینه همر استرنگث", nameEn: "Hammer Strength Chest Press", category: "سینه", image: "/file.svg" },
  { id: "hammer-strength-incline-press", nameFa: "پرس بالا سینه همر استرنگث", nameEn: "Hammer Strength Incline Press", category: "سینه", image: "/file.svg" },
  { id: "smith-decline-press", nameFa: "پرس زیر سینه اسمیت", nameEn: "Smith Machine Decline Press", category: "سینه", image: "/file.svg" },
  { id: "feet-up-bench-press", nameFa: "پرس سینه هالتر پا بالا", nameEn: "Feet-Up Barbell Bench Press", category: "سینه", image: "/file.svg" },
  { id: "dumbbell-floor-press", nameFa: "پرس سینه دمبل روی زمین", nameEn: "Dumbbell Floor Press", category: "سینه", image: "/file.svg" },
  { id: "barbell-floor-press", nameFa: "پرس سینه هالتر روی زمین", nameEn: "Barbell Floor Press", category: "سینه", image: "/file.svg" },
  { id: "incline-push-up", nameFa: "شنا سوئدی دست بالا", nameEn: "Incline Push-Up", category: "سینه", image: "/file.svg" },
  { id: "deficit-push-up", nameFa: "شنا سوئدی دیفیسیت", nameEn: "Deficit Push-Up", category: "سینه", image: "/file.svg" },
  { id: "weighted-push-up", nameFa: "شنا سوئدی وزنه‌دار", nameEn: "Weighted Push-Up", category: "سینه", image: "/file.svg" },
  { id: "assisted-chest-dip", nameFa: "دیپ سینه دستگاه کمکی", nameEn: "Assisted Chest Dip", category: "سینه", image: "/file.svg" },
  { id: "cable-squeeze-press", nameFa: "اسکوییز پرس سیم‌کش", nameEn: "Cable Squeeze Press", category: "سینه", image: "/file.svg" },
  { id: "plate-squeeze-press", nameFa: "اسکوییز پرس صفحه", nameEn: "Plate Squeeze Press", category: "سینه", image: "/file.svg" },
  { id: "reverse-grip-bench-press", nameFa: "پرس سینه هالتر مچ برعکس", nameEn: "Reverse-Grip Bench Press", category: "سینه", image: "/file.svg" },
  { id: "reverse-grip-incline-press", nameFa: "پرس بالا سینه هالتر مچ برعکس", nameEn: "Reverse-Grip Incline Press", category: "سینه", image: "/file.svg" },
  { id: "neutral-grip-seated-row", nameFa: "قایقی سیم‌کش دست خنثی", nameEn: "Neutral-Grip Seated Cable Row", category: "پشت", image: "/file.svg" },
  { id: "wide-grip-seated-row", nameFa: "قایقی سیم‌کش دست باز", nameEn: "Wide-Grip Seated Cable Row", category: "پشت", image: "/file.svg" },
  { id: "underhand-seated-cable-row", nameFa: "قایقی سیم‌کش مچ برعکس", nameEn: "Underhand Seated Cable Row", category: "پشت", image: "/file.svg" },
  { id: "single-arm-seated-cable-row", nameFa: "قایقی سیم‌کش تک‌دست", nameEn: "Single-Arm Seated Cable Row", category: "پشت", image: "/file.svg" },
  { id: "single-arm-machine-row", nameFa: "زیربغل دستگاه تک‌دست", nameEn: "Single-Arm Machine Row", category: "پشت", image: "/file.svg" },
  { id: "iso-lateral-high-row", nameFa: "زیربغل دستگاه ایزولترال های‌رو", nameEn: "Iso-Lateral High Row", category: "پشت", image: "/file.svg" },
  { id: "iso-lateral-low-row", nameFa: "زیربغل دستگاه ایزولترال لو‌رو", nameEn: "Iso-Lateral Low Row", category: "پشت", image: "/file.svg" },
  { id: "meadows-row", nameFa: "زیربغل میدوز رو", nameEn: "Meadows Row", category: "پشت", image: "/file.svg" },
  { id: "dumbbell-seal-row", nameFa: "سیل‌رو دمبل", nameEn: "Dumbbell Seal Row", category: "پشت", image: "/file.svg" },
  { id: "prone-dumbbell-row", nameFa: "زیربغل دمبل جفت‌دست روی میز شیب‌دار", nameEn: "Prone Incline Dumbbell Row", category: "پشت", image: "/file.svg" },
  { id: "cable-pullover", nameFa: "پول‌اور سیم‌کش", nameEn: "Cable Pullover", category: "پشت", image: "/file.svg" },
  { id: "kneeling-straight-arm-pulldown", nameFa: "پول‌اور سیم‌کش زانو زده", nameEn: "Kneeling Straight-Arm Pulldown", category: "پشت", image: "/file.svg" },
  { id: "close-grip-lat-pulldown", nameFa: "لت سیم‌کش دست جمع", nameEn: "Close-Grip Lat Pulldown", category: "پشت", image: "/file.svg" },
  { id: "medium-grip-lat-pulldown", nameFa: "لت سیم‌کش دست متوسط", nameEn: "Medium-Grip Lat Pulldown", category: "پشت", image: "/file.svg" },
  { id: "single-arm-lat-pulldown", nameFa: "لت سیم‌کش تک‌دست", nameEn: "Single-Arm Lat Pulldown", category: "پشت", image: "/file.svg" },
  { id: "assisted-pull-up", nameFa: "بارفیکس دستگاه کمکی", nameEn: "Assisted Pull-Up", category: "پشت", image: "/file.svg" },
  { id: "chin-up", nameFa: "بارفیکس مچ برعکس", nameEn: "Chin-Up", category: "پشت", image: "/file.svg" },
  { id: "scapular-pull-up", nameFa: "بارفیکس کتف", nameEn: "Scapular Pull-Up", category: "اصلاحی", image: "/file.svg" },
  { id: "rack-pull", nameFa: "رک پول هالتر", nameEn: "Barbell Rack Pull", category: "پشت", image: "/file.svg" },
  { id: "trap-bar-deadlift", nameFa: "ددلیفت ترپ‌بار", nameEn: "Trap-Bar Deadlift", category: "پشت", image: "/file.svg" },
  { id: "snatch-grip-deadlift", nameFa: "ددلیفت دست باز", nameEn: "Snatch-Grip Deadlift", category: "پشت", image: "/file.svg" },
  { id: "cable-row-to-hip", nameFa: "قایقی سیم‌کش به سمت لگن", nameEn: "Cable Row to Hip", category: "پشت", image: "/file.svg" },
  { id: "face-pull-row", nameFa: "فیس پول رو", nameEn: "Face Pull Row", category: "پشت", image: "/file.svg" },
  { id: "barbell-front-raise", nameFa: "نشر جلو هالتر", nameEn: "Barbell Front Raise", category: "سرشانه", image: "/file.svg" },
  { id: "dumbbell-front-raise", nameFa: "نشر جلو دمبل", nameEn: "Dumbbell Front Raise", category: "سرشانه", image: "/file.svg" },
  { id: "cable-front-raise", nameFa: "نشر جلو سیم‌کش", nameEn: "Cable Front Raise", category: "سرشانه", image: "/file.svg" },
  { id: "leaning-cable-lateral-raise", nameFa: "نشر جانب سیم‌کش با تکیه", nameEn: "Leaning Cable Lateral Raise", category: "سرشانه", image: "/file.svg" },
  { id: "lying-cable-lateral-raise", nameFa: "نشر جانب سیم‌کش خوابیده", nameEn: "Lying Cable Lateral Raise", category: "سرشانه", image: "/file.svg" },
  { id: "incline-bench-lateral-raise", nameFa: "نشر جانب دمبل روی میز شیب‌دار", nameEn: "Incline-Bench Dumbbell Lateral Raise", category: "سرشانه", image: "/file.svg" },
  { id: "standing-machine-lateral-raise", nameFa: "نشر جانب دستگاه ایستاده", nameEn: "Standing Machine Lateral Raise", category: "سرشانه", image: "/file.svg" },
  { id: "behind-back-cable-lateral-raise", nameFa: "نشر جانب سیم‌کش از پشت بدن", nameEn: "Behind-the-Back Cable Lateral Raise", category: "سرشانه", image: "/file.svg" },
  { id: "cable-y-raise", nameFa: "نشر Y سیم‌کش", nameEn: "Cable Y Raise", category: "سرشانه", image: "/file.svg" },
  { id: "dumbbell-y-raise", nameFa: "نشر Y دمبل", nameEn: "Dumbbell Y Raise", category: "سرشانه", image: "/file.svg" },
  { id: "cable-rear-delt-row", nameFa: "پارویی سیم‌کش پشت شانه", nameEn: "Cable Rear-Delt Row", category: "سرشانه", image: "/file.svg" },
  { id: "dumbbell-rear-delt-row", nameFa: "پارویی دمبل پشت شانه", nameEn: "Dumbbell Rear-Delt Row", category: "سرشانه", image: "/file.svg" },
  { id: "bent-over-cable-reverse-fly", nameFa: "فلای معکوس سیم‌کش خم", nameEn: "Bent-Over Cable Reverse Fly", category: "سرشانه", image: "/file.svg" },
  { id: "reverse-cable-crossover", nameFa: "کراس معکوس سیم‌کش", nameEn: "Reverse Cable Crossover", category: "سرشانه", image: "/file.svg" },
  { id: "high-incline-dumbbell-press", nameFa: "پرس دمبل شیب زیاد", nameEn: "High-Incline Dumbbell Press", category: "سرشانه", image: "/file.svg" },
  { id: "neutral-grip-machine-shoulder-press", nameFa: "پرس سرشانه دستگاه دست موازی", nameEn: "Neutral-Grip Machine Shoulder Press", category: "سرشانه", image: "/file.svg" },
  { id: "single-arm-machine-shoulder-press", nameFa: "پرس سرشانه دستگاه تک‌دست", nameEn: "Single-Arm Machine Shoulder Press", category: "سرشانه", image: "/file.svg" },
  { id: "standing-landmine-press", nameFa: "پرس لندماین تک‌دست ایستاده", nameEn: "Standing Single-Arm Landmine Press", category: "سرشانه", image: "/file.svg" },
  { id: "barbell-upright-row", nameFa: "کول هالتر دست باز", nameEn: "Barbell Upright Row", category: "سرشانه", image: "/file.svg" },
  { id: "dumbbell-upright-row", nameFa: "کول دمبل", nameEn: "Dumbbell Upright Row", category: "سرشانه", image: "/file.svg" },
  { id: "cable-shrug", nameFa: "شراگ سیم‌کش", nameEn: "Cable Shrug", category: "سرشانه", image: "/file.svg" },
  { id: "machine-shrug", nameFa: "شراگ دستگاه", nameEn: "Machine Shrug", category: "سرشانه", image: "/file.svg" },
  { id: "ez-bar-preacher-curl", nameFa: "جلو بازو لاری هالتر EZ دست جمع", nameEn: "EZ-Bar Preacher Curl", category: "بازو", image: "/file.svg" },
  { id: "cable-preacher-curl", nameFa: "جلو بازو لاری سیم‌کش", nameEn: "Cable Preacher Curl", category: "بازو", image: "/file.svg" },
  { id: "single-arm-preacher-curl", nameFa: "جلو بازو لاری دمبل تک‌دست", nameEn: "Single-Arm Dumbbell Preacher Curl", category: "بازو", image: "/file.svg" },
  { id: "cable-concentration-curl", nameFa: "جلو بازو تمرکزی سیم‌کش", nameEn: "Cable Concentration Curl", category: "بازو", image: "/file.svg" },
  { id: "rope-hammer-curl", nameFa: "جلو بازو چکشی طناب سیم‌کش", nameEn: "Rope Hammer Curl", category: "بازو", image: "/file.svg" },
  { id: "cable-hammer-curl", nameFa: "جلو بازو چکشی سیم‌کش", nameEn: "Cable Hammer Curl", category: "بازو", image: "/file.svg" },
  { id: "zottman-curl", nameFa: "جلو بازو زاتمن دمبل", nameEn: "Zottman Curl", category: "بازو", image: "/file.svg" },
  { id: "seated-alternating-dumbbell-curl", nameFa: "جلو بازو دمبل تناوبی نشسته", nameEn: "Seated Alternating Dumbbell Curl", category: "بازو", image: "/file.svg" },
  { id: "incline-alternating-dumbbell-curl", nameFa: "جلو بازو دمبل تناوبی روی میز شیب‌دار", nameEn: "Incline Alternating Dumbbell Curl", category: "بازو", image: "/file.svg" },
  { id: "dumbbell-drag-curl", nameFa: "جلو بازو درگ کرل دمبل", nameEn: "Dumbbell Drag Curl", category: "بازو", image: "/file.svg" },
  { id: "reverse-cable-curl", nameFa: "جلو بازو سیم‌کش مچ برعکس", nameEn: "Reverse Cable Curl", category: "بازو", image: "/file.svg" },
  { id: "reverse-dumbbell-curl", nameFa: "جلو بازو دمبل مچ برعکس", nameEn: "Reverse Dumbbell Curl", category: "بازو", image: "/file.svg" },
  { id: "barbell-wrist-curl", nameFa: "ساعد هالتر کف دست بالا", nameEn: "Barbell Wrist Curl", category: "بازو", image: "/file.svg" },
  { id: "barbell-reverse-wrist-curl", nameFa: "ساعد هالتر کف دست پایین", nameEn: "Barbell Reverse Wrist Curl", category: "بازو", image: "/file.svg" },
  { id: "cable-wrist-curl", nameFa: "ساعد سیم‌کش کف دست بالا", nameEn: "Cable Wrist Curl", category: "بازو", image: "/file.svg" },
  { id: "standing-wrist-curl-machine", nameFa: "ساعد دستگاه ایستاده", nameEn: "Standing Wrist Curl Machine", category: "بازو", image: "/file.svg" },
  { id: "preacher-wrist-curl-palms-up", nameFa: "میز ساعد کف دست بالا", nameEn: "Preacher-Bench Wrist Curl Palms Up", category: "بازو", image: "/file.svg" },
  { id: "single-arm-rope-triceps-pushdown", nameFa: "پشت بازو طناب تک‌دست", nameEn: "Single-Arm Rope Triceps Pushdown", category: "بازو", image: "/file.svg" },
  { id: "v-bar-triceps-pushdown", nameFa: "پشت بازو سیم‌کش میله V", nameEn: "V-Bar Triceps Pushdown", category: "بازو", image: "/file.svg" },
  { id: "ez-bar-triceps-pushdown", nameFa: "پشت بازو سیم‌کش میله EZ", nameEn: "EZ-Bar Cable Triceps Pushdown", category: "بازو", image: "/file.svg" },
  { id: "crossbody-cable-triceps-extension", nameFa: "پشت بازو سیم‌کش کراس‌بادی", nameEn: "Cross-Body Cable Triceps Extension", category: "بازو", image: "/file.svg" },
  { id: "cable-skullcrusher", nameFa: "پشت بازو خوابیده سیم‌کش", nameEn: "Cable Skullcrusher", category: "بازو", image: "/file.svg" },
  { id: "dumbbell-skullcrusher", nameFa: "پشت بازو خوابیده دمبل", nameEn: "Dumbbell Skullcrusher", category: "بازو", image: "/file.svg" },
  { id: "rolling-dumbbell-triceps-extension", nameFa: "پشت بازو رولینگ دمبل", nameEn: "Rolling Dumbbell Triceps Extension", category: "بازو", image: "/file.svg" },
  { id: "jm-press", nameFa: "پرس JM هالتر", nameEn: "JM Press", category: "بازو", image: "/file.svg" },
  { id: "machine-triceps-extension", nameFa: "پشت بازو دستگاه اکستنشن", nameEn: "Machine Triceps Extension", category: "بازو", image: "/file.svg" },
  { id: "safety-bar-squat", nameFa: "اسکوات سیفتی‌بار", nameEn: "Safety-Bar Squat", category: "پا", image: "/file.svg" },
  { id: "zercher-squat", nameFa: "زرچر اسکوات", nameEn: "Zercher Squat", category: "پا", image: "/file.svg" },
  { id: "heel-elevated-goblet-squat", nameFa: "گابلت اسکوات پاشنه بالا", nameEn: "Heel-Elevated Goblet Squat", category: "پا", image: "/file.svg" },
  { id: "cyclist-squat", nameFa: "سایکلست اسکوات", nameEn: "Cyclist Squat", category: "پا", image: "/file.svg" },
  { id: "sissy-squat", nameFa: "سیسی اسکوات", nameEn: "Sissy Squat", category: "پا", image: "/file.svg" },
  { id: "reverse-hack-squat", nameFa: "هاک اسکوات معکوس", nameEn: "Reverse Hack Squat", category: "پا", image: "/file.svg" },
  { id: "hack-squat-high-feet", nameFa: "هاک اسکوات جای پا بالا", nameEn: "Hack Squat High Foot Placement", category: "پا", image: "/file.svg" },
  { id: "hack-squat-low-feet", nameFa: "هاک اسکوات جای پا پایین", nameEn: "Hack Squat Low Foot Placement", category: "پا", image: "/file.svg" },
  { id: "horizontal-leg-press", nameFa: "پرس پا افقی دستگاه", nameEn: "Horizontal Leg Press", category: "پا", image: "/file.svg" },
  { id: "seated-leg-press-machine", nameFa: "پرس پا نشسته دستگاه", nameEn: "Seated Leg Press Machine", category: "پا", image: "/file.svg" },
  { id: "vertical-leg-press", nameFa: "پرس پا عمودی", nameEn: "Vertical Leg Press", category: "پا", image: "/file.svg" },
  { id: "cable-belt-squat", nameFa: "بلت اسکوات سیم‌کش", nameEn: "Cable Belt Squat", category: "پا", image: "/file.svg" },
  { id: "dumbbell-split-squat", nameFa: "اسپلیت اسکوات دمبل", nameEn: "Dumbbell Split Squat", category: "پا", image: "/file.svg" },
  { id: "front-foot-elevated-split-squat", nameFa: "اسپلیت اسکوات پای جلو بالا", nameEn: "Front-Foot-Elevated Split Squat", category: "پا", image: "/file.svg" },
  { id: "dumbbell-walking-lunge", nameFa: "لانج راه‌رفتنی دمبل", nameEn: "Dumbbell Walking Lunge", category: "پا", image: "/file.svg" },
  { id: "barbell-walking-lunge", nameFa: "لانج راه‌رفتنی هالتر", nameEn: "Barbell Walking Lunge", category: "پا", image: "/file.svg" },
  { id: "dumbbell-curtsy-lunge", nameFa: "لانج کرتسی دمبل", nameEn: "Dumbbell Curtsy Lunge", category: "پا", image: "/file.svg" },
  { id: "single-leg-lying-leg-curl", nameFa: "پشت پا خوابیده تک‌پا دستگاه", nameEn: "Single-Leg Lying Leg Curl", category: "پا", image: "/file.svg" },
  { id: "dumbbell-leg-curl", nameFa: "پشت پا دمبل خوابیده", nameEn: "Dumbbell Leg Curl", category: "پا", image: "/file.svg" },
  { id: "cable-leg-curl", nameFa: "پشت پا سیم‌کش", nameEn: "Cable Leg Curl", category: "پا", image: "/file.svg" },
  { id: "barbell-stiff-leg-deadlift", nameFa: "ددلیفت پا صاف هالتر", nameEn: "Barbell Stiff-Leg Deadlift", category: "پا", image: "/file.svg" },
  { id: "dumbbell-stiff-leg-deadlift", nameFa: "ددلیفت پا صاف دمبل", nameEn: "Dumbbell Stiff-Leg Deadlift", category: "پا", image: "/file.svg" },

];

export const TECHNIQUES = [
  "عادی",
  "سوپرست",
  "تری‌ست",
  "جاینت‌ست",
  "دراپ‌ست",
  "رست‌پاز",
  "کلاستر",
  "FST-7",
  "نگاتیو / Negative Reps",
  "مکث ایزومتریک",
];

const row = (rowId: string, exerciseId: string, sets = "3", reps = "10–12", rest = "75 ثانیه"): ProgramExercise => ({
  rowId,
  exerciseId,
  sets,
  reps,
  rest,
  tempo: "کنترل‌شده",
  technique: "عادی",
  notes: "",
});

export const FAT_LOSS_58_CLIENT_ID = "client-58-fat-loss-2026-09-01";
export const FAT_LOSS_58_SEED = "fat-loss-58-ppl-v6";

export const FAT_LOSS_58_CLIENT: Client = {
  id: FAT_LOSS_58_CLIENT_ID,
  name: "عامری",
  phone: "",
  goal: "کاهش چربی با حفظ عضله",
  notes: "قد ۱۷۵ | وزن ۹۱.۲ | دور کمر ۱۰۲ | چربی بدن ۲۱.۹٪ | سابقه تمرین ۲ ماه",
};

const rirRow = (rowId: string, exerciseId: string, sets: string, reps: string, rest = "۷۵–۹۰ ثانیه"): ProgramExercise => ({
  ...row(rowId, exerciseId, sets, reps, rest),
  tempo: "کنترل‌شده ۲-۱-۲",
  notes: "RIR 2 — دو تکرار در ذخیره",
});

export const FAT_LOSS_58_PLAN: ClientPlan = {
  title: "چربی‌سوزی مبتدی — Push / Pull / Legs",
  workoutDays: [
    {
      id: "fat-loss-push",
      title: "روز ۱ — PUSH",
      focus: "سینه، سرشانه، پشت بازو",
      exercises: [
        rirRow("fl58-push-1", "standard-grip-machine-chest-press", "3", "10–12", "۹۰ ثانیه"),
        rirRow("fl58-push-2", "incline-dumbbell-press", "3", "10–12", "۹۰ ثانیه"),
        rirRow("fl58-push-3", "pec-deck", "3", "12–15"),
        rirRow("fl58-push-4", "machine-shoulder-press", "3", "10–12", "۹۰ ثانیه"),
        rirRow("fl58-push-5", "seated-dumbbell-lateral-raise", "3", "12–15"),
        rirRow("fl58-push-6", "rope-triceps-pushdown", "3", "10–12"),
        rirRow("fl58-push-7", "overhead-rope-triceps-extension", "2", "12–15"),
      ],
    },
    {
      id: "fat-loss-pull",
      title: "روز ۲ — PULL",
      focus: "زیربغل، پشت شانه، جلو بازو",
      exercises: [
        rirRow("fl58-pull-1", "wide-grip-lat-pulldown", "3", "10–12", "۹۰ ثانیه"),
        rirRow("fl58-pull-2", "seated-cable-row", "3", "10–12", "۹۰ ثانیه"),
        rirRow("fl58-pull-3", "seated-bench-single-arm-cable-lat-pulldown", "3", "12 هر دست"),
        rirRow("fl58-pull-4", "machine-high-row", "3", "10–12", "۹۰ ثانیه"),
        rirRow("fl58-pull-5", "reverse-pec-deck", "3", "12–15"),
        rirRow("fl58-pull-6", "cable-curl", "3", "10–12"),
        rirRow("fl58-pull-7", "hammer-curl", "2", "12"),
      ],
    },
    {
      id: "fat-loss-legs",
      title: "روز ۳ — LEGS",
      focus: "پا، داخل ران، ساق و شکم",
      exercises: [
        rirRow("fl58-legs-1", "leg-press", "3", "10–12", "۹۰–۱۲۰ ثانیه"),
        rirRow("fl58-legs-2", "hack-squat", "3", "10–12", "۹۰–۱۲۰ ثانیه"),
        rirRow("fl58-legs-3", "lying-leg-curl", "3", "12–15", "۹۰ ثانیه"),
        rirRow("fl58-legs-4", "leg-extension", "3", "12–15"),
        rirRow("fl58-legs-5", "seated-hip-adduction-machine", "3", "12–15"),
        rirRow("fl58-legs-6", "standing-calf-raise-machine", "4", "12–15"),
        rirRow("fl58-legs-7", "kneeling-cable-crunch", "3", "12–15"),
      ],
    },
  ],
  nutritionGoals: { calories: "۲۱۰۰", protein: "۱۴۰–۱۵۰ گرم", carbs: "۲۰۵–۲۱۵ گرم", fat: "۶۵ گرم" },
  nutritionMeals: [
    { id: "fl58-breakfast", title: "صبحانه", time: "08:00", foods: "۲ عدد تخم‌مرغ کامل + ۶۰ گرم نان سنگک یا نان سبوس‌دار + خیار، گوجه و سبزی خوردن", notes: "چای بدون شکر — بدون سفیده اضافه" },
    { id: "fl58-snack-1", title: "میان‌وعده اول", time: "11:00", foods: "یک عدد میوه + ۱۵ گرم بادام یا گردو", notes: "بدون وی و بدون ماست" },
    { id: "fl58-lunch", title: "ناهار", time: "14:00", foods: "۲۵۰ گرم سینه مرغ یا بوقلمون خام + ۲۳۰ گرم برنج سفید پخته + سالاد", notes: "۱۰ گرم روغن زیتون" },
    { id: "fl58-snack-2", title: "میان‌وعده دوم", time: "17:30", foods: "۲۵۰ میلی‌لیتر شیر کم‌چرب + یک عدد میوه", notes: "" },
    { id: "fl58-dinner", title: "شام", time: "21:00", foods: "۲۵۰ گرم مرغ یا ماهی خام + ۲۰۰ گرم برنج سفید پخته + سبزیجات یا سالاد", notes: "۱۰ گرم روغن زیتون روی سالاد — بدون ماست" },
  ],
};

export const MEHRAD_KIAN_SEED = "mehrad-kian-ppl-v1";

const mehradRow = (
  rowId: string,
  exerciseId: string,
  sets: string,
  reps: string,
  rest = "۷۵–۹۰ ثانیه",
  notes = "RIR 2 — دو تکرار صحیح در ذخیره بماند.",
): ProgramExercise => ({
  ...row(rowId, exerciseId, sets, reps, rest),
  tempo: "کنترل‌شده ۲-۱-۲",
  notes,
});

export const MEHRAD_KIAN_PLAN: ClientPlan = {
  title: "چربی‌سوزی و فرم‌دهی — Push / Pull / Legs",
  workoutDays: [
    {
      id: "mehrad-push",
      title: "روز ۱ — PUSH",
      focus: "سینه، سرشانه و پشت بازو",
      exercises: [
        mehradRow("mehrad-push-1", "standard-grip-machine-chest-press", "3", "10–12", "۹۰ ثانیه"),
        mehradRow("mehrad-push-2", "incline-dumbbell-press", "3", "10–12", "۹۰ ثانیه"),
        mehradRow("mehrad-push-3", "pec-deck", "3", "12–15"),
        mehradRow("mehrad-push-4", "machine-shoulder-press", "3", "10–12", "۹۰ ثانیه"),
        mehradRow("mehrad-push-5", "dumbbell-lateral-raise", "3", "12–15", "۶۰ ثانیه"),
        mehradRow("mehrad-push-6", "rope-triceps-pushdown", "3", "12–15"),
        mehradRow("mehrad-push-7", "seated-single-arm-overhead-dumbbell-triceps-extension", "3", "10–12 هر دست"),
        mehradRow("mehrad-push-8", "stationary-bike", "1", "۳۰ دقیقه", "—", "در پایان تمرین با شدت متوسط و یکنواخت انجام شود."),
      ],
    },
    {
      id: "mehrad-pull",
      title: "روز ۲ — PULL",
      focus: "زیربغل، پشت شانه و جلو بازو",
      exercises: [
        mehradRow("mehrad-pull-1", "wide-grip-lat-pulldown", "3", "10–12", "۹۰ ثانیه"),
        mehradRow("mehrad-pull-2", "seated-cable-row", "3", "10–12", "۹۰ ثانیه"),
        mehradRow("mehrad-pull-3", "machine-high-row", "3", "10–12 هر دست", "۹۰ ثانیه", "اچ دستگاه را تک‌دست اجرا کن؛ تنه ثابت و آرنج به سمت پهلو کشیده شود."),
        mehradRow("mehrad-pull-4", "cable-face-pull", "3", "12–15"),
        mehradRow("mehrad-pull-5", "reverse-dumbbell-fly", "2", "15", "۶۰ ثانیه"),
        mehradRow("mehrad-pull-6", "dumbbell-curl", "3", "10–12"),
        mehradRow("mehrad-pull-7", "hammer-curl", "2", "12–15"),
        mehradRow("mehrad-pull-8", "stationary-bike", "1", "۳۰ دقیقه", "—", "در پایان تمرین با شدت متوسط و یکنواخت انجام شود."),
      ],
    },
    {
      id: "mehrad-legs",
      title: "روز ۳ — LEGS",
      focus: "چهارسر، همسترینگ، داخل ران، ساق و شکم",
      exercises: [
        mehradRow("mehrad-legs-1", "goblet-squat", "3", "10–12", "۹۰ ثانیه"),
        mehradRow("mehrad-legs-2", "leg-press", "3", "12", "۹۰–۱۲۰ ثانیه"),
        mehradRow("mehrad-legs-3", "leg-extension", "2", "12–15"),
        mehradRow("mehrad-legs-4", "dumbbell-sumo-squat", "3", "10–12", "۹۰ ثانیه", "پاها بازتر از عرض شانه؛ دمبل بین پاها و زانوها هم‌جهت پنجه‌ها باشد."),
        mehradRow("mehrad-legs-5", "seated-hip-adduction-machine", "3", "12–15"),
        mehradRow("mehrad-legs-6", "lying-leg-curl", "3", "12", "۹۰ ثانیه"),
        mehradRow("mehrad-legs-7", "standing-calf-raise-machine", "3", "15–20", "۶۰ ثانیه"),
        mehradRow("mehrad-legs-8", "forearm-plank", "3", "۳۰–۴۰ ثانیه", "۶۰ ثانیه"),
        mehradRow("mehrad-legs-9", "stationary-bike", "1", "۳۰ دقیقه", "—", "در پایان تمرین با شدت متوسط و یکنواخت انجام شود."),
      ],
    },
  ],
  nutritionGoals: { calories: "", protein: "", carbs: "", fat: "" },
  nutritionMeals: [],
  supplementItems: [],
  medicationItems: [],
};

export const MOHAMMAD_ZAREH_CLIENT_ID = "client-mohammad-zareh-2026-09-12";
export const MOHAMMAD_ZAREH_SEED = "mohammad-zareh-training-v1";

export const MOHAMMAD_ZAREH_CLIENT: Client = {
  id: MOHAMMAD_ZAREH_CLIENT_ID,
  name: "محمد زارع",
  phone: "",
  goal: "حجم خشک و عضله‌سازی",
  notes: "قد ۱۷۰ | وزن ۷۵ | سابقه تمرینی دارد | ۴ جلسه اصلی در هفته",
};

const detailedRow = (
  rowId: string,
  exerciseId: string,
  sets: string,
  reps: string,
  rest: string,
  tempo: string,
  technique: string,
  notes: string,
  supersetId?: string,
): ProgramExercise => ({ rowId, exerciseId, sets, reps, rest, tempo, technique, notes, supersetId });

export const MOHAMMAD_ZAREH_PLAN: ClientPlan = {
  title: "حجم خشک پیشرفته — اسپلیت ۴ روزه",
  workoutDays: [
    {
      id: "mz-chest-biceps",
      title: "روز ۱ — سینه و جلو بازو",
      focus: "فشار کنترل‌شده؛ دو روز تمرین، یک روز استراحت. فقط ست‌های مشخص‌شده تا نزدیکی ناتوانی اجرا شوند.",
      exercises: [
        detailedRow("mz-cb-1", "smith-incline-press", "3", "6–10", "۲–۳ دقیقه", "۳-۰-۱", "عادی", "سه ثانیه پایین‌بردن؛ بالا آمدن قدرتمند و کنترل‌شده. ست آخر RIR 1؛ یعنی فقط یک تکرار صحیح در ذخیره بماند."),
        detailedRow("mz-cb-2", "incline-cable-fly", "3", "10–15", "۷۵–۹۰ ثانیه", "۲-۱-۲", "مکث ایزومتریک", "روی میز بالاسینه اجرا شود؛ آرنج کمی خم و ثابت، کشش کامل و یک ثانیه مکث در جمع‌کردن دست‌ها."),
        detailedRow("mz-cb-3", "dumbbell-bench-press", "3", "8–10", "بدون استراحت", "۲-۰-۱", "سوپرست", "پس از آخرین تکرار، بدون استراحت سراغ پرس دمبل دست موازی برو. وزنه را طوری انتخاب کن که فرم هر دو حرکت کامل بماند.", "mz-superset-chest"),
        detailedRow("mz-cb-4", "neutral-grip-dumbbell-bench-press", "3", "8–10", "۹۰–۱۲۰ ثانیه بعد از جفت", "۲-۰-۱", "سوپرست", "دست‌ها موازی و آرنج‌ها نزدیک‌تر به بدن؛ پس از این حرکت ۹۰ تا ۱۲۰ ثانیه استراحت کن. این دو حرکت یک دور سوپرست محسوب می‌شوند.", "mz-superset-chest"),
        detailedRow("mz-cb-5", "standard-grip-machine-chest-press", "3", "8–12", "۹۰ ثانیه", "۲-۰-۱", "رست‌پاز", "فقط ست آخر: ۱۰–۱۲ تکرار، ۱۵ ثانیه مکث، سپس ۳–۵ تکرار صحیح تکمیلی. رست‌پاز فقط یک مرحله انجام شود."),
        detailedRow("mz-cb-6", "standing-ez-bar-curl", "3", "8–10", "۹۰ ثانیه", "۱-۰-۳", "تکرار منفی", "آرنج‌ها کنار بدن ثابت؛ بالا بدون تاب‌دادن و پایین‌بردن وزنه در سه ثانیه. ست آخر RIR 1."),
        detailedRow("mz-cb-7", "incline-dumbbell-curl", "3", "10–12", "بدون استراحت", "۲-۱-۳", "سوپرست", "بازو پشت خط بدن و شانه ثابت؛ بعد از هر ست بدون استراحت جلو بازو چکشی ضربدری را اجرا کن.", "mz-superset-biceps"),
        detailedRow("mz-cb-8", "cross-body-hammer-curl", "3", "10–12 هر دست", "۷۵–۹۰ ثانیه بعد از جفت", "۲-۱-۲", "سوپرست", "دمبل به سمت شانه مخالف حرکت کند؛ مچ خنثی و آرنج ثابت. بعد از هر دو حرکت استراحت انجام شود.", "mz-superset-biceps"),
        detailedRow("mz-cb-9", "double-high-cable-biceps-curl", "3", "12–15", "۷۵ ثانیه", "۲-۲-۲", "رست‌پاز", "بازوها هم‌سطح شانه ثابت و در حالت فیگور دو ثانیه منقبض شوند. فقط ست آخر: ۱۲–۱۵ تکرار + ۱۵ ثانیه مکث + ۴–۶ تکرار."),
      ],
    },
    {
      id: "mz-legs",
      title: "روز ۲ — پا",
      focus: "چهارسر، همسترینگ، داخل ران و ساق؛ فرم صحیح در هاک و رومانیایی مقدم بر افزایش وزنه است.",
      exercises: [
        detailedRow("mz-leg-1", "leg-extension", "3", "12–15", "۷۵–۹۰ ثانیه", "۲-۱-۲", "دراپ‌ست", "فقط ست آخر دراپ دوبل: ۱۲–۱۵ تکرار، ۲۵٪ کاهش وزنه و ۸–۱۰ تکرار، دوباره کاهش وزنه و ادامه تا ناتوانی کنترل‌شده."),
        detailedRow("mz-leg-2", "hack-squat", "3", "8–10", "۲–۳ دقیقه", "۳-۰-۱", "عادی", "سه ثانیه پایین برو؛ زانوها هم‌جهت پنجه‌ها و کمر چسبیده به پد. ست آخر RIR 0–1؛ بدون قفل‌کردن زانو."),
        detailedRow("mz-leg-3", "leg-press-wide-stance", "3", "10–12", "بدون استراحت", "۳-۰-۱", "سوپرست", "جای پا باز و پنجه‌ها کمی رو به بیرون؛ پس از ست بدون استراحت پرس پا پا جمع اجرا شود.", "mz-superset-legpress"),
        detailedRow("mz-leg-4", "leg-press-narrow-stance", "3", "10–12", "۲ دقیقه بعد از جفت", "۳-۰-۱", "سوپرست", "پاها جمع و در عرض لگن؛ کف پا کامل روی صفحه و زانوها قفل نشوند. پس از این حرکت دو دقیقه استراحت کن.", "mz-superset-legpress"),
        detailedRow("mz-leg-5", "romanian-deadlift", "3", "8–10", "۲–۳ دقیقه", "۳-۱-۱", "تکرار منفی", "لگن عقب، ستون فقرات خنثی و میله نزدیک پاها؛ سه ثانیه پایین و یک مکث کوتاه در کشش همسترینگ. RIR 1."),
        detailedRow("mz-leg-6", "lying-leg-curl", "3", "10–12", "۹۰ ثانیه", "۲-۱-۳", "رست‌پاز", "لگن روی پد ثابت و برگشت وزنه سه ثانیه. فقط ست آخر: ۱۰–۱۲ تکرار + ۱۵ ثانیه مکث + ۳–۵ تکرار."),
        detailedRow("mz-leg-7", "seated-hip-adduction-machine", "3", "15–20", "۷۵ ثانیه", "۲-۲-۲", "دراپ‌ست", "بدن ثابت و دو ثانیه مکث در جمع‌کردن ران‌ها. ست آخر یک‌بار ۲۵–۳۰٪ وزنه کم و تا نزدیک ناتوانی ادامه داده شود."),
        detailedRow("mz-leg-8", "standing-calf-raise-machine", "4", "10–15", "۷۵–۹۰ ثانیه", "۲-۱-۲", "رست‌پاز", "دو ثانیه کشش پایین و یک ثانیه انقباض کامل بالا. فقط ست آخر: ۱۲–۱۵ تکرار + ۱۵ ثانیه مکث + تکرارهای صحیح تکمیلی."),
      ],
    },
    {
      id: "mz-back",
      title: "روز ۳ — زیربغل و پشت",
      focus: "عرض و ضخامت پشت؛ بارفیکس بدون رست‌پاز اجرا شود و تاب‌دادن بدن ممنوع است.",
      exercises: [
        detailedRow("mz-back-1", "pull-up", "3", "6–12", "۲ دقیقه", "کنترل‌شده", "عادی", "بدون رست‌پاز؛ هر ست با یک تکرار صحیح در ذخیره تمام شود. اگر کمتر از ۶ تکرار کامل شد از دستگاه کمکی استفاده کن."),
        detailedRow("mz-back-2", "wide-grip-lat-pulldown", "3", "8–12", "۹۰ ثانیه", "۲-۱-۳", "عادی", "سینه بالا، میله به بالای سینه و مکث یک ثانیه پایین؛ برگشت وزنه سه ثانیه و کشش کامل لت."),
        detailedRow("mz-back-3", "machine-high-row", "3", "8–10", "۹۰–۱۲۰ ثانیه", "۲-۱-۲", "رست‌پاز", "آرنج‌ها به عقب و پایین کشیده شوند و سینه روی پد بماند. فقط ست آخر: ۸–۱۰ تکرار + ۱۵ ثانیه مکث + ۳–۴ تکرار."),
        detailedRow("mz-back-4", "seated-bench-single-arm-cable-lat-pulldown", "3", "10–12 هر دست", "۶۰ ثانیه بعد از دو سمت", "۲-۱-۳", "عادی", "روی نیمکت بنشین؛ شانه را بالا نکش و آرنج را به سمت لگن بیاور. برگشت وزنه سه ثانیه با کشش کامل لت."),
        detailedRow("mz-back-5", "seated-cable-row", "3", "10–12", "بدون استراحت", "۲-۱-۲", "سوپرست", "کمر خنثی؛ دسته به شکم و کتف‌ها یک ثانیه جمع شوند. بلافاصله پول‌اور طناب اجرا شود.", "mz-superset-back"),
        detailedRow("mz-back-6", "rope-straight-arm-pulldown", "3", "12–15", "۹۰ ثانیه بعد از جفت", "۲-۱-۳", "سوپرست", "آرنج تقریباً ثابت و طناب در مسیر قوسی تا کنار ران پایین بیاید. ست آخر پس از جفت، ۲۵٪ کاهش وزنه و یک دراپ‌ست اجرا شود.", "mz-superset-back"),
        detailedRow("mz-back-7", "45-degree-back-extension", "2", "12–15", "۷۵ ثانیه", "۲-۱-۲", "عادی", "ستون فقرات خنثی و حرکت از مفصل ران؛ بدون پرتاب بدن و بدون بازکردن بیش‌ازحد کمر."),
      ],
    },
    {
      id: "mz-shoulders-triceps",
      title: "روز ۴ — سرشانه و پشت بازو",
      focus: "سرشانه میانی و خلفی، کول و پشت بازو؛ تکنیک‌های شدت فقط در ست مشخص‌شده اجرا شوند.",
      exercises: [
        detailedRow("mz-st-1", "machine-shoulder-press", "3", "6–10", "۲ دقیقه", "۳-۰-۱", "عادی", "سه ثانیه پایین و بالا آمدن کنترل‌شده؛ ست آخر RIR 0–1 و بدون قفل‌کردن آرنج."),
        detailedRow("mz-st-2", "seated-dumbbell-lateral-raise", "3", "12–15", "۷۵ ثانیه", "۲-۱-۲", "دراپ‌ست", "آرنج نرم و حرکت تا هم‌سطح شانه. فقط ست آخر دراپ دوبل: دو بار ۲۵٪ کاهش وزنه با حفظ فرم."),
        detailedRow("mz-st-3", "crossed-cable-lateral-raise", "3", "12–15", "۷۵ ثانیه", "۲-۱-۳", "رست‌پاز", "سیم‌ها از پایین و به‌صورت ضربدری؛ تنه ثابت و دست‌ها تا ارتفاع شانه. فقط ست آخر: ۱۲–۱۵ + ۱۵ ثانیه مکث + ۴–۶ تکرار."),
        detailedRow("mz-st-4", "prone-incline-dumbbell-rear-delt-raise", "3", "12–15", "بدون استراحت", "۲-۱-۳", "سوپرست", "سینه روی میز شیب‌دار ثابت و دمبل‌ها در قوس باز شوند؛ از تبدیل حرکت به قایقی جلوگیری کن. بلافاصله فیس پول اجرا شود.", "mz-superset-reardelt"),
        detailedRow("mz-st-5", "cable-face-pull", "3", "12–15", "۷۵–۹۰ ثانیه بعد از جفت", "۲-۱-۲", "سوپرست", "طناب به سمت صورت، آرنج‌ها باز و کتف‌ها جمع؛ یک ثانیه مکث. پس از این حرکت استراحت کن.", "mz-superset-reardelt"),
        detailedRow("mz-st-6", "smith-machine-shrug", "3", "10–15", "۹۰ ثانیه", "۲-۲-۲", "دراپ‌ست", "آرنج‌ها صاف؛ شانه‌ها مستقیم بالا و دو ثانیه مکث، بدون چرخاندن شانه. ست آخر یک‌بار ۲۵٪ کاهش وزنه."),
        detailedRow("mz-st-7", "smith-close-grip-bench-press", "3", "8–10", "۲ دقیقه", "۳-۰-۱", "عادی", "دست‌ها کمی جمع‌تر از عرض شانه و آرنج‌ها نزدیک بدن؛ ست‌ها با RIR 1 و بدون برخورد شدید میله به سینه."),
        detailedRow("mz-st-8", "straight-bar-triceps-pushdown", "3", "10–12", "بدون استراحت", "۲-۱-۳", "سوپرست", "آرنج‌ها کنار بدن ثابت و پایین حرکت یک ثانیه انقباض؛ بلافاصله پشت بازو طناب بالای سر اجرا شود.", "mz-superset-triceps"),
        detailedRow("mz-st-9", "overhead-rope-triceps-extension", "3", "12–15", "۷۵–۹۰ ثانیه بعد از جفت", "۲-۱-۳", "سوپرست", "بازوها کنار سر ثابت و کشش کامل سر بلند پشت بازو. فقط ست آخر یک‌بار ۲۵٪ کاهش وزنه و دراپ‌ست اجرا شود.", "mz-superset-triceps"),
        detailedRow("mz-st-10", "bench-triceps-dip", "2", "12–20", "۹۰ ثانیه", "۲-۰-۲", "عادی", "بدون رست‌پاز؛ هر ست با یک تکرار صحیح در ذخیره تمام شود. باسن نزدیک نیمکت و پایین‌رفتن تا حدود ۹۰ درجه آرنج؛ در صورت درد جلوی شانه حرکت حذف شود."),
      ],
    },
  ],
  nutritionGoals: { calories: "", protein: "", carbs: "", fat: "" },
  nutritionMeals: [],
};

export const DEFAULT_STATE: CoachState = {
  version: 1,
  activeClientId: "arshiya",
  customExercises: [],
  seededPrograms: [FAT_LOSS_58_SEED, MOHAMMAD_ZAREH_SEED],
  clients: [
    {
      id: "arshiya",
      name: "عرشیا",
      phone: "",
      goal: "عضله‌سازی مقدماتی",
      notes: "برنامه شروع تمرین Power Home",
    },
    FAT_LOSS_58_CLIENT,
    MOHAMMAD_ZAREH_CLIENT,
  ],
  plans: {
    arshiya: {
      title: "برنامه مقدماتی Power Home",
      workoutDays: [
        {
          id: "push",
          title: "روز ۱",
          focus: "PUSH — سینه، سرشانه، پشت بازو",
          exercises: [
            row("push-1", "machine-chest-press"),
            row("push-2", "incline-dumbbell-press"),
            row("push-3", "dumbbell-lateral-raise", "3", "12–15"),
            row("push-4", "rope-triceps-pushdown"),
            row("push-5", "dead-bug-legs", "3", "8 هر پا"),
            row("push-6", "chin-retraction", "3", "10"),
          ],
        },
        {
          id: "pull",
          title: "روز ۲",
          focus: "PULL — پشت، جلو بازو، اصلاحی",
          exercises: [
            row("pull-1", "neutral-lat-pulldown"),
            row("pull-2", "seated-cable-row"),
            row("pull-3", "cable-face-pull", "3", "12–15"),
            row("pull-4", "cable-curl"),
            row("pull-5", "bird-dog", "3", "8 هر سمت"),
            row("pull-6", "wall-slide", "3", "10"),
          ],
        },
        {
          id: "legs",
          title: "روز ۳",
          focus: "LEGS — پا، باسن، میان‌تنه",
          exercises: [
            row("legs-1", "leg-press", "4", "10–12", "90 ثانیه"),
            row("legs-2", "seated-leg-curl"),
            row("legs-3", "leg-extension"),
            row("legs-4", "glute-bridge", "3", "12–15"),
            row("legs-5", "supported-calf-raise", "4", "12–15"),
            row("legs-6", "kneeling-side-plank", "3", "20 ثانیه هر سمت"),
          ],
        },
      ],
      nutritionGoals: { calories: "", protein: "", carbs: "", fat: "" },
      nutritionMeals: [
        { id: "breakfast", title: "صبحانه", time: "08:00", foods: "", notes: "" },
        { id: "lunch", title: "ناهار", time: "13:30", foods: "", notes: "" },
        { id: "dinner", title: "شام", time: "20:30", foods: "", notes: "" },
      ],
    },
    [FAT_LOSS_58_CLIENT_ID]: FAT_LOSS_58_PLAN,
    [MOHAMMAD_ZAREH_CLIENT_ID]: MOHAMMAD_ZAREH_PLAN,
  },
};

export function blankPlan(): ClientPlan {
  return {
    cycleId:crypto.randomUUID(),
    title: "برنامه جدید",
    workoutDays: [{ id: `day-${Date.now()}`, title: "روز ۱", focus: "", exercises: [] }],
    nutritionGoals: { calories: "", protein: "", carbs: "", fat: "" },
    nutritionMeals: [],
    supplementItems: [],
    medicationItems: [],
  };
}
