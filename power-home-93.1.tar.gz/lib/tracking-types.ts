export type HabitGoals={waterMl:number;sleepHours:number;steps:number;adherence:number};
export type DailyLog=HabitGoals&{date:string;completedMeals:string[];mealsTotal?:number;notes:string};
export type ExerciseResult={id:string;exercise_id:string;exercise_name?:string;date:string;weight:number;reps:number;sets:number;notes:string};
export type WeeklyReport={id:string;client_id?:string;clientName?:string;week:string;date:string;weight:number;waist:number|null;sleepHours:number;energy:number;hunger:number;adherence:number;notes:string;reviewed_at:string|null;photos:{id:string;pose:string}[]};
export type ProgramTerm={id:string;client_id:string;clientName?:string;title:string;started_at:string;expires_at:string;duration_days:number;daysLeft:number;status:'active'|'near'|'expired'};
