"use client";

import {CoachTrackingPanel} from "@/components/coach-tracking-panel";
import {ProgramFollowupSettings} from "@/components/program-followup-settings";
import { coachDestination } from "@/lib/notification-target";
import {CoachCommandCenter,CoachMovementAnalysis,CoachFoodBank,CoachClub,CoachFinancePro} from "@/components/coach-command-center";
import {CoachLoginSettings} from "@/components/coach-login-settings";
import { CoachSms } from "@/components/coach-sms";
import { CoachPricing } from "@/components/coach-pricing";
import { usePackages } from "@/components/package-catalog";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Activity,
  ArrowDown,
  ArrowUp,
  BookImage,
  BellRing,
  Check,
  ChevronLeft,
  CircleUserRound,
  ClipboardList,
  Dumbbell,
  FileDown,
  CircleDollarSign,
  Gauge,
  GripVertical,
  History,
  ImagePlus,
  LayoutDashboard,
  LoaderCircle,
  LogOut,
  MessageCircle,
  Plus,
  Pill,
  Pencil,
  Search,
  Send,
  Smartphone,
  Sparkles,
  Syringe,
  Trash2,
  UsersRound,
  Utensils,
  WifiOff,
  X,
} from "lucide-react";

import { GraphicSectionIcon, type GraphicSectionIconName } from "@/components/graphic-section-icon";
import { PlanPrint } from "@/components/plan-print";
import { StudentAccessButton } from "@/components/student-access-button";
import { CoachApplications } from "@/components/coach-applications";
import { ClientHistory, fetchHistory } from "@/components/client-history";
import { ClientIntakeHistory } from "@/components/client-intake-history";
import { previousExerciseIds, type Checkin } from "@/lib/checkin-data";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import {
  blankPlan,
  DEFAULT_STATE,
  EXERCISES,
  FAT_LOSS_58_CLIENT,
  FAT_LOSS_58_CLIENT_ID,
  FAT_LOSS_58_PLAN,
  FAT_LOSS_58_SEED,
  MEHRAD_KIAN_PLAN,
  MEHRAD_KIAN_SEED,
  MOHAMMAD_ZAREH_CLIENT,
  MOHAMMAD_ZAREH_CLIENT_ID,
  MOHAMMAD_ZAREH_PLAN,
  MOHAMMAD_ZAREH_SEED,
  TECHNIQUES,
  type Client,
  type ClientPlan,
  type CoachState,
  type Exercise,
  type Meal,
  type MedicationPlanItem,
  type ProgramExercise,
  type SupplementPlanItem,
  type WorkoutDay,
} from "@/lib/coach-data";
import { SUPPLEMENTS, SUPPLEMENT_CATEGORIES } from "@/lib/supplement-data";
import { MEDICATIONS, MEDICATION_CATEGORIES } from "@/lib/medication-data";
import { BUILTIN_PROGRAM_TEMPLATES, cloneTemplatePlan, planAsCustomTemplate, type ProgramTemplate } from "@/lib/program-templates";
import {
  groupExerciseRows,
  normalizeLegacySupersets,
  setTechniqueWithSuperset,
} from "@/lib/supersets";
import { downloadPlanPdf } from "@/lib/pdf-export";
import { CoachAccounting, CoachChat, CoachHome, CoachNotifications, EMPTY_OVERVIEW, type Overview } from "@/components/coach-operations";


type View = "media" | "club" | "food" | "login-settings" | "sms" | "pricing" | "home" | "dashboard" | "applications" | "client" | "builder" | "programs" | "accounting" | "library" | "notifications" | "chat" | "profile";
type SaveStatus = "loading" | "saving" | "saved" | "local";
type PdfSection = "training" | "nutrition" | "supplements" | "medications";

const cloneDefaultState = () => JSON.parse(JSON.stringify(DEFAULT_STATE)) as CoachState;
const uid = (prefix: string) =>
  `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
const EXERCISE_CATEGORIES = ["همه", "سینه", "پشت", "سرشانه", "بازو", "پا", "میان‌تنه", "اصلاحی", "هوازی", "شخصی"];
const CATEGORY_LABELS: Record<string, string> = { پشت: "زیربغل و پشت", "میان‌تنه": "شکم", اصلاحی: "اصلاحی" };
const localIsoDate = () => {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
};

function normalizeState(value: unknown): CoachState | null {
  if (!value || typeof value !== "object") return null;
  const candidate = value as Partial<CoachState>;
  if (
    candidate.version !== 1 ||
    !Array.isArray(candidate.clients) ||
    !candidate.plans ||
    typeof candidate.activeClientId !== "string"
  ) return null;
  const state = candidate as CoachState;
  const seeds = [
    { seed: FAT_LOSS_58_SEED, clientId: FAT_LOSS_58_CLIENT_ID, client: FAT_LOSS_58_CLIENT, plan: FAT_LOSS_58_PLAN },
    { seed: MOHAMMAD_ZAREH_SEED, clientId: MOHAMMAD_ZAREH_CLIENT_ID, client: MOHAMMAD_ZAREH_CLIENT, plan: MOHAMMAD_ZAREH_PLAN },
  ];
  let clients = state.clients;
  let plans = state.plans;
  let seededPrograms = state.seededPrograms ?? [];
  const deletedClientIds = state.deletedClientIds ?? [];
  for (const item of seeds) {
    if (deletedClientIds.includes(item.clientId)) continue;
    if (seededPrograms.includes(item.seed)) continue;
    if (!clients.some((client) => client.id === item.clientId)) clients = [...clients, item.client];
    plans = { ...plans, [item.clientId]: item.plan };
    seededPrograms = [...seededPrograms, item.seed];
  }

  const mehrad = clients.find((client) =>
    client.phone.replace(/\D/g, "") === "09198321003" || client.name.includes("مهراد کیان"),
  );
  if (mehrad && !seededPrograms.includes(MEHRAD_KIAN_SEED)) {
    plans = { ...plans, [mehrad.id]: MEHRAD_KIAN_PLAN };
    seededPrograms = [...seededPrograms, MEHRAD_KIAN_SEED];
  }
  return {
    ...state,
    clients,
    seededPrograms,
    deletedClientIds,
    plans: Object.fromEntries(
      Object.entries(plans).map(([clientId, plan]) => [
        clientId,
        {
          ...plan,
          supplementItems: Array.isArray(plan.supplementItems) ? plan.supplementItems : [],
          medicationItems: Array.isArray(plan.medicationItems) ? plan.medicationItems : [],
          workoutDays: plan.workoutDays.map((day) => ({
            ...day,
            exercises: normalizeLegacySupersets(day.exercises),
          })),
        },
      ]),
    ),
    customExercises: Array.isArray(candidate.customExercises) ? candidate.customExercises : [],
    customProgramTemplates: Array.isArray(candidate.customProgramTemplates) ? candidate.customProgramTemplates : [],
    programUsage: candidate.programUsage && typeof candidate.programUsage === "object" ? candidate.programUsage : {},
    exerciseImageOverrides: candidate.exerciseImageOverrides && typeof candidate.exerciseImageOverrides === "object" ? candidate.exerciseImageOverrides : {},
  };
}

function NavIcon({ view }: { view: View }) {
  const graphic: Partial<Record<View,GraphicSectionIconName>> = {
    applications: "pdf", builder: "training", programs: "pdf",
    media:"training", club:"messages", food:"nutrition", "login-settings": "messages", sms: "messages", pricing: "billing", accounting: "billing", notifications: "notifications", chat: "messages",
  };
  const name=graphic[view];
  if(name)return <span className="coach-nav-icon-frame"><GraphicSectionIcon name={name} size={43} className="coach-nav-graphic"/></span>;
  const Icon=view==="home"?LayoutDashboard:view==="dashboard"?UsersRound:view==="library"?BookImage:CircleUserRound;
  return <span className={`coach-nav-icon-frame coach-nav-icon-${view}`}><Icon aria-hidden="true"/></span>;
}

const NAV_ITEMS: { id: View; label: string }[] = [
  { id: "home", label: "اتاق فرمان" },
  { id: "media", label: "آنالیز حرکات" },
  { id: "club", label: "جلسه‌ها و رویدادها" },
  { id: "food", label: "بانک تغذیه" },
  { id: "applications", label: "درخواست‌ها" },
  { id: "dashboard", label: "مدیریت شاگردها" },
  { id: "builder", label: "برنامه" },
  { id: "programs", label: "بانک برنامه‌ها" },
  { id: "accounting", label: "حسابداری" },
  { id: "pricing", label: "قیمت پکیج‌ها و برنامه‌ها" },
  { id: "login-settings", label: "تنظیمات ورود" },
  { id: "sms", label: "مدیریت پیامک" },
  { id: "library", label: "بانک حرکات" },
  { id: "notifications", label: "اعلان‌ها" },
  { id: "chat", label: "ارتباط با شاگرد" },
  { id: "profile", label: "راهنما" },
];

type CoachAppProps = {
  coachName: string;
};

export function CoachApp({ coachName }: CoachAppProps) {
  const { packages: PACKAGES, packageById } = usePackages();
  const [recordsByClient,setRecordsByClient]=useState<Record<string,Checkin[]>>({});
  const [historyStatus,setHistoryStatus]=useState("");
  const [printedRecord,setPrintedRecord]=useState<Checkin|null>(null);
  const [archiveEdit,setArchiveEdit]=useState<{clientId:string;id:string;plan:ClientPlan}|null>(null);
  const [state, setState] = useState<CoachState>(cloneDefaultState);
  const [view, setView] = useState<View>("home");
  const [overview,setOverview]=useState<Overview>(EMPTY_OVERVIEW);
  const [notificationApplication,setNotificationApplication]=useState("");
  const [notificationClient,setNotificationClient]=useState("");
  const onChatUnreadChange=useCallback((count:number)=>setOverview(current=>current.unreadChat===count?current:{...current,unreadChat:count}),[]);
  const openNotification=useCallback((url:string,push=true)=>{
    const target=coachDestination(url);if(!target)return;
    setView(target.view as View);setNotificationApplication(target.applicationId);setNotificationClient(target.clientId);
    if(target.clientId)setState(current=>current.clients.some(c=>c.id===target.clientId)?{...current,activeClientId:target.clientId}:current);
    if(push)window.history.pushState(null,"",url);
  },[]);

  const [programTab, setProgramTab] = useState("workout");
  const [activeDayId, setActiveDayId] = useState("push");
  const [saveStatus, setSaveStatus] = useState<SaveStatus>("loading");
  const [hydrated, setHydrated] = useState(false);
  useEffect(()=>{if(!hydrated)return;const load=()=>openNotification(window.location.pathname+window.location.search,false);load();window.addEventListener("popstate",load);return()=>window.removeEventListener("popstate",load)},[hydrated,openNotification]);
  const [clientDialogOpen, setClientDialogOpen] = useState(false);
  const [exerciseDialogOpen, setExerciseDialogOpen] = useState(false);
  const [customExerciseDialogOpen, setCustomExerciseDialogOpen] = useState(false);
  const [exerciseQuery, setExerciseQuery] = useState("");
  const [exerciseCategory, setExerciseCategory] = useState("سینه");
  const [exerciseToast, setExerciseToast] = useState<{ id: string; message: string; kind: "added" | "removed" } | null>(null);
  const exerciseToastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [libraryQuery, setLibraryQuery] = useState("");
  const [libraryCategory, setLibraryCategory] = useState("همه");
  const [supplementQuery, setSupplementQuery] = useState("");
  const [supplementCategory, setSupplementCategory] = useState("همه");
  const [medicationQuery, setMedicationQuery] = useState("");
  const [medicationCategory, setMedicationCategory] = useState("همه");
  const [medicationGroup, setMedicationGroup] = useState<"pct" | "bodybuilding">("pct");
  const [newClient, setNewClient] = useState({ name: "", phone: "", goal: "", notes: "", weight: 0, height: 0, waist: 0, arm: 0, packageId: "natural", listAmount: packageById("natural")?.price ?? 0, discountAmount: 0, receivedAmount: 0 });
  const [customExercise, setCustomExercise] = useState({ nameFa: "", nameEn: "", category: "شخصی" });
  const [customImage, setCustomImage] = useState<File | null>(null);
  const [customImagePreview, setCustomImagePreview] = useState("");
  const [customExerciseError, setCustomExerciseError] = useState("");
  const [customExerciseUploading, setCustomExerciseUploading] = useState(false);
  const [newPlanBusy, setNewPlanBusy] = useState(false);
  const [newPlanMessage, setNewPlanMessage] = useState("");
  const [deleteClientBusy, setDeleteClientBusy] = useState(false);
  const [deleteClientMessage, setDeleteClientMessage] = useState("");
  const [manualSaveMessage, setManualSaveMessage] = useState("");
  const [deliveryBusy,setDeliveryBusy]=useState(false);
  const [deliveryMessage,setDeliveryMessage]=useState("");
  const saveSequence = useRef(0);
  const saveTimeoutRef = useRef<number | null>(null);
  const lastSaveRevisionRef = useRef(0);

  const logoutCoach = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
    } finally {
      window.location.assign("/");
    }
  };

  const loadOverview = useCallback(async () => {
    try { const response=await fetch("/api/coach/overview",{cache:"no-store"}); if(response.ok)setOverview(await response.json()); } catch { /* dashboard remains available offline */ }
  },[]);
  useEffect(()=>{const first=window.setTimeout(()=>void loadOverview(),0);const timer=window.setInterval(loadOverview,30000);return()=>{window.clearTimeout(first);window.clearInterval(timer)}},[loadOverview]);

  useEffect(() => {
    const clearBadge = async () => {
      try {
        const badgeNavigator = navigator as Navigator & { clearAppBadge?: () => Promise<void> };
        await badgeNavigator.clearAppBadge?.();
        if ("serviceWorker" in navigator) {
          const registration = await navigator.serviceWorker.ready;
          registration.active?.postMessage({ type: "CLEAR_BADGE" });
        }
      } catch {
        // Badge support differs between browsers; the coach panel must still open normally.
      }
    };
    const onVisibilityChange = () => { if (document.visibilityState === "visible") void clearBadge(); };
    void clearBadge();
    document.addEventListener("visibilitychange", onVisibilityChange);
    return () => document.removeEventListener("visibilitychange", onVisibilityChange);
  }, []);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const response = await fetch("/api/state", { cache: "no-store" });
        if (!response.ok) throw new Error("remote unavailable");
        const data = (await response.json()) as { state?: unknown };
        const normalized = normalizeState(data.state);
        if (!cancelled && normalized) {
          setState(normalized);
          lastSaveRevisionRef.current = Math.max(lastSaveRevisionRef.current, Number(normalized.syncRevision ?? 0));
          setActiveDayId(normalized.plans[normalized.activeClientId]?.workoutDays[0]?.id ?? "");
        }
        setSaveStatus("saved");
      } catch {
        const cached = window.localStorage.getItem("power-home-coach-draft");
        if (cached) {
          try {
            const parsed = JSON.parse(cached) as unknown;
            const normalized = normalizeState(parsed);
            if (!cancelled && normalized) {
              setState(normalized);
              lastSaveRevisionRef.current = Math.max(lastSaveRevisionRef.current, Number(normalized.syncRevision ?? 0));
              setActiveDayId(normalized.plans[normalized.activeClientId]?.workoutDays[0]?.id ?? "");
            }
          } catch {
            // A broken temporary draft should not stop the app from opening.
          }
        }
        setSaveStatus("local");
      } finally {
        if (!cancelled) setHydrated(true);
      }
    };
    void load();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    window.localStorage.setItem("power-home-coach-draft", JSON.stringify(state));
    if (saveTimeoutRef.current !== null) window.clearTimeout(saveTimeoutRef.current);
    const sequence = ++saveSequence.current;
    saveTimeoutRef.current = window.setTimeout(async () => {
      setSaveStatus("saving");
      const revision = Math.max(Date.now(), lastSaveRevisionRef.current + 1);
      lastSaveRevisionRef.current = revision;
      try {
        const response = await fetch("/api/state", {
          method: "PUT",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ state: { ...state, syncRevision: revision }, revision }),
        });
        if (!response.ok) throw new Error("save failed");
        const result = await response.json() as { revision?: number };
        lastSaveRevisionRef.current = Math.max(lastSaveRevisionRef.current, Number(result.revision ?? revision));
        if (sequence === saveSequence.current) setSaveStatus("saved");
      } catch {
        if (sequence === saveSequence.current) setSaveStatus("local");
      } finally {
        if (sequence === saveSequence.current) saveTimeoutRef.current = null;
      }
    }, 800);
    return () => {
      if (saveTimeoutRef.current !== null) {
        window.clearTimeout(saveTimeoutRef.current);
        saveTimeoutRef.current = null;
      }
    };
  }, [state, hydrated]);

  const saveNow = async () => {
    if (archiveEdit) {
      setManualSaveMessage("");
      setSaveStatus("saving");
      try {
        const useIds=new Set(archiveEdit.plan.workoutDays.flatMap(day=>day.exercises.map(row=>row.exerciseId)));
        const exercises=[...EXERCISES,...(state.customExercises??[])].filter(exercise=>useIds.has(exercise.id));
        const response=await fetch("/api/checkins",{method:"PATCH",headers:{"content-type":"application/json"},body:JSON.stringify({id:archiveEdit.id,clientId:archiveEdit.clientId,plan:archiveEdit.plan,exercises})});
        const data=await response.json() as {error?:string};
        if(!response.ok)throw new Error(data.error||"ویرایش برنامه قبلی ذخیره نشد.");
        const records=await fetchHistory(archiveEdit.clientId);
        setRecordsByClient(current=>({...current,[archiveEdit.clientId]:records}));
        setArchiveEdit(null);setView("client");setSaveStatus("saved");setManualSaveMessage("نسخه قبلی بدون تغییر شماره یا ساخت برنامه جدید ویرایش شد.");
        return true;
      } catch(error) {
        setSaveStatus("saved");
        setManualSaveMessage(error instanceof Error?error.message:"ویرایش قبلی ذخیره نشد.");
        return false;
      }
    }
    if (!hydrated || saveStatus === "loading") return false;
    if (saveTimeoutRef.current !== null) {
      window.clearTimeout(saveTimeoutRef.current);
      saveTimeoutRef.current = null;
    }
    const sequence = ++saveSequence.current;
    const revision = Math.max(Date.now(), lastSaveRevisionRef.current + 1);
    lastSaveRevisionRef.current = revision;
    setManualSaveMessage("");
    setSaveStatus("saving");
    window.localStorage.setItem("power-home-coach-draft", JSON.stringify(state));
    try {
      const response = await fetch("/api/state", {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ state: { ...state, syncRevision: revision }, revision }),
      });
      if (!response.ok) throw new Error("save failed");
      const result = await response.json() as { revision?: number };
      lastSaveRevisionRef.current = Math.max(lastSaveRevisionRef.current, Number(result.revision ?? revision));
      if (sequence === saveSequence.current) {
        setSaveStatus("saved");
        setManualSaveMessage("برنامه ثبت شد و روی سرور ذخیره شد.");
      }
      return true;
    } catch {
      if (sequence === saveSequence.current) {
        setSaveStatus("local");
        setManualSaveMessage("اتصال سرور برقرار نشد؛ نسخه روی همین گوشی ذخیره شده است.");
      }
      return false;
    }
  };

  const activeClient =
    state.clients.find((client) => client.id === state.activeClientId) ?? state.clients[0];
  const activePlan = activeClient
    ? archiveEdit?.clientId === activeClient.id ? archiveEdit.plan : state.plans[activeClient.id] ?? blankPlan()
    : blankPlan();
  const activeDay =
    activePlan.workoutDays.find((day) => day.id === activeDayId) ??
    activePlan.workoutDays[0];

  const previousIds=previousExerciseIds(recordsByClient[activeClient?.id]??[]);
  useEffect(()=>{
    if(!hydrated||!activeClient)return;
    let cancelled=false;setHistoryStatus("در حال بررسی برنامهٔ قبلی…");
    fetchHistory(activeClient.id).then(records=>{if(!cancelled){setRecordsByClient(current=>({...current,[activeClient.id]:records}));setHistoryStatus(records.length?"تیک سبز: در آخرین دورهٔ ثبت‌شده بوده است.":"هنوز برنامهٔ بایگانی‌شده‌ای برای این شاگرد نداریم.");}}).catch(()=>{if(!cancelled)setHistoryStatus("برای نمایش حرکات قبلی، بخش سوابق را باز کنید و ورود و اتصال را بررسی کنید.");});
    return()=>{cancelled=true;};
  },[activeClient?.id,hydrated]);
  useEffect(()=>{
    if(!printedRecord)return;
    let cancelled=false;
    const download=async()=>{
      await new Promise<void>((resolve)=>requestAnimationFrame(()=>resolve()));
      if(cancelled)return;
      try{await downloadPlanPdf("coach-plan-pdf",`برنامه ${printedRecord.client.name}`);}
      catch(error){window.alert(error instanceof Error?error.message:"ساخت PDF انجام نشد.");}
      finally{if(!cancelled)setPrintedRecord(null);}
    };
    void download();return()=>{cancelled=true;};
  },[printedRecord]);

  const totalExercises = activePlan.workoutDays.reduce(
    (sum, day) => sum + day.exercises.length,
    0,
  );

  const downloadActivePlan = async () => {
    try {
      await downloadPlanPdf("coach-plan-pdf", `برنامه کامل ${activeClient.name}`);
    } catch (error) {
      window.alert(error instanceof Error ? error.message : "ساخت PDF انجام نشد.");
    }
  };

  const downloadActivePlanSection = async (section: PdfSection, label: string) => {
    try {
      await downloadPlanPdf(`coach-plan-pdf-${section}`, `${label} - ${activeClient.name}`);
    } catch (error) {
      window.alert(error instanceof Error ? error.message : "ساخت PDF انجام نشد.");
    }
  };

  const deliverActivePlan = async () => {
    if (archiveEdit) {setDeliveryMessage("این برنامهٔ قبلی در حالت ویرایش است؛ ابتدا ذخیره کن.");return;}
    if (!activeClient || deliveryBusy) return;
    if (!window.confirm(`برنامه برای «${activeClient.name}» ارسال شود؟ بعد از ارسال برای شاگرد قابل مشاهده و نوتیفیکیشن ارسال می‌شود.`)) return;
    setDeliveryBusy(true);setDeliveryMessage("");
    try{
      const saved=await saveNow();
      if(!saved) throw new Error("ابتدا ذخیره برنامه روی سرور باید موفق شود.");
      const response=await fetch("/api/program-delivery",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({clientId:activeClient.id})});
      const data=await response.json() as {error?:string;baselineCreated?:boolean};
      if(!response.ok)throw new Error(data.error??"ارسال برنامه انجام نشد.");
      setDeliveryMessage(data.baselineCreated?"برنامه ارسال شد؛ اطلاعات اولیه هم خودکار به نمودار پیشرفت اضافه شد.":"برنامه ارسال شد و نوتیفیکیشن شاگرد ثبت شد.");
      void loadOverview();
      try{const records=await fetchHistory(activeClient.id);setRecordsByClient(current=>({...current,[activeClient.id]:records}));}catch{/* delivery already succeeded */}
    }catch(error){setDeliveryMessage(error instanceof Error?error.message:"ارسال برنامه انجام نشد.");}
    finally{setDeliveryBusy(false);}
  };

  const updatePlan = (updater: (plan: ClientPlan) => ClientPlan) => {
    if (!activeClient) return;
    if(archiveEdit?.clientId===activeClient.id){setArchiveEdit(current=>current?{...current,plan:updater(current.plan)}:current);return;}
    setState((current) => {
      const currentPlan = current.plans[activeClient.id] ?? blankPlan();
      return {
        ...current,
        plans: { ...current.plans, [activeClient.id]: updater(currentPlan) },
      };
    });
  };

  const changeActiveClient = (id: string) => {
    setArchiveEdit(null);
    setState((current) => ({ ...current, activeClientId: id }));
    setActiveDayId(state.plans[id]?.workoutDays[0]?.id ?? "");
    setNewPlanMessage("");
    setManualSaveMessage("");
  };

  const deleteActiveClient = async () => {
    if (!activeClient || deleteClientBusy) return;
    if (!window.confirm(`شاگرد «${activeClient.name}» و همه درخواست‌ها، عکس‌ها و برنامه‌های او حذف شود؟ این کار قابل بازگشت نیست.`)) return;
    setDeleteClientBusy(true);
    setDeleteClientMessage("");
    try {
      const response = await fetch(`/api/clients/${encodeURIComponent(activeClient.id)}`, { method: "DELETE" });
      const result = await response.json() as { error?: string };
      if (!response.ok) throw new Error(result.error ?? "حذف شاگرد انجام نشد.");
      setState((current) => {
        const clients = current.clients.filter((item) => item.id !== activeClient.id);
        const plans = { ...current.plans };
        delete plans[activeClient.id];
        return {
          ...current,
          clients,
          plans,
          activeClientId: clients[0].id,
          deletedClientIds: [...new Set([...(current.deletedClientIds ?? []), activeClient.id])],
        };
      });
      setRecordsByClient((current) => {
        const next = { ...current };
        delete next[activeClient.id];
        return next;
      });
      setView("dashboard");
    } catch (error) {
      setDeleteClientMessage(error instanceof Error ? error.message : "حذف شاگرد انجام نشد.");
    } finally {
      setDeleteClientBusy(false);
    }
  };

  const deleteCurrentProgram = async () => {
    if(!activeClient)return;
    if(!window.confirm(`برنامه جاری «${activeClient.name}» حذف شود؟ تنها این برنامه حذف می‌شود و دوره‌های بایگانی‌شده دست‌نخورده می‌مانند.`))throw new Error("حذف لغو شد.");
    const clientId=activeClient.id;
    const nextPlan=blankPlan();
    const nextState={...state,plans:{...state.plans,[clientId]:nextPlan}};
    if(saveTimeoutRef.current!==null){window.clearTimeout(saveTimeoutRef.current);saveTimeoutRef.current=null;}
    const sequence=++saveSequence.current;
    const revision=Math.max(Date.now(),lastSaveRevisionRef.current+1);
    lastSaveRevisionRef.current=revision;
    const response=await fetch("/api/state",{method:"PUT",headers:{"content-type":"application/json"},body:JSON.stringify({state:{...nextState,syncRevision:revision},revision})});
    if(!response.ok)throw new Error("ذخیره حذف روی سرور انجام نشد؛ برنامه فعلی حفظ شد.");
    const removed=await fetch("/api/program-delivery",{method:"DELETE",headers:{"content-type":"application/json"},body:JSON.stringify({clientId})});
    if(!removed.ok)throw new Error("برنامه خالی ذخیره شد اما پاکسازی وضعیت ارسال انجام نشد. صفحه را تازه کنید.");
    setState(nextState);setActiveDayId(nextPlan.workoutDays[0]?.id??"");setSaveStatus("saved");
    setManualSaveMessage("برنامه جاری حذف شد؛ برنامه‌های بایگانی‌شده باقی ماندند.");
  };

  const startNewProgram = async () => {
    if (archiveEdit) {setNewPlanMessage("اول ویرایش برنامه قبلی را ذخیره یا لغو کنید.");return;}
    if (!activeClient || newPlanBusy) return;
    const hasPlanContent =
      activePlan.workoutDays.some((day) => day.exercises.length > 0) ||
      activePlan.nutritionMeals.length > 0 ||
      (activePlan.supplementItems?.length ?? 0) > 0 ||
      (activePlan.medicationItems?.length ?? 0) > 0 ||
      Object.values(activePlan.nutritionGoals).some(Boolean);

    setNewPlanBusy(true);
    setNewPlanMessage(hasPlanContent ? "در حال بررسی ثبت برنامه قبلی…" : "");
    try {
      let shouldArchive=false;
      if(hasPlanContent){
        const response=await fetch(`/api/program-delivery?clientId=${encodeURIComponent(activeClient.id)}`,{cache:"no-store"});
        if(!response.ok)throw new Error("وضعیت ارسال برنامه معلوم نیست؛ برنامه فعلی حفظ شد.");
        const result=await response.json() as {delivered:boolean};
        shouldArchive=result.delivered;
        if(!shouldArchive&&!window.confirm("این برنامه هنوز ارسال نهایی نشده و پیش‌نویس است. بدون افزودن به سوابق کنار گذاشته و برنامه خالی بسازیم؟"))return;
      }
      if (shouldArchive) {
        if (saveStatus !== "saved") throw new Error("ابتدا صبر کنید تا برنامه آنلاین ذخیره شود.");
        const used = new Set(activePlan.workoutDays.flatMap((day) => day.exercises.map((item) => item.exerciseId)));
        const response = await fetch("/api/checkins", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            id: crypto.randomUUID(),
            clientId: activeClient.id,
            date: localIsoDate(),
            measurements: { weight: null, height: null, waist: null, arm: null },
            notes: "ذخیره خودکار هنگام ساخت برنامه جدید",
            client: activeClient,
            plan: activePlan,
            exercises: allExercises.filter((exercise) => used.has(exercise.id)),
          }),
        });
        const result = (await response.json()) as { error?: string };
        if (!response.ok) throw new Error(result.error ?? "ذخیره برنامه قبلی انجام نشد.");
        const records = await fetchHistory(activeClient.id);
        setRecordsByClient((current) => ({ ...current, [activeClient.id]: records }));
        setHistoryStatus("برنامه قبلی ذخیره شد؛ تیک سبز حرکات دوره قبل را نشان می‌دهد.");
      }

      const nextPlan = blankPlan();
      setState((current) => ({
        ...current,
        plans: { ...current.plans, [activeClient.id]: nextPlan },
      }));
      setActiveDayId(nextPlan.workoutDays[0].id);
      setProgramTab("workout");
      setView("builder");
      setNewPlanMessage(shouldArchive ? "برنامه قبلی ثبت‌شده بایگانی شد و برنامه خالی آماده است." : "برنامه خالی آماده است؛ پیش‌نویس وارد سوابق نشد.");
    } catch (error) {
      setNewPlanMessage(error instanceof Error ? error.message : "ساخت برنامه جدید انجام نشد.");
    } finally {
      setNewPlanBusy(false);
    }
  };

  const updateDay = (dayId: string, patch: Partial<WorkoutDay>) => {
    updatePlan((plan) => ({
      ...plan,
      workoutDays: plan.workoutDays.map((day) =>
        day.id === dayId ? { ...day, ...patch } : day,
      ),
    }));
  };

  const updateExercise = (rowId: string, patch: Partial<ProgramExercise>) => {
    if (!activeDay) return;
    updateDay(activeDay.id, {
      exercises: activeDay.exercises.map((item) =>
        item.rowId === rowId ? { ...item, ...patch } : item,
      ),
    });
  };

  const setExerciseTechnique = (rowId: string, technique: string) => {
    if (!activeDay) return;
    updateDay(activeDay.id, {
      exercises: setTechniqueWithSuperset(
        activeDay.exercises,
        rowId,
        technique,
        uid("superset"),
      ),
    });
  };

  const addExercise = (exerciseId: string) => {
    if (!activeDay) return;
    const newRow: ProgramExercise = {
      rowId: uid("exercise"),
      exerciseId,
      sets: "3",
      reps: "10–12",
      rest: "75 ثانیه",
      tempo: "کنترل‌شده",
      technique: "عادی",
      notes: "",
    };
    updateDay(activeDay.id, { exercises: [...activeDay.exercises, newRow] });
  };

  const showExerciseToast = (id: string, message: string, kind: "added" | "removed") => {
    if (exerciseToastTimer.current) clearTimeout(exerciseToastTimer.current);
    setExerciseToast({ id, message, kind });
    exerciseToastTimer.current = setTimeout(() => setExerciseToast(null), 1600);
  };

  const toggleExercise = (exercise: Exercise) => {
    if (!activeDay) return;
    const existing = activeDay.exercises.find((item) => item.exerciseId === exercise.id);
    if (existing) {
      removeExercise(existing.rowId);
      showExerciseToast(exercise.id, `${exercise.nameFa} از برنامه حذف شد`, "removed");
      return;
    }
    addExercise(exercise.id);
    showExerciseToast(exercise.id, `${exercise.nameFa} به برنامه اضافه شد`, "added");
  };

  const removeExercise = (rowId: string) => {
    if (!activeDay) return;
    const removedGroupId = activeDay.exercises.find((item) => item.rowId === rowId)?.supersetId;
    updateDay(activeDay.id, {
      exercises: activeDay.exercises
        .filter((item) => item.rowId !== rowId)
        .map((item) =>
          removedGroupId && item.supersetId === removedGroupId
            ? {
                ...item,
                technique: item.technique === "سوپرست" ? "عادی" : item.technique,
                supersetId: undefined,
              }
            : item,
        ),
    });
  };

  const moveExercise = (index: number, direction: -1 | 1) => {
    if (!activeDay) return;
    const row = activeDay.exercises[index];
    if (!row) return;
    const units = groupExerciseRows(activeDay.exercises);
    const unitIndex = units.findIndex((unit) =>
      unit.items.some((item) => item.rowId === row.rowId),
    );
    const destination = unitIndex + direction;
    if (unitIndex < 0 || destination < 0 || destination >= units.length) return;
    const reordered = [...units];
    [reordered[unitIndex], reordered[destination]] = [
      reordered[destination],
      reordered[unitIndex],
    ];
    updateDay(activeDay.id, { exercises: reordered.flatMap((unit) => unit.items) });
  };

  const reorderExerciseUnit = (sourceUnitId: string, targetUnitId: string) => {
    if (!activeDay || sourceUnitId === targetUnitId) return;
    const units = groupExerciseRows(activeDay.exercises);
    const sourceIndex = units.findIndex((unit) => unit.id === sourceUnitId);
    const targetIndex = units.findIndex((unit) => unit.id === targetUnitId);
    if (sourceIndex < 0 || targetIndex < 0 || sourceIndex === targetIndex) return;
    const reordered = [...units];
    const [moved] = reordered.splice(sourceIndex, 1);
    const destination = Math.min(targetIndex, reordered.length);
    reordered.splice(destination, 0, moved);
    updateDay(activeDay.id, { exercises: reordered.flatMap((unit) => unit.items) });
  };

  const updateClientProfile = async (clientId: string, patch: Pick<Client,"name"|"phone"|"goal"|"notes"|"initialMeasurements">) => {
    const response = await fetch(`/api/clients/${encodeURIComponent(clientId)}`, {
      method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify(patch),
    });
    const data = await response.json() as { client?: Client; error?: string };
    if (!response.ok || !data.client) throw new Error(data.error ?? "ویرایش مشخصات شاگرد انجام نشد.");
    setState((current) => ({ ...current, clients: current.clients.map((item) => item.id === clientId ? data.client! : item) }));
    return data.client;
  };

  const createClient = async () => {
    if (!newClient.name.trim()) return;
    const id = uid("client");
    const {packageId,listAmount,discountAmount,receivedAmount,weight,height,waist,arm,...clientFields}=newClient;
    const selectedPackage=packageById(packageId);
    const client: Client = { id, ...clientFields, name: newClient.name.trim(), goal: newClient.goal.trim() || selectedPackage?.name || "", initialMeasurements:{weight:weight>0?weight:null,height:height>0?height:null,waist:waist>0?waist:null,arm:arm>0?arm:null} };
    const plan = blankPlan();
    setState((current) => ({
      ...current,
      activeClientId: id,
      clients: [...current.clients, client],
      plans: { ...current.plans, [id]: plan },
    }));
    try{
      const response=await fetch("/api/billing",{method:"PUT",headers:{"content-type":"application/json"},body:JSON.stringify({clientId:id,applicationId:null,packageId,packageName:selectedPackage?.name,listAmount:Math.max(0,Math.round(listAmount)),discountAmount:Math.max(0,Math.round(discountAmount)),receivedAmount:Math.max(0,Math.round(receivedAmount))})});
      if(!response.ok){const data=await response.json() as {error?:string};throw new Error(data.error??"ثبت حسابداری انجام نشد.");}
    }catch(error){window.alert(`پرونده ساخته شد، اما حسابداری ذخیره نشد: ${error instanceof Error?error.message:"خطا"}`);}
    setActiveDayId(plan.workoutDays[0].id);
    setNewClient({ name: "", phone: "", goal: "", notes: "", weight: 0, height: 0, waist: 0, arm: 0, packageId: "natural", listAmount: packageById("natural")?.price ?? 0, discountAmount: 0, receivedAmount: 0 });
    setClientDialogOpen(false);
    setView("builder");
    void loadOverview();
  };

  const addDay = () => {
    const id = uid("day");
    updatePlan((plan) => ({
      ...plan,
      workoutDays: [
        ...plan.workoutDays,
        { id, title: `روز ${plan.workoutDays.length + 1}`, focus: "", exercises: [] },
      ],
    }));
    setActiveDayId(id);
  };

  const removeDay = () => {
    if (!activeDay || activePlan.workoutDays.length === 1) return;
    const next = activePlan.workoutDays.filter((day) => day.id !== activeDay.id);
    updatePlan((plan) => ({ ...plan, workoutDays: next }));
    setActiveDayId(next[0].id);
  };

  const updateMeal = (mealId: string, patch: Partial<Meal>) => {
    updatePlan((plan) => ({
      ...plan,
      nutritionMeals: plan.nutritionMeals.map((meal) =>
        meal.id === mealId ? { ...meal, ...patch } : meal,
      ),
    }));
  };

  const addMeal = () => {
    updatePlan((plan) => ({
      ...plan,
      nutritionMeals: [
        ...plan.nutritionMeals,
        { id: uid("meal"), title: `وعده ${plan.nutritionMeals.length + 1}`, time: "", foods: "", notes: "" },
      ],
    }));
  };

  const addSupplement = (supplementId: string) => {
    const definition = SUPPLEMENTS.find((item) => item.id === supplementId);
    if (!definition) return;
    updatePlan((plan) => {
      const selected = plan.supplementItems ?? [];
      const existing = selected.find((item) => item.supplementId === definition.id);
      if (existing) return { ...plan, supplementItems: selected.filter((item) => item.id !== existing.id) };
      return {
        ...plan,
        supplementItems: [...selected, { id: uid("supplement"), supplementId: definition.id, name: definition.nameFa, dose: "", timing: "", frequency: "روزانه", notes: "" }],
      };
    });
  };

  const addCustomSupplement = () => {
    updatePlan((plan) => ({
      ...plan,
      supplementItems: [
        ...(plan.supplementItems ?? []),
        { id: uid("supplement"), supplementId: "custom", name: "مکمل شخصی", dose: "", timing: "", frequency: "روزانه", notes: "" },
      ],
    }));
  };

  const updateSupplement = (id: string, patch: Partial<SupplementPlanItem>) => {
    updatePlan((plan) => ({ ...plan, supplementItems: (plan.supplementItems ?? []).map((item) => item.id === id ? { ...item, ...patch } : item) }));
  };

  const removeSupplement = (id: string) => {
    updatePlan((plan) => ({ ...plan, supplementItems: (plan.supplementItems ?? []).filter((item) => item.id !== id) }));
  };

  const addMedication = (medicationId: string) => {
    const definition = MEDICATIONS.find((item) => item.id === medicationId);
    if (!definition) return;
    updatePlan((plan) => {
      const selected = plan.medicationItems ?? [];
      const existing = selected.find((item) => item.medicationId === definition.id);
      if (existing) return { ...plan, medicationItems: selected.filter((item) => item.id !== existing.id) };
      return {
        ...plan,
        medicationItems: [...selected, { id: uid("medication"), medicationId: definition.id, name: definition.nameFa, group: definition.group, dose: "", timing: "", frequency: "", startWeek: "1", endWeek: "", notes: "" }],
      };
    });
  };

  const addCustomMedication = () => {
    updatePlan((plan) => ({
      ...plan,
      medicationItems: [
        ...(plan.medicationItems ?? []),
        { id: uid("medication"), medicationId: "custom", name: "داروی شخصی", group: medicationGroup, dose: "", timing: "", frequency: "", startWeek: "1", endWeek: "", notes: "" },
      ],
    }));
  };

  const updateMedication = (id: string, patch: Partial<MedicationPlanItem>) => {
    updatePlan((plan) => ({ ...plan, medicationItems: (plan.medicationItems ?? []).map((item) => item.id === id ? { ...item, ...patch } : item) }));
  };

  const removeMedication = (id: string) => {
    updatePlan((plan) => ({ ...plan, medicationItems: (plan.medicationItems ?? []).filter((item) => item.id !== id) }));
  };

  const chooseCustomImage = (file?: File) => {
    if (customImagePreview) URL.revokeObjectURL(customImagePreview);
    setCustomImage(file ?? null);
    setCustomImagePreview(file ? URL.createObjectURL(file) : "");
    setCustomExerciseError("");
  };

  const createCustomExercise = async () => {
    if (!customExercise.nameFa.trim() || !customImage) {
      setCustomExerciseError("نام فارسی و عکس حرکت را وارد کنید.");
      return;
    }
    setCustomExerciseUploading(true);
    setCustomExerciseError("");
    try {
      const form = new FormData();
      form.append("image", customImage);
      const response = await fetch("/api/exercise-images", { method: "POST", body: form });
      const result = (await response.json()) as { url?: string; error?: string };
      if (!response.ok || !result.url) throw new Error(result.error ?? "ذخیره عکس انجام نشد.");
      const exercise: Exercise = {
        id: uid("custom"),
        nameFa: customExercise.nameFa.trim(),
        nameEn: customExercise.nameEn.trim(),
        category: customExercise.category.trim() || "شخصی",
        image: result.url,
        custom: true,
      };
      setState((current) => ({
        ...current,
        customExercises: [...(current.customExercises ?? []), exercise],
      }));
      chooseCustomImage();
      setCustomExercise({ nameFa: "", nameEn: "", category: "شخصی" });
      setCustomExerciseDialogOpen(false);
      setView("library");
    } catch (error) {
      setCustomExerciseError(error instanceof Error ? error.message : "ذخیره حرکت انجام نشد.");
    } finally {
      setCustomExerciseUploading(false);
    }
  };

  const allExercises = useMemo(() => {
    const overrides = state.exerciseImageOverrides ?? {};
    return [...EXERCISES, ...(state.customExercises ?? [])].map((exercise) => ({
      ...exercise,
      image: overrides[exercise.id] ?? exercise.image,
    }));
  }, [state.customExercises, state.exerciseImageOverrides]);

  const allProgramTemplates = useMemo(
    () => [...BUILTIN_PROGRAM_TEMPLATES, ...(state.customProgramTemplates ?? [])],
    [state.customProgramTemplates],
  );

  const replaceExerciseImage = async (exerciseId: string, file: File) => {
    const form = new FormData();
    form.append("image", file);
    const response = await fetch("/api/exercise-images", { method: "POST", body: form });
    const result = await response.json() as { url?: string; error?: string };
    if (!response.ok || !result.url) throw new Error(result.error ?? "ذخیره عکس انجام نشد.");
    setState((current) => ({
      ...current,
      exerciseImageOverrides: { ...(current.exerciseImageOverrides ?? {}), [exerciseId]: result.url! },
    }));
  };

  const saveCurrentPlanAsTemplate = () => {
    const existingNumbers = allProgramTemplates.map((item) => item.number);
    const nextNumber = Math.max(490, ...existingNumbers) + 1;
    const title = window.prompt("نام این قالب برنامه را وارد کنید:", activePlan.title || `برنامه شخصی ${nextNumber}`);
    if (title === null) return;
    const template = planAsCustomTemplate(activePlan, nextNumber, title);
    setState((current) => ({ ...current, customProgramTemplates:[...(current.customProgramTemplates ?? []), template] }));
    window.alert(`برنامه شماره ${nextNumber.toLocaleString("fa-IR")} در بانک برنامه‌ها ذخیره شد.`);
  };

  const applyProgramTemplate = (template: ProgramTemplate, clientId: string, alreadyUsed=false) => {
    const target = state.clients.find((client) => client.id === clientId);
    if (!target) return;
    const duplicate=alreadyUsed;
    if (duplicate && !window.confirm(`برنامه ${template.number.toLocaleString("fa-IR")} قبلاً برای ${target.name} استفاده شده است. دوباره کپی شود؟`)) return;
    const existing = state.plans[clientId];
    const hasExisting = Boolean(existing && (existing.workoutDays.some((day) => day.exercises.length) || existing.nutritionMeals.length || (existing.supplementItems?.length ?? 0) || (existing.medicationItems?.length ?? 0)));
    if (hasExisting && !window.confirm(`برنامه فعلی ${target.name} با این قالب جایگزین شود؟`)) return;
    const nextPlan = cloneTemplatePlan(template);
    setState((current) => ({
      ...current,
      activeClientId: clientId,
      plans: { ...current.plans, [clientId]: nextPlan },

    }));
    setActiveDayId(nextPlan.workoutDays[0]?.id ?? "");
    setProgramTab("workout");
    setView("builder");
  };

  const deleteCustomProgramTemplate = (templateId: string) => {
    setState((current) => ({ ...current, customProgramTemplates:(current.customProgramTemplates ?? []).filter((item) => item.id !== templateId) }));
  };

  const filteredExercises = useMemo(() => {
    const query = exerciseQuery.trim().toLowerCase();
    return allExercises.filter((exercise) => {
      const matchesQuery = `${exercise.nameFa} ${exercise.nameEn} ${exercise.category}`.toLowerCase().includes(query);
      const matchesCategory = exerciseCategory === "همه" || exercise.category === exerciseCategory;
      return matchesQuery && matchesCategory;
    });
  }, [allExercises, exerciseCategory, exerciseQuery]);

  const categories = ["همه", ...Array.from(new Set(allExercises.map((exercise) => exercise.category)))];
  const selectedExerciseIds = new Set(activeDay?.exercises.map((item) => item.exerciseId) ?? []);
  const visibleLibraryExercises = allExercises.filter((exercise) => {
    const query = libraryQuery.trim().toLowerCase();
    const matchesText = `${exercise.nameFa} ${exercise.nameEn}`.toLowerCase().includes(query);
    return matchesText && (libraryCategory === "همه" || exercise.category === libraryCategory);
  });

  if (!activeClient) return null;

  return (
    <>
      <div className="app-shell min-h-dvh bg-background text-foreground" dir="rtl">
        <div className="mx-auto flex min-h-dvh max-w-[1600px]">
          <aside className="hidden w-64 shrink-0 border-l border-white/8 bg-[#08090a] p-5 lg:flex lg:flex-col">
            <Brand />
            <nav className="mt-10 space-y-2">
              {NAV_ITEMS.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {setNotificationClient("");setView(item.id)}}
                  className={`flex w-full items-center gap-3 rounded-xl px-4 py-3 text-sm transition ${
                    view === item.id
                      ? "bg-amber-500 text-white shadow-[0_12px_35px_rgba(174,184,196,.22)]"
                      : "text-zinc-400 hover:bg-white/5 hover:text-white"
                  }`}
                >
                  <NavIcon view={item.id} />
                  <span className="coach-nav-label">{item.label}</span>
                  {item.id === "applications" && overview.unreadNotifications > 0 && <NavBadge value={overview.unreadNotifications}/>}
                  {item.id === "notifications" && overview.unreadNotifications > 0 && <NavBadge value={overview.unreadNotifications}/>}
                  {item.id === "chat" && overview.unreadChat > 0 && <NavBadge value={overview.unreadChat}/>}
                </button>
              ))}
            </nav>
            <div className="mt-auto rounded-2xl border border-white/8 bg-white/[.035] p-4">
              <p className="text-xs text-zinc-500">مربی</p>
              <p className="mt-1 text-sm font-semibold text-zinc-100">{coachName}</p>
              <SaveIndicator status={saveStatus} />
              <Button type="button" variant="outline" size="sm" onClick={logoutCoach} className="mt-4 w-full border-white/10 bg-white/[.025] text-zinc-300 hover:border-amber-500/40 hover:text-white"><LogOut /> خروج از پنل</Button>
            </div>
          </aside>

          <main className="min-w-0 flex-1 pb-40 lg:pb-8">
            <MobileHeader status={saveStatus} onLogout={logoutCoach} />
            <div className="mx-auto max-w-6xl px-4 py-5 sm:px-6 lg:px-9 lg:py-8">
              {view === "home" && <><CoachCommandCenter onOpenClient={(id)=>{changeActiveClient(id);setView("client")}} onView={(view)=>{setNotificationClient("");setView(view as View)}}/><CoachHome
                overview={overview}
                onOpenApplications={()=>setView("applications")}
                onOpenClient={(id)=>{changeActiveClient(id);setView("client")}}
                onOpenPricing={()=>setView("pricing")}
                onOpenAccounting={()=>setView("accounting")}
                onOpenBuilder={(tab)=>{setProgramTab(tab);setView("builder")}}
                onOpenChat={()=>setView("chat")}
                onOpenNotifications={()=>setView("notifications")}
                onDownloadPdf={downloadActivePlan}
              /></>}
              {view === "dashboard" && (
                <Dashboard
                  activeClient={activeClient}
                  clients={state.clients}
                  plan={activePlan}
                  totalExercises={totalExercises}
                  historyCount={recordsByClient[activeClient.id]?.filter((record)=>record.recordType!=="baseline").length ?? 0}
                  onChangeClient={changeActiveClient}
                  onOpenProfile={() => setView("client")}
                  onNewClient={() => {setNewClient(current=>({...current,listAmount:packageById(current.packageId)?.price??current.listAmount}));setClientDialogOpen(true)}}
                  onNewProgram={startNewProgram}
                  newPlanBusy={newPlanBusy}
                  newPlanMessage={newPlanMessage}
                  onOpenBuilder={(tab) => {
                    setProgramTab(tab);
                    setView("builder");
                  }}
                  onPrint={downloadActivePlan}
                />
              )}

              {view === "applications" && (
                <CoachApplications initialApplicationId={notificationApplication} onOpenClient={(clientId) => {
                  changeActiveClient(clientId);
                  setView("client");
                }} />
              )}

              {view === "programs" && <ProgramBank templates={allProgramTemplates} clients={state.clients} activeClientId={activeClient.id} usage={{}} currentProgramNumber={activePlan.coachProgramNumber} onApply={applyProgramTemplate} onSaveCurrent={saveCurrentPlanAsTemplate} onDeleteCustom={deleteCustomProgramTemplate}/>}

              {view === "media" && <CoachMovementAnalysis clientId={notificationClient||undefined}/>}
              {view === "club" && <CoachClub/>}
              {view === "food" && <CoachFoodBank/>}
              {view === "login-settings" && <CoachLoginSettings/>}
              {view === "sms" && <CoachSms/>}
              {view === "pricing" && <CoachPricing/>}
              {view === "accounting" && <><CoachFinancePro/><CoachAccounting overview={overview} onUpdated={()=>void loadOverview()}/></>}
              {view === "notifications" && <CoachNotifications overview={overview} onOpen={openNotification} onRead={(ids)=>setOverview(current=>({...current,unreadNotifications:ids?Math.max(0,current.unreadNotifications-current.notifications.filter(item=>ids.includes(item.id)&&!item.read_at).length):0,notifications:current.notifications.map(item=>!ids||ids.includes(item.id)?{...item,read_at:item.read_at??new Date().toISOString()}:item)}))}/>}
              {view === "chat" && <CoachChat initialClientId={notificationClient} onUnreadChange={onChatUnreadChange}/>}

              {view === "client" && (
                <><CoachTrackingPanel key={activeClient.id} clientId={activeClient.id}/><ClientProfile
                  client={activeClient}
                  plan={activePlan}
                  historyCount={recordsByClient[activeClient.id]?.filter((record)=>record.recordType!=="baseline").length ?? 0}
                  programNumbers={state.programUsage?.[activeClient.id] ?? (activePlan.coachProgramNumber ? [activePlan.coachProgramNumber] : [])}
                  onBack={() => setView("dashboard")}
                  onNewProgram={startNewProgram}
                  newPlanBusy={newPlanBusy}
                  deleteClientBusy={deleteClientBusy}
                  deleteClientMessage={deleteClientMessage}
                  onDeleteClient={deleteActiveClient}
                  onUpdateClient={updateClientProfile}
                  onOpenBuilder={(tab) => { setProgramTab(tab); setView("builder"); }}
                  history={
                    <ClientHistory
                      key={activeClient.id}
                      client={activeClient}
                      plan={activePlan}
                      exercises={allExercises}
                      records={recordsByClient[activeClient.id] ?? []}
                      onRecords={(records) => {
                        setRecordsByClient((current) => ({ ...current, [activeClient.id]: records }));
                        setHistoryStatus(records.length ? "تیک سبز: در آخرین دورهٔ ثبت‌شده بوده است." : "هنوز دوره‌ای ثبت نشده است.");
                      }}
                      onPrint={setPrintedRecord}
                      onEditProgram={(record)=>{setArchiveEdit({clientId:activeClient.id,id:record.id,plan:structuredClone(record.plan)});setActiveDayId(record.plan.workoutDays[0]?.id??"");setProgramTab("workout");setView("builder");}}
                      onEditCurrent={()=>{setArchiveEdit(null);setProgramTab("workout");setView("builder");}}
                      onDeleteCurrent={deleteCurrentProgram}
                      online={saveStatus === "saved" && hydrated}
                      intake={(programNumber)=><ClientIntakeHistory clientId={activeClient.id} programNumber={programNumber} embedded/>}
                    />
                  }
                /></>
              )}

              {view === "builder" && (
                <><div>{archiveEdit&&<div className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-white/30 bg-white/10 p-3 text-sm text-white"><span>در حال ویرایش برنامه بایگانی‌شده — ذخیره تغییرات روی همان برنامه انجام می‌شود.</span><Button variant="outline" onClick={()=>{setArchiveEdit(null);setView("client");}}>انصراف از ویرایش</Button></div>}</div>
                <Builder
                  state={state}
                  exercises={allExercises}
                  activeClient={activeClient}
                  plan={activePlan}
                  activeDay={activeDay}
                  activeDayId={activeDayId}
                  programTab={programTab}
                  setProgramTab={setProgramTab}
                  onChangeClient={changeActiveClient}
                  onNewClient={() => {setNewClient(current=>({...current,listAmount:packageById(current.packageId)?.price??current.listAmount}));setClientDialogOpen(true)}}
                  onNewProgram={startNewProgram}
                  newPlanBusy={newPlanBusy}
                  newPlanMessage={newPlanMessage}
                  saveStatus={saveStatus}
                  saveMessage={manualSaveMessage}
                  onSaveNow={async () => { await saveNow(); }}
                  onDeliver={deliverActivePlan}
                  deliveryBusy={deliveryBusy}
                  deliveryMessage={deliveryMessage}
                  onPrint={downloadActivePlan}
                  onPrintSection={downloadActivePlanSection}
                  onUpdatePlan={updatePlan}
                  onSetDay={setActiveDayId}
                  onAddDay={addDay}
                  onRemoveDay={removeDay}
                  onUpdateDay={updateDay}
                  onOpenExercisePicker={() => setExerciseDialogOpen(true)}
                  onUpdateExercise={updateExercise}
                  onSetExerciseTechnique={setExerciseTechnique}
                  onRemoveExercise={removeExercise}
                  onMoveExercise={moveExercise}
                  onReorderExerciseUnit={reorderExerciseUnit}
                  onAddMeal={addMeal}
                  onUpdateMeal={updateMeal}
                  supplementQuery={supplementQuery}
                  supplementCategory={supplementCategory}
                  onSupplementQuery={setSupplementQuery}
                  onSupplementCategory={setSupplementCategory}
                  onAddSupplement={addSupplement}
                  onAddCustomSupplement={addCustomSupplement}
                  onUpdateSupplement={updateSupplement}
                  onRemoveSupplement={removeSupplement}
                  medicationQuery={medicationQuery}
                  medicationCategory={medicationCategory}
                  medicationGroup={medicationGroup}
                  onMedicationQuery={setMedicationQuery}
                  onMedicationCategory={setMedicationCategory}
                  onMedicationGroup={setMedicationGroup}
                  onAddMedication={addMedication}
                  onAddCustomMedication={addCustomMedication}
                  onUpdateMedication={updateMedication}
                  onRemoveMedication={removeMedication}
                />
                </>
              )}

              {view === "library" && (
                <ExerciseLibrary
                  query={libraryQuery}
                  category={libraryCategory}
                  categories={categories}
                  exercises={visibleLibraryExercises}
                  totalCount={allExercises.length}
                  onQuery={setLibraryQuery}
                  onCategory={setLibraryCategory}
                  onNewCustom={() => setCustomExerciseDialogOpen(true)}
                  onReplaceImage={replaceExerciseImage}
                  onAdd={(exerciseId) => {
                    addExercise(exerciseId);
                    setView("builder");
                    setProgramTab("workout");
                  }}
                />
              )}

              {view === "profile" && <Guide coachName={coachName} status={saveStatus} />}
            </div>
          </main>
        </div>

        <nav className="coach-mobile-nav fixed inset-x-3 bottom-[max(1.25rem,env(safe-area-inset-bottom))] z-40 overflow-x-auto rounded-2xl border border-white/10 bg-[#090a0c]/95 px-2 py-2 shadow-[0_18px_55px_rgba(0,0,0,.65)] backdrop-blur-xl lg:hidden">
          <div className="flex min-w-max items-stretch">
            {NAV_ITEMS.map((item) => (
              <button
                key={item.id}
                onClick={() => {setNotificationClient("");setView(item.id)}}
                className={`relative flex min-h-[76px] w-[104px] shrink-0 touch-manipulation flex-col items-center justify-center gap-1 rounded-xl px-2 py-2 text-[11px] transition ${
                  view === item.id ? "text-amber-400" : "text-zinc-500"
                }`}
              >
                <NavIcon view={item.id} />
                <span className="coach-nav-label">{item.label}</span>
                {item.id === "notifications" && overview.unreadNotifications > 0 && <NavBadge value={overview.unreadNotifications}/>}
                {item.id === "chat" && overview.unreadChat > 0 && <NavBadge value={overview.unreadChat}/>}
              </button>
            ))}
          </div>
        </nav>
      </div>

      <Dialog open={clientDialogOpen} onOpenChange={setClientDialogOpen}>
        <DialogContent className="border-white/10 bg-[#111316] text-zinc-100 sm:max-w-md" dir="rtl">
          <DialogHeader className="text-right sm:text-right">
            <DialogTitle>افزودن شاگرد جدید</DialogTitle>
            <DialogDescription>اطلاعات پایه را وارد کنید؛ برنامه را بعداً کامل می‌کنید.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-3">
            <Field label="نام و نام خانوادگی">
              <Input value={newClient.name} onChange={(event) => setNewClient({ ...newClient, name: event.target.value })} placeholder="مثلاً علی رضایی" autoFocus />
            </Field>
            <Field label="شماره تماس">
              <Input value={newClient.phone} onChange={(event) => setNewClient({ ...newClient, phone: event.target.value })} placeholder="09..." inputMode="tel" />
            </Field>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 sm:col-span-1">
              <Field label="وزن شروع"><Input type="number" inputMode="decimal" min={0} value={newClient.weight||""} onChange={(event)=>setNewClient({...newClient,weight:Number(event.target.value)||0})} placeholder="kg"/></Field>
              <Field label="قد شروع"><Input type="number" inputMode="decimal" min={0} value={newClient.height||""} onChange={(event)=>setNewClient({...newClient,height:Number(event.target.value)||0})} placeholder="cm"/></Field>
              <Field label="دور کمر"><Input type="number" inputMode="decimal" min={0} value={newClient.waist||""} onChange={(event)=>setNewClient({...newClient,waist:Number(event.target.value)||0})} placeholder="cm"/></Field>
              <Field label="دور بازو"><Input type="number" inputMode="decimal" min={0} value={newClient.arm||""} onChange={(event)=>setNewClient({...newClient,arm:Number(event.target.value)||0})} placeholder="cm"/></Field>
            </div>
            <Field label="پکیج شاگرد">
              <Select value={newClient.packageId} onValueChange={(value)=>{const selected=packageById(value);setNewClient({...newClient,packageId:value,listAmount:selected?.price??newClient.listAmount});}}><SelectTrigger className="h-11"><SelectValue/></SelectTrigger><SelectContent>{PACKAGES.map(item=><SelectItem key={item.id} value={item.id}>{item.name}</SelectItem>)}</SelectContent></Select>
            </Field>
            <div className="grid grid-cols-3 gap-2">
              <Field label="مبلغ"><Input type="number" inputMode="numeric" min={0} value={newClient.listAmount} onChange={e=>setNewClient({...newClient,listAmount:Number(e.target.value)||0})}/></Field>
              <Field label="تخفیف"><Input type="number" inputMode="numeric" min={0} value={newClient.discountAmount} onChange={e=>setNewClient({...newClient,discountAmount:Number(e.target.value)||0})}/></Field>
              <Field label="دریافتی"><Input type="number" inputMode="numeric" min={0} value={newClient.receivedAmount} onChange={e=>setNewClient({...newClient,receivedAmount:Number(e.target.value)||0})}/></Field>
            </div>
            <Field label="هدف">
              <Input value={newClient.goal} onChange={(event) => setNewClient({ ...newClient, goal: event.target.value })} placeholder="عضله‌سازی، کاهش وزن..." />
            </Field>
            <Field label="یادداشت مربی">
              <Textarea value={newClient.notes} onChange={(event) => setNewClient({ ...newClient, notes: event.target.value })} placeholder="آسیب‌دیدگی، محدودیت یا نکته مهم" />
            </Field>
          </div>
          <Button onClick={()=>void createClient()} disabled={!newClient.name.trim()} className="h-11 bg-amber-500 hover:bg-amber-500">
            <Plus /> ساخت پرونده شاگرد
          </Button>
        </DialogContent>
      </Dialog>

      <Dialog open={exerciseDialogOpen} onOpenChange={setExerciseDialogOpen}>
        <DialogContent className="max-h-[90dvh] overflow-hidden border-white/10 bg-[#111316] p-0 text-zinc-100 sm:max-w-3xl" dir="rtl">
          <DialogHeader className="border-b border-white/8 p-5 text-right sm:text-right">
            <DialogTitle>افزودن حرکت به {activeDay?.title ?? "جلسه"}</DialogTitle>
            <DialogDescription>از بانک فعلی انتخاب کنید؛ می‌توانید چند حرکت پشت سر هم اضافه کنید.</DialogDescription>
            <p className="text-sm text-zinc-400">{historyStatus}</p>
          </DialogHeader>
          <div className="grid gap-2 px-5 sm:grid-cols-[1fr_auto]">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 size-4 -translate-y-1/2 text-zinc-500" />
              <Input className="h-12 rounded-xl pr-10" value={exerciseQuery} onChange={(event) => setExerciseQuery(event.target.value)} placeholder="جست‌وجوی نام حرکت یا عضله..." />
            </div>
            <Button variant="outline" className="h-11 border-white/10" onClick={() => { setExerciseDialogOpen(false); setCustomExerciseDialogOpen(true); }}><ImagePlus /> حرکت شخصی</Button>
          </div>
          <div className="flex gap-2 overflow-x-auto px-5 pb-1 scrollbar-none">
            {EXERCISE_CATEGORIES.filter((category) => category === "همه" || allExercises.some((exercise) => exercise.category === category)).map((category) => (
              <button
                key={category}
                onClick={() => setExerciseCategory(category)}
                className={`min-h-11 shrink-0 touch-manipulation rounded-full border px-4 py-2 text-xs font-semibold transition ${exerciseCategory === category ? "border-amber-500 bg-amber-500 text-white" : "border-white/10 bg-white/[.025] text-zinc-400"}`}
              >
                {CATEGORY_LABELS[category] ?? category}
              </button>
            ))}
          </div>
          <div className="grid max-h-[62dvh] gap-3 overflow-y-auto px-5 pb-5 sm:grid-cols-2">
            {filteredExercises.map((exercise) => {
              const selected = selectedExerciseIds.has(exercise.id);
              return (
                <div key={exercise.id} className={`relative flex items-center gap-3 rounded-2xl border p-2.5 transition ${selected ? "border-emerald-500/70 bg-emerald-500/[.09] ring-1 ring-emerald-500/20" : "border-white/8 bg-white/[.035]"}`}>
                  {selected && <span className="absolute -top-2 right-3 inline-flex items-center gap-1 rounded-full bg-emerald-500 px-2 py-1 text-[9px] font-black text-black shadow-lg"><Check className="size-3"/> اضافه شده</span>}
                  <img src={exercise.image} alt={exercise.nameFa} loading="lazy" className="h-20 w-24 shrink-0 rounded-xl bg-white object-contain" />
                  <div className="min-w-0 flex-1">
                    <h3 className="truncate text-sm font-semibold">{exercise.nameFa}</h3>
                    {previousIds.has(exercise.id)&&<Badge className="mt-1 bg-emerald-900 text-emerald-100"><Check className="size-3"/>در برنامهٔ قبلی</Badge>}
                    <p className="mt-1 truncate text-[11px] text-zinc-500" dir="ltr">{exercise.nameEn}</p>
                    <Badge variant="outline" className="mt-2 border-white/10 text-[10px] text-zinc-400">{exercise.category}</Badge>
                  </div>
                  <Button size="icon-lg" onClick={() => toggleExercise(exercise)} className={`size-11 shrink-0 touch-manipulation rounded-full transition ${selected ? "bg-emerald-500 text-black hover:bg-emerald-400" : "bg-amber-500 hover:bg-amber-500"}`} aria-label={selected ? `حذف ${exercise.nameFa} از برنامه` : `افزودن ${exercise.nameFa}`}>
                    {selected ? <Check /> : <Plus />}
                  </Button>
                </div>
              );
            })}
            {filteredExercises.length === 0 && (
              <p className="col-span-full py-10 text-center text-sm text-zinc-500">حرکتی در این دسته پیدا نشد.</p>
            )}
          </div>
          {exerciseToast && (
            <div key={`${exerciseToast.id}-${exerciseToast.kind}`} className={`pointer-events-none absolute bottom-[max(1rem,env(safe-area-inset-bottom))] left-1/2 z-[70] flex -translate-x-1/2 items-center gap-2 whitespace-nowrap rounded-full border px-4 py-2.5 text-xs font-bold shadow-2xl backdrop-blur ${exerciseToast.kind === "added" ? "border-emerald-400/40 bg-emerald-500/95 text-black" : "border-white/15 bg-zinc-900/95 text-zinc-100"}`} role="status" aria-live="polite">
              {exerciseToast.kind === "added" ? <Check className="size-4" /> : <X className="size-4" />}
              {exerciseToast.message}
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={customExerciseDialogOpen} onOpenChange={setCustomExerciseDialogOpen}>
        <DialogContent className="border-white/10 bg-[#111316] text-zinc-100 sm:max-w-md" dir="rtl">
          <DialogHeader className="text-right sm:text-right">
            <DialogTitle>افزودن حرکت شخصی</DialogTitle>
            <DialogDescription>یک عکس واضح و نام حرکت را ثبت کنید تا همیشه در بانک حرکات بماند.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-3">
            <label className="relative grid min-h-44 cursor-pointer place-items-center overflow-hidden rounded-2xl border border-dashed border-white/15 bg-white/[.025] text-center transition hover:border-amber-500/40">
              {customImagePreview ? (
                <img src={customImagePreview} alt="پیش‌نمایش حرکت" className="h-48 w-full bg-white object-contain" />
              ) : (
                <div className="p-5">
                  <ImagePlus className="mx-auto size-8 text-amber-400" />
                  <p className="mt-3 text-sm font-semibold text-zinc-200">انتخاب عکس حرکت</p>
                  <p className="mt-1 text-xs text-zinc-500">JPG، PNG یا WebP تا ۸ مگابایت</p>
                </div>
              )}
              <input type="file" accept="image/jpeg,image/png,image/webp" className="sr-only" onChange={(event) => chooseCustomImage(event.target.files?.[0])} />
            </label>
            <Field label="نام فارسی حرکت">
              <Input value={customExercise.nameFa} onChange={(event) => setCustomExercise({ ...customExercise, nameFa: event.target.value })} placeholder="مثلاً پرس بالا سینه هالتر" />
            </Field>
            <Field label="نام انگلیسی (اختیاری)">
              <Input value={customExercise.nameEn} onChange={(event) => setCustomExercise({ ...customExercise, nameEn: event.target.value })} placeholder="Incline Barbell Press" dir="ltr" />
            </Field>
            <Field label="گروه عضلانی">
              <Input value={customExercise.category} onChange={(event) => setCustomExercise({ ...customExercise, category: event.target.value })} placeholder="سینه، پا، پشت..." />
            </Field>
          </div>
          <div className="min-h-5 text-xs text-amber-300" role="alert">{customExerciseError}</div>
          <Button onClick={createCustomExercise} disabled={customExerciseUploading || !customExercise.nameFa.trim() || !customImage} className="h-11 bg-amber-500 hover:bg-amber-500">
            {customExerciseUploading ? <LoaderCircle className="animate-spin" /> : <ImagePlus />}
            ذخیره در بانک حرکات
          </Button>
        </DialogContent>
      </Dialog>

      <PlanPrint elementId="coach-plan-pdf" client={printedRecord?.client??activeClient} plan={printedRecord?.plan??activePlan} exercises={printedRecord?.exercises??allExercises} />
      <PlanPrint elementId="coach-plan-pdf-training" client={activeClient} plan={activePlan} exercises={allExercises} section="training" />
      <PlanPrint elementId="coach-plan-pdf-nutrition" client={activeClient} plan={activePlan} exercises={allExercises} section="nutrition" />
      <PlanPrint elementId="coach-plan-pdf-supplements" client={activeClient} plan={activePlan} exercises={allExercises} section="supplements" />
      <PlanPrint elementId="coach-plan-pdf-medications" client={activeClient} plan={activePlan} exercises={allExercises} section="medications" />
    </>
  );
}

function Brand() {
  return (
    <div className="flex items-center gap-3" dir="ltr">
      <img src="/brand/armin.png" alt="" className="h-12 w-9 object-contain" />
      <div>
        <p className="text-sm font-black tracking-[.16em] text-white">ARMIN SORKHEI</p>
        <p className="mt-0.5 text-xs text-zinc-400" dir="rtl">پنل آرمین سرخه‌ای</p>
      </div>
    </div>
  );
}

function NavBadge({value}:{value:number}) { return <span className="mr-auto grid min-w-5 place-items-center rounded-full bg-amber-500 px-1.5 py-0.5 text-[10px] font-black text-white">{value.toLocaleString("fa-IR")}</span>; }

function MobileHeader({ status, onLogout }: { status: SaveStatus; onLogout: () => void }) {
  return (
    <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-white/8 bg-[#090a0c]/90 px-4 backdrop-blur-xl lg:hidden">
      <Brand />
      <div className="flex items-center gap-2">
        <SaveIndicator status={status} compact />
        <Button type="button" variant="outline" size="sm" onClick={onLogout} className="h-9 border-white/10 bg-white/5 px-2.5 text-xs text-zinc-300" aria-label="خروج از پنل مربی"><LogOut className="size-4" /><span className="hidden min-[390px]:inline">خروج</span></Button>
      </div>
    </header>
  );
}

function SaveIndicator({ status, compact = false }: { status: SaveStatus; compact?: boolean }) {
  const config = {
    loading: { icon: LoaderCircle, label: "در حال بارگذاری", className: "text-zinc-500" },
    saving: { icon: LoaderCircle, label: "در حال ذخیره", className: "text-amber-400" },
    saved: { icon: Check, label: "ذخیره شد", className: "text-emerald-400" },
    local: { icon: WifiOff, label: "پیش‌نویس دستگاه", className: "text-zinc-400" },
  }[status];
  const Icon = config.icon;
  return (
    <div className={`mt-3 flex items-center gap-1.5 text-[11px] ${config.className} ${compact ? "mt-0" : ""}`}>
      <Icon className={`size-3.5 ${status === "loading" || status === "saving" ? "animate-spin" : ""}`} />
      {!compact && config.label}
    </div>
  );
}

function PageTitle({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: React.ReactNode }) {
  return (
    <div className="mb-6 flex items-end justify-between gap-4">
      <div>
        <p className="mb-2 text-[11px] font-bold tracking-[.2em] text-amber-400">{eyebrow}</p>
        <h1 className="text-2xl font-black tracking-tight text-white sm:text-3xl">{title}</h1>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-zinc-500">{description}</p>
      </div>
      {action}
    </div>
  );
}

type DashboardProps = {
  activeClient: Client;
  clients: Client[];
  plan: ClientPlan;
  totalExercises: number;
  historyCount: number;
  onChangeClient: (id: string) => void;
  onOpenProfile: () => void;
  onNewClient: () => void;
  onNewProgram: () => void;
  newPlanBusy: boolean;
  newPlanMessage: string;
  onOpenBuilder: (tab: string) => void;
  onPrint: () => void;
};

function Dashboard({ activeClient, clients, plan, totalExercises, historyCount, onChangeClient, onOpenProfile, onNewClient, onNewProgram, newPlanBusy, newPlanMessage, onOpenBuilder, onPrint }: DashboardProps) {
  const [clientQuery, setClientQuery] = useState("");
  const visibleClients = clients.filter((client) =>
    `${client.name} ${client.phone} ${client.goal}`
      .toLowerCase()
      .includes(clientQuery.trim().toLowerCase()),
  );

  return (
    <div>
      <PageTitle eyebrow="CLIENT MANAGEMENT" title="مدیریت شاگردها" description="شاگرد را پیدا یا ثبت کن؛ بعد برنامه تمرینی، غذایی و سوابق همان شاگرد در دسترس است." action={<Button onClick={onNewClient} className="hidden bg-amber-500 hover:bg-amber-500 sm:flex"><Plus /> ثبت شاگرد</Button>} />

      <section className="mb-5 rounded-3xl border border-white/8 bg-card p-5">
        <div className="mb-4 flex items-center justify-between gap-3">
          <div>
            <h2 className="font-bold text-white">انتخاب شاگرد</h2>
            <p className="mt-1 text-xs text-zinc-500">نام شاگرد را جست‌وجو کنید یا شاگرد جدید بسازید.</p>
          </div>
          <Button onClick={onNewClient} className="shrink-0 bg-amber-500 hover:bg-amber-500"><Plus /> ثبت شاگرد</Button>
        </div>
        <div className="relative mb-3">
          <Search className="absolute right-3 top-1/2 size-4 -translate-y-1/2 text-zinc-500" />
          <Input
            value={clientQuery}
            onChange={(event) => setClientQuery(event.target.value)}
            className="h-11 border-white/10 bg-black/20 pr-10"
            placeholder="جست‌وجوی نام، شماره یا هدف شاگرد..."
          />
        </div>
        <div className="max-h-64 space-y-2 overflow-y-auto scrollbar-thin">
          {visibleClients.map((client) => (
            <button key={client.id} onClick={() => { onChangeClient(client.id); onOpenProfile(); }} className={`flex w-full items-center gap-3 rounded-2xl border p-3 text-right transition ${client.id === activeClient.id ? "border-amber-500/50 bg-amber-500/10" : "border-white/6 bg-white/[.025] hover:bg-white/[.05]"}`}>
              <div className={`grid size-11 shrink-0 place-items-center rounded-xl text-sm font-black ${client.id === activeClient.id ? "bg-amber-500 text-white" : "bg-zinc-800 text-zinc-200"}`}>{client.name.slice(0, 1)}</div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold text-zinc-100">{client.name}</p>
                <p className="mt-1 truncate text-xs text-zinc-500">{client.goal || "بدون هدف ثبت‌شده"}</p>
              </div>
              {client.id === activeClient.id ? <Badge className="bg-amber-500 text-white">انتخاب‌شده</Badge> : <ChevronLeft className="size-4 text-zinc-600" />}
            </button>
          ))}
          {visibleClients.length === 0 && (
            <div className="rounded-2xl border border-dashed border-white/10 p-5 text-center">
              <p className="text-sm text-zinc-400">شاگردی با این مشخصات پیدا نشد.</p>
              <Button onClick={onNewClient} variant="outline" className="mt-3 border-white/10"><Plus /> ثبت همین شاگرد</Button>
            </div>
          )}
        </div>
      </section>

      <section className="relative overflow-hidden rounded-[28px] border border-white/8 bg-[radial-gradient(circle_at_10%_0%,rgba(174,184,196,.22),transparent_35%),linear-gradient(135deg,#17191d,#0d0e10)] p-5 sm:p-7">
        <div className="relative z-10 max-w-xl">
          <Badge className="bg-amber-500 text-white">شاگرد فعال</Badge>
          <h2 className="mt-4 text-3xl font-black text-white sm:text-4xl">{activeClient.name}</h2>
          <p className="mt-2 text-sm text-zinc-400">{activeClient.goal || "هدف هنوز ثبت نشده"}</p>
          <p className="mt-1 text-xs text-zinc-600">{plan.title}</p>{plan.coachProgramNumber&&<Badge className="mt-3 bg-emerald-600/15 text-emerald-400">شماره داخلی برنامه: {plan.coachProgramNumber.toLocaleString("fa-IR")}</Badge>}
          <div className="mt-6 flex flex-wrap gap-2">
            <Button onClick={onNewProgram} disabled={newPlanBusy} className="h-11 bg-amber-500 hover:bg-amber-500">
              {newPlanBusy ? <LoaderCircle className="animate-spin" /> : <Plus />} برنامه جدید
            </Button>
            <Button onClick={() => onOpenBuilder("workout")} variant="outline" className="h-11 border-white/10 bg-white/5"><Dumbbell /> ادامه برنامه فعلی</Button>
            <Button onClick={() => onOpenBuilder("nutrition")} variant="outline" className="h-11 border-white/10 bg-white/5"><Utensils /> برنامه غذایی</Button>
            <Button onClick={() => onOpenBuilder("supplements")} variant="outline" className="h-11 border-white/10 bg-white/5"><Pill /> برنامه مکمل</Button><Button onClick={() => onOpenBuilder("medications")} variant="outline" className="h-11 border-white/10 bg-white/5"><Syringe /> دارو / PCT</Button>
            <Button onClick={onOpenProfile} variant="outline" className="h-11 border-white/10 bg-white/5"><CircleUserRound /> پروفایل شاگرد</Button>
            <StudentAccessButton client={activeClient} />
          </div>
          <button
            type="button"
            onClick={onOpenProfile}
            className="mt-3 flex w-full max-w-xl items-center gap-3 rounded-2xl border border-white/10 bg-black/20 p-3 text-right transition hover:border-amber-500/35 hover:bg-amber-500/[.06]"
          >
            <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-amber-500/10 text-amber-400">
              <History className="size-5" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-sm font-bold text-white">پروفایل، سوابق و پیشرفت</span>
              <span className="mt-1 block text-xs text-zinc-500">
                {historyCount > 0 ? `${historyCount.toLocaleString("fa-IR")} برنامه ذخیره‌شده` : "هنوز برنامه‌ای در سوابق نیست"}
              </span>
            </span>
            {historyCount > 0 && <Badge className="bg-amber-500 text-white">{historyCount.toLocaleString("fa-IR")}</Badge>}
            <ChevronLeft className="size-4 shrink-0 text-zinc-500" />
          </button>
          {newPlanMessage && <p className="mt-3 text-xs text-zinc-300" role="status">{newPlanMessage}</p>}
        </div>
        <Dumbbell className="absolute -bottom-10 -left-8 size-56 rotate-[-18deg] text-white/[.035]" />
      </section>

      <section className="mt-4 grid grid-cols-3 gap-3">
        <Stat icon={<UsersRound />} value={String(clients.length)} label="شاگرد" />
        <Stat icon={<Activity />} value={String(plan.workoutDays.length)} label="روز تمرین" />
        <Stat icon={<Gauge />} value={String(totalExercises)} label="حرکت" />
      </section>

      <section className="mt-7">
        <div className="rounded-3xl border border-white/8 bg-card p-5">
          <h2 className="font-bold text-white">مسیر سریع</h2>
          <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <QuickAction icon={<Sparkles />} title="برنامه جدید" subtitle="ذخیره قبلی و شروع از صفحه خالی" onClick={onNewProgram} />
            <QuickAction icon={<Utensils />} title="نوشتن تغذیه" subtitle="وعده‌ها و درشت‌مغذی‌ها" onClick={() => onOpenBuilder("nutrition")} />
            <QuickAction icon={<Pill />} title="نوشتن مکمل" subtitle="انتخاب از بانک مکمل و ویتامین" onClick={() => onOpenBuilder("supplements")} />
            <QuickAction icon={<Syringe />} title="نوشتن دارو / PCT" subtitle="انتخاب دارو و تعیین بازه هفته‌ها" onClick={() => onOpenBuilder("medications")} />
            <QuickAction icon={<FileDown />} title="دانلود PDF" subtitle="ذخیره و ارسال برنامه" onClick={onPrint} />
          </div>
        </div>
      </section>
    </div>
  );
}

function Stat({ icon, value, label }: { icon: React.ReactNode; value: string; label: string }) {
  return (
    <div className="rounded-2xl border border-white/8 bg-card p-3 sm:p-4">
      <div className="text-amber-400 [&_svg]:size-4">{icon}</div>
      <p className="mt-3 text-xl font-black text-white sm:text-2xl">{value}</p>
      <p className="mt-1 text-[11px] text-zinc-500">{label}</p>
    </div>
  );
}

function QuickAction({ icon, title, subtitle, onClick }: { icon: React.ReactNode; title: string; subtitle: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="flex w-full items-center gap-3 rounded-2xl border border-white/7 bg-white/[.025] p-3 text-right transition hover:border-amber-500/30 hover:bg-amber-500/5">
      <div className="grid size-10 shrink-0 place-items-center rounded-xl bg-amber-500/10 text-amber-400 [&_svg]:size-5">{icon}</div>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-semibold text-zinc-100">{title}</p>
        <p className="mt-1 text-[11px] text-zinc-500">{subtitle}</p>
      </div>
      <ChevronLeft className="size-4 text-zinc-700" />
    </button>
  );
}

function ClientProfile({ client, plan, historyCount, programNumbers, history, onBack, onNewProgram, newPlanBusy, deleteClientBusy, deleteClientMessage, onDeleteClient, onUpdateClient, onOpenBuilder }: {
  client: Client;
  plan: ClientPlan;
  historyCount: number;
  programNumbers: number[];
  history: React.ReactNode;
  onBack: () => void;
  onNewProgram: () => void;
  newPlanBusy: boolean;
  deleteClientBusy: boolean;
  deleteClientMessage: string;
  onDeleteClient: () => void;
  onUpdateClient: (clientId:string, patch:Pick<Client,"name"|"phone"|"goal"|"notes"|"initialMeasurements">) => Promise<Client>;
  onOpenBuilder: (tab: string) => void;
}) {
  const [editing,setEditing]=useState(false);
  const [draft,setDraft]=useState({name:client.name,phone:client.phone,goal:client.goal,notes:client.notes,initialMeasurements:{weight:client.initialMeasurements?.weight??0,height:client.initialMeasurements?.height??0,waist:client.initialMeasurements?.waist??0,arm:client.initialMeasurements?.arm??0}});
  const [editBusy,setEditBusy]=useState(false);
  const [editMessage,setEditMessage]=useState("");
  useEffect(()=>{setDraft({name:client.name,phone:client.phone,goal:client.goal,notes:client.notes,initialMeasurements:{weight:client.initialMeasurements?.weight??0,height:client.initialMeasurements?.height??0,waist:client.initialMeasurements?.waist??0,arm:client.initialMeasurements?.arm??0}});setEditMessage("");},[client.id,client.name,client.phone,client.goal,client.notes,client.initialMeasurements?.weight,client.initialMeasurements?.height,client.initialMeasurements?.waist,client.initialMeasurements?.arm]);
  const saveClient=async()=>{setEditBusy(true);setEditMessage("");try{await onUpdateClient(client.id,draft);setEditing(false);setEditMessage("مشخصات شاگرد ذخیره شد.");}catch(error){setEditMessage(error instanceof Error?error.message:"ذخیره انجام نشد.");}finally{setEditBusy(false)}};
  return <div>
    <PageTitle eyebrow="CLIENT PROFILE" title="پروفایل شاگرد" description="اطلاعات، سوابق برنامه‌ها، اندازه‌ها و عکس‌های پیشرفت این شاگرد در یک پرونده نگهداری می‌شود." action={<Button variant="outline" onClick={onBack} className="border-white/10"><ChevronLeft className="rotate-180"/> بازگشت</Button>}/>
    <section className="mb-5 overflow-hidden rounded-[28px] border border-white/8 bg-[radial-gradient(circle_at_90%_0%,rgba(174,184,196,.20),transparent_38%),#111316] p-5 sm:p-7">
      <div className="flex flex-col gap-5 sm:flex-row sm:items-center">
        <div className="grid size-20 shrink-0 place-items-center rounded-3xl bg-amber-500 text-3xl font-black text-white">{client.name.slice(0,1)}</div>
        <div className="min-w-0 flex-1"><p className="text-xs font-bold text-amber-400">شاگرد فعال</p><h2 className="mt-1 text-3xl font-black text-white">{client.name}</h2><p className="mt-2 text-sm text-zinc-400">{client.goal || "هدف ثبت نشده"}</p><p className="mt-1 text-sm text-zinc-600">{client.phone || "شماره تماس ثبت نشده"}</p>{plan.coachProgramNumber&&<Badge className="mt-3 bg-emerald-600/15 text-emerald-400">شماره داخلی برنامه: {plan.coachProgramNumber.toLocaleString("fa-IR")}</Badge>}{client.notes&&<p className="mt-3 max-w-2xl text-sm leading-7 text-zinc-400">{client.notes}</p>}</div>
        <div className="flex flex-col gap-2"><StudentAccessButton client={client}/><Button variant="outline" onClick={()=>setEditing(value=>!value)} className="h-11 border-white/10"><Pencil/> ویرایش مشخصات</Button></div>
      </div>
      {editing&&<div className="mt-5 grid gap-3 rounded-2xl border border-amber-500/15 bg-black/20 p-4 sm:grid-cols-2"><Field label="نام و نام خانوادگی"><Input value={draft.name} onChange={e=>setDraft({...draft,name:e.target.value})}/></Field><Field label="شماره تماس"><Input value={draft.phone} onChange={e=>setDraft({...draft,phone:e.target.value})} inputMode="tel" dir="ltr"/></Field><Field label="هدف"><Input value={draft.goal} onChange={e=>setDraft({...draft,goal:e.target.value})}/></Field><div className="grid grid-cols-2 gap-2 sm:col-span-2 sm:grid-cols-4"><Field label="وزن شروع"><Input type="number" min={0} value={draft.initialMeasurements.weight||""} onChange={e=>setDraft({...draft,initialMeasurements:{...draft.initialMeasurements,weight:Number(e.target.value)||0}})}/></Field><Field label="قد شروع"><Input type="number" min={0} value={draft.initialMeasurements.height||""} onChange={e=>setDraft({...draft,initialMeasurements:{...draft.initialMeasurements,height:Number(e.target.value)||0}})}/></Field><Field label="دور کمر"><Input type="number" min={0} value={draft.initialMeasurements.waist||""} onChange={e=>setDraft({...draft,initialMeasurements:{...draft.initialMeasurements,waist:Number(e.target.value)||0}})}/></Field><Field label="دور بازو"><Input type="number" min={0} value={draft.initialMeasurements.arm||""} onChange={e=>setDraft({...draft,initialMeasurements:{...draft.initialMeasurements,arm:Number(e.target.value)||0}})}/></Field></div><div className="sm:col-span-2"><Field label="یادداشت مربی"><Textarea value={draft.notes} onChange={e=>setDraft({...draft,notes:e.target.value})}/></Field></div><div className="flex flex-wrap items-center gap-2 sm:col-span-2"><Button onClick={()=>void saveClient()} disabled={editBusy||!draft.name.trim()} className="bg-amber-500 text-black hover:bg-amber-400">{editBusy?<LoaderCircle className="animate-spin"/>:<Check/>} ذخیره مشخصات</Button><Button variant="ghost" onClick={()=>{setEditing(false);setDraft({name:client.name,phone:client.phone,goal:client.goal,notes:client.notes,initialMeasurements:{weight:client.initialMeasurements?.weight??0,height:client.initialMeasurements?.height??0,waist:client.initialMeasurements?.waist??0,arm:client.initialMeasurements?.arm??0}})}}><X/> انصراف</Button>{editMessage&&<span className="text-xs text-amber-200">{editMessage}</span>}</div></div>}
      {!editing&&editMessage&&<p className="mt-3 text-xs text-emerald-400">{editMessage}</p>}
      {programNumbers.length>0&&<div className="mt-5 rounded-2xl border border-emerald-500/15 bg-emerald-500/[.04] p-3"><p className="text-xs font-bold text-emerald-400">سابقه شماره برنامه‌ها — فقط مربی</p><div className="mt-2 flex flex-wrap gap-2">{[...new Set(programNumbers)].sort((a,b)=>a-b).map((number)=><Badge key={number} variant="outline" className="border-emerald-500/25 text-emerald-300">برنامه {number.toLocaleString("fa-IR")}</Badge>)}</div></div>}
      <div className="mt-6 grid grid-cols-3 gap-3"><Stat icon={<History/>} value={historyCount.toLocaleString("fa-IR")} label="سوابق"/><Stat icon={<Dumbbell/>} value={plan.workoutDays.length.toLocaleString("fa-IR")} label="روز تمرین"/><Stat icon={<Pill/>} value={(plan.supplementItems?.length??0).toLocaleString("fa-IR")} label="مکمل"/></div>
      <div className="mt-5 flex flex-wrap gap-2"><Button onClick={onNewProgram} disabled={newPlanBusy} className="bg-amber-500 hover:bg-amber-500">{newPlanBusy?<LoaderCircle className="animate-spin"/>:<Plus/>} برنامه جدید</Button><Button variant="outline" onClick={()=>onOpenBuilder("workout")} className="border-white/10"><Dumbbell/> تمرینی</Button><Button variant="outline" onClick={()=>onOpenBuilder("nutrition")} className="border-white/10"><Utensils/> غذایی</Button><Button variant="outline" onClick={()=>onOpenBuilder("supplements")} className="border-white/10"><Pill/> مکمل</Button><Button variant="outline" onClick={()=>onOpenBuilder("medications")} className="border-white/10"><Syringe/> دارو / PCT</Button></div>
      <div className="mt-4 border-t border-white/8 pt-4"><Button variant="outline" onClick={onDeleteClient} disabled={deleteClientBusy} className="border-amber-500/25 text-red-300 hover:bg-amber-500/10">{deleteClientBusy?<LoaderCircle className="animate-spin"/>:<Trash2/>} حذف شاگرد</Button>{deleteClientMessage&&<p className="mt-2 text-sm text-red-300">{deleteClientMessage}</p>}</div>
    </section>
    {history}
  </div>;
}


type BillingRecord = {
  id: string;
  application_id: string | null;
  package_id: string;
  package_name: string;
  list_amount: number;
  discount_amount: number;
  final_amount: number;
  received_amount: number;
};

function BuilderBillingPanel({ clientId }: { clientId: string }) {
  const { packages: PACKAGES, packageById, loading: pricesLoading } = usePackages();
  const defaultPackage = PACKAGES[0];
  const [record,setRecord]=useState<BillingRecord|null>(null);
  const [form,setForm]=useState<{ packageId: string; listAmount: number; discountAmount: number; receivedAmount: number }>({packageId:defaultPackage.id,listAmount:defaultPackage.price??0,discountAmount:0,receivedAmount:0});
  const [busy,setBusy]=useState(false);
  const [message,setMessage]=useState("");

  useEffect(()=>{
    if(pricesLoading)return;
    let cancelled=false;
    const load=async()=>{
      setMessage("");
      try{
        const response=await fetch(`/api/billing?clientId=${encodeURIComponent(clientId)}`,{cache:"no-store"});
        const data=await response.json() as {record?:BillingRecord|null;error?:string};
        if(!response.ok)throw new Error(data.error??"دریافت حسابداری انجام نشد.");
        if(cancelled)return;
        const next=data.record??null;
        setRecord(next);
        if(next){setForm({packageId:next.package_id,listAmount:Number(next.list_amount)||0,discountAmount:Number(next.discount_amount)||0,receivedAmount:Number(next.received_amount)||0});}
        else{setForm({packageId:defaultPackage.id,listAmount:defaultPackage.price??0,discountAmount:0,receivedAmount:0});}
      }catch(error){if(!cancelled)setMessage(error instanceof Error?error.message:"دریافت حسابداری انجام نشد.");}
    };
    void load();
    return()=>{cancelled=true};
  },[clientId,pricesLoading]);

  const save=async()=>{
    if(busy)return;
    setBusy(true);setMessage("");
    try{
      const selected=packageById(form.packageId);
      const response=await fetch("/api/billing",{method:"PUT",headers:{"content-type":"application/json"},body:JSON.stringify({
        id:record?.id,
        clientId,
        applicationId:record?.application_id??null,
        packageId:form.packageId,
        packageName:selected?.name,
        listAmount:Math.max(0,Math.round(form.listAmount)),
        discountAmount:Math.max(0,Math.round(form.discountAmount)),
        receivedAmount:Math.max(0,Math.round(form.receivedAmount)),
      })});
      const data=await response.json() as {record?:BillingRecord;error?:string};
      if(!response.ok||!data.record)throw new Error(data.error??"ذخیره حسابداری انجام نشد.");
      setRecord(data.record);
      setForm({packageId:data.record.package_id,listAmount:Number(data.record.list_amount)||0,discountAmount:Number(data.record.discount_amount)||0,receivedAmount:Number(data.record.received_amount)||0});
      setMessage("پکیج و مبالغ حسابداری ذخیره شد.");
    }catch(error){setMessage(error instanceof Error?error.message:"ذخیره حسابداری انجام نشد.");}
    finally{setBusy(false);}
  };
  const finalAmount=Math.max(0,form.listAmount-form.discountAmount);
  const remaining=Math.max(0,finalAmount-form.receivedAmount);
  return <section className="builder-billing-panel mb-4 rounded-2xl border border-white/8 bg-white/[.025] p-3">
    <div className="mb-3 flex flex-wrap items-center justify-between gap-2"><div><strong className="text-sm text-white">پکیج و حسابداری این شاگرد</strong><p className="mt-1 text-xs text-zinc-500">از همین صفحه نوع پکیج، تخفیف و مبلغ دریافتی را اصلاح کن.</p></div><span className="rounded-full border border-white/10 bg-black/20 px-3 py-1 text-xs text-zinc-300">مانده: {remaining.toLocaleString("fa-IR")} تومان</span></div>
    <div className="grid gap-2 sm:grid-cols-[1.2fr_repeat(3,minmax(0,.75fr))_auto] sm:items-end">
      <Field label="نوع پکیج"><Select value={form.packageId} onValueChange={(value)=>{const selected=packageById(value);setForm(current=>({...current,packageId:value,listAmount:selected?.price??current.listAmount}));}}><SelectTrigger className="h-11"><SelectValue/></SelectTrigger><SelectContent>{PACKAGES.map(item=><SelectItem key={item.id} value={item.id}>{item.name}</SelectItem>)}</SelectContent></Select></Field>
      <Field label="مبلغ"><Input type="number" inputMode="numeric" min={0} value={form.listAmount} onChange={e=>setForm({...form,listAmount:Number(e.target.value)||0})}/></Field>
      <Field label="تخفیف"><Input type="number" inputMode="numeric" min={0} value={form.discountAmount} onChange={e=>setForm({...form,discountAmount:Number(e.target.value)||0})}/></Field>
      <Field label="دریافتی"><Input type="number" inputMode="numeric" min={0} value={form.receivedAmount} onChange={e=>setForm({...form,receivedAmount:Number(e.target.value)||0})}/></Field>
      <Button type="button" onClick={()=>void save()} disabled={busy} className="h-11 bg-emerald-600 hover:bg-emerald-500">{busy?<LoaderCircle className="animate-spin"/>:<Check/>} ثبت حساب</Button>
    </div>
    {message&&<p className={`mt-2 text-xs ${message.includes("ذخیره شد")?"text-emerald-300":"text-rose-300"}`}>{message}</p>}
  </section>;
}

type BuilderProps = {
  state: CoachState;
  exercises: Exercise[];
  activeClient: Client;
  plan: ClientPlan;
  activeDay?: WorkoutDay;
  activeDayId: string;
  programTab: string;
  setProgramTab: (tab: string) => void;
  onChangeClient: (id: string) => void;
  onNewClient: () => void;
  onNewProgram: () => void;
  newPlanBusy: boolean;
  newPlanMessage: string;
  saveStatus: SaveStatus;
  saveMessage: string;
  onSaveNow: () => void | Promise<void>;
  onDeliver: () => void | Promise<void>;
  deliveryBusy: boolean;
  deliveryMessage: string;
  onPrint: () => void;
  onPrintSection: (section: PdfSection, label: string) => void;
  onUpdatePlan: (updater: (plan: ClientPlan) => ClientPlan) => void;
  onSetDay: (id: string) => void;
  onAddDay: () => void;
  onRemoveDay: () => void;
  onUpdateDay: (id: string, patch: Partial<WorkoutDay>) => void;
  onOpenExercisePicker: () => void;
  onUpdateExercise: (rowId: string, patch: Partial<ProgramExercise>) => void;
  onSetExerciseTechnique: (rowId: string, technique: string) => void;
  onRemoveExercise: (rowId: string) => void;
  onMoveExercise: (index: number, direction: -1 | 1) => void;
  onReorderExerciseUnit: (sourceUnitId: string, targetUnitId: string) => void;
  onAddMeal: () => void;
  onUpdateMeal: (id: string, patch: Partial<Meal>) => void;
  supplementQuery: string;
  supplementCategory: string;
  onSupplementQuery: (value: string) => void;
  onSupplementCategory: (value: string) => void;
  onAddSupplement: (id: string) => void;
  onAddCustomSupplement: () => void;
  onUpdateSupplement: (id: string, patch: Partial<SupplementPlanItem>) => void;
  onRemoveSupplement: (id: string) => void;
  medicationQuery: string;
  medicationCategory: string;
  medicationGroup: "pct" | "bodybuilding";
  onMedicationQuery: (value: string) => void;
  onMedicationCategory: (value: string) => void;
  onMedicationGroup: (value: "pct" | "bodybuilding") => void;
  onAddMedication: (id: string) => void;
  onAddCustomMedication: () => void;
  onUpdateMedication: (id: string, patch: Partial<MedicationPlanItem>) => void;
  onRemoveMedication: (id: string) => void;
};

function Builder(props: BuilderProps) {
  const { state, activeClient, plan, activeDay, activeDayId, programTab, setProgramTab } = props;
  const exerciseUnits = activeDay ? groupExerciseRows(activeDay.exercises) : [];
  const [clientPickerOpen, setClientPickerOpen] = useState(false);
  const [clientPickerQuery, setClientPickerQuery] = useState("");
  const [draggingUnitId, setDraggingUnitId] = useState<string | null>(null);
  const [dragOverUnitId, setDragOverUnitId] = useState<string | null>(null);
  const visibleClients = state.clients.filter((client) => `${client.name} ${client.phone} ${client.goal}`.toLowerCase().includes(clientPickerQuery.trim().toLowerCase()));
  return (
    <div className="program-builder pb-[calc(10rem+env(safe-area-inset-bottom))] sm:pb-0">
      <PageTitle
        eyebrow="PROGRAM BUILDER"
        title="برنامه‌ساز مربی"
        description="برای گوشی بهینه شده؛ تغییرات خودکار ذخیره می‌شوند و با «ثبت و ذخیره» می‌توانی ذخیره روی سرور را همان لحظه قطعی کنی."
        action={
          <div className="hidden items-center gap-2 sm:flex">
            <Button onClick={props.onSaveNow} disabled={props.saveStatus === "saving" || props.saveStatus === "loading"} className="h-11 bg-emerald-600 hover:bg-emerald-500">
              {props.saveStatus === "saving" ? <LoaderCircle className="animate-spin" /> : <Check />}
              {props.saveStatus === "saving" ? "در حال ذخیره" : "ثبت و ذخیره"}
            </Button>
            <Button onClick={props.onPrint} variant="outline" className="h-11 border-white/10"><FileDown /> خروجی PDF</Button>
            <Button onClick={props.onDeliver} disabled={props.deliveryBusy||props.saveStatus==="saving"} className="h-11 bg-amber-500 font-black text-black hover:bg-amber-400">{props.deliveryBusy?<LoaderCircle className="animate-spin"/>:<Send/>} ارسال برنامه</Button>
          </div>
        }
      />
      {props.deliveryMessage&&<p className="mb-4 rounded-2xl border border-amber-500/20 bg-amber-500/[.06] p-3 text-sm text-amber-100">{props.deliveryMessage}</p>}

      <section className="coach-pdf-section-grid mb-4 grid grid-cols-2 gap-2 sm:grid-cols-4" aria-label="خروجی PDF جداگانه">
        <Button type="button" variant="outline" onClick={()=>props.onPrintSection("training","برنامه تمرینی")} className="h-12 border-white/10 bg-white/[.025]"><Dumbbell/> PDF تمرین</Button>
        <Button type="button" variant="outline" onClick={()=>props.onPrintSection("nutrition","برنامه غذایی")} className="h-12 border-white/10 bg-white/[.025]"><Utensils/> PDF تغذیه</Button>
        <Button type="button" variant="outline" onClick={()=>props.onPrintSection("supplements","برنامه مکمل")} className="h-12 border-white/10 bg-white/[.025]"><Pill/> PDF مکمل</Button>
        <Button type="button" variant="outline" onClick={()=>props.onPrintSection("medications","برنامه دارو و PCT")} disabled={(plan.medicationItems?.length??0)===0} className="h-12 border-white/10 bg-white/[.025]"><Syringe/> PDF دارو</Button>
      </section>

      <div className="mb-4 grid gap-3 rounded-2xl border border-white/8 bg-card p-3 sm:grid-cols-[1fr_1.2fr_auto]">
        <div className="flex gap-2">
          <button type="button" onClick={() => setClientPickerOpen(true)} className="flex h-12 min-w-0 flex-1 touch-manipulation items-center gap-3 rounded-xl border border-white/10 bg-white/[.03] px-3 text-right text-sm transition active:scale-[.99] hover:border-amber-500/35"><span className="grid size-7 shrink-0 place-items-center rounded-lg bg-amber-500 text-xs font-black text-white">{activeClient.name.slice(0,1)}</span><span className="min-w-0 flex-1 truncate font-semibold text-zinc-100">{activeClient.name}</span><ChevronLeft className="size-4 rotate-90 text-zinc-500"/></button>
          <Button size="icon-lg" variant="outline" onClick={props.onNewClient} className="size-12 touch-manipulation border-white/10"><Plus /></Button>
        </div>
        <Input value={plan.title} onChange={(event) => props.onUpdatePlan((current) => ({ ...current, title: event.target.value }))} className="h-12 rounded-xl border-white/10 bg-white/[.03] font-medium" aria-label="عنوان برنامه" placeholder="عنوان برنامه" />
        <Button onClick={props.onNewProgram} disabled={props.newPlanBusy} variant="outline" className="h-12 touch-manipulation rounded-xl border-amber-500/30 text-amber-200 hover:bg-amber-500/10">
          {props.newPlanBusy ? <LoaderCircle className="animate-spin" /> : <Plus />} برنامه جدید
        </Button>
      </div>
      <ProgramFollowupSettings plan={plan} onChange={props.onUpdatePlan}/>
      <BuilderBillingPanel clientId={activeClient.id} />
      {props.saveMessage && <p className={`mb-3 rounded-xl border px-3 py-2.5 text-xs ${props.saveStatus === "saved" ? "border-emerald-500/20 bg-emerald-500/[.07] text-emerald-200" : "border-amber-500/20 bg-amber-500/[.07] text-amber-200"}`} role="status">{props.saveMessage}</p>}
      {props.newPlanMessage && <p className="mb-4 rounded-xl border border-white/8 bg-white/[.025] px-3 py-2 text-xs text-zinc-300" role="status">{props.newPlanMessage}</p>}

      <Tabs value={programTab} onValueChange={setProgramTab} dir="rtl">
        <TabsList className="mb-5 flex h-14 w-full justify-start gap-1 overflow-x-auto rounded-2xl bg-white/[.04] p-1 scrollbar-none sm:grid sm:h-12 sm:max-w-2xl sm:grid-cols-4">
          <TabsTrigger value="workout" className="h-12 min-w-28 shrink-0 touch-manipulation rounded-xl data-[state=active]:bg-amber-500 data-[state=active]:text-white sm:h-10 sm:min-w-0"><Dumbbell /> تمرینی</TabsTrigger>
          <TabsTrigger value="nutrition" className="h-12 min-w-28 shrink-0 touch-manipulation rounded-xl data-[state=active]:bg-amber-500 data-[state=active]:text-white sm:h-10 sm:min-w-0"><Utensils /> غذایی</TabsTrigger>
          <TabsTrigger value="supplements" className="h-12 min-w-28 shrink-0 touch-manipulation rounded-xl data-[state=active]:bg-amber-500 data-[state=active]:text-white sm:h-10 sm:min-w-0"><Pill /> مکمل</TabsTrigger>
          <TabsTrigger value="medications" className="h-12 min-w-32 shrink-0 touch-manipulation rounded-xl data-[state=active]:bg-amber-500 data-[state=active]:text-white sm:h-10 sm:min-w-0"><Syringe /> دارو / PCT</TabsTrigger>
        </TabsList>

        <TabsContent value="workout">
          <div className="mb-4 flex gap-2 overflow-x-auto pb-2 scrollbar-none">
            {plan.workoutDays.map((day) => (
              <button key={day.id} onClick={() => props.onSetDay(day.id)} className={`min-h-12 shrink-0 touch-manipulation rounded-xl border px-4 py-2.5 text-sm font-semibold transition active:scale-[.99] ${activeDayId === day.id ? "border-amber-500 bg-amber-500 text-white" : "border-white/8 bg-card text-zinc-400"}`}>{day.title}</button>
            ))}
            <Button size="icon-lg" variant="outline" onClick={props.onAddDay} className="size-12 shrink-0 touch-manipulation border-dashed border-white/15"><Plus /></Button>
          </div>

          {activeDay && (
            <>
              <div className="mb-4 rounded-2xl border border-white/8 bg-card p-4">
                <div className="grid gap-3 sm:grid-cols-[.55fr_1.45fr_auto]">
                  <Field label="نام روز"><Input className="h-12 sm:h-9" value={activeDay.title} onChange={(event) => props.onUpdateDay(activeDay.id, { title: event.target.value })} /></Field>
                  <Field label="هدف جلسه"><Input className="h-12 sm:h-9" value={activeDay.focus} onChange={(event) => props.onUpdateDay(activeDay.id, { focus: event.target.value })} placeholder="مثلاً سینه و پشت بازو" /></Field>
                  <Button variant="ghost" onClick={props.onRemoveDay} disabled={plan.workoutDays.length === 1} className="h-12 touch-manipulation self-end rounded-xl text-zinc-500 hover:text-amber-300"><Trash2 /> حذف روز</Button>
                </div>
              </div>

              {activeDay.exercises.length > 1 && <div className="mb-3 flex items-center gap-2 rounded-xl border border-white/8 bg-white/[.025] px-3 py-2 text-xs text-zinc-400"><GripVertical className="size-4 text-amber-300" /> برای جابه‌جایی ترتیب حرکات، آیکن دستگیره را بگیر و حرکت را بالا یا پایین بکش.</div>}
              <div className="space-y-3">
                {exerciseUnits.map((unit, unitIndex) => {
                  const reorderHandle = (
                    <ExerciseReorderHandle
                      unitId={unit.id}
                      dragging={draggingUnitId === unit.id}
                      onDragging={(id) => { setDraggingUnitId(id); if (!id) setDragOverUnitId(null); }}
                      onDropUnit={(sourceId, targetId) => {
                        props.onReorderExerciseUnit(sourceId, targetId);
                        setDraggingUnitId(null);
                        setDragOverUnitId(null);
                      }}
                    />
                  );
                  const rows = unit.items.map((item, pairIndex) => {
                    const index = activeDay.exercises.findIndex(
                      (candidate) => candidate.rowId === item.rowId,
                    );
                    return (
                      <ExerciseRow
                        key={item.rowId}
                        item={item}
                        exercises={props.exercises}
                        index={index}
                        canMoveUp={unitIndex > 0}
                        canMoveDown={unitIndex < exerciseUnits.length - 1}
                        supersetLabel={unit.type === "superset" ? (pairIndex === 0 ? "A" : "B") : undefined}
                        reorderHandle={unit.type === "single" ? reorderHandle : undefined}
                        onUpdate={props.onUpdateExercise}
                        onSetTechnique={props.onSetExerciseTechnique}
                        onRemove={props.onRemoveExercise}
                        onMove={props.onMoveExercise}
                      />
                    );
                  });

                  return (
                    <div
                      key={unit.id}
                      data-exercise-unit-id={unit.id}
                      onDragEnter={(event) => {
                        if (!draggingUnitId || draggingUnitId === unit.id) return;
                        event.preventDefault();
                        setDragOverUnitId(unit.id);
                      }}
                      onDragOver={(event) => { if (draggingUnitId && draggingUnitId !== unit.id) event.preventDefault(); }}
                      onDragLeave={(event) => { if (!event.currentTarget.contains(event.relatedTarget as Node | null)) setDragOverUnitId((current) => current === unit.id ? null : current); }}
                      onDrop={(event) => {
                        event.preventDefault();
                        const sourceId = draggingUnitId || event.dataTransfer.getData("application/x-powerhome-exercise-unit");
                        if (sourceId && sourceId !== unit.id) props.onReorderExerciseUnit(sourceId, unit.id);
                        setDraggingUnitId(null);
                        setDragOverUnitId(null);
                      }}
                      className={`rounded-3xl transition ${draggingUnitId === unit.id ? "opacity-55" : ""} ${dragOverUnitId === unit.id ? "ring-2 ring-amber-500/70 ring-offset-2 ring-offset-background" : ""}`}
                    >
                      {unit.type === "superset" ? (
                        <section className="overflow-hidden rounded-3xl border-2 border-amber-500/55 bg-amber-500/[.035]">
                          <div className="flex items-center justify-between gap-3 border-b border-amber-500/25 bg-amber-500/10 px-4 py-2.5">
                            <div className="flex items-center gap-2">{reorderHandle}<Badge className="superset-label bg-amber-500 text-white">سوپرست A / B</Badge></div>
                            <span className="text-[10px] text-amber-300">بدون استراحت بین دو حرکت</span>
                          </div>
                          <div className="space-y-2 p-2">{rows}</div>
                        </section>
                      ) : rows[0]}
                    </div>
                  );
                })}
                {activeDay.exercises.length === 0 && (
                  <div className="grid min-h-52 place-items-center rounded-3xl border border-dashed border-white/12 bg-white/[.02] p-6 text-center">
                    <div>
                      <Dumbbell className="mx-auto size-8 text-zinc-700" />
                      <h3 className="mt-3 font-semibold text-zinc-200">این جلسه هنوز حرکتی ندارد</h3>
                      <p className="mt-1 text-xs text-zinc-500">از بانک تصاویر یک یا چند حرکت انتخاب کنید.</p>
                    </div>
                  </div>
                )}
              </div>

              <Button onClick={props.onOpenExercisePicker} className="mt-4 h-14 w-full touch-manipulation rounded-2xl bg-amber-500 text-base font-bold hover:bg-amber-500 active:scale-[.99]"><Plus /> افزودن حرکت از بانک تصاویر</Button>
            </>
          )}
        </TabsContent>

        <TabsContent value="nutrition">
          <NutritionBuilder plan={plan} onUpdatePlan={props.onUpdatePlan} onAddMeal={props.onAddMeal} onUpdateMeal={props.onUpdateMeal} />
        </TabsContent>
        <TabsContent value="supplements">
          <SupplementBuilder
            plan={plan}
            query={props.supplementQuery}
            category={props.supplementCategory}
            onQuery={props.onSupplementQuery}
            onCategory={props.onSupplementCategory}
            onAdd={props.onAddSupplement}
            onAddCustom={props.onAddCustomSupplement}
            onUpdate={props.onUpdateSupplement}
            onRemove={props.onRemoveSupplement}
          />
        </TabsContent>
        <TabsContent value="medications">
          <MedicationBuilder
            plan={plan}
            query={props.medicationQuery}
            category={props.medicationCategory}
            group={props.medicationGroup}
            onQuery={props.onMedicationQuery}
            onCategory={props.onMedicationCategory}
            onGroup={props.onMedicationGroup}
            onAdd={props.onAddMedication}
            onAddCustom={props.onAddCustomMedication}
            onUpdate={props.onUpdateMedication}
            onRemove={props.onRemoveMedication}
          />
        </TabsContent>
      </Tabs>

      <div className="program-save-bar sticky bottom-[calc(5.4rem+env(safe-area-inset-bottom))] z-30 mt-6 rounded-2xl border border-white/10 bg-[#0b0c0e]/95 p-2.5 shadow-[0_-12px_40px_rgba(0,0,0,.35)] backdrop-blur-xl sm:hidden">
        <div className="mb-2 flex items-center justify-between px-1 text-[11px]">
          <span className="text-zinc-400">{props.saveStatus === "saving" ? "در حال ثبت تغییرات…" : props.saveStatus === "saved" ? "آخرین تغییرات ذخیره شده" : props.saveStatus === "local" ? "فعلاً ذخیره روی گوشی" : "در حال آماده‌سازی"}</span>
          <SaveIndicator status={props.saveStatus} />
        </div>
        <div className="grid grid-cols-[1fr_auto_auto] gap-2">
          <Button onClick={props.onSaveNow} disabled={props.saveStatus === "saving" || props.saveStatus === "loading"} className="h-14 touch-manipulation rounded-xl bg-emerald-600 text-base font-black hover:bg-emerald-500 active:scale-[.99]">
            {props.saveStatus === "saving" ? <LoaderCircle className="animate-spin" /> : <Check className="size-5" />}
            {props.saveStatus === "saving" ? "در حال ذخیره" : "ثبت و ذخیره برنامه"}
          </Button>
          <Button onClick={props.onPrint} variant="outline" className="size-14 touch-manipulation rounded-xl border-white/10 bg-white/[.04]" aria-label="خروجی PDF"><FileDown className="size-5" /></Button>
          <Button onClick={props.onDeliver} disabled={props.deliveryBusy||props.saveStatus==="saving"} className="size-14 touch-manipulation rounded-xl bg-amber-500 text-black" aria-label="ارسال برنامه">{props.deliveryBusy?<LoaderCircle className="size-5 animate-spin"/>:<Send className="size-5"/>}</Button>
        </div>
      </div>

      <Dialog open={clientPickerOpen} onOpenChange={setClientPickerOpen}>
        <DialogContent className="max-h-[82dvh] overflow-hidden border-white/10 bg-[#111316] p-0 text-zinc-100 sm:max-w-md" dir="rtl">
          <DialogHeader className="border-b border-white/8 p-5 text-right sm:text-right"><DialogTitle>انتخاب شاگرد</DialogTitle><DialogDescription>نام یا شماره شاگرد را جست‌وجو کن.</DialogDescription></DialogHeader>
          <div className="relative px-5"><Search className="absolute right-8 top-1/2 size-4 -translate-y-1/2 text-zinc-500"/><Input autoFocus value={clientPickerQuery} onChange={(event)=>setClientPickerQuery(event.target.value)} placeholder="جست‌وجوی شاگرد..." className="h-12 border-white/10 bg-black/20 pr-10"/></div>
          <div className="max-h-[55dvh] space-y-2 overflow-y-auto px-5 pb-5">{visibleClients.map((client)=><button type="button" key={client.id} onClick={()=>{props.onChangeClient(client.id);setClientPickerOpen(false);setClientPickerQuery("");}} className={`flex w-full items-center gap-3 rounded-2xl border p-3 text-right ${client.id===activeClient.id?"border-amber-500/50 bg-amber-500/10":"border-white/8 bg-white/[.025]"}`}><span className="grid size-10 shrink-0 place-items-center rounded-xl bg-zinc-800 font-black text-white">{client.name.slice(0,1)}</span><span className="min-w-0 flex-1"><strong className="block truncate text-sm">{client.name}</strong><small className="mt-1 block truncate text-xs text-zinc-500">{client.phone||client.goal||"بدون مشخصات"}</small></span>{client.id===activeClient.id&&<Check className="size-5 text-emerald-400"/>}</button>)}{visibleClients.length===0&&<p className="py-10 text-center text-sm text-zinc-500">شاگردی پیدا نشد.</p>}</div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ExerciseReorderHandle({ unitId, dragging, onDragging, onDropUnit }: { unitId: string; dragging: boolean; onDragging: (id: string | null) => void; onDropUnit: (sourceUnitId: string, targetUnitId: string) => void }) {
  const touchDragging = useRef(false);
  return (
    <button
      type="button"
      draggable
      title="برای جابه‌جایی بکش"
      aria-label="گرفتن و جابه‌جایی حرکت"
      onDragStart={(event) => {
        event.dataTransfer.effectAllowed = "move";
        event.dataTransfer.setData("application/x-powerhome-exercise-unit", unitId);
        event.dataTransfer.setData("text/plain", unitId);
        onDragging(unitId);
      }}
      onDragEnd={() => onDragging(null)}
      onPointerDown={(event) => {
        if (event.pointerType === "mouse") return;
        touchDragging.current = true;
        event.currentTarget.setPointerCapture(event.pointerId);
        onDragging(unitId);
      }}
      onPointerMove={(event) => {
        if (!touchDragging.current) return;
        if (event.clientY < 120) window.scrollBy({ top: -14, behavior: "auto" });
        else if (event.clientY > window.innerHeight - 150) window.scrollBy({ top: 14, behavior: "auto" });
      }}
      onPointerUp={(event) => {
        if (!touchDragging.current) return;
        const target = document.elementFromPoint(event.clientX, event.clientY)?.closest<HTMLElement>("[data-exercise-unit-id]");
        const targetId = target?.dataset.exerciseUnitId;
        if (targetId && targetId !== unitId) onDropUnit(unitId, targetId);
        touchDragging.current = false;
        if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
        onDragging(null);
      }}
      onPointerCancel={(event) => {
        touchDragging.current = false;
        if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
        onDragging(null);
      }}
      className={`inline-flex h-11 min-w-11 touch-none cursor-grab items-center justify-center gap-1 rounded-xl border px-2 text-[10px] transition active:cursor-grabbing sm:h-8 sm:min-w-8 sm:rounded-lg sm:px-1.5 ${dragging ? "border-amber-500 bg-amber-500/20 text-amber-200" : "border-white/10 bg-black/20 text-zinc-400 hover:border-amber-500/40 hover:text-white"}`}
    >
      <GripVertical className="size-4" />
      <span className="hidden sm:inline">بکش</span>
    </button>
  );
}

function ExerciseRow({ item, exercises, index, canMoveUp, canMoveDown, supersetLabel, reorderHandle, onUpdate, onSetTechnique, onRemove, onMove }: { item: ProgramExercise; exercises: Exercise[]; index: number; canMoveUp: boolean; canMoveDown: boolean; supersetLabel?: string; reorderHandle?: React.ReactNode; onUpdate: (id: string, patch: Partial<ProgramExercise>) => void; onSetTechnique: (id: string, technique: string) => void; onRemove: (id: string) => void; onMove: (index: number, direction: -1 | 1) => void }) {
  const exercise = exercises.find((candidate) => candidate.id === item.exerciseId);
  if (!exercise) return null;
  return (
    <article className="overflow-hidden rounded-3xl border border-white/8 bg-card">
      <div className="flex gap-3 p-3 sm:p-4">
        <div className="relative shrink-0">
          <img src={exercise.image} alt={exercise.nameFa} loading="lazy" className="h-24 w-28 rounded-2xl bg-white object-contain sm:h-28 sm:w-36" />
          <span className="absolute right-2 top-2 grid size-6 place-items-center rounded-full bg-black/75 text-[10px] font-black text-white">{index + 1}</span>
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <Input
                value={item.nameFa ?? exercise.nameFa}
                onChange={(event) => onUpdate(item.rowId, { nameFa: event.target.value })}
                className="h-10 min-w-0 border-white/10 bg-black/20 px-2 text-sm font-bold text-zinc-100 sm:h-9"
                aria-label="نام حرکت در این برنامه"
              />
              <p className="mt-1 truncate text-[11px] text-zinc-500" dir="ltr">{item.nameEn ?? exercise.nameEn}</p>
              <div className="mt-2 flex items-center gap-2">
                <Badge variant="outline" className="border-amber-500/20 bg-amber-500/5 text-[10px] text-amber-300">{exercise.category}</Badge>
                {supersetLabel && <Badge className="superset-label bg-amber-500 text-white">{supersetLabel}</Badge>}
              </div>
            </div>
            <div className="hidden gap-1 sm:flex">
              {reorderHandle}
              <Button size="icon-xs" variant="ghost" disabled={!canMoveUp} onClick={() => onMove(index, -1)} aria-label="حرکت به بالا"><ArrowUp /></Button>
              <Button size="icon-xs" variant="ghost" disabled={!canMoveDown} onClick={() => onMove(index, 1)} aria-label="حرکت به پایین"><ArrowDown /></Button>
              <Button size="icon-xs" variant="ghost" onClick={() => onRemove(item.rowId)} className="text-zinc-600 hover:text-amber-300" aria-label="حذف حرکت"><Trash2 /></Button>
            </div>
          </div>
          <div className="mt-3 grid grid-cols-4 gap-2 sm:hidden">
            <div className="flex justify-center">{reorderHandle}</div>
            <Button size="icon-lg" variant="outline" disabled={!canMoveUp} onClick={() => onMove(index, -1)} className="size-11 w-full touch-manipulation rounded-xl border-white/10" aria-label="حرکت به بالا"><ArrowUp /></Button>
            <Button size="icon-lg" variant="outline" disabled={!canMoveDown} onClick={() => onMove(index, 1)} className="size-11 w-full touch-manipulation rounded-xl border-white/10" aria-label="حرکت به پایین"><ArrowDown /></Button>
            <Button size="icon-lg" variant="outline" onClick={() => onRemove(item.rowId)} className="size-11 w-full touch-manipulation rounded-xl border-amber-500/20 text-amber-300" aria-label="حذف حرکت"><Trash2 /></Button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2 border-t border-white/7 p-3 sm:grid-cols-6 sm:p-4">
        <CompactField label="ست"><Input className="h-11 sm:h-9" value={item.sets} onChange={(event) => onUpdate(item.rowId, { sets: event.target.value })} inputMode="numeric" /></CompactField>
        <CompactField label="تکرار"><Input className="h-11 sm:h-9" value={item.reps} onChange={(event) => onUpdate(item.rowId, { reps: event.target.value })} /></CompactField>
        <CompactField label="استراحت"><Input className="h-11 sm:h-9" value={item.rest} onChange={(event) => onUpdate(item.rowId, { rest: event.target.value })} /></CompactField>
        <CompactField label="تمپو"><Input className="h-11 sm:h-9" value={item.tempo} onChange={(event) => onUpdate(item.rowId, { tempo: event.target.value })} /></CompactField>
        <div className="col-span-2 sm:col-span-2">
          <span className="mb-1.5 block text-[10px] text-zinc-500">تکنیک اجرایی</span>
          <Select value={item.technique} onValueChange={(value) => onSetTechnique(item.rowId, value)}>
            <SelectTrigger className="h-11 w-full border-white/10 bg-white/[.03] text-base sm:h-9 sm:text-sm"><SelectValue /></SelectTrigger>
            <SelectContent dir="rtl" className="program-technique-menu">{TECHNIQUES.map((technique) => <SelectItem className="program-technique-item" key={technique} value={technique}>{technique}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="col-span-2 sm:col-span-6">
          <Input className="h-11 sm:h-9" value={item.notes} onChange={(event) => onUpdate(item.rowId, { notes: event.target.value })} placeholder="نکته مربی، شدت، RIR یا توضیح حرکت..." />
        </div>
      </div>
    </article>
  );
}

function NutritionBuilder({ plan, onUpdatePlan, onAddMeal, onUpdateMeal }: { plan: ClientPlan; onUpdatePlan: (updater: (plan: ClientPlan) => ClientPlan) => void; onAddMeal: () => void; onUpdateMeal: (id: string, patch: Partial<Meal>) => void }) {
  const updateGoal = (key: keyof ClientPlan["nutritionGoals"], value: string) => onUpdatePlan((current) => ({ ...current, nutritionGoals: { ...current.nutritionGoals, [key]: value } }));
  return (
    <div>
      <div className="grid grid-cols-2 gap-3 rounded-3xl border border-white/8 bg-card p-4 sm:grid-cols-4">
        <CompactField label="کالری روزانه"><Input className="h-12 sm:h-9" value={plan.nutritionGoals.calories} onChange={(event) => updateGoal("calories", event.target.value)} placeholder="kcal" inputMode="numeric" /></CompactField>
        <CompactField label="پروتئین"><Input className="h-12 sm:h-9" value={plan.nutritionGoals.protein} onChange={(event) => updateGoal("protein", event.target.value)} placeholder="گرم" inputMode="numeric" /></CompactField>
        <CompactField label="کربوهیدرات"><Input className="h-12 sm:h-9" value={plan.nutritionGoals.carbs} onChange={(event) => updateGoal("carbs", event.target.value)} placeholder="گرم" inputMode="numeric" /></CompactField>
        <CompactField label="چربی"><Input className="h-12 sm:h-9" value={plan.nutritionGoals.fat} onChange={(event) => updateGoal("fat", event.target.value)} placeholder="گرم" inputMode="numeric" /></CompactField>
      </div>
      <div className="mt-4 space-y-3">
        {plan.nutritionMeals.map((meal, index) => (
          <article key={meal.id} className="rounded-3xl border border-white/8 bg-card p-4">
            <div className="mb-3 flex items-center justify-between">
              <div className="flex items-center gap-2"><span className="grid size-7 place-items-center rounded-lg bg-amber-500/10 text-xs font-black text-amber-400">{index + 1}</span><h3 className="text-sm font-bold text-zinc-200">وعده غذایی</h3></div>
              <Button size="icon-lg" variant="ghost" className="size-11 touch-manipulation text-zinc-600 hover:text-amber-300 sm:size-6" onClick={() => onUpdatePlan((current) => ({ ...current, nutritionMeals: current.nutritionMeals.filter((candidate) => candidate.id !== meal.id) }))}><Trash2 /></Button>
            </div>
            <div className="grid gap-3 sm:grid-cols-[1fr_.5fr]">
              <Field label="نام وعده"><Input className="h-12 sm:h-9" value={meal.title} onChange={(event) => onUpdateMeal(meal.id, { title: event.target.value })} /></Field>
              <Field label="ساعت"><Input className="h-12 sm:h-9" type="time" value={meal.time} onChange={(event) => onUpdateMeal(meal.id, { time: event.target.value })} /></Field>
              <div className="sm:col-span-2"><Field label="مواد غذایی و مقدار"><Textarea value={meal.foods} onChange={(event) => onUpdateMeal(meal.id, { foods: event.target.value })} placeholder={'مثلاً:\nبرنج پخته ۲۰۰ گرم\nسینه مرغ ۱۵۰ گرم\nسالاد یک بشقاب'} className="min-h-28" /></Field></div>
              <div className="sm:col-span-2"><Field label="توضیحات"><Input className="h-12 sm:h-9" value={meal.notes} onChange={(event) => onUpdateMeal(meal.id, { notes: event.target.value })} placeholder="مکمل، جایگزین یا نکته اجرایی..." /></Field></div>
            </div>
          </article>
        ))}
        {plan.nutritionMeals.length === 0 && <div className="grid min-h-44 place-items-center rounded-3xl border border-dashed border-white/12 text-center text-sm text-zinc-500">اولین وعده غذایی را اضافه کنید.</div>}
      </div>
      <Button onClick={onAddMeal} className="mt-4 h-14 w-full touch-manipulation rounded-2xl bg-amber-500 text-base font-bold hover:bg-amber-500 active:scale-[.99]"><Plus /> افزودن وعده غذایی</Button>
    </div>
  );
}

function SupplementBuilder({ plan, query, category, onQuery, onCategory, onAdd, onAddCustom, onUpdate, onRemove }: {
  plan: ClientPlan;
  query: string;
  category: string;
  onQuery: (value: string) => void;
  onCategory: (value: string) => void;
  onAdd: (id: string) => void;
  onAddCustom: () => void;
  onUpdate: (id: string, patch: Partial<SupplementPlanItem>) => void;
  onRemove: (id: string) => void;
}) {
  const normalizedQuery = query.trim().toLowerCase();
  const results = SUPPLEMENTS.filter((item) => {
    const searchable = `${item.nameFa} ${item.nameEn} ${item.aliases ?? ""}`.toLowerCase();
    return (!normalizedQuery || searchable.includes(normalizedQuery)) && (category === "همه" || item.category === category);
  });
  const selected = plan.supplementItems ?? [];
  const selectedDefinitionIds = new Set(selected.map((item) => item.supplementId));
  return (
    <div className="space-y-5">
      <section className="rounded-3xl border border-white/8 bg-card p-4 sm:p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div><p className="text-xs font-bold text-amber-400">SUPPLEMENT LIBRARY</p><h2 className="mt-1 text-xl font-black text-white">بانک مکمل و ویتامین</h2><p className="mt-2 text-sm leading-6 text-zinc-500">مورد دلخواه را جست‌وجو و اضافه کن؛ مقدار و زمان مصرف را در برنامه شاگرد تنظیم کن.</p></div>
          <Badge className="bg-amber-500 text-white">{SUPPLEMENTS.length.toLocaleString("fa-IR")} مورد</Badge>
        </div>
        <div className="relative mt-4"><Search className="absolute right-3 top-1/2 size-4 -translate-y-1/2 text-zinc-500"/><Input value={query} onChange={(event) => onQuery(event.target.value)} placeholder="جست‌وجوی کراتین، ویتامین D، منیزیم، امگا ۳..." className="h-12 border-white/10 bg-black/20 pr-10"/></div>
        <div className="mt-3 flex gap-2 overflow-x-auto pb-1 scrollbar-none">{SUPPLEMENT_CATEGORIES.map((item) => <button type="button" key={item} onClick={() => onCategory(item)} className={`min-h-11 shrink-0 touch-manipulation rounded-full border px-3 py-2 text-xs font-semibold transition ${category === item ? "border-amber-500 bg-amber-500 text-white" : "border-white/10 bg-white/[.025] text-zinc-400"}`}>{item}</button>)}</div>
        <div className="mt-4 grid max-h-[430px] gap-2 overflow-y-auto pr-1 sm:grid-cols-2">
          {results.map((item) => {const isSelected=selectedDefinitionIds.has(item.id);return <article key={item.id} className={`flex items-center gap-3 rounded-2xl border p-3 transition ${isSelected?"border-emerald-500/55 bg-emerald-500/[.08]":"border-white/8 bg-white/[.025]"}`}><span className={`grid size-10 shrink-0 place-items-center rounded-xl ${isSelected?"bg-emerald-500/15 text-emerald-400":"bg-amber-500/10 text-amber-400"}`}><Pill className="size-5"/></span><div className="min-w-0 flex-1"><h3 className="truncate text-sm font-bold text-zinc-100">{item.nameFa}</h3><p className="mt-1 truncate text-xs text-zinc-500" dir="ltr">{item.nameEn}</p><small className={`mt-1 block text-xs ${isSelected?"text-emerald-400":"text-zinc-600"}`}>{isSelected?"انتخاب شده — برای حذف دوباره بزن":item.category}</small></div><Button type="button" size="icon-lg" onClick={() => onAdd(item.id)} className={`size-11 shrink-0 touch-manipulation rounded-full ${isSelected?"bg-emerald-600 hover:bg-emerald-500":"bg-amber-500 hover:bg-amber-500"}`} aria-label={`${isSelected?"حذف":"افزودن"} ${item.nameFa}`}>{isSelected?<Check/>:<Plus/>}</Button></article>})}
          {results.length === 0 && <p className="col-span-full py-10 text-center text-sm text-zinc-500">موردی با این نام پیدا نشد؛ می‌توانی مکمل شخصی اضافه کنی.</p>}
        </div>
        <Button type="button" variant="outline" onClick={onAddCustom} className="mt-4 h-12 w-full touch-manipulation rounded-xl border-white/10"><Plus/> افزودن مکمل شخصی</Button>
      </section>

      <section>
        <div className="mb-3 flex items-center justify-between"><div><h2 className="font-bold text-white">برنامه مکمل شاگرد</h2><p className="mt-1 text-xs text-zinc-500">{selected.length.toLocaleString("fa-IR")} مورد انتخاب شده</p></div></div>
        <div className="space-y-3">{selected.map((item, index) => <article key={item.id} className="rounded-3xl border border-white/8 bg-card p-4">
          <div className="mb-4 flex items-center justify-between gap-3"><div className="flex min-w-0 items-center gap-3"><span className="grid size-9 shrink-0 place-items-center rounded-xl bg-amber-500 text-sm font-black text-white">{(index + 1).toLocaleString("fa-IR")}</span><Input value={item.name} onChange={(event) => onUpdate(item.id, { name: event.target.value })} className="h-12 min-w-0 border-white/10 bg-black/20 font-bold sm:h-10" aria-label="نام مکمل"/></div><Button type="button" size="icon-lg" variant="ghost" onClick={() => onRemove(item.id)} className="size-11 shrink-0 touch-manipulation text-zinc-600 hover:text-amber-300 sm:size-8" aria-label={`حذف ${item.name}`}><Trash2/></Button></div>
          <div className="grid gap-3 sm:grid-cols-3"><Field label="مقدار مصرف"><Input className="h-12 sm:h-9" value={item.dose} onChange={(event) => onUpdate(item.id, { dose: event.target.value })} placeholder="مثلاً ۵ گرم"/></Field><Field label="زمان مصرف"><Input className="h-12 sm:h-9" value={item.timing} onChange={(event) => onUpdate(item.id, { timing: event.target.value })} placeholder="مثلاً بعد تمرین"/></Field><Field label="دفعات مصرف"><Input className="h-12 sm:h-9" value={item.frequency} onChange={(event) => onUpdate(item.id, { frequency: event.target.value })} placeholder="مثلاً روزانه"/></Field><div className="sm:col-span-3"><Field label="توضیحات مربی"><Textarea value={item.notes} onChange={(event) => onUpdate(item.id, { notes: event.target.value })} placeholder="نحوه مصرف، روز تمرین/استراحت یا نکته مهم..." className="min-h-20"/></Field></div></div>
        </article>)}</div>
        {selected.length === 0 && <div className="grid min-h-40 place-items-center rounded-3xl border border-dashed border-white/12 text-center text-sm text-zinc-500">از بانک بالا اولین مکمل یا ویتامین را انتخاب کن.</div>}
        <p className="mt-4 rounded-2xl border border-amber-500/15 bg-amber-500/[.05] p-3 text-xs leading-6 text-amber-200/80">مقدار مصرف باید با شرایط پزشکی، داروها و آزمایش شاگرد تطبیق داده شود؛ مکمل‌هایی مثل آهن، پتاسیم و ویتامین‌های محلول در چربی بدون ارزیابی مناسب ثبت نشوند.</p>
      </section>
    </div>
  );
}

function MedicationBuilder({ plan, query, category, group, onQuery, onCategory, onGroup, onAdd, onAddCustom, onUpdate, onRemove }: {
  plan: ClientPlan;
  query: string;
  category: string;
  group: "pct" | "bodybuilding";
  onQuery: (value: string) => void;
  onCategory: (value: string) => void;
  onGroup: (value: "pct" | "bodybuilding") => void;
  onAdd: (id: string) => void;
  onAddCustom: () => void;
  onUpdate: (id: string, patch: Partial<MedicationPlanItem>) => void;
  onRemove: (id: string) => void;
}) {
  const normalizedQuery=query.trim().toLowerCase();
  const results=MEDICATIONS.filter((item)=>{
    const searchable=`${item.nameFa} ${item.nameEn} ${item.aliases??""}`.toLowerCase();
    return item.group===group&&(!normalizedQuery||searchable.includes(normalizedQuery))&&(category==="همه"||item.category===category);
  });
  const selected=plan.medicationItems??[];
  const selectedDefinitionIds=new Set(selected.map((item)=>item.medicationId));
  return <div className="space-y-5">
    <section className="rounded-3xl border border-white/8 bg-card p-4 sm:p-5">
      <div className="flex flex-wrap items-start justify-between gap-3"><div><p className="text-xs font-bold text-amber-400">MEDICATION LIBRARY</p><h2 className="mt-1 text-xl font-black text-white">بانک دارو و PCT</h2><p className="mt-2 text-sm leading-6 text-zinc-500">دارو را انتخاب کن و دوز، زمان و بازهٔ هفته‌های مصرف را خودت ثبت کن.</p></div><Badge className="bg-amber-500 text-white">{MEDICATIONS.length.toLocaleString("fa-IR")} مورد</Badge></div>
      <div className="mt-4 grid grid-cols-2 gap-2 rounded-2xl bg-black/20 p-1"><button type="button" onClick={()=>{onGroup("pct");onCategory("همه");}} className={`min-h-12 touch-manipulation rounded-xl px-3 py-3 text-sm font-bold ${group==="pct"?"bg-amber-500 text-white":"text-zinc-400"}`}>پاک‌سازی و PCT</button><button type="button" onClick={()=>{onGroup("bodybuilding");onCategory("همه");}} className={`min-h-12 touch-manipulation rounded-xl px-3 py-3 text-sm font-bold ${group==="bodybuilding"?"bg-amber-500 text-white":"text-zinc-400"}`}>داروهای بدنسازی</button></div>
      <div className="relative mt-4"><Search className="absolute right-3 top-1/2 size-4 -translate-y-1/2 text-zinc-500"/><Input value={query} onChange={(event)=>onQuery(event.target.value)} placeholder={group==="pct"?"جست‌وجوی HCG، کلومیفن، تاموکسیفن...":"جست‌وجوی تستوسترون، ناندرولون، ترنبولون..."} className="h-12 border-white/10 bg-black/20 pr-10"/></div>
      <div className="mt-3 flex gap-2 overflow-x-auto pb-1 scrollbar-none">{MEDICATION_CATEGORIES.filter((item)=>item==="همه"||MEDICATIONS.some((drug)=>drug.group===group&&drug.category===item)).map((item)=><button type="button" key={item} onClick={()=>onCategory(item)} className={`min-h-11 shrink-0 touch-manipulation rounded-full border px-3 py-2 text-xs font-semibold ${category===item?"border-amber-500 bg-amber-500 text-white":"border-white/10 bg-white/[.025] text-zinc-400"}`}>{item}</button>)}</div>
      <div className="mt-4 grid max-h-[430px] gap-2 overflow-y-auto pr-1 sm:grid-cols-2">{results.map((item)=>{const isSelected=selectedDefinitionIds.has(item.id);return <article key={item.id} className={`flex items-center gap-3 rounded-2xl border p-3 transition ${isSelected?"border-emerald-500/55 bg-emerald-500/[.08]":"border-white/8 bg-white/[.025]"}`}><span className={`grid size-10 shrink-0 place-items-center rounded-xl ${isSelected?"bg-emerald-500/15 text-emerald-400":"bg-amber-500/10 text-amber-400"}`}><Syringe className="size-5"/></span><div className="min-w-0 flex-1"><h3 className="truncate text-sm font-bold text-zinc-100">{item.nameFa}</h3><p className="mt-1 truncate text-xs text-zinc-500" dir="ltr">{item.nameEn}</p><small className={`mt-1 block text-xs ${isSelected?"text-emerald-400":"text-zinc-600"}`}>{isSelected?"انتخاب شده — برای حذف دوباره بزن":item.category}</small></div><Button type="button" size="icon-lg" onClick={()=>onAdd(item.id)} className={`size-11 shrink-0 touch-manipulation rounded-full ${isSelected?"bg-emerald-600 hover:bg-emerald-500":"bg-amber-500 hover:bg-amber-500"}`} aria-label={`${isSelected?"حذف":"افزودن"} ${item.nameFa}`}>{isSelected?<Check/>:<Plus/>}</Button></article>})}{results.length===0&&<p className="col-span-full py-10 text-center text-sm text-zinc-500">موردی پیدا نشد؛ داروی شخصی اضافه کن.</p>}</div>
      <Button type="button" variant="outline" onClick={onAddCustom} className="mt-4 h-12 w-full touch-manipulation rounded-xl border-white/10"><Plus/> افزودن داروی شخصی</Button>
    </section>
    <section>
      <div className="mb-3"><h2 className="font-bold text-white">برنامه دارویی شاگرد</h2><p className="mt-1 text-xs text-zinc-500">{selected.length.toLocaleString("fa-IR")} مورد انتخاب شده</p></div>
      <div className="space-y-3">{selected.map((item,index)=><article key={item.id} className="rounded-3xl border border-white/8 bg-card p-4"><div className="mb-4 flex items-center justify-between gap-3"><div className="flex min-w-0 flex-1 items-center gap-3"><span className="grid size-9 shrink-0 place-items-center rounded-xl bg-amber-500 text-sm font-black text-white">{(index+1).toLocaleString("fa-IR")}</span><Input value={item.name} onChange={(event)=>onUpdate(item.id,{name:event.target.value})} className="h-12 min-w-0 border-white/10 bg-black/20 font-bold sm:h-10" aria-label="نام دارو"/><Badge variant="outline" className="shrink-0 border-amber-500/20 text-amber-300">{item.group==="pct"?"PCT":"دارویی"}</Badge></div><Button type="button" size="icon-lg" variant="ghost" onClick={()=>onRemove(item.id)} className="size-11 shrink-0 touch-manipulation text-zinc-600 hover:text-amber-300 sm:size-8" aria-label={`حذف ${item.name}`}><Trash2/></Button></div>
        <div className="grid gap-3 sm:grid-cols-4"><Field label="از هفته"><Input className="h-12 sm:h-9" value={item.startWeek} onChange={(event)=>onUpdate(item.id,{startWeek:event.target.value})} inputMode="numeric" placeholder="۱"/></Field><Field label="تا هفته"><Input className="h-12 sm:h-9" value={item.endWeek} onChange={(event)=>onUpdate(item.id,{endWeek:event.target.value})} inputMode="numeric" placeholder="۴"/></Field><Field label="دوز / مقدار"><Input className="h-12 sm:h-9" value={item.dose} onChange={(event)=>onUpdate(item.id,{dose:event.target.value})} placeholder="مقدار تجویزشده"/></Field><Field label="دفعات"><Input className="h-12 sm:h-9" value={item.frequency} onChange={(event)=>onUpdate(item.id,{frequency:event.target.value})} placeholder="مثلاً هفته‌ای ۲ بار"/></Field><div className="sm:col-span-2"><Field label="زمان مصرف"><Input className="h-12 sm:h-9" value={item.timing} onChange={(event)=>onUpdate(item.id,{timing:event.target.value})} placeholder="روزها یا ساعت مصرف"/></Field></div><div className="sm:col-span-2"><Field label="توضیحات"><Textarea value={item.notes} onChange={(event)=>onUpdate(item.id,{notes:event.target.value})} placeholder="نکته، پایش آزمایش یا هشدار..." className="min-h-20"/></Field></div></div>
      </article>)}</div>
      {selected.length===0&&<div className="grid min-h-40 place-items-center rounded-3xl border border-dashed border-white/12 text-center text-sm text-zinc-500">از بانک بالا اولین مورد را انتخاب کن.</div>}
      <p className="mt-4 rounded-2xl border border-amber-500/20 bg-amber-500/[.06] p-4 text-xs leading-6 text-amber-100/80">این بخش فقط برای ثبت نسخه و پایش است. انتخاب دارو، دوز و مدت باید براساس آزمایش، وضعیت پزشکی و نظر پزشک انجام شود.</p>
    </section>
  </div>;
}


function ProgramBank({ templates, clients, activeClientId, usage, currentProgramNumber, onApply, onSaveCurrent, onDeleteCustom }: {
  templates: ProgramTemplate[];
  clients: Client[];
  activeClientId: string;
  usage: Record<string, number[]>;
  currentProgramNumber?: number;
  onApply: (template: ProgramTemplate, clientId: string, alreadyUsed?: boolean) => void;
  onSaveCurrent: () => void;
  onDeleteCustom: (templateId: string) => void;
}) {
  const [query,setQuery]=useState("");
  const [kind,setKind]=useState<"all"|ProgramTemplate["kind"]>("all");
  const [targetClientId,setTargetClientId]=useState(activeClientId);
  useEffect(()=>setTargetClientId(activeClientId),[activeClientId]);
  const selectedClient=clients.find((client)=>client.id===targetClientId)??clients[0];
  const [remoteUsed,setRemoteUsed]=useState<number[]>([]);
  useEffect(()=>{if(!selectedClient?.id){setRemoteUsed([]);return;}let cancelled=false;fetch(`/api/program-assignments?clientId=${encodeURIComponent(selectedClient.id)}`,{cache:"no-store"}).then(async r=>r.ok?r.json():{assignments:[]}).then((data:{assignments?:Array<{program_number:number}>})=>{if(!cancelled)setRemoteUsed((data.assignments??[]).map(item=>Number(item.program_number)).filter(Number.isFinite));}).catch(()=>{if(!cancelled)setRemoteUsed([]);});return()=>{cancelled=true};},[selectedClient?.id]);
  const usedNumbers=new Set([...(usage[selectedClient?.id]??[]),...remoteUsed]);
  const normalized=query.trim().toLowerCase();
  const visible=templates.filter((template)=>{
    const matchesKind=kind==="all"||template.kind===kind;
    const matchesQuery=!normalized||`${template.number} ${template.title} ${template.description}`.toLowerCase().includes(normalized);
    return matchesKind&&matchesQuery;
  });
  const filters:["all"|ProgramTemplate["kind"],string][]=[["all","همه"],["split-4","۱۰۰ برنامه ۴ روزه"],["single-5","۱۰۰ برنامه ۵ روزه"],["beginner-fullbody","۳۰ فول‌بادی مبتدی"],["mass","۵۰ حجم"],["cut","۵۰ کات"],["back-friendly","۱۰ دیسک کمر"],["beginner-4","۲۵ مبتدی ۴ روزه"],["beginner-5","۲۵ مبتدی ۵ روزه"],["professional-4","۵۰ حرفه‌ای ۴ روزه"],["professional-5","۵۰ حرفه‌ای ۵ روزه"],["custom","برنامه‌های من"]];
  return <div>
    <PageTitle eyebrow="PROGRAM BANK" title="بانک برنامه‌ها" description="۴۹۰ قالب آماده + برنامه‌هایی که خودت ذخیره می‌کنی. شماره برنامه فقط در پنل مربی دیده می‌شود." action={<Button onClick={onSaveCurrent} className="bg-amber-500 hover:bg-amber-500"><Plus/> ذخیره برنامه فعلی در بانک</Button>}/>
    <section className="mb-5 grid gap-3 rounded-3xl border border-white/8 bg-card p-4 sm:grid-cols-[1fr_260px]">
      <div className="relative"><Search className="absolute right-3 top-1/2 size-4 -translate-y-1/2 text-zinc-500"/><Input value={query} onChange={(event)=>setQuery(event.target.value)} className="h-12 pr-10" placeholder="شماره یا نام برنامه را جست‌وجو کن..."/></div>
      <Select value={targetClientId} onValueChange={setTargetClientId}><SelectTrigger className="h-12"><SelectValue placeholder="شاگرد مقصد"/></SelectTrigger><SelectContent>{clients.map((client)=><SelectItem key={client.id} value={client.id}>{client.name}</SelectItem>)}</SelectContent></Select>
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none sm:col-span-2">{filters.map(([value,label])=><button key={value} type="button" onClick={()=>setKind(value)} className={`min-h-10 shrink-0 rounded-full border px-3 text-xs font-bold ${kind===value?"border-amber-500 bg-amber-500 text-white":"border-white/10 text-zinc-400"}`}>{label}</button>)}</div>
      <div className="sm:col-span-2 flex flex-wrap items-center gap-2 text-xs text-zinc-500"><span>{visible.length.toLocaleString("fa-IR")} برنامه</span>{currentProgramNumber&&<Badge className="bg-emerald-600/15 text-emerald-400">برنامه فعلی: {currentProgramNumber.toLocaleString("fa-IR")}</Badge>}{selectedClient&&<span>مقصد: <strong className="text-zinc-300">{selectedClient.name}</strong></span>}</div>
    </section>
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
      {visible.map((template)=>{const used=usedNumbers.has(template.number);return <article key={template.id} className={`rounded-3xl border p-4 ${used?"border-amber-500/35 bg-amber-500/[.04]":"border-white/8 bg-card"}`}>
        <div className="flex items-start justify-between gap-3"><div><div className="flex items-center gap-2"><Badge className="bg-amber-500 text-white">برنامه {template.number.toLocaleString("fa-IR")}</Badge>{template.custom&&<Badge variant="outline" className="border-violet-500/30 text-violet-300">شخصی</Badge>}{used&&<Badge variant="outline" className="border-amber-500/30 text-amber-300">قبلاً استفاده شده</Badge>}</div><h3 className="mt-3 font-black text-white">{template.title}</h3><p className="mt-2 text-xs leading-6 text-zinc-500">{template.description}</p></div>{template.custom&&<Button type="button" size="icon" variant="ghost" className="text-zinc-600 hover:text-amber-300" onClick={()=>{if(window.confirm("این قالب شخصی از بانک حذف شود؟"))onDeleteCustom(template.id)}}><Trash2/></Button>}</div>
        <div className="mt-4 flex items-center justify-between rounded-2xl bg-black/20 px-3 py-2 text-xs"><span className="text-zinc-500">جلسه در هفته</span><strong className="text-zinc-200">{template.daysPerWeek.toLocaleString("fa-IR")}</strong></div>
        <Button type="button" onClick={()=>selectedClient&&onApply(template,selectedClient.id,used)} disabled={!selectedClient} className={`mt-4 h-11 w-full ${used?"bg-amber-600 hover:bg-amber-500":"bg-amber-500 hover:bg-amber-500"}`}>{used?<><History/> کپی مجدد با هشدار</>:<><ClipboardList/> کپی برای {selectedClient?.name??"شاگرد"}</>}</Button>
      </article>})}
    </div>
    {!visible.length&&<div className="mt-5 rounded-3xl border border-dashed border-white/10 p-10 text-center text-sm text-zinc-500">برنامه‌ای با این فیلتر پیدا نشد.</div>}
  </div>;
}

type ExerciseLibraryProps = {
  query: string;
  category: string;
  categories: string[];
  exercises: Exercise[];
  totalCount: number;
  onQuery: (value: string) => void;
  onCategory: (value: string) => void;
  onNewCustom: () => void;
  onReplaceImage: (exerciseId: string, file: File) => Promise<void>;
  onAdd: (exerciseId: string) => void;
};

function ExerciseLibrary({ query, category, categories, exercises, totalCount, onQuery, onCategory, onNewCustom, onReplaceImage, onAdd }: ExerciseLibraryProps) {
  const [missingImageIds,setMissingImageIds]=useState<Set<string>>(()=>new Set());
  const [uploadingId,setUploadingId]=useState("");
  const upload=async(exerciseId:string,file?:File)=>{if(!file)return;setUploadingId(exerciseId);try{await onReplaceImage(exerciseId,file);setMissingImageIds((current)=>{const next=new Set(current);next.delete(exerciseId);return next;});}catch(error){window.alert(error instanceof Error?error.message:"آپلود عکس انجام نشد.");}finally{setUploadingId("");}};
  return (
    <div>
      <PageTitle eyebrow="EXERCISE LIBRARY" title="بانک حرکات" description={`${totalCount} حرکت در بانک ثبت شده؛ موارد «عکس ندارد» را می‌توانی مستقیم همین‌جا آپلود کنی.`} action={<Button onClick={onNewCustom} className="shrink-0 bg-amber-500 hover:bg-amber-500"><ImagePlus /> حرکت شخصی</Button>} />
      <div className="sticky top-20 z-20 rounded-2xl border border-white/8 bg-[#0b0c0e]/95 p-3 backdrop-blur lg:top-4">
        <div className="relative"><Search className="absolute right-3 top-1/2 size-4 -translate-y-1/2 text-zinc-500" /><Input value={query} onChange={(event) => onQuery(event.target.value)} placeholder="جست‌وجوی حرکت..." className="h-12 rounded-xl pr-10" /></div>
        <div className="mt-3 flex gap-2 overflow-x-auto scrollbar-none">{categories.map((item) => <button key={item} onClick={() => onCategory(item)} className={`min-h-11 shrink-0 touch-manipulation rounded-full border px-3 py-1.5 text-xs ${category === item ? "border-amber-500 bg-amber-500 text-white" : "border-white/10 text-zinc-500"}`}>{item}</button>)}</div>
      </div>
      <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
        {exercises.map((exercise) => (
          <article key={exercise.id} className="group overflow-hidden rounded-2xl border border-white/8 bg-card">
            <div className="relative aspect-[4/3] bg-white p-1"><img src={exercise.image} alt={exercise.nameFa} loading="lazy" onLoad={(event)=>{if(exercise.image!=="/file.svg"&&event.currentTarget.naturalWidth>20)setMissingImageIds((current)=>{const next=new Set(current);next.delete(exercise.id);return next;});}} onError={(event)=>{event.currentTarget.onerror=null;event.currentTarget.src="/file.svg";setMissingImageIds((current)=>new Set(current).add(exercise.id));}} className="h-full w-full object-contain transition duration-300 group-hover:scale-[1.03]" />{exercise.custom && <span className="absolute right-2 top-2 rounded-full bg-amber-500 px-2 py-1 text-[9px] font-bold text-white">شخصی</span>}{(missingImageIds.has(exercise.id)||exercise.image==="/file.svg")&&<span className="absolute left-2 top-2 rounded-full bg-amber-500 px-2 py-1 text-[9px] font-bold text-black">عکس ندارد</span>}</div>
            <div className="p-3">
              <Badge variant="outline" className="border-white/10 text-[9px] text-zinc-500">{exercise.category}</Badge>
              <h3 className="mt-2 truncate text-sm font-bold text-zinc-100">{exercise.nameFa}</h3>
              <p className="mt-1 truncate text-[10px] text-zinc-600" dir="ltr">{exercise.nameEn}</p>
              <div className="mt-3 grid grid-cols-2 gap-2"><Button onClick={() => onAdd(exercise.id)} className="h-11 touch-manipulation rounded-xl bg-amber-500/10 text-amber-300 hover:bg-amber-500 hover:text-white"><Plus /> افزودن</Button><label className="flex h-11 cursor-pointer items-center justify-center gap-1 rounded-xl border border-white/10 px-2 text-[11px] font-bold text-zinc-400 hover:border-emerald-500/30 hover:text-emerald-300">{uploadingId===exercise.id?<LoaderCircle className="size-4 animate-spin"/>:<ImagePlus className="size-4"/>}{missingImageIds.has(exercise.id)||exercise.image==="/file.svg"?"آپلود عکس":"تعویض عکس"}<input type="file" accept="image/*" className="hidden" disabled={uploadingId===exercise.id} onChange={(event)=>{const file=event.target.files?.[0];void upload(exercise.id,file);event.currentTarget.value="";}}/></label></div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}

function Guide({ coachName, status }: { coachName: string; status: SaveStatus }) {
  const logout = async () => {
    try { await fetch("/api/auth/logout", { method: "POST" }); }
    finally { window.location.assign("/"); }
  };

  return (
    <div>
      <PageTitle eyebrow="SETUP & GUIDE" title="راهنمای استفاده روی گوشی" description="این وب‌اپ بدون نصب از اپ‌استور روی آیفون یا اندروید مثل برنامه باز می‌شود." />
      <div className="grid gap-4 lg:grid-cols-2">
        <section className="rounded-3xl border border-white/8 bg-card p-5">
          <div className="grid size-12 place-items-center rounded-2xl bg-amber-500/10 text-amber-400"><Smartphone /></div>
          <h2 className="mt-4 font-bold text-white">اضافه کردن به صفحه اصلی آیفون</h2>
          <ol className="mt-4 space-y-3 text-sm leading-6 text-zinc-400">
            <li><b className="ml-2 text-amber-400">۱</b>لینک را با Safari باز کنید.</li>
            <li><b className="ml-2 text-amber-400">۲</b>دکمه Share را پایین صفحه بزنید.</li>
            <li><b className="ml-2 text-amber-400">۳</b>گزینه Add to Home Screen را انتخاب کنید.</li>
          </ol>
        </section>
        <section className="rounded-3xl border border-white/8 bg-card p-5">
          <div className="grid size-12 place-items-center rounded-2xl bg-amber-500/10 text-amber-400"><FileDown /></div>
          <h2 className="mt-4 font-bold text-white">ارسال PDF در واتساپ</h2>
          <ol className="mt-4 space-y-3 text-sm leading-6 text-zinc-400">
            <li><b className="ml-2 text-amber-400">۱</b>داخل برنامه روی «خروجی PDF» بزنید.</li>
            <li><b className="ml-2 text-amber-400">۲</b>در پیش‌نمایش چاپ، صفحه را با دو انگشت باز کنید.</li>
            <li><b className="ml-2 text-amber-400">۳</b>Share و سپس WhatsApp را بزنید؛ خود فایل ارسال می‌شود.</li>
          </ol>
        </section>
        <section className="rounded-3xl border border-white/8 bg-card p-5 lg:col-span-2">
          <div className="flex items-center justify-between gap-3">
            <div><p className="text-xs text-zinc-500">حساب مربی</p><p className="mt-1 font-bold text-zinc-100">{coachName}</p></div>
            <div className="flex items-center gap-3">
              <SaveIndicator status={status} />
              <Button variant="outline" size="sm" onClick={logout} className="border-white/10 text-zinc-400"><LogOut /> خروج</Button>
            </div>
          </div>
          <p className="mt-4 border-t border-white/8 pt-4 text-xs leading-6 text-zinc-500">نسخه فعلی مخصوص پنل مربی است. شاگرد فقط فایل PDF را دریافت می‌کند و برای دیدن برنامه نیازی به حساب یا لینک ندارد.</p>
        </section>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <label className="block"><span className="mb-1.5 block text-xs text-zinc-500">{label}</span>{children}</label>;
}

function CompactField({ label, children }: { label: string; children: React.ReactNode }) {
  return <label className="block"><span className="mb-1.5 block text-[10px] text-zinc-500">{label}</span>{children}</label>;
}
