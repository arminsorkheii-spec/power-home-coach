# Male exercise demonstrations — 94.0.1

290 male-only H.264 MP4 demonstrations, 57 explicit reviewed default exercise mappings. Coach can preview and assign remaining clips in the existing exercise library. No fuzzy automatic mapping or female fallback. No AI Coach code is included.

Videos open only on request in a native-control modal in student program and live-workout views. Same-origin authenticated endpoint supports byte ranges for seeking/iOS. Assets live outside the image in APP_DATA_DIR/exercise-videos/male. Coach overrides use the existing state store; no schema migration.

Source: https://github.com/harshvishu/free-exercise-db-with-videos
Metadata blob: bb3ec631c391f7e4cd709850d8446792f93aa372
Upstream README states MIT for code and metadata; asset provenance and original/final SHA-256 are recorded in male-video-assets.json. This records provenance, not an independent sublicense verification. Copied at the site owner's explicit request.

Optimization: original total 200000571 bytes; final 41451706 bytes. H.264, yuv420p, height <=720, CRF28, faststart, no audio. Full durations retained. All 290 files inspected using ffprobe; bench press sample visually checked.

Validation: production build passed; all 165 tests passed (162 existing + 3 video tests covering catalog, range requests, authentication and file access constraints). Actual live authenticated playback must be checked after installation.

Rollback: retain prior Docker image and database/source backups. Retag rollback image as latest and recreate app; added video files can remain harmlessly in the data directory. Do not delete student files or dependency cache.
