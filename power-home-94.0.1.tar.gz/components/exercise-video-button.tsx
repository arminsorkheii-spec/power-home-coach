"use client";

import * as React from "react";
import { AlertCircle, Play, Video } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export type MaleExerciseVideo = {
  /** A male-only video authorized for use in Power Home Coach. */
  maleVideoUrl: string;
  malePosterUrl?: string | null;
  attribution?: string | null;
};

export type ExerciseVideoButtonProps = {
  exerciseName: string;
  video?: MaleExerciseVideo | null;
  className?: string;
};

function safeMediaUrl(candidate?: string | null): string | undefined {
  if (!candidate) return undefined;
  const value = candidate.trim();
  if (!value || value.startsWith("//") || value.startsWith("\\")) return undefined;
  if (value.startsWith("/") && !value.includes("\\") && !value.includes("..")) return value;
  try {
    const parsed = new URL(value);
    return parsed.protocol === "https:" ? parsed.toString() : undefined;
  } catch {
    return undefined;
  }
}

/**
 * Add to the student workout row next to the exercise name.
 * Renders no button if a verified male-only video has not been assigned.
 * Does not alter existing workout rows, print output, or exercise data.
 */
export function ExerciseVideoButton({
  exerciseName,
  video,
  className,
}: ExerciseVideoButtonProps) {
  const [open, setOpen] = React.useState(false);
  const [failed, setFailed] = React.useState(false);
  const videoUrl = safeMediaUrl(video?.maleVideoUrl);
  const posterUrl = safeMediaUrl(video?.malePosterUrl);

  React.useEffect(() => {
    if (open) setFailed(false);
  }, [open, videoUrl]);

  if (!videoUrl) return null;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button
          type="button"
          className={[
            "inline-flex min-h-10 items-center justify-center gap-2 rounded-xl border",
            "border-zinc-600 bg-zinc-800 px-3 py-2 text-sm font-semibold text-zinc-100",
            "transition-colors hover:border-zinc-400 hover:bg-zinc-700",
            "focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-500",
            className ?? "",
          ].join(" ")}
          aria-label={`پخش ویدئوی حرکت ${exerciseName}`}
        >
          <Play aria-hidden="true" className="h-4 w-4" fill="currentColor" />
          نمایش ویدئو
        </button>
      </DialogTrigger>
      <DialogContent
        dir="rtl"
        className="exercise-video-dialog w-[min(95vw,680px)] max-w-[680px] gap-3 border-zinc-700 bg-zinc-950 p-4 text-zinc-100 sm:p-5"
      >
        <DialogHeader className="pr-1 text-right sm:text-right">
          <DialogTitle className="flex items-center gap-2 text-base font-bold sm:text-lg">
            <Video className="h-5 w-5 text-red-500" aria-hidden="true" />
            {exerciseName}
          </DialogTitle>
          <DialogDescription className="text-right text-xs text-zinc-400">
            ویدئوی آموزشی اجرای صحیح حرکت — مدل مردانه
          </DialogDescription>
        </DialogHeader>
        <div className="overflow-hidden rounded-xl border border-zinc-800 bg-black">
          {open && !failed ? (
            <video
              key={videoUrl}
              controls
              playsInline
              preload="metadata"
              poster={posterUrl}
              className="aspect-video w-full bg-black object-contain"
              aria-label={`ویدئوی اجرای ${exerciseName}`}
              onError={() => setFailed(true)}
            >
              <source src={videoUrl} />
              مرورگر شما از پخش این ویدئو پشتیبانی نمی‌کند.
            </video>
          ) : (
            <div className="flex aspect-video flex-col items-center justify-center gap-3 p-6 text-center text-sm text-zinc-300" role="alert">
              <AlertCircle className="h-7 w-7 text-amber-400" aria-hidden="true" />
              بارگذاری ویدئو امکان‌پذیر نیست. لطفاً بعداً دوباره امتحان کنید.
            </div>
          )}
        </div>
        {video?.attribution ? (
          <p className="text-center text-xs text-zinc-400">{video.attribution}</p>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}
