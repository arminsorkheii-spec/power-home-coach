'use client';
import {ExerciseVideoButton} from './exercise-video-button';import {MALE_VIDEO_CATALOG,videoForExercise} from '@/lib/exercise-videos';
export function ExerciseDemoButton({exerciseId,name,videoId}:{exerciseId:string;name:string;videoId?:string|null}){const video=videoId===undefined?videoForExercise(exerciseId):videoId&&Object.hasOwn(MALE_VIDEO_CATALOG,videoId)?MALE_VIDEO_CATALOG[videoId as keyof typeof MALE_VIDEO_CATALOG]:null;return <ExerciseVideoButton exerciseName={name} video={video?{maleVideoUrl:'/api/exercise-videos/'+video.file}:null}/>}
