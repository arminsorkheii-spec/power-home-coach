USDA FoodData Central — SR Legacy April 2018
https://fdc.nal.usda.gov/download-datasets/
https://fdc.nal.usda.gov/fdc-datasets/FoodData_Central_sr_legacy_food_json_2018-04.zip
License: CC0 1.0. Nutrients per 100 g edible portion. Food state and official gram weights retained. Persian aliases aid discovery; original description is authoritative. Missing nutrients remain null; no zero imputation.
Source SHA256: 0fe8ae486a2c8eb42cb96413f058deb51863a46c8fb8eeb4b1fb45006dd338ef
Records: 7793

30 transparent example Iranian recipes added. Not lab measurements. Ingredient USDA IDs, gram weights and assumed final cooked yields are included. Recipe variants and substitutions are explicit in dish names; coaches must adjust for their actual recipe. No generic cup or serving weights have been fabricated.

30 transparent example Iranian recipes added. Not lab measurements. Ingredient USDA IDs, gram weights and assumed final cooked yields are included. Recipe variants and substitutions are explicit in dish names; coaches must adjust for their actual recipe. No generic cup or serving weights have been fabricated.
