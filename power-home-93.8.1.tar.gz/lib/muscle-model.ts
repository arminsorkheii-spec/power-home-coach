import type {MuscleId} from '@/lib/muscle-data';
export type BodyPart={group:MuscleId|null;center:[number,number,number];scale:[number,number,number];tilt?:number};
// Original procedural 3D mannequin: selectable training regions, not an anatomical scan.
export const BODY_PARTS:BodyPart[]=[
 {group:null,center:[0,2.55,0],scale:[.26,.34,.25]}, {group:null,center:[0,2.15,0],scale:[.17,.18,.17]},
 {group:null,center:[0,1.35,-.04],scale:[.47,.77,.23]}, {group:null,center:[0,.4,0],scale:[.42,.36,.24]},
 ...[-1,1].flatMap(side=>[
 {group:'chest' as const,center:[side*.245,1.77,.235] as [number,number,number],scale:[.265,.24,.11] as [number,number,number],tilt:side*.08},
 {group:'shoulders' as const,center:[side*.58,1.85,0] as [number,number,number],scale:[.22,.26,.255] as [number,number,number],tilt:side*.1},
 {group:'biceps' as const,center:[side*.74,1.37,.13] as [number,number,number],scale:[.16,.34,.16] as [number,number,number],tilt:side*.23},
 {group:'triceps' as const,center:[side*.73,1.37,-.13] as [number,number,number],scale:[.18,.36,.15] as [number,number,number],tilt:side*.23},
 {group:'forearms' as const,center:[side*.91,.77,.03] as [number,number,number],scale:[.135,.33,.135] as [number,number,number],tilt:side*.19},
 {group:null,center:[side*1.0,.33,.04] as [number,number,number],scale:[.12,.18,.09] as [number,number,number]},
 {group:'back' as const,center:[side*.27,1.48,-.25] as [number,number,number],scale:[.25,.47,.11] as [number,number,number],tilt:-side*.12},
 {group:'traps' as const,center:[side*.21,2.03,-.16] as [number,number,number],scale:[.23,.18,.105] as [number,number,number],tilt:side*.3},
 {group:'lowerback' as const,center:[side*.12,.96,-.24] as [number,number,number],scale:[.12,.29,.09] as [number,number,number]},
 {group:'glutes' as const,center:[side*.215,.34,-.205] as [number,number,number],scale:[.25,.29,.18] as [number,number,number]},
 {group:'quads' as const,center:[side*.26,-.28,.12] as [number,number,number],scale:[.235,.56,.22] as [number,number,number],tilt:side*.03},
 {group:'hamstrings' as const,center:[side*.26,-.28,-.14] as [number,number,number],scale:[.22,.53,.17] as [number,number,number],tilt:side*.03},
 {group:'adductors' as const,center:[side*.12,-.13,.02] as [number,number,number],scale:[.13,.39,.16] as [number,number,number],tilt:-side*.04},
 {group:null,center:[side*.265,-.9,.035] as [number,number,number],scale:[.16,.16,.155] as [number,number,number]},
 {group:'calves' as const,center:[side*.265,-1.36,-.045] as [number,number,number],scale:[.17,.42,.17] as [number,number,number]},
 {group:null,center:[side*.265,-1.88,.11] as [number,number,number],scale:[.145,.13,.29] as [number,number,number]},
 ]),
 ...[.75,1.04,1.33,1.58].flatMap(y=>[-1,1].map(side=>({group:'core' as const,center:[side*.105,y,.247] as [number,number,number],scale:[.103,.125,.062] as [number,number,number]})))
];
export function ellipsoid(part:BodyPart,rings=16,sectors=22){const vertices:number[]=[],normals:number[]=[];const angle=part.tilt??0,cos=Math.cos(angle),sin=Math.sin(angle);function point(i:number,j:number){const theta=i/rings*Math.PI,phi=j/sectors*Math.PI*2;const raw=[Math.sin(theta)*Math.cos(phi),Math.cos(theta),Math.sin(theta)*Math.sin(phi)];const x=raw[0]*part.scale[0],y=raw[1]*part.scale[1],z=raw[2]*part.scale[2];const n=[raw[0]/part.scale[0],raw[1]/part.scale[1],raw[2]/part.scale[2]],length=Math.hypot(...n);return {p:[cos*x-sin*y+part.center[0],sin*x+cos*y+part.center[1],z+part.center[2]],n:[(cos*n[0]-sin*n[1])/length,(sin*n[0]+cos*n[1])/length,n[2]/length]}}
 for(let i=0;i<rings;i++)for(let j=0;j<sectors;j++){const a=point(i,j),b=point(i+1,j),c=point(i,j+1),d=point(i+1,j+1);for(const vertex of [a,b,c,c,b,d]){vertices.push(...vertex.p);normals.push(...vertex.n)}}return {vertices:new Float32Array(vertices),normals:new Float32Array(normals)}
}
