export type NoticeTarget={type:string;url?:string;application_id?:string|null;actor_client_id?:string|null;recipient_client_id?:string|null};
const applicationEvents=new Set(['registration','welcome','program_request','request_completed','payment_received','payment_receipt','payment_receipt_sent','payment_review','payment_approved','awaiting_payment','program_writing']);
export function notificationTarget(role:'coach'|'student',notice:NoticeTarget){
 const params=new URLSearchParams();
 if(role==='coach'){
  if(notice.type==='movement_video')params.set('view','media');
  else if(notice.type==='appointment_reserved')params.set('view','club');
  else if(notice.type==='exercise_replacement')params.set('view','replacements');
  else if(notice.type==='weekly_report')params.set('view','reports');
  else if(notice.type==='program_expiring'||notice.type==='program_expired')params.set('view','client');
  else if(notice.type==='chat_message'||notice.type==='message')params.set('view','chat');
  else if(applicationEvents.has(notice.type)||notice.type==='program_delivered')params.set('view','applications');
  else params.set('view','notifications');
  if(notice.actor_client_id)params.set('client',notice.actor_client_id);
 }else params.set('section',notice.type==='movement_review'||notice.type==='private_reminder'?'life':notice.type==='payment_due'?'request':notice.type==='exercise_replacement_answer'?'training':notice.type==='chat_message'||notice.type==='message'?'chat':notice.type==='weekly_checkin_due'?'wellness':notice.type==='program_expiring'||notice.type==='program_expired'?'renewal':notice.type==='program_delivered'?'program':applicationEvents.has(notice.type)?'request':'notifications');
 if(role==='student'&&notice.type==='private_reminder')params.set('life','planner');
 if(role==='student'&&notice.type==='movement_review')params.set('life','club');
 if(notice.application_id)params.set('application',notice.application_id);
 return `/${role}?${params}`;
}
export function coachDestination(value:string){
 const url=new URL(value,'https://portal.local');if(url.origin!=='https://portal.local'||url.pathname!=='/coach')return null;
 const view=url.searchParams.get('view');if(!view||!['media','club','food','applications','chat','client','builder','notifications','sms','pricing','accounting','home','command','dashboard','companion','replacements','reports'].includes(view))return null;
 return {view,clientId:url.searchParams.get('client')??'',applicationId:url.searchParams.get('application')??''};
}
