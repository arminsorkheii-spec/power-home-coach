export const DATA_UPDATED_EVENT='power-data-updated';
export type RefreshClock={now:()=>number;schedule:(run:()=>void,delay:number)=>unknown;cancel:(id:unknown)=>void};
/** Completion-based polling, coalesced wakeups and no background or overlapping requests. */
export function createRefreshLoop({refresh,canRefresh,intervalMs,clock,initial=false}:{refresh:()=>Promise<unknown>|unknown;canRefresh:()=>boolean;intervalMs:number;clock:RefreshClock;initial?:boolean}){
 let stopped=false,running=false,pending=false,last=-Infinity,timer:unknown;
 const later=(delay:number)=>{if(stopped)return;if(timer!==undefined)clock.cancel(timer);timer=clock.schedule(()=>{timer=undefined;void run()},delay)};
 const run=async()=>{if(stopped)return;if(!canRefresh()){later(intervalMs);return}if(running){pending=true;return}const wait=1000-(clock.now()-last);if(wait>0){later(wait);return}running=true;last=clock.now();try{await refresh()}catch{/* Existing data stays available; the next wakeup retries. */}finally{running=false;if(!stopped){const delay=pending?Math.max(0,1000-(clock.now()-last)):intervalMs;pending=false;later(delay)}}};
 if(initial)later(0);else later(intervalMs);
 return {trigger:()=>{if(stopped)return;if(running){pending=true;return}later(Math.max(0,1000-(clock.now()-last)))},stop:()=>{stopped=true;pending=false;if(timer!==undefined)clock.cancel(timer)}};
}
export function notifyDataUpdated(){if(typeof window!=='undefined')window.dispatchEvent(new Event(DATA_UPDATED_EVENT))}
