import { createHmac, randomInt, randomUUID, randomBytes, timingSafeEqual } from "node:crypto";
import { database } from "@/lib/raw-db";
import { normalizePhone } from "@/lib/student-auth";
import { getSmsSettings, sendSmsTemplate } from "@/lib/sms";

export class OtpError extends Error {
  constructor(message:string,public status=400,public retryAfter=0){super(message);}
}
function digest(value:string) {
  if(!process.env.APP_SESSION_SECRET)throw new OtpError("سرویس ورود پیامکی هنوز آماده نیست.",503);
  return createHmac("sha256",process.env.APP_SESSION_SECRET).update(value).digest("hex");
}
function rate(key:string,limit:number,seconds:number) {
  const now=Math.floor(Date.now()/1000),hash=digest(key);
  const row=database().prepare("INSERT INTO sms_rate_limits (key,count,reset_at) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET count=CASE WHEN reset_at<=? THEN 1 ELSE count+1 END,reset_at=CASE WHEN reset_at<=? THEN ? ELSE reset_at END RETURNING count,reset_at")
    .bind(hash,now+seconds,now,now,now+seconds).first<{count:number;reset_at:number}>();
  if(!row||row.count>limit)throw new OtpError("تلاش‌های زیاد؛ کمی بعد دوباره امتحان کنید.",429,Math.max(1,(row?.reset_at??now+seconds)-now));
}
export function requestIp(request:Request){return request.headers.get("cf-connecting-ip")??request.headers.get("x-forwarded-for")?.split(",")[0]?.trim()??"unknown";}
export async function requestStudentCode(value:string,ip:string,purpose:"login"|"registration"="login") {
  const settings=getSmsSettings();
  if(!settings.loginEnabled)throw new OtpError("ورود پیامکی هنوز فعال نشده است.",503);
  const phone=normalizePhone(value);
  if(!/^09\d{9}$/.test(phone))throw new OtpError("شماره موبایل را درست وارد کنید.");
  rate("send-global",200,3600);
  rate("send-ip:"+ip,12,3600);
  const now=Date.now(),db=database();
  db.prepare("DELETE FROM student_login_codes WHERE expires_at<?").bind(now-86_400_000).run();
  db.prepare("DELETE FROM sms_rate_limits WHERE reset_at<?").bind(Math.floor(now/1000)-3600).run();
  const previous=db.prepare("SELECT next_send_at FROM student_login_codes WHERE phone=?").bind(phone).first<{next_send_at:number}>();
  if(previous&&previous.next_send_at>now)throw new OtpError("برای ارسال دوباره کد کمی صبر کنید.",429,Math.ceil((previous.next_send_at-now)/1000));
  rate("send-phone:"+phone,6,3600);
  const account=db.prepare("SELECT client_id FROM student_accounts WHERE phone=?").bind(phone).first();
  if(purpose==="registration"&&account)throw new OtpError("این شماره قبلاً ثبت شده؛ از صفحه ورود شاگرد وارد شوید.",409);
  const challengeId=randomUUID(),code=String(randomInt(100000,1_000_000));
  const codeHash=digest(`${purpose==="login"?"otp":"registration-otp"}:${phone}:${challengeId}:${code}`);
  const reserved=db.prepare("INSERT INTO student_login_codes (phone,challenge_id,code_hash,expires_at,next_send_at,attempts,ready) VALUES (?,?,?,?,?,0,0) ON CONFLICT(phone) DO UPDATE SET challenge_id=excluded.challenge_id,code_hash=excluded.code_hash,expires_at=excluded.expires_at,next_send_at=excluded.next_send_at,attempts=0,ready=0 WHERE next_send_at<=? RETURNING challenge_id")
    .bind(phone,challengeId,codeHash,now+300_000,now+60_000,now).first<{challenge_id:string}>();
  if(!reserved)throw new OtpError("برای ارسال دوباره کد کمی صبر کنید.",429,60);
  if(account||purpose==="registration"){
    try{
      await sendSmsTemplate(phone,settings.otpTemplateId,settings.otpParameter,code);
      db.prepare("UPDATE student_login_codes SET ready=1 WHERE phone=? AND challenge_id=?").bind(phone,challengeId).run();
    }catch{
      db.prepare("UPDATE student_login_codes SET code_hash='',ready=0 WHERE phone=? AND challenge_id=?").bind(phone,challengeId).run();
      throw new OtpError("ارسال کد انجام نشد؛ پس از یک دقیقه دوباره تلاش کنید یا به مربی اطلاع بدهید.",503,60);
    }
  }
  // Unknown numbers receive the same public response, with no SMS or usable challenge.
  return {challengeId,expiresIn:300,retryAfter:60,message:purpose==="registration"?"کد تأیید شماره موبایل ارسال شد.":"اگر این شماره در سایت ثبت شده باشد، کد ورود برای آن ارسال می‌شود."};
}
function verifyCode(value:string,challengeId:string,code:string,ip:string,purpose:"login"|"registration") {
  const phone=normalizePhone(value),db=database(),now=Date.now();
  if(!/^09\d{9}$/.test(phone)||!/^\d{6}$/.test(code)||!challengeId||challengeId.length>80)throw new OtpError("شماره موبایل و کد ۶ رقمی را درست وارد کنید.");
  rate("verify-ip:"+ip,40,900);rate("verify-phone:"+phone,15,900);
  const row=db.prepare("UPDATE student_login_codes SET attempts=attempts+1 WHERE phone=? AND challenge_id=? AND ready=1 AND expires_at>? AND attempts<5 RETURNING code_hash")
    .bind(phone,challengeId,now).first<{code_hash:string}>();
  const expected=digest(`${purpose==="login"?"otp":"registration-otp"}:${phone}:${challengeId}:${code}`);
  if(!row||row.code_hash.length!==expected.length||!timingSafeEqual(Buffer.from(row.code_hash),Buffer.from(expected)))throw new OtpError("کد ورود نادرست یا منقضی شده است.",401);
  const consumed=db.prepare("DELETE FROM student_login_codes WHERE phone=? AND challenge_id=? AND code_hash=? AND ready=1 AND expires_at>? RETURNING challenge_id").bind(phone,challengeId,expected,Date.now()).first();
  if(!consumed)throw new OtpError("این کد قابل استفاده نیست؛ کد تازه بگیرید.",401);
  return phone;
}
export function verifyStudentCode(value:string,challengeId:string,code:string,ip:string) {
  const phone=verifyCode(value,challengeId,code,ip,"login"),db=database();
  const account=db.prepare("SELECT client_id,revision FROM student_accounts WHERE phone=?").bind(phone).first<{client_id:string;revision:string}>();
  if(!account)throw new OtpError("ورود انجام نشد.",401);
  return account;
}

export function registrationProofHash(token:string){return digest("registration-proof:"+token);}
export function verifyRegistrationCode(value:string,challengeId:string,code:string,ip:string){
  if(!getSmsSettings().loginEnabled)throw new OtpError("ثبت‌نام پیامکی فعال نیست.",503);
  const phone=verifyCode(value,challengeId,code,ip,"registration"),token=randomBytes(32).toString("base64url"),now=Date.now();
  const db=database();
  db.prepare("DELETE FROM student_registration_proofs WHERE expires_at<?").bind(now).run();
  db.prepare("INSERT INTO student_registration_proofs(token_hash,phone,expires_at) VALUES(?,?,?)").bind(registrationProofHash(token),phone,now+900_000).run();
  return {registrationToken:token,expiresIn:900};
}
