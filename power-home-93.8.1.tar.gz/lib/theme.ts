export type Appearance = 'dark' | 'light';
export const APPEARANCE_KEY = 'power-home-appearance';
export function validAppearance(value:unknown): Appearance { return value === 'light' ? 'light' : 'dark'; }
export const APPEARANCE_BOOTSTRAP = `(function(){var t='dark';try{if(localStorage.getItem('${APPEARANCE_KEY}')==='light')t='light'}catch(e){}document.documentElement.dataset.theme=t;document.documentElement.style.colorScheme=t;})();`;
