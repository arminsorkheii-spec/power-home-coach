/** Display only preparation state; source descriptions remain in saved snapshots. */
export function foodDisplayDetail(food:{state?:string;category?:string;description?:string;recipe?:unknown}){
 return food.state==='raw'?'خام':food.state==='cooked'?'پخته':'';
}
