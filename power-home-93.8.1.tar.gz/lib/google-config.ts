import {createCipheriv,createDecipheriv,createHash,randomBytes} from 'node:crypto';
import {z} from 'zod';
import {database} from '@/lib/raw-db';

export const googleSettingsSchema=z.object({
  enabled:z.boolean().optional(),
  clientId:z.string().trim().max(255).regex(/^\d+-[A-Za-z0-9_-]+\.apps\.googleusercontent\.com$/).optional(),
  clientSecret:z.string().trim().max(512).regex(/^GOCSPX-[A-Za-z0-9_-]+$/).refine(v=>v.indexOf('GOCSPX-',1)===-1).optional(),
}).strict();
function key(){if(!process.env.APP_SESSION_SECRET)throw Error('google_configuration');return createHash('sha256').update('google-oauth\0'+process.env.APP_SESSION_SECRET).digest()}
function encrypt(value:string){const iv=randomBytes(12),cipher=createCipheriv('aes-256-gcm',key(),iv);const bytes=Buffer.concat([cipher.update(value,'utf8'),cipher.final()]);return [iv,cipher.getAuthTag(),bytes].map(v=>v.toString('base64url')).join('.')}
function decrypt(value:string){const [iv,tag,bytes]=value.split('.').map(v=>Buffer.from(v,'base64url'));const cipher=createDecipheriv('aes-256-gcm',key(),iv);cipher.setAuthTag(tag);return Buffer.concat([cipher.update(bytes),cipher.final()]).toString('utf8')}
function stored(){return database().prepare("SELECT client_id,encrypted_secret FROM google_oauth_settings WHERE id='student'").first<{client_id:string;encrypted_secret:string}>()}
function readSecret(value:string){try{return decrypt(value)}catch{return ''}}
export function googleCredentials(){const row=stored();return row?{clientId:row.client_id,clientSecret:readSecret(row.encrypted_secret)}:{clientId:process.env.GOOGLE_CLIENT_ID??'',clientSecret:process.env.GOOGLE_CLIENT_SECRET??''}}
export function googlePublicSettings(){const credentials=googleCredentials();const origin=process.env.APP_ORIGIN??'';let validOrigin=false;try{const url=new URL(origin);validOrigin=url.protocol==='https:'&&url.pathname==='/'&&!url.search&&!url.hash}catch{}
 const preference=database().prepare("SELECT enabled FROM google_login_preferences WHERE id='student'").first<{enabled:number}>();
 return {enabled:preference?Boolean(preference.enabled):Boolean(credentials.clientId&&credentials.clientSecret),configured:Boolean(credentials.clientId&&credentials.clientSecret&&process.env.APP_SESSION_SECRET&&validOrigin),clientId:credentials.clientId,clientIdConfigured:Boolean(credentials.clientId),secretConfigured:Boolean(credentials.clientSecret),originConfigured:validOrigin,origin:validOrigin?new URL(origin).origin:null,redirectUri:validOrigin?new URL('/api/student/google/callback',origin).href:null}}
export function saveGoogleSettings(value:z.infer<typeof googleSettingsSchema>){
 const previous=googleCredentials(),before=googlePublicSettings();
 const clientId=value.clientId??previous.clientId;
 if(value.clientSecret&&!clientId)throw Error('google_secret_required');
 if(value.clientId&&!value.clientSecret&&previous.clientId!==clientId)throw Error('google_secret_required');
 const secret=value.clientSecret??previous.clientSecret;
 const enabled=value.enabled??(before.configured?before.enabled:Boolean(clientId&&secret));
 if(enabled&&(!clientId||!secret||!before.originConfigured))throw Error('google_secret_required');
 const writes=[];
 if((value.clientId&&value.clientId!==previous.clientId)||value.clientSecret)writes.push(database().prepare("INSERT INTO google_oauth_settings(id,client_id,encrypted_secret,updated_at) VALUES('student',?,?,?) ON CONFLICT(id) DO UPDATE SET client_id=excluded.client_id,encrypted_secret=excluded.encrypted_secret,updated_at=excluded.updated_at").bind(clientId,encrypt(secret),new Date().toISOString()));
 writes.push(database().prepare("INSERT INTO google_login_preferences(id,enabled) VALUES('student',?) ON CONFLICT(id) DO UPDATE SET enabled=excluded.enabled").bind(enabled?1:0));
 database().batch(writes);
 return googlePublicSettings();
}
