// Store ISO Gregorian keys; localize only at the UI boundary.
const partsFormatter = new Intl.DateTimeFormat('en-US-u-ca-persian', {year:'numeric',month:'numeric',day:'numeric',timeZone:'UTC'});
export const PERSIAN_MONTHS=['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
export function persianParts(iso:string){
 const date=new Date(iso.slice(0,10)+'T12:00:00Z');
 if(!Number.isFinite(date.getTime()))return null;
 const parts=partsFormatter.formatToParts(date);
 const get=(type:string)=>Number(parts.find(p=>p.type===type)?.value);
 return {year:get('year'),month:get('month'),day:get('day')};
}
const starts=new Map<number,number>();
function yearStart(year:number){
 if(!Number.isInteger(year)||year<1200||year>1601)return NaN;
 if(starts.has(year))return starts.get(year)!;
 // Intl is the single conversion authority, including Persian leap years.
 for(let day=18;day<=23;day++){
  const time=Date.UTC(year+621,2,day),iso=new Date(time).toISOString();
  const p=persianParts(iso);
  if(p?.year===year&&p.month===1&&p.day===1){starts.set(year,time);return time}
 }
 return NaN;
}
export function persianMonthLength(year:number,month:number){return month<=6?31:month<=11?30:Math.round((yearStart(year+1)-yearStart(year))/86400000)-336}
export function persianToISO(year:number,month:number,day:number){
 if(!Number.isInteger(month)||month<1||month>12||!Number.isInteger(day)||day<1||day>persianMonthLength(year,month))return '';
 const start=yearStart(year);if(!Number.isFinite(start))return '';
 const time=start+((month<=6?(month-1)*31:186+(month-7)*30)+day-1)*86400000;
 return new Date(time).toISOString().slice(0,10);
}
export function formatPersianDate(value:string){
 const date=new Date(value.length===10?value+'T12:00:00Z':value);
 return Number.isFinite(date.getTime())?date.toLocaleDateString('fa-IR-u-ca-persian',{timeZone:value.length===10?'UTC':'Asia/Tehran'}):'—';
}
