import {normalizeDigits} from '@/lib/student-auth-client';
export function plannedSets(value:string){const first=Number(normalizeDigits(value).match(/\d+/)?.[0]??3);return Math.min(20,Math.max(1,first))}
export function restSeconds(value:string){const text=normalizeDigits(value).trim();if(/بدون\s*استراحت|no\s*rest/i.test(text))return 0;const clock=text.match(/^(\d{1,2}):(\d{2})$/);if(clock)return Math.min(1800,Number(clock[1])*60+Number(clock[2]));const numbers=text.match(/\d+(?:\.\d+)?/g)?.map(Number)??[];if(!numbers.length)return 60;return Math.min(1800,Math.max(0,Math.round(Math.max(...numbers)*(/دقیق|minute|min\b/i.test(text)?60:1))))}
export function remainingSeconds(deadline:number,now=Date.now()){return Math.max(0,Math.ceil((deadline-now)/1000))}
export function shiftDate(date:string,amount:number){const value=new Date(date+'T12:00:00Z');value.setUTCDate(value.getUTCDate()+amount);return value.toISOString().slice(0,10)}
