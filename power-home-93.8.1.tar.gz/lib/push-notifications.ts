import { buildPushPayload, type PushSubscription } from "@block65/webcrypto-web-push";
import { database } from "@/lib/raw-db";
import { generateKeyPairSync } from "node:crypto";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";

type PushRow = { id:string;endpoint:string;p256dh:string;auth:string };
type NotificationData = { title:string;body:string;url:string;tag:string;notificationId?:string;role?:"coach"|"student" };

type VapidCredentials={publicKey:string;privateKey:string;subject:string};
let generatedCredentials:VapidCredentials|undefined;
function runtimeCredentials():VapidCredentials{
  const values=process.env;
  if(values.VAPID_PUBLIC_KEY&&values.VAPID_PRIVATE_KEY)return {publicKey:values.VAPID_PUBLIC_KEY,privateKey:values.VAPID_PRIVATE_KEY,subject:values.VAPID_SUBJECT||"mailto:arminsorkheii@gmail.com"};
  if(generatedCredentials)return generatedCredentials;
  const dataDirectory=values.APP_DATA_DIR??"/data",file=path.join(dataDirectory,"vapid.json");
  try{generatedCredentials=JSON.parse(readFileSync(file,"utf8")) as VapidCredentials;return generatedCredentials;}catch{
    const pair=generateKeyPairSync("ec",{namedCurve:"prime256v1"});
    const publicJwk=pair.publicKey.export({format:"jwk"}),privateJwk=pair.privateKey.export({format:"jwk"});
    if(!publicJwk.x||!publicJwk.y||!privateJwk.d)throw new Error("VAPID key generation failed");
    const publicBytes=Buffer.concat([Buffer.from([4]),Buffer.from(publicJwk.x,"base64url"),Buffer.from(publicJwk.y,"base64url")]);
    generatedCredentials={publicKey:publicBytes.toString("base64url"),privateKey:privateJwk.d,subject:values.VAPID_SUBJECT||"mailto:arminsorkheii@gmail.com"};
    mkdirSync(dataDirectory,{recursive:true});writeFileSync(file,JSON.stringify(generatedCredentials),{mode:0o600});return generatedCredentials;
  }
}
export function pushPublicKey(){return runtimeCredentials().publicKey;}
export function validPushEndpoint(value:string){try{const url=new URL(value);const host=url.hostname.toLowerCase();return url.protocol==="https:"&&(host==="fcm.googleapis.com"||host.endsWith(".push.apple.com")||host==="push.services.mozilla.com"||host.endsWith(".push.services.mozilla.com")||host.endsWith(".notify.windows.com"));}catch{return false;}}

export async function sendPush(role:"coach"|"student",clientId:string|null,data:NotificationData){
  const values=runtimeCredentials();
  try{
    const query=clientId?database().prepare("SELECT id,endpoint,p256dh,auth FROM push_subscriptions WHERE role=? AND client_id=?").bind(role,clientId):database().prepare("SELECT id,endpoint,p256dh,auth FROM push_subscriptions WHERE role=?").bind(role);
    const rows=await query.all<PushRow>();
    const results=await Promise.all(rows.results.map(async row=>{try{const subscription:PushSubscription={endpoint:row.endpoint,expirationTime:null,keys:{p256dh:row.p256dh,auth:row.auth}};const payload=await buildPushPayload({data,options:{ttl:3600,urgency:"high",topic:data.tag.slice(0,32)}},subscription,{subject:values.subject,publicKey:values.publicKey,privateKey:values.privateKey});const response=await fetch(row.endpoint,{...payload,body:payload.body as BodyInit});if(response.status===404||response.status===410)await database().prepare("DELETE FROM push_subscriptions WHERE id=?").bind(row.id).run();return response.ok;}catch{return false;}}));
    const sent=results.filter(Boolean).length;
    return {configured:true,total:rows.results.length,sent,failed:rows.results.length-sent};
  }catch{return {configured:true,total:0,sent:0,failed:0};}
}
