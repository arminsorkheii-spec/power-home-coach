import { mkdirSync } from "node:fs";
import { createHash } from "node:crypto";
import path from "node:path";
import { DatabaseSync, type StatementSync } from "node:sqlite";

type SqlValue = unknown;

class BoundStatement {
  constructor(
    private readonly statement: StatementSync,
    private readonly values: SqlValue[],
  ) {}

  bind(...values: SqlValue[]) {
    return new BoundStatement(this.statement, values);
  }

  first<T>() {
    return (this.statement.get(...(this.values as never[])) as T | undefined) ?? null;
  }

  all<T>() {
    return { results: this.statement.all(...(this.values as never[])) as T[] };
  }

  run() {
    return this.statement.run(...(this.values as never[]));
  }
}

class DatabaseAdapter {
  constructor(private readonly sqlite: DatabaseSync) {}

  prepare(sql: string) {
    const statement = this.sqlite.prepare(sql);
    return new BoundStatement(statement, []);
  }

  batch(statements: BoundStatement[]) {
    this.sqlite.exec("BEGIN IMMEDIATE");
    try {
      const results = statements.map((statement) => statement.run());
      this.sqlite.exec("COMMIT");
      return results;
    } catch (error) {
      this.sqlite.exec("ROLLBACK");
      throw error;
    }
  }
}

let adapter: DatabaseAdapter | undefined;

function initialize(sqlite: DatabaseSync) {
  sqlite.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
    CREATE TABLE IF NOT EXISTS muscle_checkins(client_id TEXT NOT NULL,muscle_id TEXT NOT NULL,date TEXT NOT NULL,payload TEXT NOT NULL,PRIMARY KEY(client_id,muscle_id,date));
    CREATE TABLE IF NOT EXISTS student_life_items (
      id TEXT PRIMARY KEY,client_id TEXT NOT NULL,kind TEXT NOT NULL,date TEXT NOT NULL,payload TEXT NOT NULL,shared INTEGER NOT NULL DEFAULT 0,notified_at TEXT,remind_at TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS life_client_kind_date ON student_life_items(client_id,kind,date);
    CREATE TABLE IF NOT EXISTS coach_foods(id TEXT PRIMARY KEY,payload TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1);
    CREATE TABLE IF NOT EXISTS life_files(id TEXT PRIMARY KEY,client_id TEXT NOT NULL,kind TEXT NOT NULL,name TEXT NOT NULL,mime TEXT NOT NULL,size INTEGER NOT NULL,title TEXT NOT NULL,exercise_id TEXT NOT NULL DEFAULT '',data BLOB NOT NULL,created_at TEXT NOT NULL,reviewed_at TEXT);
    CREATE TABLE IF NOT EXISTS video_annotations(id TEXT PRIMARY KEY,file_id TEXT NOT NULL REFERENCES life_files(id) ON DELETE CASCADE,second REAL NOT NULL,text TEXT NOT NULL,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS club_events(id TEXT PRIMARY KEY,kind TEXT NOT NULL,title TEXT NOT NULL,starts_at TEXT NOT NULL,ends_at TEXT NOT NULL,capacity INTEGER NOT NULL,description TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1);
    CREATE TABLE IF NOT EXISTS club_reservations(event_id TEXT NOT NULL REFERENCES club_events(id),client_id TEXT NOT NULL,created_at TEXT NOT NULL,PRIMARY KEY(event_id,client_id));
    CREATE TABLE IF NOT EXISTS billing_due_dates(billing_id TEXT PRIMARY KEY,due_date TEXT NOT NULL,enabled INTEGER NOT NULL DEFAULT 1,notified_date TEXT);
    CREATE TABLE IF NOT EXISTS coach_expenses(id TEXT PRIMARY KEY,date TEXT NOT NULL,title TEXT NOT NULL,amount INTEGER NOT NULL,category TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS discount_codes(code TEXT PRIMARY KEY,percent INTEGER NOT NULL,max_uses INTEGER NOT NULL,expires_at TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1);
    CREATE TABLE IF NOT EXISTS discount_redemptions(application_id TEXT PRIMARY KEY,code TEXT NOT NULL,client_id TEXT NOT NULL,amount INTEGER NOT NULL,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS workout_calendar (
      client_id TEXT NOT NULL,date TEXT NOT NULL,day_id TEXT,title TEXT NOT NULL,kind TEXT NOT NULL,updated_at TEXT NOT NULL,PRIMARY KEY(client_id,date)
    );
    CREATE TABLE IF NOT EXISTS workout_sessions (
      id TEXT PRIMARY KEY,client_id TEXT NOT NULL,date TEXT NOT NULL,day_id TEXT NOT NULL,snapshot TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'active',started_at TEXT NOT NULL,completed_at TEXT,UNIQUE(client_id,date,day_id)
    );
    CREATE INDEX IF NOT EXISTS workout_sessions_client_date ON workout_sessions(client_id,date);
    CREATE TABLE IF NOT EXISTS workout_sets (
      session_id TEXT NOT NULL REFERENCES workout_sessions(id),row_id TEXT NOT NULL,set_index INTEGER NOT NULL,weight REAL NOT NULL,reps INTEGER NOT NULL,done INTEGER NOT NULL,result_id TEXT NOT NULL UNIQUE,PRIMARY KEY(session_id,row_id,set_index)
    );
    CREATE TABLE IF NOT EXISTS exercise_replacement_requests (
      id TEXT PRIMARY KEY,client_id TEXT NOT NULL,session_id TEXT NOT NULL,row_id TEXT NOT NULL,exercise_name TEXT NOT NULL,reason TEXT NOT NULL,message TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',response TEXT NOT NULL DEFAULT '',alternative_name TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL,updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS replacement_client_status ON exercise_replacement_requests(client_id,status,created_at);
    CREATE TABLE IF NOT EXISTS google_login_preferences (
      id TEXT PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS google_oauth_settings (
      id TEXT PRIMARY KEY, client_id TEXT NOT NULL, encrypted_secret TEXT NOT NULL, updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS sms_settings (
      id TEXT PRIMARY KEY,
      payload TEXT NOT NULL,
      encrypted_key TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS sms_rate_limits (
      key TEXT PRIMARY KEY,
      count INTEGER NOT NULL,
      reset_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS student_login_codes (
      phone TEXT PRIMARY KEY,
      challenge_id TEXT NOT NULL UNIQUE,
      code_hash TEXT NOT NULL,
      expires_at INTEGER NOT NULL,
      next_send_at INTEGER NOT NULL,
      attempts INTEGER NOT NULL DEFAULT 0,
      ready INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS student_registration_proofs (
      token_hash TEXT PRIMARY KEY,
      phone TEXT NOT NULL,
      expires_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS student_daily_logs (
      client_id TEXT NOT NULL, date TEXT NOT NULL, payload TEXT NOT NULL, updated_at TEXT NOT NULL,
      PRIMARY KEY(client_id,date)
    );
    CREATE TABLE IF NOT EXISTS exercise_results (
      id TEXT PRIMARY KEY, client_id TEXT NOT NULL, exercise_id TEXT NOT NULL, exercise_name TEXT NOT NULL DEFAULT '', date TEXT NOT NULL,
      weight REAL NOT NULL, reps INTEGER NOT NULL, sets INTEGER NOT NULL, notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS exercise_results_client_date ON exercise_results(client_id,date);
    CREATE TABLE IF NOT EXISTS weekly_reports (
      id TEXT PRIMARY KEY, client_id TEXT NOT NULL, week TEXT NOT NULL, payload TEXT NOT NULL,
      reviewed_at TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, UNIQUE(client_id,week)
    );
    CREATE TABLE IF NOT EXISTS weekly_report_photos (
      id TEXT PRIMARY KEY, report_id TEXT NOT NULL REFERENCES weekly_reports(id), client_id TEXT NOT NULL,
      pose TEXT NOT NULL, content_type TEXT NOT NULL, data BLOB NOT NULL, updated_at TEXT NOT NULL, UNIQUE(report_id,pose)
    );
    CREATE TABLE IF NOT EXISTS program_terms (
      id TEXT PRIMARY KEY, delivery_key TEXT NOT NULL UNIQUE, client_id TEXT NOT NULL, application_id TEXT,
      title TEXT NOT NULL, started_at TEXT NOT NULL, expires_at TEXT NOT NULL, duration_days INTEGER NOT NULL,
      remind_days INTEGER NOT NULL, reminders_enabled INTEGER NOT NULL DEFAULT 1, active INTEGER NOT NULL DEFAULT 1
    );
    CREATE INDEX IF NOT EXISTS program_terms_active_expiry ON program_terms(active,expires_at);
    CREATE TABLE IF NOT EXISTS student_google_accounts (
      subject TEXT PRIMARY KEY, client_id TEXT NOT NULL UNIQUE REFERENCES student_accounts(client_id), email TEXT NOT NULL, linked_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS google_registration_proofs (
      token_hash TEXT PRIMARY KEY, subject TEXT NOT NULL, email TEXT NOT NULL, name TEXT NOT NULL, expires_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS sms_deliveries (
      notification_id TEXT PRIMARY KEY,
      role TEXT NOT NULL,
      phone TEXT NOT NULL,
      status TEXT NOT NULL,
      message_id TEXT,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS sms_campaigns (
      request_id TEXT PRIMARY KEY,
      payload_hash TEXT NOT NULL,
      message TEXT NOT NULL,
      recipient_count INTEGER NOT NULL,
      status TEXT NOT NULL,
      pack_id TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS package_prices (
      package_id TEXT PRIMARY KEY,
      price INTEGER NOT NULL CHECK(price >= 0 AND price <= 2000000000),
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS coach_security (
      owner TEXT PRIMARY KEY,
      password_hash TEXT NOT NULL,
      salt TEXT NOT NULL,
      revision TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS login_attempts (
      key TEXT PRIMARY KEY,
      count INTEGER NOT NULL,
      reset_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS coach_states (
      owner_email TEXT PRIMARY KEY,
      payload TEXT NOT NULL,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS checkins (
      id TEXT PRIMARY KEY,
      owner TEXT NOT NULL,
      client_id TEXT NOT NULL,
      date TEXT NOT NULL,
      payload TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_checkins_owner_client_date
      ON checkins(owner, client_id, date);
    CREATE TABLE IF NOT EXISTS body_photos (
      id TEXT PRIMARY KEY,
      owner TEXT NOT NULL,
      checkin_id TEXT NOT NULL REFERENCES checkins(id),
      pose TEXT NOT NULL,
      key TEXT NOT NULL
    );
    CREATE UNIQUE INDEX IF NOT EXISTS idx_body_photos_checkin_pose
      ON body_photos(owner, checkin_id, pose);
    CREATE TABLE IF NOT EXISTS client_body_photos (
      id TEXT PRIMARY KEY,
      owner TEXT NOT NULL,
      client_id TEXT NOT NULL,
      pose TEXT NOT NULL,
      key TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE UNIQUE INDEX IF NOT EXISTS idx_client_body_photos_client_pose
      ON client_body_photos(owner, client_id, pose);
    CREATE TABLE IF NOT EXISTS student_accounts (
      client_id TEXT PRIMARY KEY,
      phone TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      salt TEXT NOT NULL,
      revision TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS applications (
      id TEXT PRIMARY KEY,
      client_id TEXT NOT NULL REFERENCES student_accounts(client_id),
      package_id TEXT NOT NULL,
      package_name TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'draft',
      price_amount INTEGER,
      paid_at TEXT,
      profile_json TEXT NOT NULL DEFAULT '{}',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_applications_status_updated
      ON applications(status, updated_at);
    CREATE INDEX IF NOT EXISTS idx_applications_client_created
      ON applications(client_id, created_at);
    CREATE TABLE IF NOT EXISTS application_uploads (
      id TEXT PRIMARY KEY,
      application_id TEXT NOT NULL REFERENCES applications(id),
      client_id TEXT NOT NULL,
      kind TEXT NOT NULL,
      key TEXT NOT NULL,
      filename TEXT NOT NULL,
      content_type TEXT NOT NULL,
      size INTEGER NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_application_uploads_application
      ON application_uploads(application_id);
    CREATE INDEX IF NOT EXISTS idx_application_uploads_client_kind
      ON application_uploads(client_id, kind);
    CREATE TABLE IF NOT EXISTS push_subscriptions (
      id TEXT PRIMARY KEY,
      role TEXT NOT NULL,
      client_id TEXT,
      endpoint TEXT NOT NULL UNIQUE,
      p256dh TEXT NOT NULL,
      auth TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_push_subscriptions_role_client
      ON push_subscriptions(role, client_id);
    CREATE TABLE IF NOT EXISTS notification_events (
      id TEXT PRIMARY KEY,
      recipient_role TEXT NOT NULL,
      recipient_client_id TEXT,
      actor_client_id TEXT,
      application_id TEXT,
      type TEXT NOT NULL,
      title TEXT NOT NULL,
      body TEXT NOT NULL,
      url TEXT NOT NULL,
      tag TEXT NOT NULL,
      read_at TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_notification_events_recipient_unread
      ON notification_events(recipient_role, recipient_client_id, read_at, created_at);
    CREATE INDEX IF NOT EXISTS idx_notification_events_application
      ON notification_events(application_id, created_at);
    CREATE TABLE IF NOT EXISTS chat_messages (
      id TEXT PRIMARY KEY,
      client_id TEXT NOT NULL REFERENCES student_accounts(client_id),
      sender_role TEXT NOT NULL,
      body TEXT NOT NULL,
      read_at TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_chat_messages_client_created
      ON chat_messages(client_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_chat_messages_client_unread
      ON chat_messages(client_id, sender_role, read_at);
    CREATE TABLE IF NOT EXISTS student_magic_links (
      client_id TEXT PRIMARY KEY,
      token_hash TEXT NOT NULL UNIQUE,
      session_revision TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_student_magic_links_hash ON student_magic_links(token_hash);
    CREATE TABLE IF NOT EXISTS payments (
      id TEXT PRIMARY KEY,
      application_id TEXT NOT NULL UNIQUE REFERENCES applications(id),
      client_id TEXT NOT NULL,
      amount INTEGER NOT NULL,
      paid_at TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_payments_paid_at ON payments(paid_at);
    CREATE INDEX IF NOT EXISTS idx_payments_client ON payments(client_id);
    CREATE TABLE IF NOT EXISTS billing_records (
      id TEXT PRIMARY KEY,
      application_id TEXT UNIQUE,
      client_id TEXT NOT NULL,
      package_id TEXT NOT NULL,
      package_name TEXT NOT NULL,
      list_amount INTEGER NOT NULL DEFAULT 0,
      discount_amount INTEGER NOT NULL DEFAULT 0,
      final_amount INTEGER NOT NULL DEFAULT 0,
      received_amount INTEGER NOT NULL DEFAULT 0,
      received_at TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_billing_records_client ON billing_records(client_id);
    CREATE INDEX IF NOT EXISTS idx_billing_records_updated ON billing_records(updated_at);
    CREATE TABLE IF NOT EXISTS billing_events (
      id TEXT PRIMARY KEY,
      billing_id TEXT NOT NULL,
      application_id TEXT,
      client_id TEXT NOT NULL,
      package_name TEXT NOT NULL,
      amount_delta INTEGER NOT NULL,
      event_at TEXT NOT NULL,
      note TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_billing_events_event_at ON billing_events(event_at);
    CREATE INDEX IF NOT EXISTS idx_billing_events_client ON billing_events(client_id,event_at);
    CREATE INDEX IF NOT EXISTS idx_billing_events_billing ON billing_events(billing_id);
    CREATE TABLE IF NOT EXISTS billing_event_audit (
      id TEXT PRIMARY KEY,
      event_id TEXT NOT NULL,
      billing_id TEXT NOT NULL,
      action TEXT NOT NULL,
      old_amount INTEGER NOT NULL,
      new_amount INTEGER NOT NULL,
      old_event_at TEXT NOT NULL,
      new_event_at TEXT NOT NULL,
      old_note TEXT NOT NULL,
      new_note TEXT NOT NULL,
      reason TEXT NOT NULL,
      changed_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_billing_event_audit_event ON billing_event_audit(event_id,changed_at);

    CREATE TABLE IF NOT EXISTS current_program_deliveries (
      client_id TEXT PRIMARY KEY,
      plan_hash TEXT NOT NULL,
      delivered_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS coach_schema_migrations (
      name TEXT PRIMARY KEY,
      applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS program_assignments (
      id TEXT PRIMARY KEY,
      client_id TEXT NOT NULL,
      template_id TEXT NOT NULL,
      program_number INTEGER NOT NULL,
      template_title TEXT NOT NULL,
      assigned_at TEXT NOT NULL,
      delivered_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_program_assignments_client_template ON program_assignments(client_id,template_id);
    CREATE INDEX IF NOT EXISTS idx_program_assignments_client_assigned ON program_assignments(client_id,assigned_at);
  `);

  const lifeColumns=sqlite.prepare("PRAGMA table_info(student_life_items)").all() as Array<{name:string}>;
  if(!lifeColumns.some(column=>column.name==='remind_at'))sqlite.exec('ALTER TABLE student_life_items ADD COLUMN remind_at TEXT');
  sqlite.exec('CREATE INDEX IF NOT EXISTS life_reminders_due ON student_life_items(kind,notified_at,remind_at)');
  const ledgerColumns = sqlite.prepare("PRAGMA table_info(billing_events)").all() as Array<{name:string}>;
  if (!ledgerColumns.some(column => column.name === "deleted_at")) {
    sqlite.exec("ALTER TABLE billing_events ADD COLUMN deleted_at TEXT");
  }
  if (!ledgerColumns.some(column => column.name === "edited_at")) {
    sqlite.exec("ALTER TABLE billing_events ADD COLUMN edited_at TEXT");
  }

  const applicationColumns = sqlite
    .prepare("PRAGMA table_info(applications)")
    .all() as Array<{ name: string }>;
  if (!applicationColumns.some((column) => column.name === "paid_at")) {
    sqlite.exec("ALTER TABLE applications ADD COLUMN paid_at TEXT");
  }
  if (!applicationColumns.some(column => column.name === "package_items_json")) sqlite.exec("ALTER TABLE applications ADD COLUMN package_items_json TEXT NOT NULL DEFAULT '[]'");
  if (!applicationColumns.some(column => column.name === "parent_application_id")) sqlite.exec("ALTER TABLE applications ADD COLUMN parent_application_id TEXT");
  // Billing is independent from workflow status. Merely moving a request to writing/delivered
  // must never create income. Existing applications get a zero-received ledger row and the
  // coach explicitly records the amount actually collected.
  sqlite.exec(`
    INSERT OR IGNORE INTO billing_records (id,application_id,client_id,package_id,package_name,list_amount,discount_amount,final_amount,received_amount,received_at,created_at,updated_at)
    SELECT 'billing-' || a.id,a.id,a.client_id,a.package_id,a.package_name,COALESCE(a.price_amount,0),0,COALESCE(a.price_amount,0),0,NULL,a.created_at,a.updated_at
    FROM applications a;

    -- Release 90 transaction ledger: preserve already-recorded received balances as an
    -- opening transaction once, then all future changes are stored as deltas.
    INSERT OR IGNORE INTO billing_events (id,billing_id,application_id,client_id,package_name,amount_delta,event_at,note,created_at)
    SELECT 'opening-' || b.id,b.id,b.application_id,b.client_id,b.package_name,b.received_amount,COALESCE(b.received_at,b.updated_at),'مانده انتقالی از نسخه قبل',COALESCE(b.received_at,b.updated_at)
    FROM billing_records b
    WHERE b.received_amount<>0
      AND NOT EXISTS (SELECT 1 FROM billing_events e WHERE e.billing_id=b.id);
  `);
  // Existing installations already exposed their current saved programs. Keep those
  // visible when the explicit-delivery gate is introduced; only newly created drafts
  // require an actual "send" action before being counted on student-facing pages.
  const legacyMigration = sqlite.prepare("SELECT name FROM coach_schema_migrations WHERE name='delivered_current_v1'").get();
  if (!legacyMigration) {
    const rows = sqlite.prepare("SELECT payload FROM coach_states").all() as Array<{payload:string}>;
    const insert = sqlite.prepare("INSERT OR IGNORE INTO current_program_deliveries (client_id,plan_hash,delivered_at) VALUES (?,?,?)");
    for (const row of rows) {
      try {
        const parsed = JSON.parse(row.payload) as {plans?:Record<string,{workoutDays?:Array<{exercises?:unknown[]}>;nutritionMeals?:unknown[];supplementItems?:unknown[];medicationItems?:unknown[]}>};
        for (const [clientId,plan] of Object.entries(parsed.plans??{})) {
          if (!plan || !(plan.workoutDays?.some(day=>(day.exercises??[]).length)||plan.nutritionMeals?.length||plan.supplementItems?.length||plan.medicationItems?.length)) continue;
          insert.run(clientId,createHash('sha256').update(JSON.stringify(plan)).digest('hex'),new Date().toISOString());
        }
      } catch { /* Ignore only invalid legacy snapshots, never overwrite them. */ }
    }
    sqlite.prepare("INSERT INTO coach_schema_migrations (name) VALUES ('delivered_current_v1')").run();
  }
  // Release 90: duplicate template assignments are allowed only after an explicit warning.
  // Older builds created this as UNIQUE; drop/recreate it as a normal lookup index.
  sqlite.exec(`DROP INDEX IF EXISTS idx_program_assignments_client_template;`);
  sqlite.exec(`CREATE INDEX IF NOT EXISTS idx_program_assignments_client_template ON program_assignments(client_id,template_id);`);
}

export function database() {
  if (adapter) return adapter;
  const dataDirectory = process.env.APP_DATA_DIR ?? "/data";
  mkdirSync(dataDirectory, { recursive: true });
  const sqlite = new DatabaseSync(path.join(dataDirectory, "power-home.sqlite"));
  initialize(sqlite);
  adapter = new DatabaseAdapter(sqlite);
  return adapter;
}

export function sameOrigin(request: Request) {
  const host = request.headers.get("x-forwarded-host") ?? request.headers.get("host");
  if (!host) return false;
  const origin = request.headers.get("origin");
  const referer = request.headers.get("referer");
  const forwardedProtocol = request.headers.get("x-forwarded-proto");
  const matches = (value: string) => {
    try {
      const parsed = new URL(value);
      return parsed.host === host && (!forwardedProtocol || parsed.protocol === `${forwardedProtocol}:`);
    } catch { return false; }
  };
  if (origin) return matches(origin);
  if (referer) return matches(referer);
  return request.headers.get("sec-fetch-site") === "same-origin";
}
