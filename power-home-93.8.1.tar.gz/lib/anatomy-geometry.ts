import type {MuscleId} from './muscle-data';
export type AnatomySlice={offset:number;length:number};
export type AnatomyPart={group:MuscleId|null;vertexCount:number;indexCount:number;positions:AnatomySlice;normals:AnatomySlice;colors:AnatomySlice;indices:AnatomySlice};
export type AnatomyManifest={version:number;license:string;source:string;sourceSha256:string;binarySha256:string;binaryBytes:number;bounds:{min:number[];max:number[]};parts:AnatomyPart[];triangles:number};
export async function loadAnatomyGeometry(signal:AbortSignal){
 const [metadata,geometry]=await Promise.all([fetch('/anatomy/body-v1.json',{signal}),fetch('/anatomy/body-v1.bin',{signal})]);
 if(!metadata.ok||!geometry.ok)throw Error('model_download');
 const [manifest,bytes]=await Promise.all([metadata.json() as Promise<AnatomyManifest>,geometry.arrayBuffer()]);
 if(manifest.version!==1||bytes.byteLength!==manifest.binaryBytes||bytes.byteLength>24*1024*1024||manifest.parts.length>64)throw Error('model_format');
 for(const part of manifest.parts){
  if(part.vertexCount<1||part.vertexCount>65535||part.indexCount%3)throw Error('model_geometry');
  for(const [key,size] of [['positions',part.vertexCount*6],['normals',part.vertexCount*3],['colors',part.vertexCount*4],['indices',part.indexCount*2]] as const){const a=part[key];if(a.offset<0||a.offset%4||a.length!==size||a.offset+a.length>bytes.byteLength)throw Error('model_buffer')}
 }
 return {manifest,bytes};
}
