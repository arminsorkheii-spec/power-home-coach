export const STUDENT_NAV=[
 {key:'today',module:'training',tab:'today',label:'امروز من',group:'روزانه'},
 {key:'workout',module:'training',tab:'workout',label:'شروع و ادامه تمرین',group:'روزانه'},
 {key:'muscles',module:'muscles',tab:'',label:'نقشه سه‌بعدی عضلات',group:'روزانه'},
 {key:'records',module:'wellness',tab:'records',label:'رکورد و نمودار',group:'روزانه'},
 {key:'planner',module:'life',tab:'planner',label:'برنامه‌ریز زندگی',group:'روزانه'},
 {key:'companion',module:'chat',tab:'',label:'همراه مربی',group:'ارتباط و حساب'},
 {key:'calendar',module:'training',tab:'calendar',label:'تقویم تمرین',group:'برنامه و پیشرفت'},
 {key:'programs',module:'programs',tab:'',label:'برنامه‌های من و سوابق بدن',group:'برنامه و پیشرفت'},
 {key:'nutrition',module:'life',tab:'kitchen',label:'تغذیه و آشپزخانه',group:'برنامه و پیشرفت'},
 {key:'recovery',module:'life',tab:'health',label:'سلامت و ریکاوری',group:'برنامه و پیشرفت'},
 {key:'habits',module:'wellness',tab:'habits',label:'آب، خواب و عادت‌ها',group:'برنامه و پیشرفت'},
 {hidden:true,key:'weekly',module:'wellness',tab:'weekly',label:'گزارش و عکس هفتگی',group:'برنامه و پیشرفت'},
 {hidden:true,key:'replacements',module:'training',tab:'requests',label:'درخواست جایگزین حرکت',group:'ارتباط و حساب'},
 {hidden:true,key:'club',module:'life',tab:'club',label:'فیلم، جلسه و رویداد',group:'ارتباط و حساب'},
 {hidden:true,key:'chat',module:'chat',tab:'',label:'گفت‌وگو با مربی',group:'ارتباط و حساب'},
 {key:'notifications',module:'notifications',tab:'',label:'اعلان‌ها',group:'ارتباط و حساب'},
 {key:'orders',module:'orders',tab:'',label:'درخواست، پرداخت و تمدید',group:'ارتباط و حساب'},
 {key:'private',module:'life',tab:'private',label:'دفترچه و ابزارهای خصوصی',group:'فضای من'},
 {key:'account',module:'account',tab:'',label:'حساب و ورود گوگل',group:'فضای من'}
] as const;
export type StudentNavKey=typeof STUDENT_NAV[number]['key'];
export function studentNavigation(key:string){return STUDENT_NAV.find(item=>item.key===key)??STUDENT_NAV[0]}
export function noticeNavigation(section:string,lifeTab?:string):StudentNavKey{return section==='muscles'?'muscles':section==='chat'?'chat':section==='program'?'programs':section==='request'||section==='renewal'?'orders':section==='wellness'?'weekly':section==='training'?'replacements':section==='life'?(lifeTab==='planner'?'planner':'club'):'notifications'}
export const STUDENT_HASH_NAV:Record<string,StudentNavKey>={'#student-training':'today','#student-muscles':'muscles','#student-life':'planner','#student-wellness':'habits','#student-chat':'chat','#student-notifications':'notifications','#student-program':'programs','#student-program-open':'programs','#student-current-request':'orders','#student-request-history':'orders','#student-renewal':'orders'};

export const STUDENT_MENU_NAV=STUDENT_NAV.filter(item=>!('hidden' in item&&item.hidden));
