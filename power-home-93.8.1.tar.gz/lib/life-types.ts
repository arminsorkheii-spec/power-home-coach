export type LifeKind='task'|'goal'|'shopping'|'journal'|'expense'|'budget'|'food'|'meal'|'recipe'|'health';
export type LifeItem={id:string;kind:LifeKind;date:string;data:Record<string,any>;shared:boolean;updatedAt:string};
export type Food={id:string;name:string;calories:number;protein:number;carbs:number;fat:number;approved?:boolean};
export type LifeFile={id:string;kind:'private'|'video';name:string;mime:string;size:number;title:string;exercise_id:string;created_at:string;clientName?:string;client_id?:string;reviewed_at?:string;annotations?:{id:string;second:number;text:string;created_at:string}[]};
export type ClubEvent={id:string;kind:'appointment'|'event'|'challenge';title:string;starts_at:string;ends_at:string;capacity:number;description:string;joined:boolean;reserved:number;active:number};
export type LifeData={date:string;today?:string;name:string;items:LifeItem[];foods:Food[];files:LifeFile[];meals:{id:string;title:string;foods:string;time:string}[];daily:Record<string,any>|null;goals:Record<string,number>;club:ClubEvent[]};
