export const STUDENT_COMPANION_TABS=[{key:'chat',label:'پیام‌ها و سؤال‌ها',icon:'chat',count:'messages'},{key:'club',label:'فیلم و بازخورد',icon:'video',count:'videos'},{key:'replacements',label:'جایگزین حرکت',icon:'replacements',count:'requests'},{key:'weekly',label:'گزارش و عکس هفتگی',icon:'weekly',count:'reports'}] as const;
export const COACH_COMPANION_TABS=[{key:'chat',label:'پیام‌ها و سؤال‌ها',icon:'chat',count:'messages'},{key:'media',label:'فیلم و بررسی',icon:'video',count:'videos'},{key:'replacements',label:'جایگزین حرکت',icon:'replacements',count:'requests'},{key:'reports',label:'گزارش‌ها و بازخورد',icon:'weekly',count:'reports'}] as const;
export type CompanionCounts={messages:number;videos:number;requests:number;reports:number;total:number};
export const EMPTY_COMPANION_COUNTS:CompanionCounts={messages:0,videos:0,requests:0,reports:0,total:0};
export function isStudentCompanion(key:string){return key==='companion'||STUDENT_COMPANION_TABS.some(t=>t.key===key)}
export function isCoachCompanion(view:string){return view==='companion'||COACH_COMPANION_TABS.some(t=>t.key===view)}
