"use client";

import {googleErrorMessage} from "@/lib/google-errors";
import {GoogleSignInButton} from "@/components/google-sign-in-button";
import { FormEvent, useEffect, useState } from "react";
import { ArrowRight, LoaderCircle, LockKeyhole, UserRound } from "lucide-react";
import { normalizeDigits, normalizePhone } from "@/lib/student-auth-client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

function refreshAuthenticated(){const destination=new URL(window.location.href);destination.searchParams.delete('googleError');destination.searchParams.delete('googleRef');window.location.replace(destination.pathname+destination.search+destination.hash)}
function LegacyStudentLogin({googleMessage=""}:{googleMessage?:string}) {
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (!phone || !password || loading) return;
    setLoading(true); setError("");
    try {
      const response = await fetch("/api/student/login", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ phone, password }) });
      const result = (await response.json()) as { error?: string };
      if (!response.ok) { setError(result.error ?? "ورود انجام نشد."); return; }
      refreshAuthenticated();
    } catch { setError("اتصال برقرار نشد؛ دوباره امتحان کنید."); }
    finally { setLoading(false); }
  };
  return <main className="portal-login-page student-login-page" dir="rtl">
    <a href="/" className="portal-back"><ArrowRight /> بازگشت به صفحه اصلی</a>
    <form onSubmit={submit} className="portal-login-card">
      <div className="portal-login-icon"><UserRound /></div>
      <p>STUDENT PORTAL</p><h1>ورود شاگرد</h1><span>مشاهده برنامه تمرینی، غذایی و اطلاعات اختصاصی</span>
      {googleMessage&&<p className="google-login-error" role="alert">{googleMessage}</p>}
    <GoogleSignInButton/>
      <label htmlFor="student-phone">شماره موبایل</label>
      <Input id="student-phone" type="tel" inputMode="tel" autoComplete="tel" placeholder="09xxxxxxxxx" value={phone} onChange={(event) => setPhone(event.target.value)} className="h-12 text-left text-base" dir="ltr" />
      <label htmlFor="student-password">رمز ۶ رقمی</label>
      <Input id="student-password" type="password" inputMode="numeric" autoComplete="current-password" maxLength={6} placeholder="••••••" value={password} onChange={(event) => setPassword(event.target.value.replace(/[۰-۹]/g,d=>String("۰۱۲۳۴۵۶۷۸۹".indexOf(d))).replace(/[٠-٩]/g,d=>String("٠١٢٣٤٥٦٧٨٩".indexOf(d))).replace(/\D/g,"").slice(0,6))} className="h-12 text-center text-lg tracking-[.35em]" dir="ltr" />
      <div className="min-h-6 text-center text-xs text-amber-300" role="alert">{error}</div>
      <Button type="submit" disabled={!phone || password.length !== 6 || loading} className="h-12 w-full rounded-xl bg-amber-500 text-base hover:bg-amber-500">{loading ? <LoaderCircle className="animate-spin" /> : <LockKeyhole />} ورود به برنامه من</Button>
      <small>رمز ورود همان رمز ۶ رقمی است که هنگام ثبت‌نام انتخاب کردی.</small>
    </form>
  </main>;
}


export function StudentLogin({initialSmsEnabled=false}:{initialSmsEnabled?:boolean}) {
  const [sms,setSms]=useState(initialSmsEnabled);
  useEffect(()=>{const load=()=>{void fetch("/api/student/login",{cache:"no-store"}).then(r=>r.ok?r.json():null).then(d=>{if(d)setSms(d.smsEnabled===true)}).catch(()=>{});};load();window.addEventListener("focus",load);return()=>window.removeEventListener("focus",load)},[]);
  const [googleMessage,setGoogleMessage]=useState("");useEffect(()=>{const query=new URLSearchParams(window.location.search);if(query.has("googleError")){const reference=query.get("googleRef");setGoogleMessage(googleErrorMessage(query.get("googleError"))+(/^[a-f0-9]{10}$/.test(reference??'')?' کد پیگیری: '+reference:''));}},[]);
  return sms?<SmsStudentLogin googleMessage={googleMessage}/>:<LegacyStudentLogin googleMessage={googleMessage}/>;
}
function SmsStudentLogin({googleMessage=""}:{googleMessage?:string}){
  const [phone,setPhone]=useState("");const [code,setCode]=useState("");const [challenge,setChallenge]=useState("");
  const [retryAt,setRetryAt]=useState(0);const [clock,setClock]=useState(Date.now());
  const [busy,setBusy]=useState(false);const [error,setError]=useState("");const [message,setMessage]=useState("");
  useEffect(()=>{const t=setInterval(()=>setClock(Date.now()),1000);return()=>clearInterval(t)},[]);
  const remaining=Math.max(0,Math.ceil((retryAt-clock)/1000));
  const requestCode=async()=>{if(busy||remaining)return;setBusy(true);setError("");try{
    const r=await fetch("/api/student/login-code",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({phone}),signal:AbortSignal.timeout(15000)});
    const d=await r.json();if(d.retryAfter)setRetryAt(Date.now()+d.retryAfter*1000);if(!r.ok)throw new Error(d.error??"ارسال کد انجام نشد.");
    setChallenge(d.challengeId);setCode("");setMessage(d.message);
  }catch(e){setError(e instanceof Error?e.message:"ارسال کد انجام نشد.")}finally{setBusy(false)}};
  const submit=async(event:FormEvent)=>{event.preventDefault();if(!challenge){await requestCode();return;}if(busy||code.length!==6)return;setBusy(true);setError("");try{
    const r=await fetch("/api/student/login",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({phone,code,challengeId:challenge}),signal:AbortSignal.timeout(15000)});
    const d=await r.json();if(!r.ok)throw new Error(d.error??"ورود انجام نشد.");refreshAuthenticated();
  }catch(e){setError(e instanceof Error?e.message:"ورود انجام نشد.")}finally{setBusy(false)}};
  return <main className="portal-login-page student-login-page" dir="rtl"><a href="/" className="portal-back"><ArrowRight/> بازگشت به صفحه اصلی</a><form onSubmit={submit} className="portal-login-card">
    <div className="portal-login-icon"><UserRound/></div><p>STUDENT PORTAL</p><h1>ورود با کد پیامکی</h1><span>شماره موبایل ثبت‌شده در سایت را وارد کن.</span>
    {googleMessage&&<p className="google-login-error" role="alert">{googleMessage}</p>}
    <GoogleSignInButton/>
    <label htmlFor="student-sms-phone">شماره موبایل</label><Input id="student-sms-phone" type="tel" inputMode="tel" autoComplete="tel" dir="ltr" disabled={Boolean(challenge)||busy} value={phone} onChange={e=>setPhone(e.target.value)} placeholder="09xxxxxxxxx" className="h-12 text-base"/>
    {challenge&&<><label htmlFor="student-sms-code">کد ورود ۶ رقمی</label><Input id="student-sms-code" key={challenge} autoFocus autoComplete="one-time-code" inputMode="numeric" dir="ltr" maxLength={6} value={code} onChange={e=>setCode(normalizeDigits(e.target.value).replace(/\D/g,"").slice(0,6))} className="h-12 text-center text-lg tracking-[.35em]"/><small>این کد یک‌بارمصرف است و ۵ دقیقه اعتبار دارد.</small></>}
    {message&&<small role="status">{message}</small>}<div className="min-h-6 text-center text-xs text-amber-300" role="alert">{error}</div>
    <Button type="submit" disabled={busy||!/^09\d{9}$/.test(normalizePhone(phone))||(challenge?code.length!==6:remaining>0)} className="h-12 w-full rounded-xl">{busy?<LoaderCircle className="animate-spin"/>:<LockKeyhole/>}{challenge?"تأیید کد و ورود":"دریافت کد پیامکی"}</Button>
    {challenge&&<div className="mt-3 flex flex-wrap justify-between gap-3"><Button type="button" variant="outline" disabled={busy||remaining>0} onClick={()=>void requestCode()}>{remaining?`ارسال دوباره تا ${remaining.toLocaleString("fa-IR")} ثانیه`:"ارسال دوباره کد"}</Button><Button type="button" variant="ghost" disabled={busy} onClick={()=>{setChallenge("");setCode("");setError("");setMessage("")}}>تغییر شماره</Button></div>}
    {!challenge&&remaining>0&&<small>{remaining.toLocaleString("fa-IR")} ثانیه تا امکان درخواست دوباره</small>}
  </form></main>;
}
