"use client";
import {useChatScroll} from "@/hooks/use-chat-scroll";
import {mergeChatMessage} from "@/lib/chat-scroll";
import {useAutoRefresh} from "@/hooks/use-auto-refresh";
import {notifyDataUpdated} from "@/lib/auto-refresh";
import {MessageReceipt,useMessageReadReceipts} from "@/components/message-receipt";
import {PersianDatePicker} from "@/components/persian-date-picker";
import {markNotificationRead} from "@/lib/notification-read-client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ArrowDown, BellRing, CheckCircle2, ChevronLeft, CircleDollarSign, Clock3, CreditCard, FileText, MessageCircle, Pencil, RefreshCw, Search, Send, Trash2, UsersRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { CoachNotificationComposer } from "@/components/coach-notification-composer";
import { portalFetch } from "@/lib/pwa-client";
import { PushNotificationControl } from "@/components/push-notification-control";
import { GraphicSectionIcon } from "@/components/graphic-section-icon";
import { notificationTarget } from "@/lib/notification-target";
import { GlassSectionIcon } from "@/components/glass-section-icon";

export type Overview={
  applications:Array<{id:string;client_id:string;name:string;package_name:string;status:string;price_amount:number|null;updated_at:string}>;
  months:Array<{month:string;payments:number;students:number;total:number}>;
  billingIssues?:Array<{id:string;client_id:string;package_name:string;received_amount:number;ledger_amount:number}>;
  transactions:Array<{id:string;billing_id:string;application_id:string;client_id:string;amount:number;paid_at:string;package_name:string;name:string;note?:string}>;
  notifications:Array<{id:string;type:string;title:string;body:string;url:string;tag:string;read_at:string|null;created_at:string;actor_client_id?:string|null;application_id?:string|null}>;
  unreadChat:number;
  unreadNotifications:number;
};
export const EMPTY_OVERVIEW:Overview={applications:[],months:[],transactions:[],notifications:[],unreadChat:0,unreadNotifications:0};
const STATUS:Record<string,string>={draft:"درخواست جدید",awaiting_payment:"در انتظار پرداخت",payment_review:"بررسی پرداخت",payment_approved:"پرداخت تأیید شد",writing:"در حال نوشتن",ready:"در حال نوشتن",delivered:"ارسال شده"};
const money=(value:number)=>`${value.toLocaleString("fa-IR")} تومان`;
const monthName=(value:string)=>new Intl.DateTimeFormat("fa-IR",{year:"numeric",month:"long"}).format(new Date(`${value}-01T12:00:00`));
const currentMonth=()=>new Date().toISOString().slice(0,7);

export function CoachHome({
  overview,
  onOpenApplications,
  onOpenClient,
  onOpenPricing,
  onOpenAccounting,
  onOpenBuilder,
  onOpenChat,
  onOpenNotifications,
  onDownloadPdf,
}:{
  overview:Overview;
  onOpenApplications:()=>void;
  onOpenClient:(id:string)=>void;
  onOpenPricing:()=>void;
  onOpenAccounting:()=>void;
  onOpenBuilder:(tab:"workout"|"nutrition"|"supplements"|"medications")=>void;
  onOpenChat:()=>void;
  onOpenNotifications:()=>void;
  onDownloadPdf:()=>void;
}){
 const active=overview.applications.filter(item=>["draft","awaiting_payment","payment_review","payment_approved","writing","ready"].includes(item.status));const current=overview.months.find(row=>row.month===currentMonth());
 const modules=[
  {key:"training",label:"برنامه تمرینی",hint:"نوشتن و ویرایش تمرین",action:()=>onOpenBuilder("workout"),graphic:true},
  {key:"nutrition",label:"رژیم غذایی",hint:"وعده‌ها و ماکروها",action:()=>onOpenBuilder("nutrition"),graphic:true},
  {key:"supplements",label:"مکمل‌ها",hint:"برنامه مکمل و ویتامین",action:()=>onOpenBuilder("supplements"),graphic:true},
  {key:"medications",label:"دارو / PCT",hint:"برنامه دارویی و PCT",action:()=>onOpenBuilder("medications"),graphic:true},
  {key:"messages",label:"همراه شاگرد",hint:`${overview.unreadChat.toLocaleString("fa-IR")} پیام خوانده‌نشده`,action:onOpenChat,graphic:true},
  {key:"billing",label:"حسابداری",hint:current?money(Number(current.total)):"۰ تومان",action:onOpenAccounting,graphic:true},
  {key:"notifications",label:"اعلان‌ها",hint:`${overview.unreadNotifications.toLocaleString("fa-IR")} اعلان خوانده‌نشده`,action:onOpenNotifications,graphic:true},
  {key:"pdf",label:"PDF",hint:"خروجی برنامه فعلی",action:onDownloadPdf,graphic:true},
 ] as const;
 return <div><PageTitle title="داشبورد مربی" description="درخواست‌ها، برنامه‌ها، پیام‌ها و حسابداری را از یک نمای سریع مدیریت کن."/>
  <Button className="mb-4" onClick={onOpenPricing}><CreditCard/> قیمت پکیج‌ها و برنامه‌ها</Button>
  <section className="dashboard-module-grid">{modules.map(item=><button key={item.key} type="button" onClick={item.action} className={`dashboard-module-card dashboard-module-${item.key}`}>
    <span className="dashboard-module-icon"><GraphicSectionIcon name={item.key} size={66} className="dashboard-color-graphic"/></span>
    <span className="dashboard-module-copy"><strong>{item.label}</strong><small>{item.hint}</small></span><ChevronLeft className="dashboard-module-chevron"/>
  </button>)}</section>
  <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4"><Metric icon={<Clock3/>} label="نیازمند پیگیری" value={active.length}/><Metric icon={<MessageCircle/>} label="پیام خوانده‌نشده" value={overview.unreadChat}/><Metric icon={<CreditCard/>} label="پرداخت ماه" value={current?.payments??0}/><Metric icon={<CircleDollarSign/>} label="دریافتی ماه" value={current?money(Number(current.total)):"۰ تومان"}/></div>
  <section className="mt-5 rounded-3xl border border-white/8 bg-card p-5"><div className="flex items-center justify-between gap-3"><div><h2 className="font-black text-white">درخواست‌ها و وضعیت‌های مهم</h2><p className="mt-1 text-xs text-zinc-500">موارد فعال به ترتیب آخرین تغییر</p></div><Button variant="outline" onClick={onOpenApplications}>همه درخواست‌ها <ChevronLeft/></Button></div><div className="mt-4 grid gap-2">{active.slice(0,6).map(item=><button key={item.id} onClick={()=>onOpenClient(item.client_id)} className="flex items-center gap-3 rounded-2xl border border-white/7 bg-black/20 p-3 text-right hover:border-white/20"><span className="grid size-10 place-items-center rounded-xl border border-white/10 bg-white/[.055] text-zinc-200"><Clock3/></span><span className="min-w-0 flex-1"><strong className="block truncate text-sm text-white">{item.name}</strong><small className="text-zinc-500">{item.package_name}</small></span><span className="rounded-full border border-white/8 bg-white/5 px-3 py-1 text-xs text-zinc-300">{STATUS[item.status]??item.status}</span></button>)}{active.length===0&&<Empty text="موردی برای پیگیری باقی نمانده است."/>}</div></section>
 </div>;
}

export function CoachAccounting({overview,onUpdated}:{overview:Overview;onUpdated?:()=>void}){
  const current=overview.months.find(row=>row.month===currentMonth());
  const [editing,setEditing]=useState<Overview["transactions"][number]|null>(null);
  const [amount,setAmount]=useState(0);
  const [note,setNote]=useState("");
  const [eventAt,setEventAt]=useState("");
  const [reason,setReason]=useState("");
  const [busy,setBusy]=useState(false);
  const [feedback,setFeedback]=useState("");
  const edit=(item:Overview["transactions"][number])=>{
    setEditing(item);setAmount(Number(item.amount));setNote(item.note??"");
    const date=new Date(item.paid_at);
    setEventAt(Number.isNaN(date.valueOf())?"":`${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${String(date.getDate()).padStart(2,"0")}T${String(date.getHours()).padStart(2,"0")}:${String(date.getMinutes()).padStart(2,"0")}`);
    setReason("");setFeedback("");
  };
  const submit=async(remove:boolean)=>{
    if(!editing||busy)return;
    if(reason.trim().length<3){setFeedback("دلیل اصلاح یا حذف را وارد کنید.");return;}
    if(remove&&!window.confirm(`تراکنش ${money(Math.abs(Number(editing.amount)))} برای ${editing.name} از گزارش مالی حذف شود؟ سابقه اصلاح محفوظ می‌ماند.`))return;
    if(!remove&&(!eventAt||!Number.isFinite(amount))){setFeedback("مبلغ و تاریخ معتبر وارد کنید.");return;}
    setBusy(true);setFeedback("");
    try{
      const body=remove?{id:editing.id,reason:reason.trim()}:{id:editing.id,amount:Math.round(amount),eventAt:new Date(eventAt).toISOString(),note:note.trim(),reason:reason.trim()};
      const response=await fetch("/api/billing/entries",{method:remove?"DELETE":"PATCH",headers:{"content-type":"application/json"},body:JSON.stringify(body)});
      const data=await response.json() as {error?:string};
      if(!response.ok)throw new Error(data.error||"اصلاح حسابداری انجام نشد.");
      setEditing(null);setFeedback(remove?"تراکنش از جمع حسابداری خارج شد؛ سابقه حذف محفوظ است.":"تراکنش اصلاح شد؛ جمع حسابداری به‌روز شد.");
      onUpdated?.();
    }catch(error){setFeedback(error instanceof Error?error.message:"خطای ناشناخته در اصلاح حسابداری");}
    finally{setBusy(false);}
  };
  return <div><PageTitle title="حسابداری مربی" description="ویرایش، اصلاح و حذف ثبت اشتباه با سابقه تغییرات؛ جمع مالی فقط از تراکنش‌های معتبر محاسبه می‌شود."/>
    <div className="grid gap-3 sm:grid-cols-3"><Metric icon={<CircleDollarSign/>} label="جمع ماه جاری" value={current?money(Number(current.total)):"۰ تومان"}/><Metric icon={<CreditCard/>} label="تعداد پرداخت" value={Number(current?.payments??0)}/><Metric icon={<UsersRound/>} label="شاگرد پرداخت‌کننده" value={Number(current?.students??0)}/></div>
    <section className="mt-5 overflow-hidden rounded-3xl border border-white/8 bg-card"><div className="grid grid-cols-[1.2fr_.7fr_.7fr_1fr] gap-2 border-b border-white/8 px-4 py-3 text-xs text-zinc-500"><span>ماه</span><span>پرداخت</span><span>شاگرد</span><span>جمع</span></div>{overview.months.map(row=><div key={row.month} className="grid grid-cols-[1.2fr_.7fr_.7fr_1fr] gap-2 border-b border-white/5 px-4 py-4 text-sm last:border-0"><strong className="text-white">{monthName(row.month)}</strong><span>{Number(row.payments).toLocaleString("fa-IR")}</span><span>{Number(row.students).toLocaleString("fa-IR")}</span><span className="font-bold text-emerald-400">{money(Number(row.total))}</span></div>)}{!overview.months.length&&<Empty text="هنوز پرداخت تأییدشده‌ای ثبت نشده است."/>}</section>
    {Boolean(overview.billingIssues?.length)&&<section className="mt-5 rounded-2xl border border-rose-300/30 bg-rose-400/[.05] p-4"><h2 className="font-bold text-white">نیازمند بررسی مغایرت حسابداری</h2><p className="mt-2 text-xs leading-6 text-zinc-300">مانده پرونده مالی بعضی شاگردها با جمع تراکنش‌های معتبر یکی نیست. احتمال ثبت تکراری یا اصلاح قدیمی وجود دارد؛ بدون بررسی، هیچ پرداختی خودکار حذف نمی‌شود.</p><div className="mt-3 grid gap-2">{overview.billingIssues?.slice(0,8).map(issue=><div key={issue.id} className="flex flex-wrap justify-between gap-2 border-t border-white/10 py-2 text-xs"><span>{issue.package_name}</span><span>دریافتی پرونده: {money(Number(issue.received_amount))}</span><span>جمع تراکنش‌ها: {money(Number(issue.ledger_amount))}</span></div>)}</div></section>}
    <section className="mt-5 overflow-hidden rounded-3xl border border-white/8 bg-card"><div className="border-b border-white/8 px-4 py-4"><h2 className="font-black text-white">دفتر پرداخت‌ها</h2><p className="mt-1 text-xs text-zinc-400">برای هر تراکنش «ویرایش» را بزن؛ در صورت ثبت اشتباه، می‌توان مبلغ، تاریخ و توضیحات را اصلاح کرد یا تراکنش را از محاسبات حذف کرد. تمام اصلاحات ثبت می‌شوند.</p></div>
      {feedback&&<p role="status" className="mx-4 mt-3 rounded-xl border border-white/15 bg-white/5 p-3 text-sm text-white">{feedback}</p>}
      {editing&&<div className="m-4 rounded-2xl border border-white/20 bg-white/[.045] p-4" dir="rtl"><h3 className="font-bold text-white">اصلاح پرداخت {editing.name}</h3><p className="mt-1 text-xs text-zinc-400">{editing.package_name} · {editing.id}</p><div className="mt-4 grid gap-3 md:grid-cols-2"><label className="text-sm text-zinc-300">مبلغ تراکنش (تومان)<Input type="number" value={amount} onChange={e=>setAmount(Number(e.target.value))} className="mt-2"/></label><label className="text-sm text-zinc-300">تاریخ پرداخت<PersianDatePicker value={eventAt.slice(0,10)} onChange={date=>setEventAt(date+'T'+(eventAt.split('T')[1]||'12:00'))} className="mt-2"/><Input type="time" aria-label="ساعت پرداخت" value={eventAt.split('T')[1]||'12:00'} onChange={e=>setEventAt(eventAt.slice(0,10)+'T'+e.target.value)}/></label><label className="text-sm text-zinc-300">توضیح تراکنش<Input value={note} onChange={e=>setNote(e.target.value)} className="mt-2" maxLength={300}/></label><label className="text-sm text-zinc-300">دلیل اصلاح یا حذف (الزامی)<Input value={reason} onChange={e=>setReason(e.target.value)} className="mt-2" placeholder="مثلاً مبلغ تکراری وارد شده" maxLength={300}/></label></div><div className="mt-4 flex flex-wrap gap-2"><Button onClick={()=>void submit(false)} disabled={busy||reason.trim().length<3}><Pencil className="size-4"/>ذخیره اصلاح</Button><Button variant="outline" onClick={()=>void submit(true)} disabled={busy||reason.trim().length<3} className="border-rose-500/40 text-rose-300"><Trash2 className="size-4"/> حذف تراکنش اشتباه</Button><Button variant="outline" onClick={()=>{setEditing(null);setFeedback("");}} disabled={busy}>انصراف</Button></div></div>}
      <div className="divide-y divide-white/5">{overview.transactions.map(item=><div key={item.id} className="grid gap-2 px-4 py-4 sm:grid-cols-[1fr_1fr_auto_auto_auto] sm:items-center"><div><strong className="text-sm text-white">{item.name}</strong><p className="mt-1 text-xs text-zinc-500">{item.package_name}</p></div><time className="text-xs text-zinc-400">{new Date(item.paid_at).toLocaleString("fa-IR")}</time><span className="text-xs text-zinc-400">{item.note|| (Number(item.amount)>=0?"دریافت وجه":"اصلاح حساب")}</span><strong className={`text-sm ${Number(item.amount)>=0?"text-emerald-400":"text-rose-400"}`}>{Number(item.amount)>=0?money(Number(item.amount)):`−${money(Math.abs(Number(item.amount)))}`}</strong><Button variant="outline" size="sm" onClick={()=>edit(item)} className="border-white/20"><Pencil className="size-4"/> ویرایش / حذف</Button></div>)}{!overview.transactions.length&&<Empty text="هنوز تراکنشی در دفتر پرداخت ثبت نشده است."/>}</div>
    </section>
  </div>;
}

export function CoachNotifications({overview,onRead,onOpen}:{overview:Overview;onRead?:(ids?:string[])=>void;onOpen?:(url:string)=>void}){
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState("");
  const markAll=async()=>{if(busy||overview.unreadNotifications===0)return;setBusy(true);setError("");try{const response=await portalFetch("/api/notifications",{method:"PATCH",headers:{"content-type":"application/json","x-portal-role":"coach"},body:JSON.stringify({all:true})});if(!response.ok)throw new Error();onRead?.();}catch{setError("خواندن اعلان‌ها انجام نشد؛ دوباره تلاش کنید.")}finally{setBusy(false)}};
  return <div><PageTitle title="اعلان‌ها" description="ثبت‌نام، درخواست برنامه، رسید پرداخت، مراحل نگارش، ارسال برنامه و پیام‌ها به‌صورت رویداد مستقل ثبت می‌شوند."/><PushNotificationControl/>{error&&<p role="status">{error}</p>}<CoachNotificationComposer/><section className="mt-5 rounded-3xl border border-white/8 bg-card p-5"><div className="flex items-center justify-between gap-3"><h2 className="flex items-center gap-3 font-black text-white"><GlassSectionIcon name="notifications" size={44} className="coach-feature-glass"/> اعلان‌های کاری</h2>{overview.unreadNotifications>0&&<Button type="button" variant="outline" onClick={()=>void markAll()} disabled={busy}>خواندن همه</Button>}</div><div className="mt-4 grid gap-2">{overview.notifications.map(item=><a href={notificationTarget("coach",item)} onClick={event=>{if(!item.read_at){onRead?.([item.id]);void markNotificationRead("coach",item.id).catch(reason=>setError(reason.message));}if(onOpen&&!event.ctrlKey&&!event.metaKey&&!event.shiftKey&&!event.altKey){event.preventDefault();onOpen(notificationTarget("coach",item));}}} key={item.id} className={`flex items-start gap-3 rounded-2xl border p-3 transition ${item.read_at?"border-white/5 bg-black/15":"border-amber-400/20 bg-amber-400/[.055]"}`}><BellRing className={item.read_at?"mt-1 size-5 text-zinc-600":"mt-1 size-5 text-amber-400"}/><div className="min-w-0 flex-1"><strong className="block text-sm text-white">{item.title}</strong><p className="mt-1 text-xs leading-6 text-zinc-400">{item.body}</p></div><time className="shrink-0 text-[10px] text-zinc-600">{new Date(item.created_at).toLocaleString("fa-IR")}</time></a>)}{!overview.notifications.length&&<Empty text="اعلان جدیدی ندارید."/>}</div></section></div>}

type Thread={client_id:string;name:string;phone:string;last_message:string|null;last_at:string|null;unread:number;has_account:number};
type Message={id:string;sender_role:"coach"|"student";body:string;created_at:string;read_at?:string|null};
export function CoachChat({onUnreadChange,initialClientId="",onClientChange}:{onUnreadChange:(count:number)=>void;initialClientId?:string;onClientChange?:(id:string)=>void}){
  const[threads,setThreads]=useState<Thread[]>([]),[selected,setSelected]=useState(""),[messages,setMessages]=useState<Message[]>([]),[body,setBody]=useState(""),[busy,setBusy]=useState(false),[error,setError]=useState(""),[query,setQuery]=useState("");
  const requestSequence=useRef(0),selectedRef=useRef(""),sending=useRef(false),drafts=useRef<Record<string,string>>({}),handledInitial=useRef("");
  const scroll=useChatScroll(messages.at(-1)?.id??"",messages.length,Boolean(selected),selected);
  const markRead=useCallback((ids:string[],at:string)=>setMessages(current=>current.map(m=>ids.includes(m.id)?{...m,read_at:at}:m)),[]);
  useMessageReadReceipts(messages,'coach',selected,Boolean(selected),markRead);
  const loadThreads=useCallback(async()=>{try{const r=await fetch("/api/messages",{cache:"no-store",signal:AbortSignal.timeout(15000),headers:{"x-portal-role":"coach"}});const d=await r.json() as {threads?:Thread[];error?:string};if(!r.ok)throw new Error(d.error??"دریافت گفت‌وگوها انجام نشد.");const rows=d.threads??[];setThreads(rows);onUnreadChange(rows.reduce((sum,t)=>sum+Number(t.unread),0));}catch(e){setError(e instanceof Error?e.message:"دریافت گفت‌وگوها انجام نشد.");}},[onUnreadChange]);
  const loadMessages=useCallback(async(id:string)=>{if(document.visibilityState==='hidden')return;const seq=++requestSequence.current;try{const r=await fetch(`/api/messages?clientId=${encodeURIComponent(id)}&read=0`,{cache:"no-store",signal:AbortSignal.timeout(15000),headers:{"x-portal-role":"coach"}});const d=await r.json() as {messages?:Message[];error?:string;accountReady?:boolean};if(!r.ok)throw new Error(d.error??"دریافت پیام‌ها انجام نشد.");if(seq!==requestSequence.current||selectedRef.current!==id)return;setMessages(d.messages??[]);setError(d.accountReady===false?(d.error??"دسترسی پنل شاگرد فعال نیست."):"");void loadThreads();}catch(e){if(seq!==requestSequence.current||selectedRef.current!==id)return;setError(e instanceof Error?e.message:"دریافت پیام‌ها انجام نشد.");}},[loadThreads]);
  useAutoRefresh(async()=>{await loadThreads();if(selected)await loadMessages(selected)},{intervalMs:10000,initial:true});
  const selectThread=useCallback((id:string)=>{if(sending.current)return;requestSequence.current++;selectedRef.current=id;setSelected(id);setMessages([]);setError('');setBody(drafts.current[id]??'');void loadMessages(id)},[loadMessages]);
  useEffect(()=>{if(initialClientId&&!busy&&handledInitial.current!==initialClientId){handledInitial.current=initialClientId;selectThread(initialClientId)}},[initialClientId,selectThread,busy]);
  const selectedThread=threads.find(t=>t.client_id===selected);
  const visible=useMemo(()=>{const q=query.trim().toLowerCase();return !q?threads:threads.filter(t=>`${t.name} ${t.phone} ${t.last_message??""}`.toLowerCase().includes(q));},[threads,query]);
  const send=async()=>{const client=selected;if(!client||!body.trim()||sending.current||selectedThread?.has_account===0)return;sending.current=true;setBusy(true);setError('');const text=body.trim();setBody('');drafts.current[client]='';try{const r=await fetch('/api/messages',{method:'POST',headers:{'content-type':'application/json','x-portal-role':'coach'},body:JSON.stringify({clientId:client,body:text}),signal:AbortSignal.timeout(25000)});const d=await r.json() as {message?:Message;error?:string};if(!r.ok)throw Error(d.error??'ارسال پیام انجام نشد.');if(selectedRef.current===client){requestSequence.current++;if(d.message)setMessages(current=>mergeChatMessage(current,d.message!));scroll.forceBottom();void loadMessages(client)}notifyDataUpdated()}catch(e){drafts.current[client]=text;if(selectedRef.current===client){setBody(text);setError(e instanceof Error?e.message:'ارسال پیام انجام نشد.')}}finally{sending.current=false;setBusy(false)}};
  return <div><PageTitle title="پیام‌ها و سؤال‌ها" description="جست‌وجوی شاگرد، گفت‌وگوی مستقل، وضعیت دسترسی پنل و خطای ارسال همه در همین صفحه دیده می‌شود."/><div className="mb-4 flex items-center gap-3 rounded-2xl border border-amber-400/15 bg-amber-400/[.035] p-3"><GlassSectionIcon name="messages" size={48} className="coach-feature-glass"/><div><strong className="text-sm text-white">پیام‌رسان مربی و شاگرد</strong><p className="mt-1 text-xs text-zinc-500">پیام جدید برای هر دو طرف نوتیفیکیشن دارد.</p></div></div>
    <div ref={scroll.shell} className="messenger-chat coach-chat-grid grid min-h-[420px] overflow-hidden rounded-3xl border border-white/8 bg-card md:grid-cols-[320px_1fr]">
      <aside className="min-h-0 overflow-y-auto border-b border-white/8 p-3 md:border-b-0 md:border-l"><div className="sticky top-0 z-10 -mx-1 mb-2 bg-card px-1 pb-1"><div className="mb-3 flex items-center justify-between px-2"><strong>گفت‌وگوها</strong><Button size="icon" variant="ghost" onClick={()=>void loadThreads()}><RefreshCw/></Button></div><div className="relative mb-3"><Search className="absolute right-3 top-1/2 size-4 -translate-y-1/2 text-zinc-500"/><Input value={query} onChange={e=>setQuery(e.target.value)} placeholder="جست‌وجوی نام یا شماره..." className="h-10 pr-9"/></div></div>{visible.map(t=><button key={t.client_id} disabled={busy} onClick={()=>{selectThread(t.client_id);onClientChange?.(t.client_id)}} className={`mb-2 flex w-full items-center gap-3 rounded-2xl border p-3 text-right ${selected===t.client_id?"border-amber-500/30 bg-amber-500/15":"border-transparent bg-black/15"}`}><span className="grid size-10 place-items-center rounded-xl bg-zinc-800 font-black">{t.name?.slice(0,1)}</span><span className="min-w-0 flex-1"><strong className="block truncate text-sm">{t.name}</strong><small className={`block truncate ${t.has_account?"text-zinc-500":"text-amber-400"}`}>{t.has_account?(t.last_message??t.phone):"دسترسی پنل شاگرد فعال نیست"}</small></span>{Number(t.unread)>0&&<b className="grid size-6 place-items-center rounded-full bg-amber-500 text-xs">{Number(t.unread).toLocaleString("fa-IR")}</b>}</button>)}{!visible.length&&<Empty text="شاگردی پیدا نشد."/>}</aside>
      <section className="flex min-h-0 flex-col">{selected?<><div className="shrink-0 border-b border-white/8 px-4 py-3"><strong className="text-white">{selectedThread?.name??"شاگرد"}</strong><p className="mt-1 text-xs text-zinc-500">{selectedThread?.phone||"بدون شماره"}</p></div>{error&&<p className="m-3 shrink-0 rounded-xl border border-amber-500/25 bg-amber-500/[.06] p-3 text-xs leading-6 text-amber-200" role="alert">{error}</p>}<div ref={scroll.history} onScroll={scroll.onScroll} className="messenger-history min-h-0 flex-1 space-y-3 overflow-y-auto overscroll-contain p-4" role="log" aria-label="پیام‌های گفتگو" aria-live="polite" aria-relevant="additions">{messages.map(m=><div key={m.id} className={`messenger-bubble max-w-[82%] rounded-2xl px-4 py-3 text-sm ${m.sender_role==="coach"?"ml-auto bg-amber-500 text-white":"mr-auto bg-white/7 text-zinc-100"}`}><p className="whitespace-pre-wrap">{m.body}</p><time className="mt-1 block text-[10px] opacity-60">{new Date(m.created_at).toLocaleString("fa-IR")}</time>{m.sender_role==="coach"&&<MessageReceipt readAt={m.read_at}/>}</div>)}{!messages.length&&!error&&<Empty text="هنوز پیامی ثبت نشده است."/>}</div>{scroll.newMessages&&<button className="chat-new-messages" type="button" onClick={scroll.forceBottom}><ArrowDown size={16}/> آخر گفتگو</button>}<div className="messenger-compose sticky bottom-0 z-20 flex shrink-0 gap-2 border-t border-white/8 bg-card/95 p-3 pb-[max(.75rem,env(safe-area-inset-bottom))] backdrop-blur"><Textarea value={body} onChange={e=>{setBody(e.target.value);drafts.current[selected]=e.target.value}} maxLength={2000} onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey&&!e.nativeEvent.isComposing){e.preventDefault();void send();}}} disabled={busy||selectedThread?.has_account===0} placeholder={selectedThread?.has_account===0?"ابتدا دسترسی شاگرد را از پروفایل فعال کنید":"پیام برای شاگرد…"} className="min-h-12 max-h-28 resize-none"/><Button aria-label="ارسال پیام به شاگرد" type="button" onClick={send} disabled={busy||!body.trim()||selectedThread?.has_account===0} className="h-12 shrink-0 bg-amber-500"><Send/></Button></div></>:<Empty text="برای شروع، یک شاگرد را انتخاب کنید."/>}</section>
    </div>
  </div>;
}

function PageTitle({title,description}:{title:string;description:string}){return <div className="mb-6"><p className="mb-2 text-[11px] font-bold tracking-[.2em] text-amber-400">COACH PANEL</p><h1 className="text-2xl font-black text-white sm:text-3xl">{title}</h1><p className="mt-2 text-sm text-zinc-500">{description}</p></div>}
function Metric({icon,label,value}:{icon:React.ReactNode;label:string;value:string|number}){return <div className="rounded-2xl border border-white/8 bg-card p-4"><span className="text-amber-400 [&>svg]:size-5">{icon}</span><strong className="mt-3 block text-xl text-white">{typeof value==="number"?value.toLocaleString("fa-IR"):value}</strong><small className="text-zinc-500">{label}</small></div>}
function Empty({text}:{text:string}){return <div className="grid min-h-28 place-items-center p-5 text-center text-sm text-zinc-500"><span>{text}</span></div>}
