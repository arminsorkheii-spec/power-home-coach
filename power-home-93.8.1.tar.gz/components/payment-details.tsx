"use client";

import {DiscountEntry} from "@/components/discount-entry";
import { useState } from "react";
import { Copy, CreditCard } from "lucide-react";

export function PaymentDetails() {
  const [message,setMessage] = useState("");
  const copy = async () => {
    try { await navigator.clipboard.writeText("6219861988270095"); setMessage("شماره کارت کپی شد."); }
    catch { setMessage("برای کپی، شماره کارت را نگه دارید یا انتخاب کنید."); }
  };
  return <section className="payment-bank-details" aria-label="اطلاعات کارت پرداخت">
    <DiscountEntry/><h3><CreditCard aria-hidden="true"/> پرداخت کارت به کارت</h3>
    <p>مبلغ این درخواست را به کارت زیر واریز کنید و سپس تصویر رسید را بفرستید.</p>
    <strong className="payment-card-number" dir="ltr">6219 8619 8827 0095</strong>
    <p>بلو بانک · به نام <b>علیرضا سرخه</b></p>
    <button type="button" onClick={()=>void copy()}><Copy aria-hidden="true"/> کپی شماره کارت</button>
    <small role="status">{message}</small>
  </section>;
}
