"use client";
import {useAutoRefresh} from "@/hooks/use-auto-refresh";
import {notifyDataUpdated} from "@/lib/auto-refresh";
import { markNotificationRead } from "@/lib/notification-read-client";
import { notificationTarget } from "@/lib/notification-target";
import { useCallback,useEffect,useState } from "react";
import { BellRing,CheckCheck,LoaderCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { portalFetch } from "@/lib/pwa-client";
import { GlassSectionIcon } from "@/components/glass-section-icon";

type Notice={id:string;type:string;title:string;body:string;url:string;application_id?:string|null;read_at:string|null;created_at:string};
export function StudentNotifications({onOpen,onUnreadChange}:{onOpen?:(url:string)=>void;onUnreadChange?:(count:number)=>void}){
  const [error,setError]=useState("");
  const [items,setItems]=useState<Notice[]>([]),[unread,setUnread]=useState(0),[busy,setBusy]=useState(false);
  const load=useCallback(async()=>{try{const r=await portalFetch("/api/notifications",{cache:"no-store",headers:{"x-portal-role":"student"}});if(!r.ok)return;const d=await r.json() as {notifications?:Notice[];unread?:number};setItems(Array.isArray(d.notifications)?d.notifications:[]);setUnread(Number(d.unread??0));}catch{/* push remains available */}},[]);
  useAutoRefresh(load,{initial:true,intervalMs:20000});
  useEffect(()=>{onUnreadChange?.(unread)},[unread,onUnreadChange]);
  const markAll=async()=>{if(!unread||busy)return;setBusy(true);setError("");try{const r=await portalFetch("/api/notifications",{method:"PATCH",headers:{"content-type":"application/json","x-portal-role":"student"},body:JSON.stringify({all:true})});if(!r.ok)throw new Error();{setUnread(0);setItems(current=>current.map(item=>({...item,read_at:item.read_at??new Date().toISOString()})));}}catch{setError("خواندن اعلان‌ها انجام نشد؛ دوباره تلاش کنید.")}finally{setBusy(false)}};
  if(!items.length)return <section className="student-notification-center"><h2>اعلان‌های من</h2><p>هنوز اعلانی در این فهرست نداری.</p>{error&&<p role="status">{error}</p>}</section>;
  return <section className="student-notification-center"><div className="student-files-heading"><div><span>NOTIFICATIONS</span><h2><GlassSectionIcon name="notifications" size={42} className="student-heading-glass"/> اعلان‌های من</h2><p>تأیید پرداخت، نگارش برنامه، ارسال برنامه و پیام‌های مهم اینجا هم ذخیره می‌شوند.</p></div>{unread>0&&<Button type="button" variant="outline" onClick={()=>void markAll()} disabled={busy}>{busy?<LoaderCircle className="animate-spin"/>:<CheckCheck/>} خواندن همه</Button>}</div>{error&&<p role="status">{error}</p>}<div className="student-notification-list">{items.slice(0,8).map(item=><a key={item.id} href={notificationTarget("student",item)} onClick={event=>{if(!item.read_at){const readAt=new Date().toISOString();setItems(current=>current.map(notice=>notice.id===item.id?{...notice,read_at:readAt}:notice));setUnread(current=>Math.max(0,current-1));void markNotificationRead("student",item.id).catch(reason=>{setError(reason.message);void load();});}if(onOpen&&!event.ctrlKey&&!event.metaKey&&!event.shiftKey&&!event.altKey){event.preventDefault();onOpen(notificationTarget("student",item));}}} className={item.read_at?"read":"unread"}><BellRing/><div><strong>{item.title}</strong><p>{item.body}</p><time>{new Date(item.created_at).toLocaleString("fa-IR")}</time></div></a>)}</div></section>;
}
