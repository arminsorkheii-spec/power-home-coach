"use client";
import {useEffect,useRef,useState} from 'react';
import {RotateCcw,ZoomIn,ZoomOut} from 'lucide-react';
import {loadAnatomyGeometry} from '@/lib/anatomy-geometry';
import {MUSCLES,type MuscleId,type MuscleRow} from '@/lib/muscle-data';

type Engine={draw:()=>void;rotate:(angle:number)=>void;zoom:(amount:number)=>void};
export function MuscleBody3D({rows,selected,onSelect}:{rows:MuscleRow[];selected:MuscleId;onSelect:(id:MuscleId)=>void}){
 const stage=useRef<HTMLDivElement>(null),canvas=useRef<HTMLCanvasElement>(null),state=useRef({rows,selected,onSelect}),engine=useRef<Engine|null>(null);
 const [visible,setVisible]=useState(false),[status,setStatus]=useState<'loading'|'ready'|'error'>('loading'),[error,setError]=useState(''),[revision,setRevision]=useState(0),[fallbackView,setFallbackView]=useState<'front'|'back'>('front');
 state.current={rows,selected,onSelect};
 useEffect(()=>{const node=stage.current;if(!node)return;if(!('IntersectionObserver' in window)){setVisible(true);return}const observer=new IntersectionObserver(entries=>{if(entries.some(e=>e.isIntersecting)){setVisible(true);observer.disconnect()}},{rootMargin:'80px'});observer.observe(node);return()=>observer.disconnect()},[]);
 useEffect(()=>{
  if(!visible)return;
  const element=canvas.current;if(!element)return;
  setStatus('loading');setError('');
  const gl=element.getContext('webgl',{alpha:true,antialias:true,preserveDrawingBuffer:false});
  if(!gl){setStatus('error');setError('این دستگاه نمای ثابت را نشان می‌دهد؛ عضله را از فهرست انتخاب کن.');return}
  const controller=new AbortController(),buffers:WebGLBuffer[]=[],shaders:WebGLShader[]=[];
  let disposed=false,program:WebGLProgram|null=null,observer:ResizeObserver|null=null,frame=0,angle=0,zoom=1;
  let drag:{x:number;y:number;startX:number;startY:number;moved:boolean}|null=null;
  let pickBuffer:WebGLFramebuffer|null=null,pickTexture:WebGLTexture|null=null,pickDepth:WebGLRenderbuffer|null=null,pickWidth=0,pickHeight=0;
  const fail=()=>{if(!disposed){setStatus('error');setError('مدل آناتومی بارگذاری نشد؛ انتخاب از فهرست عضلات همچنان فعال است.')}};
  const lost=(event:Event)=>{event.preventDefault();engine.current=null;fail()},restored=()=>setRevision(value=>value+1);
  element.addEventListener('webglcontextlost',lost);element.addEventListener('webglcontextrestored',restored);
  const events:{name:keyof HTMLElementEventMap;handler:EventListener}[]=[];
  void loadAnatomyGeometry(controller.signal).then(({manifest,bytes})=>{
   if(disposed)return;
   const shader=(kind:number,source:string)=>{const result=gl.createShader(kind);if(!result)throw Error('shader');shaders.push(result);gl.shaderSource(result,source);gl.compileShader(result);if(!gl.getShaderParameter(result,gl.COMPILE_STATUS))throw Error('shader_compile');return result};
   const vertex=shader(gl.VERTEX_SHADER,`attribute vec3 position;attribute vec3 normal;attribute vec4 vertexColor;uniform vec3 center;uniform float modelScale;uniform float angle;uniform float aspect;uniform float zoom;varying vec3 N;varying vec3 P;varying vec3 C;void main(){float c=cos(angle),s=sin(angle);mat3 R=mat3(c,0.,-s,0.,1.,0.,s,0.,c);vec3 p=R*((position-center)*modelScale);N=R*normal;P=p;C=vertexColor.rgb;float w=7.8-p.z;gl_Position=vec4(p.x*2.25*zoom/aspect,p.y*2.25*zoom,1.02*w-.202,w);}`);
   const fragment=shader(gl.FRAGMENT_SHADER,`precision mediump float;varying vec3 N;varying vec3 P;varying vec3 C;uniform vec3 pickColor;uniform float picking;uniform float selected;void main(){if(picking>.5){gl_FragColor=vec4(pickColor,1.);return;}vec3 n=normalize(N);vec3 light=normalize(vec3(-.6,.9,1.8));float d=max(dot(n,light),0.);float fill=max(dot(n,normalize(vec3(1.,.2,-.7))),0.);float rim=pow(1.-abs(n.z),2.7);vec3 view=normalize(vec3(0.,0.,7.8)-P);float gloss=pow(max(dot(reflect(-light,n),view),0.),34.);vec3 shaded=C*(.42+.64*d+.16*fill)+vec3(1.,.94,.88)*gloss*.16;shaded=mix(shaded,shaded*1.15+vec3(.24,.13,.025)*(.25+rim),selected);gl_FragColor=vec4(shaded,1.);}`);
   program=gl.createProgram();if(!program)throw Error('program');gl.attachShader(program,vertex);gl.attachShader(program,fragment);gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error('program_link');
   const attributes={position:gl.getAttribLocation(program,'position'),normal:gl.getAttribLocation(program,'normal'),color:gl.getAttribLocation(program,'vertexColor')};
   const uniform=(name:string)=>gl.getUniformLocation(program!,name),u={center:uniform('center'),scale:uniform('modelScale'),angle:uniform('angle'),aspect:uniform('aspect'),zoom:uniform('zoom'),picking:uniform('picking'),pickColor:uniform('pickColor'),selected:uniform('selected')};
   const upload=(target:number,offset:number,length:number)=>{const b=gl.createBuffer();if(!b)throw Error('buffer');buffers.push(b);gl.bindBuffer(target,b);gl.bufferData(target,new Uint8Array(bytes,offset,length),gl.STATIC_DRAW);return b};
   const meshes=manifest.parts.map(part=>({group:part.group,positions:upload(gl.ARRAY_BUFFER,part.positions.offset,part.positions.length),normals:upload(gl.ARRAY_BUFFER,part.normals.offset,part.normals.length),colors:upload(gl.ARRAY_BUFFER,part.colors.offset,part.colors.length),indices:upload(gl.ELEMENT_ARRAY_BUFFER,part.indices.offset,part.indices.length),count:part.indexCount}));
   gl.enable(gl.DEPTH_TEST);gl.clearColor(0,0,0,0);
   const pickingTarget=()=>{
    if(!pickBuffer){pickBuffer=gl.createFramebuffer();pickTexture=gl.createTexture();pickDepth=gl.createRenderbuffer()}
    gl.bindFramebuffer(gl.FRAMEBUFFER,pickBuffer);
    if(pickWidth!==element.width||pickHeight!==element.height){pickWidth=element.width;pickHeight=element.height;gl.bindTexture(gl.TEXTURE_2D,pickTexture);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,pickWidth,pickHeight,0,gl.RGBA,gl.UNSIGNED_BYTE,null);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,pickTexture,0);gl.bindRenderbuffer(gl.RENDERBUFFER,pickDepth);gl.renderbufferStorage(gl.RENDERBUFFER,gl.DEPTH_COMPONENT16,pickWidth,pickHeight);gl.framebufferRenderbuffer(gl.FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.RENDERBUFFER,pickDepth)}
    if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw Error('picking_buffer');
   };
   const draw=(pick=false)=>{
    if(disposed||!program||!element.width||!element.height||!element.getBoundingClientRect().width)return;
    if(pick){pickingTarget();gl.disable(gl.DITHER)}else{gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.enable(gl.DITHER)}
    gl.useProgram(program);gl.viewport(0,0,element.width,element.height);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.uniform1f(u.angle,angle);gl.uniform1f(u.aspect,element.width/element.height);gl.uniform1f(u.zoom,zoom);gl.uniform1f(u.picking,pick?1:0);
    gl.uniform1f(u.scale,5.4/(manifest.bounds.max[1]-manifest.bounds.min[1]));gl.uniform3f(u.center,...manifest.bounds.min.map((v,i)=>(v+manifest.bounds.max[i])/2) as [number,number,number]);
    for(const mesh of meshes){const index=MUSCLES.findIndex(m=>m.id===mesh.group)+1;gl.uniform3f(u.pickColor,index/255,0,0);gl.uniform1f(u.selected,mesh.group===state.current.selected?1:0);gl.bindBuffer(gl.ARRAY_BUFFER,mesh.positions);gl.vertexAttribPointer(attributes.position,3,gl.SHORT,false,0,0);gl.enableVertexAttribArray(attributes.position);gl.bindBuffer(gl.ARRAY_BUFFER,mesh.normals);gl.vertexAttribPointer(attributes.normal,3,gl.BYTE,true,0,0);gl.enableVertexAttribArray(attributes.normal);gl.bindBuffer(gl.ARRAY_BUFFER,mesh.colors);gl.vertexAttribPointer(attributes.color,4,gl.UNSIGNED_BYTE,true,0,0);gl.enableVertexAttribArray(attributes.color);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,mesh.indices);gl.drawElements(gl.TRIANGLES,mesh.count,gl.UNSIGNED_SHORT,0)}
   };
   const schedule=()=>{cancelAnimationFrame(frame);frame=requestAnimationFrame(()=>draw())};
   const resize=()=>{const rect=element.getBoundingClientRect();if(rect.width<1||rect.height<1)return;const ratio=Math.min(1.5,window.devicePixelRatio||1);element.width=Math.round(rect.width*ratio);element.height=Math.round(rect.height*ratio);schedule()};
   observer=new ResizeObserver(resize);observer.observe(element);resize();engine.current={draw:schedule,rotate:value=>{angle=value;schedule()},zoom:amount=>{zoom=Math.min(1.35,Math.max(.72,zoom+amount));schedule()}};
   const down=(event:PointerEvent)=>{drag={x:event.clientX,y:event.clientY,startX:event.clientX,startY:event.clientY,moved:false};element.setPointerCapture(event.pointerId)},move=(event:PointerEvent)=>{if(!drag)return;const dx=event.clientX-drag.x;if(Math.hypot(event.clientX-drag.startX,event.clientY-drag.startY)>5)drag.moved=true;if(drag.moved){angle+=dx*.01;drag.x=event.clientX;drag.y=event.clientY;schedule()}},up=(event:PointerEvent)=>{if(drag&&!drag.moved){const r=element.getBoundingClientRect(),x=Math.min(element.width-1,Math.max(0,Math.floor((event.clientX-r.left)*element.width/r.width))),y=Math.min(element.height-1,Math.max(0,Math.floor((r.bottom-event.clientY)*element.height/r.height))),pixel=new Uint8Array(4);try{draw(true);gl.readPixels(x,y,1,1,gl.RGBA,gl.UNSIGNED_BYTE,pixel);draw();const target=MUSCLES[pixel[0]-1];if(target)state.current.onSelect(target.id)}catch{gl.bindFramebuffer(gl.FRAMEBUFFER,null);draw();setError('انتخاب روی تصویر در دسترس نیست؛ از فهرست عضلات استفاده کن.')}}drag=null},cancel=()=>{drag=null};
   for(const [name,handler] of [['pointerdown',down],['pointermove',move],['pointerup',up],['pointercancel',cancel]] as const){element.addEventListener(name,handler);events.push({name,handler:handler as EventListener})}
   setStatus('ready');schedule();
  }).catch(error=>{if((error as Error).name!=='AbortError')fail()});
  return()=>{disposed=true;controller.abort();observer?.disconnect();cancelAnimationFrame(frame);engine.current=null;events.forEach(({name,handler})=>element.removeEventListener(name,handler));element.removeEventListener('webglcontextlost',lost);element.removeEventListener('webglcontextrestored',restored);buffers.forEach(b=>gl.deleteBuffer(b));shaders.forEach(s=>gl.deleteShader(s));if(program)gl.deleteProgram(program);if(pickBuffer)gl.deleteFramebuffer(pickBuffer);if(pickTexture)gl.deleteTexture(pickTexture);if(pickDepth)gl.deleteRenderbuffer(pickDepth)};
 },[visible,revision]);
 useEffect(()=>engine.current?.draw(),[rows,selected]);
 return <div ref={stage} className="muscle-model-stage anatomy-model-stage" data-model-status={status}>{status==='error'&&<img className="anatomy-static-preview" style={{position:"absolute",inset:0,width:"100%",height:"100%",objectFit:"contain",padding:"8px 12px 62px",background:"#404040"}} src={`/anatomy/preview-${fallbackView}.png`} alt={fallbackView==='front'?'نمای جلو مدل آناتومی عضلات':'نمای پشت مدل آناتومی عضلات'}/>}<canvas ref={canvas} aria-label="مدل سه‌بعدی آناتومی عضلات؛ برای چرخاندن بکش و برای انتخاب روی عضله بزن." className={status==='error'?'unavailable':''}/>{status==='loading'&&<p className="muscle-model-loading" role="status">در حال آماده‌سازی مدل آناتومی…</p>}{error&&<div className="muscle-model-error" role="status" style={status==='error'?{top:"auto",bottom:2,left:12,right:12,padding:4,fontSize:10,background:"#111b",pointerEvents:"none"}:undefined}><p>{error}</p></div>}<div className="muscle-model-controls"><button type="button" disabled={status==='loading'} onClick={()=>{setFallbackView('front');engine.current?.rotate(0)}}>جلو</button><button type="button" disabled={status==='loading'} onClick={()=>{setFallbackView('back');engine.current?.rotate(Math.PI)}}>پشت</button><button type="button" disabled={status!=='ready'} aria-label="بزرگ‌نمایی بدن" onClick={()=>engine.current?.zoom(.06)}><ZoomIn/></button><button type="button" disabled={status!=='ready'} aria-label="کوچک‌نمایی بدن" onClick={()=>engine.current?.zoom(-.06)}><ZoomOut/></button><button type="button" disabled={status!=='ready'} aria-label="بازنشانی چرخش" onClick={()=>{engine.current?.rotate(0)}}><RotateCcw/></button></div><p className="muscle-rotate-hint">{status==='error'?'پیش‌نمایش ثابت · نمای جلو و پشت':'برای چرخاندن، افقی بکش · برای انتخاب، روی عضله بزن'}</p></div>;
}
