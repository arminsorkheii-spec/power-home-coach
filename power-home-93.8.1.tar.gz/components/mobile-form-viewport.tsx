"use client";

import {visibleFormBounds,fieldNeedsScroll} from "@/lib/viewport-safety";
import { useEffect } from "react";

// Keep layout height stable while the keyboard changes the visual viewport.
// Native scrolling remains available to reach inputs above the keyboard.
export function MobileFormViewport() {
  useEffect(() => {
    const root = document.documentElement;
    const mode = matchMedia('(display-mode: standalone)');
    const setMode = () => { root.dataset.displayMode = mode.matches || (navigator as Navigator & {standalone?:boolean}).standalone ? 'standalone' : 'browser'; };
    setMode();mode.addEventListener('change',setMode);
    const bounds = document.createElement('div');
    bounds.setAttribute('aria-hidden','true');
    bounds.style.cssText='position:fixed;visibility:hidden;pointer-events:none;inset:0 auto auto 0;padding:calc(var(--app-safe-top) + 12px) calc(var(--safe-right) + 12px) calc(var(--safe-bottom) + 12px) calc(var(--safe-left) + 12px)';
    document.body.appendChild(bounds);
    // Dialogs follow the visible screen when the keyboard opens or the phone rotates.
    const viewport = window.visualViewport;
    let frame = 0;
    let revealFocused=false;
    const updateViewport = (event?:Event) => {
      if(event?.type==='resize'||event?.type==='orientationchange')revealFocused=true;
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        root.style.setProperty("--overlay-viewport-height", `${viewport?.height ?? window.innerHeight}px`);
        root.style.setProperty("--overlay-viewport-width", `${viewport?.width ?? window.innerWidth}px`);
        root.style.setProperty("--overlay-viewport-top", `${viewport?.offsetTop ?? 0}px`);
        root.style.setProperty("--overlay-viewport-left", `${viewport?.offsetLeft ?? 0}px`);
        const css=getComputedStyle(bounds);
        for(const side of ['top','right','bottom','left'])root.style.setProperty('--surface-safe-'+side,css.getPropertyValue('padding-'+side));
        const keyboard=Boolean(viewport && window.innerHeight-viewport.height>120 && viewport.scale<1.1 && document.activeElement?.matches('input,textarea,[contenteditable=true]'));
        root.dataset.keyboardVisible=keyboard?'true':'false';
        window.dispatchEvent(new Event('power-viewport-change'));
        if(revealFocused){revealFocused=false;const field=document.activeElement as HTMLElement|null;if(field?.matches('input:not([type=file]):not([type=checkbox]):not([type=radio]),textarea,select,[contenteditable=true]')&&(!viewport||viewport.scale<1.1)){
          const padding={top:parseFloat(css.paddingTop)||12,right:parseFloat(css.paddingRight)||12,bottom:parseFloat(css.paddingBottom)||12,left:parseFloat(css.paddingLeft)||12};
          const visible=visibleFormBounds({top:viewport?.offsetTop??0,left:viewport?.offsetLeft??0,width:viewport?.width??window.innerWidth,height:viewport?.height??window.innerHeight},padding);
          if(!field.closest('dialog,[data-slot=dialog-content],[data-slot=sheet-content],[data-slot=drawer-content]')){const page=field.closest('.app-shell,.student-dashboard,.register-page');const header=page?.querySelector('.student-dashboard-top,.coach-mobile-header,.register-header');if(header){const rect=header.getBoundingClientRect();if(rect.height>0&&rect.bottom<visible.bottom-60)visible.top=Math.max(visible.top,rect.bottom+12)}}
          if(fieldNeedsScroll(field.getBoundingClientRect(),visible))field.scrollIntoView({block:'center',inline:'nearest',behavior:'auto'});
        }}
      });
    };
    updateViewport();
    viewport?.addEventListener("resize", updateViewport);
    viewport?.addEventListener("scroll", updateViewport);
    window.addEventListener("resize", updateViewport);
    window.addEventListener('orientationchange',updateViewport);
    const editable = (element: Element | null) => element?.matches("input:not([type=checkbox]):not([type=radio]):not([type=file]), textarea, select, [contenteditable=true]");
    const focus = () => {
      revealFocused=true;updateViewport();
      if (!matchMedia("(max-width: 1024px)").matches || !editable(document.activeElement)) return;
      if (!root.classList.contains("form-keyboard-open")) {
        root.style.setProperty("--form-layout-height", `${window.innerHeight}px`);
        root.classList.add("form-keyboard-open");
      }
    };
    let timer: ReturnType<typeof setTimeout>;
    const blur = () => {
      updateViewport();
      clearTimeout(timer);
      timer = setTimeout(() => {
        if (editable(document.activeElement)) return;
        root.classList.remove("form-keyboard-open");
        root.style.removeProperty("--form-layout-height");
      }, 200);
    };
    document.addEventListener("focusin", focus);
    document.addEventListener("focusout", blur);
    return () => {
      clearTimeout(timer);
      cancelAnimationFrame(frame);
      viewport?.removeEventListener("resize", updateViewport);
      viewport?.removeEventListener("scroll", updateViewport);
      window.removeEventListener("resize", updateViewport);
      window.removeEventListener('orientationchange',updateViewport);
      mode.removeEventListener('change',setMode);bounds.remove();
      delete root.dataset.displayMode;delete root.dataset.keyboardVisible;
      for(const side of ['top','right','bottom','left'])root.style.removeProperty('--surface-safe-'+side);
      for (const property of ["height", "width", "top", "left"]) root.style.removeProperty(`--overlay-viewport-${property}`);
      document.removeEventListener("focusin", focus);
      document.removeEventListener("focusout", blur);
      root.classList.remove("form-keyboard-open");
      root.style.removeProperty("--form-layout-height");
    };
  }, []);
  return null;
}
