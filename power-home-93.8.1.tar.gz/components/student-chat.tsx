'use client';
import {useAutoRefresh} from '@/hooks/use-auto-refresh';
import {useChatScroll} from '@/hooks/use-chat-scroll';
import {mergeChatMessage} from '@/lib/chat-scroll';
import {notifyDataUpdated} from '@/lib/auto-refresh';
import {MessageReceipt,useMessageReadReceipts} from '@/components/message-receipt';
import {useStudentWorkspace} from '@/components/student-dashboard-shell';
import {useCallback,useRef,useState} from 'react';
import {ArrowDown,LoaderCircle,RefreshCw,Send} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {Textarea} from '@/components/ui/textarea';
import {GlassSectionIcon} from '@/components/glass-section-icon';
type Message={id:string;sender_role:'coach'|'student';body:string;created_at:string;read_at?:string|null};
export function StudentChat(){
 const workspace=useStudentWorkspace(),active=!workspace||workspace.selection.module==='chat';
 const [messages,setMessages]=useState<Message[]>([]),[body,setBody]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState('');
 const requestSequence=useRef(0),sending=useRef(false),scroll=useChatScroll(messages.at(-1)?.id??'',messages.length,active);
 const markRead=useCallback((ids:string[],at:string)=>setMessages(current=>current.map(m=>ids.includes(m.id)?{...m,read_at:at}:m)),[]);
 useMessageReadReceipts(messages,'student',undefined,active,markRead);
 const load=useCallback(async()=>{if(!active||document.visibilityState==='hidden')return;const sequence=++requestSequence.current;try{const r=await fetch('/api/messages?read=0',{cache:'no-store',signal:AbortSignal.timeout(15000),headers:{'x-portal-role':'student'}});const data=await r.json() as {messages?:Message[];error?:string};if(!r.ok)throw Error(data.error??'دریافت پیام‌ها انجام نشد.');if(sequence!==requestSequence.current)return;setMessages(data.messages??[]);setError('')}catch(e){if(sequence===requestSequence.current)setError(e instanceof Error?e.message:'دریافت پیام‌ها انجام نشد.')}},[active]);
 useAutoRefresh(load,{intervalMs:10000,enabled:active,initial:true});
 const send=async()=>{if(!active||!body.trim()||sending.current)return;sending.current=true;setBusy(true);setError('');const text=body.trim();setBody('');try{const r=await fetch('/api/messages',{method:'POST',headers:{'content-type':'application/json','x-portal-role':'student'},body:JSON.stringify({body:text}),signal:AbortSignal.timeout(25000)});const data=await r.json() as {message?:Message;error?:string};if(!r.ok)throw Error(data.error??'ارسال پیام انجام نشد.');requestSequence.current++;if(data.message)setMessages(current=>mergeChatMessage(current,data.message!));scroll.forceBottom();notifyDataUpdated();void load()}catch(e){setBody(current=>current?text+'\n'+current:text);setError(e instanceof Error?e.message:'ارسال پیام انجام نشد.')}finally{sending.current=false;setBusy(false)}};
 return <section ref={scroll.shell} id="student-chat" className="student-chat messenger-chat" aria-label="گفت‌وگو با مربی"><div className="student-files-heading"><div><h2><GlassSectionIcon name="messages" size={38}/> گفت‌وگو با مربی</h2><p>پیام‌ها فقط بین شما و مربی است.</p></div><Button type="button" variant="outline" size="icon" onClick={()=>void load()} aria-label="تازه‌سازی پیام‌ها"><RefreshCw/></Button></div>{error&&<p className="request-error" role="alert">{error}</p>}<div ref={scroll.history} onScroll={scroll.onScroll} className="student-chat-history messenger-history" role="log" aria-label="پیام‌های گفتگو" aria-live="polite" aria-relevant="additions">{messages.map(m=><div key={m.id} className={m.sender_role==='student'?'mine':'coach'}><p>{m.body}</p><div className="messenger-meta"><time>{new Date(m.created_at).toLocaleString('fa-IR')}</time>{m.sender_role==='student'&&<MessageReceipt readAt={m.read_at}/>}</div></div>)}{!messages.length&&!error&&<p className="student-empty">هنوز پیامی ثبت نشده است.</p>}</div>{scroll.newMessages&&<button className="chat-new-messages" type="button" onClick={scroll.forceBottom}><ArrowDown size={16}/> رفتن به آخر گفتگو</button>}<div className="student-chat-compose messenger-compose"><Textarea value={body} maxLength={2000} aria-label="متن پیام به مربی" onChange={e=>setBody(e.target.value)} placeholder="پیامت را بنویس…" onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.nativeEvent.isComposing){e.preventDefault();void send()}}}/><Button type="button" onClick={()=>void send()} disabled={busy||!body.trim()} aria-label={busy?'در حال ارسال پیام':'ارسال پیام به مربی'}>{busy?<LoaderCircle className="animate-spin"/>:<Send/>}<span>ارسال</span></Button></div></section>
}
