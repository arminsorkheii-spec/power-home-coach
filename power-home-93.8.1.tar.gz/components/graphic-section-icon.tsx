import {PowerGraphicIcon,type PowerIconName} from "@/components/power-graphic-icon";

export type GraphicSectionIconName = "training" | "nutrition" | "supplements" | "medications" | "messages" | "billing" | "notifications" | "pdf";

const labels: Record<GraphicSectionIconName,string> = {
  training:"برنامه تمرینی", nutrition:"رژیم غذایی", supplements:"مکمل", medications:"دارو / PCT",
  messages:"پیام‌ها", billing:"حسابداری", notifications:"نوتیفیکیشن", pdf:"PDF",
};

export function GraphicSectionIcon({name,size=76,className=""}:{name:GraphicSectionIconName;size?:number;className?:string}){
  const names:Record<GraphicSectionIconName,PowerIconName>={training:'workout',nutrition:'nutrition',supplements:'supplements',medications:'medications',messages:'chat',billing:'orders',notifications:'notifications',pdf:'pdf'};
  return <span className={`graphic-section-icon ${className}`} style={{width:size,height:size}} role="img" aria-label={labels[name]}><PowerGraphicIcon name={names[name]} size={size}/></span>;
}
