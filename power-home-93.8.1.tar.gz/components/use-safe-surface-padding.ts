"use client";
import {useEffect,useState} from 'react';

/** Shared collision bounds for menus portalled outside either dashboard. */
export function useSafeSurfacePadding(){
 const [padding,setPadding]=useState({top:12,right:12,bottom:12,left:12});
 useEffect(()=>{
  const update=()=>{const css=getComputedStyle(document.documentElement),value=(side:string)=>Math.max(12,parseFloat(css.getPropertyValue('--surface-safe-'+side))||12);const next={top:value('top'),right:value('right'),bottom:value('bottom'),left:value('left')};setPadding(old=>Object.keys(next).every(key=>old[key as keyof typeof old]===next[key as keyof typeof next])?old:next)};
  update();window.addEventListener('power-viewport-change',update);window.addEventListener('resize',update);
  return()=>{window.removeEventListener('power-viewport-change',update);window.removeEventListener('resize',update)};
 },[]);
 return padding;
}
