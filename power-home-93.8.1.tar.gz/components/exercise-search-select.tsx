"use client";
import {useId,useMemo,useState} from 'react';
import {Input} from '@/components/ui/input';
import {filterExercises,type SearchExercise} from '@/lib/exercise-search';
export function ExerciseSearchSelect({exercises,value,onChange}:{exercises:SearchExercise[];value:string;onChange:(id:string)=>void}){
 const [query,setQuery]=useState(''),[open,setOpen]=useState(false);const id=useId();
 const matches=useMemo(()=>filterExercises(exercises,query),[exercises,query]);const selected=exercises.find(e=>e.id===value);
 return <div className="exercise-search-select"><label htmlFor={id}>جست‌وجوی حرکت در کل بانک حرکات</label><Input id={id} type="search" value={query} placeholder="نام فارسی یا انگلیسی حرکت…" autoComplete="off" onFocus={()=>setOpen(true)} onChange={e=>{setQuery(e.target.value);setOpen(true)}} aria-controls={id+'-results'}/><button type="button" className="exercise-search-current" aria-expanded={open} aria-controls={id+'-results'} onClick={()=>setOpen(!open)}>{selected?`حرکت انتخاب‌شده: ${selected.nameFa}`:'حرکت را انتخاب کن'}</button>{open&&<div id={id+'-results'} className="exercise-search-results" role="group" aria-label="نتایج جست‌وجوی حرکات" onKeyDown={e=>{if(e.key==='Escape')setOpen(false)}}><p role="status">{matches.length.toLocaleString('fa-IR')} حرکت</p>{matches.length?matches.map(item=><button type="button" key={item.id} aria-pressed={value===item.id} onClick={()=>{onChange(item.id);setQuery('');setOpen(false)}}><strong>{item.nameFa}</strong>{item.nameEn&&<small dir="ltr">{item.nameEn}</small>}{item.category&&<small>{item.category}</small>}</button>):<p>حرکتی پیدا نشد؛ نام دیگری جست‌وجو کن.</p>}</div>}</div>
}
