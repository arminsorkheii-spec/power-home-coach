import {plannedTotal,type PlannedFood} from '@/lib/food-catalog';

const fa=(value:number)=>value.toLocaleString('fa-IR',{maximumFractionDigits:1});
const nutrients=[{key:'protein',name:'پروتئین',color:'#569bc5',factor:4},{key:'carbs',name:'کربوهیدرات',color:'#68ac88',factor:4},{key:'fat',name:'چربی',color:'#a38ac7',factor:9}] as const;

/** Shared SVG chart for the student plan and its printable PDF, using saved food snapshots. */
export function PlanNutritionChart({meals}:{meals:{foods:string;foodItems?:PlannedFood[]}[]}){
 const rows=meals.flatMap(meal=>meal.foodItems??[]),total=plannedTotal(rows);
 const partial=meals.some(meal=>meal.foods.trim());
 if(!rows.length)return <p className="plan-nutrition-unavailable">برای نمایش نمودار کالری و ماکروها، مواد غذایی باید از بانک غذا انتخاب شوند.</p>;
 const energy=nutrients.reduce((sum,n)=>sum+total[n.key]*n.factor,0);
 let offset=0;
 return <section className="plan-nutrition-chart" aria-label="نمودار کالری و ماکروهای برنامه غذایی" dir="rtl">
  <h3>{partial?'ارزش غذایی مواد محاسبه‌شده':'ارزش غذایی برنامه روزانه'}</h3>
  <div className="plan-nutrition-chart-body">
   <div className="plan-nutrition-ring">
    <svg viewBox="0 0 120 120" role="img" aria-label={nutrients.map(n=>`${n.name} ${fa(total[n.key])} گرم`).join('، ')}>
     <circle cx="60" cy="60" r="48" fill="none" stroke="#dedee3" strokeWidth="12"/>
     {nutrients.map(n=>{const percentage=energy?total[n.key]*n.factor/energy*100:0,start=offset;offset+=percentage;return <circle key={n.key} cx="60" cy="60" r="48" fill="none" stroke={n.color} strokeWidth="12" pathLength="100" strokeDasharray={`${percentage} ${100-percentage}`} strokeDashoffset={-start} transform="rotate(-90 60 60)"/>})}
    </svg>
    <div><strong>{fa(total.calories)}</strong><span>کیلوکالری</span></div>
   </div>
   <div className="plan-nutrition-values">{nutrients.map(n=><div key={n.key}><span><i style={{backgroundColor:n.color}}/>{n.name}</span><strong>{fa(total[n.key])} <small>گرم</small></strong><span>{fa(energy?total[n.key]*n.factor/energy*100:0)}٪ انرژی ماکروها</span></div>)}</div>
  </div>
  {partial&&<p>غذاهای متنی در این جمع محاسبه نشده‌اند.</p>}
 </section>;
}
