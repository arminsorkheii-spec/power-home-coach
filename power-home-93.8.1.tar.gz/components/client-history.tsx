"use client";
import {PersianDatePicker} from "@/components/persian-date-picker";
import { useEffect, useState } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Camera, ChevronLeft, Folder, FolderOpen, Pencil, Trash2 } from "lucide-react";
import { POSES, METRICS, type Checkin, type Measurements, type Pose } from "@/lib/checkin-data";
import type { Client, ClientPlan, Exercise } from "@/lib/coach-data";
import { PhotoGallery } from "@/components/photo-gallery";
import { groupExerciseRows } from "@/lib/supersets";

export async function fetchHistory(clientId:string):Promise<Checkin[]> {
  const query=`clientId=${encodeURIComponent(clientId)}`;
  const response=await fetch(`/api/checkins?${query}`,{cache:"no-store"});
  if(!response.ok) throw new Error("دریافت سوابق انجام نشد؛ اتصال و ورود را بررسی کنید.");
  const {records}=await response.json();
  const result:Checkin[]=[];
  for(const row of records) {
    const r=await fetch(`/api/checkins?${query}&id=${encodeURIComponent(row.id)}`,{cache:"no-store"});
    if(!r.ok) throw new Error("بارگیری بعضی دوره‌ها انجام نشد؛ دوباره تلاش کنید.");
    result.push((await r.json()).record);
  }
  return result;
}

export function PasswordSettings({onReady}:{onReady:()=>void}) {
  const [current,setCurrent]=useState(""); const [password,setPassword]=useState(""); const [repeat,setRepeat]=useState("");
  const [message,setMessage]=useState(""); const [busy,setBusy]=useState(false);
  return <form className="space-y-4 rounded-2xl border border-white/10 bg-card p-5" onSubmit={async e=>{
    e.preventDefault(); if(password!==repeat){setMessage("تکرار رمز یکسان نیست.");return;} setBusy(true);setMessage("");
    try{const r=await fetch("/api/auth/password",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({currentPassword:current,newPassword:password})});const data=await r.json();if(!r.ok)throw new Error(data.error);setCurrent("");setPassword("");setRepeat("");onReady();}
    catch(e){setMessage(e instanceof Error?e.message:"تغییر رمز انجام نشد.");}finally{setBusy(false);}
  }}>
    <h2 className="text-xl font-bold">رمز اختصاصی مربی</h2><p className="text-sm text-zinc-400">قبل از ثبت عکس و دوره، رمز بلند تنظیم کنید. همهٔ ورودهای قبلی لغو می‌شوند؛ فقط این دستگاه وارد می‌ماند. رمز جدید را در جای امن نگه دارید؛ بازیابی خودکار رمز نداریم.</p>
    <label className="block text-sm">رمز فعلی<Input type="password" autoComplete="current-password" value={current} onChange={e=>setCurrent(e.target.value)} required maxLength={128}/></label>
    <label className="block text-sm">رمز جدید — حداقل ۱۴ کاراکتر<Input type="password" autoComplete="new-password" value={password} onChange={e=>setPassword(e.target.value)} required minLength={14} maxLength={128}/></label>
    <label className="block text-sm">تکرار رمز جدید<Input type="password" autoComplete="new-password" value={repeat} onChange={e=>setRepeat(e.target.value)} required minLength={14} maxLength={128}/></label>
    <p role="alert" className="text-sm text-amber-300">{message}</p><Button disabled={busy} type="submit">{busy?"در حال ذخیره…":"ذخیره رمز جدید"}</Button>
  </form>;
}

const formatDate=(date:string)=>new Date(`${date}T12:00:00`).toLocaleDateString("fa-IR");
const emptyMeasurements={weight:null,height:null,waist:null,arm:null};
type Props={client:Client;plan:ClientPlan;exercises:Exercise[];records:Checkin[];onRecords:(r:Checkin[])=>void;onPrint:(r:Checkin)=>void;online:boolean;intake:(programNumber:number)=>React.ReactNode;onEditProgram?:(record:Checkin)=>void;onEditCurrent?:()=>void;onDeleteCurrent?:()=>Promise<void>};

function ProgramFileSections({plan,exercises,photos,intake,photoTools,onPrint}:{plan:ClientPlan;exercises:Exercise[];photos:{src:string;label:string;caption:string}[];intake?:React.ReactNode;photoTools?:React.ReactNode;onPrint?:()=>void}){
  const supplements=plan.supplementItems??[];
  return <Tabs defaultValue="workout" className="space-y-4" dir="rtl">
    <TabsList className="grid h-auto w-full grid-cols-5 rounded-2xl bg-black/25 p-1">
      <TabsTrigger value="workout">تمرینی</TabsTrigger><TabsTrigger value="nutrition">غذایی</TabsTrigger><TabsTrigger value="supplements">مکمل</TabsTrigger><TabsTrigger value="medications">دارو</TabsTrigger><TabsTrigger value="photos">عکس‌ها</TabsTrigger>
    </TabsList>
    <TabsContent value="workout" className="space-y-2">
      {plan.workoutDays.map(d=><details className="rounded-2xl border border-white/8 bg-black/15 p-2" key={d.id}><summary className="cursor-pointer p-2 font-bold">{d.title} — {d.focus}</summary>{d.exercises.length?<div className="space-y-2">{groupExerciseRows(d.exercises).map((unit,unitIndex)=>unit.type==="superset"?<section className="history-superset-group" key={unit.id}><div className="history-superset-title"><strong>سوپرست {(unitIndex+1).toLocaleString("fa-IR")}</strong><span>اجرای A سپس B</span></div>{unit.items.map((e,pairIndex)=><p className="history-superset-row" key={e.rowId}><b className="superset-label">{pairIndex===0?"A":"B"}</b>{exercises.find(x=>x.id===e.exerciseId)?.nameFa??e.exerciseId} · {e.sets} × {e.reps} · {e.technique}</p>)}</section>:<p className="border-t border-white/5 p-2 text-sm" key={unit.id}>{exercises.find(x=>x.id===unit.items[0].exerciseId)?.nameFa??unit.items[0].exerciseId} · {unit.items[0].sets} × {unit.items[0].reps} · {unit.items[0].technique}</p>)}</div>:<p className="p-2 text-sm text-zinc-500">حرکتی ثبت نشده است.</p>}</details>)}
      {!plan.workoutDays.length&&<p className="rounded-2xl border border-dashed border-white/10 p-4 text-sm text-zinc-500">برنامه تمرینی ثبت نشده است.</p>}
      {onPrint&&<Button variant="outline" onClick={onPrint}>PDF همین برنامهٔ بایگانی‌شده</Button>}
    </TabsContent>
    <TabsContent value="nutrition" className="space-y-3">
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">{Object.entries({"کالری":plan.nutritionGoals.calories,"پروتئین":plan.nutritionGoals.protein,"کربوهیدرات":plan.nutritionGoals.carbs,"چربی":plan.nutritionGoals.fat}).map(([label,value])=><div className="rounded-2xl border border-white/8 bg-black/15 p-3" key={label}><small className="text-zinc-500">{label}</small><strong className="mt-1 block text-white">{value||"—"}</strong></div>)}</div>
      {plan.nutritionMeals.map(meal=><article className="rounded-2xl border border-white/8 bg-black/15 p-4" key={meal.id}><div className="flex justify-between gap-3"><strong>{meal.title}</strong><span className="text-xs text-amber-300">{meal.time}</span></div><p className="mt-2 whitespace-pre-wrap text-sm text-zinc-300">{meal.foods||"مواد غذایی ثبت نشده است."}</p>{meal.notes&&<p className="mt-2 text-xs text-zinc-500">{meal.notes}</p>}</article>)}
      {!plan.nutritionMeals.length&&<p className="rounded-2xl border border-dashed border-white/10 p-4 text-sm text-zinc-500">برنامه غذایی ثبت نشده است.</p>}
    </TabsContent>
    <TabsContent value="supplements" className="space-y-2">
      {supplements.map(item=><article className="rounded-2xl border border-white/8 bg-black/15 p-4" key={item.id}><strong>{item.name}</strong><p className="mt-1 text-sm text-zinc-300">{[item.dose,item.timing,item.frequency].filter(Boolean).join(" · ")}</p>{item.notes&&<p className="mt-2 text-xs text-zinc-500">{item.notes}</p>}</article>)}
      {!supplements.length&&<p className="rounded-2xl border border-dashed border-white/10 p-4 text-sm text-zinc-500">مکملی برای این برنامه ثبت نشده است.</p>}
    </TabsContent>
    <TabsContent value="medications" className="space-y-2">
      {(plan.medicationItems??[]).map(item=><article className="rounded-2xl border border-white/8 bg-black/15 p-4" key={item.id}><div className="flex flex-wrap items-center justify-between gap-2"><strong>{item.name}</strong><span className="rounded-full bg-amber-500/10 px-3 py-1 text-xs text-amber-300">هفته {item.startWeek||"—"} تا {item.endWeek||"—"}</span></div><p className="mt-2 text-sm text-zinc-300">{[item.dose,item.timing,item.frequency].filter(Boolean).join(" · ")}</p>{item.notes&&<p className="mt-2 text-xs text-zinc-500">{item.notes}</p>}</article>)}
      {!(plan.medicationItems??[]).length&&<p className="rounded-2xl border border-dashed border-white/10 p-4 text-sm text-zinc-500">برنامه دارویی یا PCT ثبت نشده است.</p>}
    </TabsContent>
    <TabsContent value="photos" className="space-y-4">
      {photos.length?<PhotoGallery images={photos}/>:<p className="rounded-2xl border border-dashed border-white/10 p-4 text-sm text-zinc-500">هنوز عکسی برای این برنامه ثبت نشده است.</p>}
      {photoTools}{intake}
    </TabsContent>
  </Tabs>;
}

export function ClientHistory({client,plan,exercises,records,onRecords,onPrint,online,intake,onEditProgram,onEditCurrent,onDeleteCurrent}:Props){
  const [currentDelivered,setCurrentDelivered]=useState(false);
  const [ready,setReady]=useState<boolean|null>(null);const [securityOpen,setSecurityOpen]=useState(false);
  const [error,setError]=useState("");const [notice,setNotice]=useState("");const [busy,setBusy]=useState(false);const [loading,setLoading]=useState(true);
  const [date,setDate]=useState(()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;});
  const [measurements,setMeasurements]=useState<Measurements>(emptyMeasurements);const [notes,setNotes]=useState("");
  const [selected,setSelected]=useState("");const [compare,setCompare]=useState("");const [metric,setMetric]=useState<keyof Measurements>("weight");
  const [consent,setConsent]=useState(false);const [pose,setPose]=useState<Pose>("front"); const [requestId,setRequestId]=useState(()=>crypto.randomUUID());
  const refresh=async()=>{setLoading(true);try{const r=await fetchHistory(client.id);onRecords(r);setError("");}catch(e){setError(String(e instanceof Error?e.message:e));}finally{setLoading(false);}};
  useEffect(()=>{let active=true;fetch("/api/auth/password",{cache:"no-store"}).then(async r=>{if(!r.ok)throw new Error();const d=await r.json();if(active){setReady(d.configured);if(d.configured)void refresh();else setLoading(false);}}).catch(()=>{if(active){setError("بررسی ورود انجام نشد؛ صفحه را دوباره باز کنید.");setLoading(false);}});return()=>{active=false;};},[]);
  useEffect(()=>{
    if(!online){setCurrentDelivered(false);return;}
    let cancelled=false;
    fetch(`/api/program-delivery?clientId=${encodeURIComponent(client.id)}`,{cache:"no-store"}).then(r=>r.ok?r.json():{delivered:false}).then((v:{delivered:boolean})=>{if(!cancelled)setCurrentDelivered(v.delivered);}).catch(()=>{if(!cancelled)setCurrentDelivered(false);});
    return()=>{cancelled=true;};
  },[client.id,online,plan]);
  const archivedRecords=records.filter((record)=>record.recordType!=="baseline");
  const chosen=archivedRecords.find(r=>r.id===selected); const older=archivedRecords.find(r=>r.id===compare);
  const numberedRecords=[...archivedRecords]
    .sort((a,b)=>a.date.localeCompare(b.date)||a.createdAt.localeCompare(b.createdAt))
    .map((record,index)=>({record,number:index+1}))
    .reverse();
  const currentNumber=archivedRecords.length+1;
  const currentSelected=selected==="current"&&currentDelivered;
  const chart=records.filter(r=>r.measurements[metric]!==null).map(r=>({time:Date.parse(r.date),date:formatDate(r.date),value:r.measurements[metric]})).sort((a,b)=>a.time-b.time);
  const save=async()=>{
    setBusy(true);setError("");setNotice("");
    try{const used=new Set(plan.workoutDays.flatMap(d=>d.exercises.map(e=>e.exerciseId)));
      const r=await fetch("/api/checkins",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({id:requestId,clientId:client.id,date,measurements,notes,client,plan,exercises:exercises.filter(e=>used.has(e.id))})});
      const data=await r.json();if(!r.ok)throw new Error(data.error??"ثبت انجام نشد.");
      setSelected(data.id);setRequestId(crypto.randomUUID());await refresh();setNotice("دوره ثبت شد. می‌توانید عکس‌های همین دوره را اضافه کنید؛ تغییرات برنامهٔ جاری به این نسخه منتقل نمی‌شوند.");
    }catch(e){setError(e instanceof Error?e.message:"ثبت انجام نشد.");}finally{setBusy(false);}
  };
  const upload=async(file:File,p:Pose)=>{
    if(!chosen||!consent)return;setBusy(true);setError("");
    try{const form=new FormData();form.set("image",file);form.set("checkinId",chosen.id);form.set("pose",p);form.set("consent","yes");const r=await fetch("/api/body-photos",{method:"POST",body:form});const d=await r.json();if(!r.ok)throw new Error(d.error??"آپلود انجام نشد.");await refresh();}
    catch(e){setError(e instanceof Error?e.message:"آپلود انجام نشد.");}finally{setBusy(false);}
  };
  const deleteArchivedProgram=async(record:Checkin)=>{
    if(!window.confirm(`برنامه بایگانی‌شده «${record.plan.title}» حذف شود؟ عکس‌ها و سابقه همین دوره هم حذف می‌شوند و این کار قابل بازگشت نیست.`))return;
    setBusy(true);setError("");setNotice("");
    try{
      const response=await fetch("/api/checkins",{method:"DELETE",headers:{"content-type":"application/json"},body:JSON.stringify({id:record.id,clientId:client.id})});
      const data=await response.json().catch(()=>({})) as {error?:string};
      if(!response.ok)throw new Error(data.error??"حذف برنامه انجام نشد.");
      if(selected===record.id)setSelected("");
      if(compare===record.id)setCompare("");
      await refresh();
      setNotice("برنامه قبلی شاگرد حذف شد.");
    }catch(e){setError(e instanceof Error?e.message:"حذف برنامه انجام نشد.");}
    finally{setBusy(false);}
  };
  if(ready===false)return <PasswordSettings onReady={()=>{setReady(true);void refresh();}}/>;
  return <section className="space-y-5" dir="rtl">
    <div className="flex flex-wrap items-center justify-between gap-3"><h2 className="text-xl font-bold">پروندهٔ پیشرفت {client.name}</h2><Button variant="outline" onClick={()=>setSecurityOpen(true)}>تغییر رمز</Button></div>
    {error&&<p role="alert" className="rounded-xl bg-amber-500/10 p-3 text-sm text-red-300">{error}</p>}{notice&&<p role="status" className="rounded-xl bg-white/5 p-3 text-sm">{notice}</p>}
    <fieldset disabled={busy||ready!==true||!online||loading} className="space-y-4 rounded-2xl border border-white/10 bg-card p-4 disabled:opacity-60">
      <legend className="px-2 font-bold">ثبت برنامه و اندازه‌های دورهٔ جدید</legend>
      <p className="text-sm text-zinc-400">نسخهٔ تمرینی و غذایی فعلی با این تاریخ بایگانی می‌شود. سابقهٔ قبلی تغییر نمی‌کند. عکس‌ها پس از ثبت دوره اضافه می‌شوند.</p>
      {!online&&<p className="text-sm text-amber-400">منتظر ذخیره آنلاین برنامه بمانید.</p>}
      <label className="block text-sm">تاریخ دوره<PersianDatePicker value={date} onChange={value=>{setDate(value);setRequestId(crypto.randomUUID());}}/><span className="text-sm text-zinc-400">{date&&Number.isFinite(Date.parse(date))?formatDate(date):""}</span></label>
      <div className="grid grid-cols-2 gap-3">{Object.entries(METRICS).map(([key,label])=><label key={key} className="text-sm">{label}<Input type="number" min="0.1" step="0.1" value={measurements[key as keyof Measurements]??""} onChange={e=>{setMeasurements({...measurements,[key]:e.target.value===""?null:Number(e.target.value)});setRequestId(crypto.randomUUID());}}/></label>)}</div>
      <label className="block text-sm">یادداشت مربی<Textarea value={notes} onChange={e=>{setNotes(e.target.value);setRequestId(crypto.randomUUID());}}/></label>
      <Button onClick={save} disabled={busy||!date||!measurements.weight||!measurements.height}>ثبت نسخهٔ برنامه و دوره</Button>
    </fieldset>
    <div className="flex items-center justify-between"><h3 className="font-bold">دوره‌های ثبت‌شده ({records.length})</h3><Button variant="outline" disabled={busy||ready!==true||loading} onClick={refresh}>بارگیری دوباره</Button></div>
    {loading?<p>در حال دریافت سوابق…</p>:<>
      {!archivedRecords.length&&<p className="text-sm text-zinc-400">این اولین برنامه شاگرد است؛ اطلاعات شروع می‌تواند در نمودار ثبت شده باشد، اما هنوز برنامه‌ای بایگانی نشده است.</p>}
      {records.length>0&&
      <div className="rounded-2xl border border-white/10 p-4"><Select value={metric} onValueChange={v=>setMetric(v as keyof Measurements)}><SelectTrigger><SelectValue/></SelectTrigger><SelectContent>{Object.entries(METRICS).map(([k,v])=><SelectItem value={k} key={k}>{v}</SelectItem>)}</SelectContent></Select>
        <div className="mt-4 h-64" dir="ltr"><ResponsiveContainer width="100%" height="100%"><LineChart data={chart}><CartesianGrid stroke="#333"/><XAxis dataKey="time" type="number" domain={["dataMin","dataMax"]} tickFormatter={t=>new Date(t).toLocaleDateString("fa-IR")}/><YAxis domain={["auto","auto"]}/><Tooltip labelFormatter={t=>new Date(Number(t)).toLocaleDateString("fa-IR")}/><Line name={METRICS[metric]} type="linear" dataKey="value" stroke="#d8dde4" strokeWidth={2} dot={{r:4}}/></LineChart></ResponsiveContainer></div>
        <p className="text-sm text-zinc-400">{chart.length<2?"برای مشاهده روند، حداقل دو اندازه‌گیری ثبت کنید.":"تغییر وزن به‌تنهایی نشانهٔ پیشرفت یا پسرفت نیست؛ هدف، اندازه‌ها و عکس‌ها را هم مقایسه کنید."}</p>
        <div className="overflow-x-auto"><table className="mt-3 w-full text-sm"><thead><tr><th>تاریخ</th>{Object.values(METRICS).map(v=><th className="p-2" key={v}>{v}</th>)}</tr></thead><tbody>{records.map(r=><tr key={r.id}><td>{formatDate(r.date)}</td>{Object.keys(METRICS).map(k=><td className="p-2 text-center" key={k}>{r.measurements[k as keyof Measurements]??"—"}</td>)}</tr>)}</tbody></table></div>
      </div>}
      <section className="space-y-3 rounded-[28px] border border-white/10 bg-card p-4 sm:p-5">
        <div><h3 className="font-bold text-white">پرونده برنامه‌ها</h3><p className="mt-1 text-sm text-zinc-500">برای دیدن برنامه، عکس‌ها و اندازه‌های هر دوره، پوشه همان برنامه را باز کنید.</p></div>
        <div className="grid gap-3 sm:grid-cols-2">
          {currentDelivered&&<button type="button" aria-expanded={currentSelected} onClick={()=>setSelected(currentSelected?"":"current")} className={`flex min-h-20 w-full items-center gap-3 rounded-2xl border p-4 text-right transition ${currentSelected?"border-amber-500/60 bg-amber-500/10":"border-white/8 bg-white/[.025] hover:border-amber-500/30 hover:bg-white/[.045]"}`}>
            <span className={`grid size-11 shrink-0 place-items-center rounded-2xl ${currentSelected?"bg-amber-500 text-white":"bg-white/5 text-amber-400"}`}>{currentSelected?<FolderOpen className="size-5"/>:<Folder className="size-5"/>}</span>
            <span className="min-w-0 flex-1"><strong className="block text-base text-white">برنامه شماره {currentNumber.toLocaleString("fa-IR")}</strong><small className="mt-1 block truncate text-zinc-500">برنامه جاری · {plan.title}</small></span>
            <ChevronLeft className={`size-5 shrink-0 text-zinc-600 transition ${currentSelected?"-rotate-90 text-amber-400":""}`}/>
          </button>}
          {numberedRecords.map(({record,number})=>{
          const active=selected===record.id;
          const photoCount=Object.keys(record.photos).length;
          return <button key={record.id} type="button" aria-expanded={active} onClick={()=>setSelected(active?"":record.id)} className={`flex min-h-20 w-full items-center gap-3 rounded-2xl border p-4 text-right transition ${active?"border-amber-500/60 bg-amber-500/10":"border-white/8 bg-white/[.025] hover:border-amber-500/30 hover:bg-white/[.045]"}`}>
            <span className={`grid size-11 shrink-0 place-items-center rounded-2xl ${active?"bg-amber-500 text-white":"bg-white/5 text-amber-400"}`}>{active?<FolderOpen className="size-5"/>:<Folder className="size-5"/>}</span>
            <span className="min-w-0 flex-1"><strong className="block text-base text-white">برنامه شماره {number.toLocaleString("fa-IR")}</strong><small className="mt-1 block truncate text-zinc-500">{formatDate(record.date)} · {record.plan.title}</small>{photoCount>0&&<small className="mt-1 flex items-center gap-1 text-zinc-400"><Camera className="size-3.5"/> {photoCount.toLocaleString("fa-IR")} عکس</small>}</span>
            <ChevronLeft className={`size-5 shrink-0 text-zinc-600 transition ${active?"-rotate-90 text-amber-400":""}`}/>
          </button>;
        })}</div>
      </section>
      {currentSelected&&<article className="space-y-4 rounded-[28px] border border-amber-500/25 bg-card p-4 sm:p-6"><div className="flex flex-wrap items-start justify-between gap-3"><div><p className="text-xs font-bold text-white">برنامه شماره {currentNumber.toLocaleString("fa-IR")} · جاری</p><h3 className="mt-1 text-lg font-black text-white">{plan.title}</h3></div><div className="flex flex-wrap gap-2"><Button variant="outline" onClick={()=>setSelected("")}>بستن پرونده</Button>{onEditCurrent&&<Button variant="outline" onClick={onEditCurrent}><Pencil/> ویرایش برنامه جاری</Button>}{onDeleteCurrent&&<Button variant="outline" disabled={busy} onClick={()=>{setBusy(true);void onDeleteCurrent().then(()=>{setSelected("");setCurrentDelivered(false);setNotice("برنامه جاری حذف شد.");}).catch(e=>setError(e instanceof Error?e.message:"حذف برنامه انجام نشد.")).finally(()=>setBusy(false));}} className="border-rose-500/30 text-rose-300"><Trash2/> حذف این برنامه</Button>}</div></div>
        <ProgramFileSections plan={plan} exercises={exercises} photos={[]} intake={intake(currentNumber)}/>
      </article>}
      {chosen&&<article className="space-y-4 rounded-[28px] border border-amber-500/25 bg-card p-4 sm:p-6"><div className="flex flex-wrap items-start justify-between gap-3"><div><p className="text-xs font-bold text-amber-400">{`برنامه شماره ${numberedRecords.find(item=>item.record.id===chosen.id)?.number.toLocaleString("fa-IR")}`}</p><h3 className="mt-1 text-lg font-black text-white">{chosen.plan.title}</h3><p className="mt-1 text-sm text-zinc-500">{formatDate(chosen.date)}</p></div><div className="flex flex-wrap gap-2"><Button variant="outline" onClick={()=>setSelected("")}>بستن پرونده</Button>{onEditProgram&&<Button variant="outline" disabled={busy} onClick={()=>onEditProgram(chosen)} className="border-white/20"><Pencil/> ویرایش در برنامه‌ساز</Button>}<Button variant="outline" disabled={busy} onClick={()=>void deleteArchivedProgram(chosen)} className="border-red-500/30 text-red-300 hover:bg-red-500/10 hover:text-red-200"><Trash2/> حذف این برنامه</Button></div></div><p className="whitespace-pre-wrap text-sm">{chosen.notes}</p>
        <ProgramFileSections plan={chosen.plan} exercises={chosen.exercises} photos={Object.entries(POSES).filter(([p])=>chosen.photos[p as Pose]).map(([p,label])=>({src:chosen.photos[p as Pose]!,label,caption:formatDate(chosen.date)}))} onPrint={()=>onPrint(chosen)} intake={intake(numberedRecords.find(item=>item.record.id===chosen.id)?.number??1)} photoTools={<><label className="flex items-start gap-2 text-sm"><Checkbox checked={consent} onCheckedChange={v=>setConsent(v===true)}/>رضایت شاگرد برای ذخیره خصوصی این عکس‌ها را دارم. عکس‌ها برای هوش مصنوعی ارسال نمی‌شوند.</label><div className="grid gap-3 sm:grid-cols-2">{Object.entries(POSES).map(([p,label])=><div className="rounded-xl border border-white/10 p-3" key={p}><h4 className="mb-2 text-sm font-bold">{label}</h4><label className="block text-sm text-zinc-400">{chosen.photos[p as Pose]?"تعویض عکس":"عکس ثبت نشده"}<Input type="file" accept="image/jpeg,image/png,image/webp" disabled={!consent||busy} onChange={e=>{const f=e.target.files?.[0];if(f)void upload(f,p as Pose);e.target.value="";}}/></label></div>)}</div><p className="text-sm text-zinc-400">عکس‌های هر دوره جدا نگهداری می‌شوند و در PDF برنامه قرار نمی‌گیرند.</p></>}/>
      </article>}
      {archivedRecords.length>1&&<div className="space-y-3 rounded-2xl border border-white/10 p-4"><h3 className="font-bold">مقایسهٔ دو دوره</h3><Select value={compare} onValueChange={setCompare}><SelectTrigger><SelectValue placeholder="دورهٔ دوم را انتخاب کنید"/></SelectTrigger><SelectContent>{archivedRecords.filter(r=>r.id!==chosen?.id).map(r=><SelectItem key={r.id} value={r.id}>{formatDate(r.date)} — {r.plan.title}</SelectItem>)}</SelectContent></Select><Select value={pose} onValueChange={v=>setPose(v as Pose)}><SelectTrigger><SelectValue/></SelectTrigger><SelectContent>{Object.entries(POSES).map(([p,l])=><SelectItem key={p} value={p}>{l}</SelectItem>)}</SelectContent></Select>
      {chosen&&older&&older.id!==chosen.id&&<><div className="grid grid-cols-2 gap-2">{[older,chosen].map(r=><figure key={r.id}><figcaption className="mb-2 text-sm">{formatDate(r.date)}</figcaption>{r.photos[pose]?<img src={r.photos[pose]} className="h-72 w-full object-contain" alt={`${POSES[pose]} ${formatDate(r.date)}`}/>:<p className="text-sm">این نما ثبت نشده</p>}</figure>)}</div><p className="text-sm">اختلاف وزن دورهٔ انتخابی نسبت به دورهٔ دوم: {chosen.measurements.weight!==null&&older.measurements.weight!==null?`${(chosen.measurements.weight-older.measurements.weight).toFixed(1)} کیلوگرم`:"داده کافی نیست"}</p></>}
      </div>}
    </>}
    <Dialog open={securityOpen} onOpenChange={setSecurityOpen}><DialogContent dir="rtl" className="max-h-[90dvh] overflow-y-auto"><DialogHeader><DialogTitle>تغییر رمز مربی</DialogTitle><DialogDescription>رمز را با دیگران به اشتراک نگذارید.</DialogDescription></DialogHeader><PasswordSettings onReady={()=>{setSecurityOpen(false);setReady(true);void refresh();}}/></DialogContent></Dialog>
  </section>;
}
