"use client";
import {useId,useState} from 'react';
import {PERSIAN_MONTHS,persianParts,persianToISO,persianMonthLength,formatPersianDate} from '@/lib/persian-date';
export function PersianDatePicker({value,onChange,disabled=false,className='',label='انتخاب تاریخ شمسی'}:{value:string;onChange:(value:string)=>void;disabled?:boolean;className?:string;label?:string}){
 const [open,setOpen]=useState(false),[view,setView]=useState<{year:number;month:number}|null>(null);const id=useId();
 const current=persianParts(value)||persianParts(new Date().toISOString())!;
 const {year,month}=view||current;
 const start=persianToISO(year,month,1),offset=(new Date(start+'T12:00:00Z').getUTCDay()+1)%7;
 const move=(direction:number)=>{const next=month+direction;setView(next<1?{year:year-1,month:12}:next>12?{year:year+1,month:1}:{year,month:next})};
 return <div className={'persian-date-picker '+className} dir="rtl" onKeyDown={e=>{if(e.key==='Escape'){setOpen(false);e.stopPropagation()}}}>
  <button type="button" className="persian-date-trigger" disabled={disabled} aria-label={label} aria-expanded={open} aria-controls={id} onClick={()=>{setView(null);setOpen(!open)}}>{value?formatPersianDate(value):'انتخاب تاریخ شمسی'} <span aria-hidden>▦</span></button>
  {open&&<div id={id} className="persian-calendar" role="group" aria-label={label}>
   <div className="persian-calendar-head"><button type="button" aria-label="ماه قبل" disabled={disabled||year<=1201} onClick={()=>move(-1)}>ماه قبل</button><strong>{PERSIAN_MONTHS[month-1]} {year.toLocaleString('fa-IR',{useGrouping:false})}</strong><button type="button" aria-label="ماه بعد" disabled={disabled||year>=1599} onClick={()=>move(1)}>ماه بعد</button></div>
   <div className="persian-calendar-month"><select aria-label="ماه شمسی" value={month} disabled={disabled} onChange={e=>setView({year,month:Number(e.target.value)})}>{PERSIAN_MONTHS.map((name,i)=><option key={name} value={i+1}>{name}</option>)}</select><select aria-label="سال شمسی" value={year} disabled={disabled} onChange={e=>setView({year:Number(e.target.value),month})}>{Array.from({length:401},(_,i)=>1200+i).map(y=><option key={y} value={y}>{y.toLocaleString('fa-IR',{useGrouping:false})}</option>)}</select></div>
   <div className="persian-calendar-grid">{['ش','ی','د','س','چ','پ','ج'].map((d,i)=><span key={i} aria-hidden>{d}</span>)}{Array.from({length:offset},(_,i)=><span key={'blank'+i}/>)}{Array.from({length:persianMonthLength(year,month)},(_,i)=>i+1).map(day=>{const iso=persianToISO(year,month,day);return <button key={day} type="button" disabled={disabled} aria-pressed={iso===value} aria-label={`${day} ${PERSIAN_MONTHS[month-1]} ${year}`} onClick={()=>{onChange(iso);setOpen(false)}}>{day.toLocaleString('fa-IR')}</button>})}</div>
   <button type="button" disabled={disabled} onClick={()=>{const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Tehran',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());onChange(today);setOpen(false)}}>امروز</button>
  </div>}
 </div>
}
