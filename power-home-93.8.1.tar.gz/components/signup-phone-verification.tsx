"use client";
import {useEffect,useState} from "react";
import {Button} from "@/components/ui/button";
import {Input} from "@/components/ui/input";
import {normalizeDigits,normalizePhone} from "@/lib/student-auth-client";
export function SignupPhoneVerification({phone,verified,disabled,onPhoneChange,onVerified}:{phone:string;verified:boolean;disabled:boolean;onPhoneChange:(phone:string)=>void;onVerified:(token:string)=>void}){
  const [challenge,setChallenge]=useState(""),[code,setCode]=useState(""),[busy,setBusy]=useState(false),[message,setMessage]=useState(""),[retryAt,setRetryAt]=useState(0),[seconds,setSeconds]=useState(0);
  useEffect(()=>{const tick=()=>setSeconds(Math.max(0,Math.ceil((retryAt-Date.now())/1000)));tick();const timer=setInterval(tick,1000);return()=>clearInterval(timer)},[retryAt]);
  const send=async()=>{if(busy||disabled||Date.now()<retryAt)return;setBusy(true);setMessage("");try{
    const response=await fetch("/api/student/signup-code",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({phone}),signal:AbortSignal.timeout(20000)});const data=await response.json();
    if(data.retryAfter)setRetryAt(Date.now()+data.retryAfter*1000);if(!response.ok)throw new Error(data.error||"ارسال کد انجام نشد.");setChallenge(data.challengeId);setCode("");setMessage("کد تأیید برای شماره شما ارسال شد.");
  }catch(error){setMessage(error instanceof Error?error.message:"ارسال کد انجام نشد.")}finally{setBusy(false)}};
  const verify=async()=>{if(busy||disabled)return;setBusy(true);setMessage("");try{
    const response=await fetch("/api/student/signup-verify",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({phone,challengeId:challenge,code}),signal:AbortSignal.timeout(15000)});const data=await response.json();if(!response.ok)throw new Error(data.error||"کد تأیید معتبر نیست.");onVerified(data.registrationToken);setCode("");setMessage("");
  }catch(error){setMessage(error instanceof Error?error.message:"تأیید شماره انجام نشد.")}finally{setBusy(false)}};
  return <section className="signup-phone-verification" aria-label="تأیید شماره موبایل"><label>شماره موبایل<Input type="tel" inputMode="tel" autoComplete="tel" dir="ltr" disabled={disabled||busy} value={phone} placeholder="09xxxxxxxxx" onChange={event=>{onPhoneChange(event.target.value);setChallenge("");setCode("");setMessage("")}}/></label>
    {verified?<p role="status">شماره موبایل تأیید شد. مشخصات و خدمات موردنظرت را انتخاب کن.</p>:<><Button type="button" disabled={disabled||busy||seconds>0||!/^09\d{9}$/.test(normalizePhone(phone))} onClick={()=>void send()}>{busy?"در حال پردازش…":seconds>0?`ارسال دوباره پس از ${seconds.toLocaleString("fa-IR")} ثانیه`:challenge?"ارسال دوباره کد":"دریافت کد پیامکی"}</Button>
    {challenge&&<><label>کد تأیید پیامکی<Input type="text" inputMode="numeric" autoComplete="one-time-code" dir="ltr" maxLength={6} value={code} disabled={disabled||busy} onChange={event=>setCode(normalizeDigits(event.target.value).replace(/\D/g,""))}/></label><Button type="button" disabled={disabled||busy||code.length!==6} onClick={()=>void verify()}>تأیید شماره و ادامه</Button></>}
    {message&&<p role="status" aria-live="polite">{message}</p>}<p>کد تأیید ۵ دقیقه معتبر است. نیازی به ساخت رمز ثابت نیست.</p><a href="/student">قبلاً ثبت‌نام کرده‌ام؛ ورود به پنل</a></>}
  </section>;
}
