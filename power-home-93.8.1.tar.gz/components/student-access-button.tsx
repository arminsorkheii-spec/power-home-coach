"use client";

import { useEffect, useState } from "react";
import { Check, Copy, KeyRound, Link2, LoaderCircle, Share2, Smartphone, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import type { Client } from "@/lib/coach-data";

export function StudentAccessButton({ client }: { client: Client }) {
  const [open, setOpen] = useState(false);
  const [phone, setPhone] = useState(client.phone || "");
  const [password, setPassword] = useState("");
  const [status, setStatus] = useState("");
  const [busy, setBusy] = useState(false);
  const [configured, setConfigured] = useState(false);
  const [linkActive,setLinkActive]=useState(false);
  const [linkUrl,setLinkUrl]=useState("");
  const [linkExpiration,setLinkExpiration]=useState("");
  useEffect(() => { setPhone(client.phone || ""); setPassword(""); setStatus(""); setConfigured(false);setLinkActive(false);setLinkUrl(""); }, [client.id, client.phone]);
  useEffect(() => { if (!open) return; fetch(`/api/student-access?clientId=${encodeURIComponent(client.id)}`, { cache: "no-store" }).then((response) => response.json()).then((result: { account?: { phone: string } | null }) => { if (result.account) { setPhone(result.account.phone); setConfigured(true); } }).catch(() => undefined); }, [open, client.id]);
  useEffect(()=>{if(!open)return;fetch(`/api/student-links?clientId=${encodeURIComponent(client.id)}`,{cache:"no-store"})
    .then(r=>r.json()).then((v:{active?:boolean;expiresAt?:string})=>{setLinkActive(Boolean(v.active));setLinkExpiration(v.expiresAt||"");}).catch(()=>undefined);
  },[open,client.id]);
  const createLink=async()=>{
    setBusy(true);setStatus("");
    try{
      const r=await fetch("/api/student-links",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({clientId:client.id})});
      const v=await r.json() as {url?:string;expiresAt?:string;error?:string};
      if(!r.ok||!v.url)throw new Error(v.error||"ساخت لینک انجام نشد.");
      setLinkUrl(v.url);setLinkActive(true);setLinkExpiration(v.expiresAt||"");
      await navigator.clipboard.writeText(v.url).catch(()=>undefined);
      setStatus("لینک مستقیم ساخته و کپی شد. فقط برای همین شاگرد بفرست؛ هر کسی لینک را داشته باشد می‌تواند وارد پروفایل او شود.");
    }catch(error){setStatus(error instanceof Error?error.message:"ساخت لینک انجام نشد.");}finally{setBusy(false)}
  };
  const revokeLink=async()=>{
    if(!window.confirm("این لینک و نشست‌های ورود با لینک شاگرد را باطل می‌کنید؟ ورود با شماره و رمز همچنان فعال می‌ماند."))return;
    setBusy(true);setStatus("");
    try{
      const r=await fetch("/api/student-links",{method:"DELETE",headers:{"content-type":"application/json"},body:JSON.stringify({clientId:client.id})});
      if(!r.ok)throw new Error("ابطال لینک انجام نشد.");
      setLinkActive(false);setLinkUrl("");setStatus("لینک قبلی باطل شد؛ ورود با شماره و رمز بدون تغییر باقی ماند.");
    }catch(error){setStatus(error instanceof Error?error.message:"ابطال لینک انجام نشد.");}finally{setBusy(false)}
  };
  const save = async () => {
    setBusy(true); setStatus("");
    try {
      const response = await fetch("/api/student-access", { method: "PUT", headers: { "content-type": "application/json" }, body: JSON.stringify({ clientId: client.id, phone, password }) });
      const result = await response.json() as { error?: string };
      if (!response.ok) throw new Error(result.error ?? "ساخت دسترسی انجام نشد.");
      setConfigured(true); setStatus(configured?"شماره ذخیره شد؛ رمز اولیه شاگرد تغییر نکرد.":"دسترسی شاگرد فعال شد.");
    } catch (error) { setStatus(error instanceof Error ? error.message : "خطا در ساخت دسترسی"); }
    finally { setBusy(false); }
  };
  const studentUrl = () => `${window.location.origin}/student?phone=${encodeURIComponent(phone)}`;
  const copy = async () => { await navigator.clipboard.writeText(studentUrl()); setStatus("لینک صفحه ورود عادی شاگرد کپی شد؛ شماره و رمز لازم است."); };
  const share = async () => {
    const url = studentUrl();
    if (navigator.share) {
      try { await navigator.share({ title: `ورود برنامه ${client.name}`, text: `لینک ورود به برنامه اختصاصی ${client.name}`, url }); setStatus("لینک شاگرد آماده ارسال شد."); return; }
      catch (error) { if (error instanceof DOMException && error.name === "AbortError") return; }
    }
    await navigator.clipboard.writeText(url);
    setStatus("لینک صفحه ورود عادی کپی شد.");
  };
  return <>
    <Button onClick={() => setOpen(true)} variant="outline" className="h-11 border-white/10 bg-white/5"><Smartphone /> لینک دسترسی شاگرد</Button>
    <Dialog open={open} onOpenChange={setOpen}><DialogContent className="max-w-md border-white/10 bg-[color:var(--ph-tone-19_1000)]" dir="rtl">
      <DialogHeader><DialogTitle>ورود اختصاصی {client.name}</DialogTitle><DialogDescription>شماره موبایل و یک رمز ۶ رقمی تعیین کنید. شاگرد فقط برنامه خودش را می‌بیند.</DialogDescription></DialogHeader>
      <div className="grid gap-4 py-2">
        <div className="rounded-2xl border border-white/15 bg-white/[.04] p-3"><div className="flex items-center gap-2 font-bold text-white"><Link2 className="size-5"/> لینک ورود مستقیم شاگرد</div>
          <p className="mt-2 text-xs text-zinc-400">بدون نیاز به شماره یا رمز، برای همه شاگردها. لینک تا ۹۰ روز معتبر است و می‌توان آن را هر زمان باطل یا دوباره صادر کرد.</p>
          <div className="mt-3 flex flex-wrap gap-2"><Button onClick={()=>void createLink()} disabled={busy} className="bg-zinc-100 text-zinc-950 hover:bg-zinc-300"><Link2/> {linkActive?"ساخت لینک جدید":"ساخت و کپی لینک"}</Button>
          {linkUrl&&<Button variant="outline" onClick={()=>void navigator.clipboard.writeText(linkUrl).then(()=>setStatus("لینک کپی شد."))}><Copy/> کپی دوباره</Button>}
          {linkActive&&<Button variant="outline" onClick={()=>void revokeLink()} disabled={busy} className="border-rose-500/30 text-rose-300"><Trash2/> باطل‌کردن لینک</Button>}</div>
          {linkActive&&<p className="mt-2 text-xs text-zinc-400">{linkExpiration?`اعتبار تا ${new Date(linkExpiration).toLocaleDateString("fa-IR")}`:"لینک فعال است"}{!linkUrl?"؛ برای کپی دوباره لینک جدید بساز.":""}</p>}
        </div>
        <div className="border-t border-white/10 pt-4"><p className="mb-3 text-sm font-bold text-white">ورود عادی با شماره و رمز (روش قبلی)</p><label className="mb-2 block text-sm text-zinc-300">شماره موبایل</label><Input value={phone} onChange={(event) => setPhone(event.target.value)} inputMode="tel" placeholder="09xxxxxxxxx" dir="ltr" /></div>
        {configured?<div className="rounded-xl border border-emerald-500/20 bg-emerald-500/[.06] p-3 text-sm text-emerald-300">رمز ورود همان رمز اولیه‌ای است که شاگرد موقع ثبت‌نام انتخاب کرده و تغییر نمی‌کند.</div>:<div><label className="mb-2 block text-sm text-zinc-300">رمز ۶ رقمی</label><Input value={password} onChange={(event) => setPassword(event.target.value.replace(/\D/g, "").slice(0, 6))} inputMode="numeric" placeholder="مثلاً 246810" dir="ltr" className="text-center tracking-[.25em]" /></div>}
        <Button onClick={save} disabled={busy || (!configured&&password.length !== 6)} className="bg-zinc-100 text-zinc-950 hover:bg-zinc-300">{busy ? <LoaderCircle className="animate-spin" /> : <KeyRound />} {configured ? "ذخیره شماره و حفظ رمز اولیه" : "فعال‌کردن ورود شاگرد"}</Button>
        {configured && <div className="grid grid-cols-1 gap-2 sm:grid-cols-2"><Button onClick={share} className="bg-emerald-600 hover:bg-emerald-500"><Share2 /> ارسال لینک ورود عادی</Button><Button onClick={copy} variant="outline" className="border-white/10"><Copy /> کپی لینک</Button></div>}
        {status && <p className={`flex items-center justify-center gap-2 text-xs ${status.includes("خطا") || status.includes("نیست") ? "text-amber-300" : "text-emerald-400"}`}>{!status.includes("خطا") && <Check className="size-4" />}{status}</p>}
      </div>
    </DialogContent></Dialog>
  </>;
}
