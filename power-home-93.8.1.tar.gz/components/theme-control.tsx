'use client';
import {useEffect,useSyncExternalStore} from 'react';
import {Moon,Sun} from 'lucide-react';
import {APPEARANCE_KEY,validAppearance,type Appearance} from '@/lib/theme';
const eventName='power-appearance-changed';
function snapshot():Appearance{return validAppearance(document.documentElement.dataset.theme)}
function subscribe(callback:()=>void){window.addEventListener(eventName,callback);return()=>window.removeEventListener(eventName,callback)}
function apply(value:Appearance){document.documentElement.dataset.theme=value;document.documentElement.style.colorScheme=value;document.querySelector('meta[name="theme-color"]')?.setAttribute('content',value==='light'?'#f5f5f5':'#090909');window.dispatchEvent(new Event(eventName))}
export function ThemeController(){useEffect(()=>{apply(snapshot());const sync=(event:StorageEvent)=>{if(event.key===APPEARANCE_KEY||event.key===null)apply(validAppearance(event.newValue))};window.addEventListener('storage',sync);return()=>window.removeEventListener('storage',sync)},[]);return null}
export function ThemeToggle(){const theme=useSyncExternalStore(subscribe,snapshot,()=> 'dark' as const);return <button type="button" className="appearance-toggle" aria-label={theme==='dark'?'فعال‌کردن حالت روز':'فعال‌کردن حالت شب'} aria-pressed={theme==='light'} onClick={()=>{const next=theme==='dark'?'light':'dark';apply(next);try{localStorage.setItem(APPEARANCE_KEY,next)}catch{/* The current session still switches when storage is disabled. */}}}>{theme==='dark'?<Sun size={20}/>:<Moon size={20}/>}<span>{theme==='dark'?'حالت روز':'حالت شب'}</span></button>}
