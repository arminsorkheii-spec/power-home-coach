"use client";
import {PlanNutritionChart} from "@/components/plan-nutrition-chart";
import {useAutoRefresh} from "@/hooks/use-auto-refresh";
import {notifyDataUpdated} from "@/lib/auto-refresh";
import {TechniqueExplanation,PlanTechniqueGlossary} from "@/components/training-technique-guide";
import {mealFoodText} from "@/lib/food-catalog";
import {StudentCompanionHeader} from "@/components/companion-workspace";
import {StudentMuscleMap} from "@/components/student-muscle-map";
import {StudentDashboardShell,StudentArea} from "@/components/student-dashboard-shell";
import {StudentLifeHub} from "@/components/student-life-hub";
import {StudentTrainingHub} from "@/components/student-training-hub";
import {StudentWellness} from "@/components/student-wellness";
import {ProgramRenewalCard} from "@/components/program-renewal-card";
import {GoogleSignInButton} from "@/components/google-sign-in-button";

import { PaymentDetails } from "@/components/payment-details";

import { useCallback, useEffect, useState } from "react";
import { CalendarDays, Camera, Check, ChevronLeft, ClipboardCheck, Dumbbell, ExternalLink, FileDown, FileText, Folder, FolderOpen, LoaderCircle, LogOut, Pill, Plus, Salad, Syringe, TrendingUp, UserRound, X } from "lucide-react";
import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { Client, ClientPlan, Exercise } from "@/lib/coach-data";
import { PushNotificationControl } from "@/components/push-notification-control";
import { PhotoGallery } from "@/components/photo-gallery";
import { PlanPrint } from "@/components/plan-print";
import { downloadPlanPdf } from "@/lib/pdf-export";
import { StudentChat } from "@/components/student-chat";
import { StudentNotifications } from "@/components/student-notifications";
import { GlassSectionIcon } from "@/components/glass-section-icon";
import { GraphicSectionIcon } from "@/components/graphic-section-icon";
import { groupExerciseRows } from "@/lib/supersets";

type Payload = { client: Client; plan: ClientPlan; exercises: Exercise[]; currentDelivered:boolean };
type StudentUpload = {id:string;kind:string;filename:string;content_type?:string};
type StudentApplication = { parent_application_id?:string|null; id:string;package_name:string;status:string;price_amount:number|null;updated_at:string;created_at:string;profile:Record<string,string>;uploads:StudentUpload[] };
type ApplicationPayload = { application: StudentApplication; uploads:StudentUpload[]; applications:StudentApplication[]; canRequestNew?:boolean;canRequestAddon?:boolean };
type ProgressRecord = {id:string;date:string;recordType?:"baseline"|"archive";title:string;plan?:ClientPlan;exercises:Exercise[];measurements:{weight?:number|null;waist?:number|null;arm?:number|null};photos:Record<string,string>};
const statusLabels:Record<string,string>={draft:"تکمیل اطلاعات",awaiting_payment:"در انتظار پرداخت",payment_review:"در حال بررسی پرداخت",payment_approved:"پرداخت تأیید شد",writing:"در حال نوشتن برنامه",ready:"در حال نوشتن برنامه",delivered:"ارسال شده"};
const processSteps=["شروع درخواست","اطلاعات و عکس‌ها","پرداخت و رسید","بررسی مربی","تأیید پرداخت","نگارش برنامه","تحویل در پنل"];
const statusPosition:Record<string,number>={draft:1,awaiting_payment:2,payment_review:3,payment_approved:4,writing:5,ready:5,delivered:6};
const statusDescriptions:Record<string,string>={
  draft:"درخواست برنامه شروع شده؛ مشخصات، عکس‌ها و مدارک را کامل کن.",
  awaiting_payment:"پرونده کامل است؛ پرداخت را انجام بده و تصویر رسید را بفرست.",
  payment_review:"رسید دریافت شده و پرداخت و پرونده در حال بررسی مربی است.",
  payment_approved:"پرداخت تأیید شده و پرونده آماده شروع نگارش برنامه است.",
  writing:"پرونده تأیید شده و مربی در حال نوشتن برنامه اختصاصی تو است.",
  ready:"پرونده تأیید شده و مربی در حال نوشتن برنامه اختصاصی تو است.",
  delivered:"برنامه ارسال شده و از بخش‌های تمرین، تغذیه، مکمل و دارو قابل مشاهده و دانلود است.",
};

export function StudentPortal() {
  const [data, setData] = useState<Payload | null>(null);
  const [application,setApplication]=useState<ApplicationPayload|null>(null);
  const [progress,setProgress]=useState<ProgressRecord[]>([]);
  const [studentUnread,setStudentUnread]=useState(0);
  const [personalTasks,setPersonalTasks]=useState<number|undefined>(undefined);
  const [selectedProgram,setSelectedProgram]=useState<string>("");
  const [noticeRoute,setNoticeRoute]=useState<{section:string;applicationId:string;stamp:number;lifeTab?:string}|null>(null);
  const [focusedRequest,setFocusedRequest]=useState("");
  const openStudentNotice=useCallback((value:string,push=true)=>{
    const url=new URL(value,window.location.origin);if(url.origin!==window.location.origin||url.pathname!=="/student")return;
    const legacy=url.searchParams.get("view")??url.searchParams.get("tab")??"";
    const section=url.searchParams.get("section")??({messages:"chat",chat:"chat",plans:"program",program:"program",orders:"request"} as Record<string,string>)[legacy]??"notifications";
    if(!["chat","program","request","notifications","renewal","wellness","training","life","muscles"].includes(section))return;
    if(push)window.history.pushState(null,"",url.pathname+url.search);
    setNoticeRoute({section,lifeTab:url.searchParams.get('life')??undefined,applicationId:url.searchParams.get("application")??"",stamp:Date.now()});
  },[]);
  useEffect(()=>{const load=()=>{if(window.location.search)openStudentNotice(window.location.pathname+window.location.search,false)};load();window.addEventListener("popstate",load);return()=>window.removeEventListener("popstate",load)},[openStudentNotice]);
  useEffect(()=>{
    if(!noticeRoute||!data||!application)return;
    const requested=application.applications.find(item=>item.id===noticeRoute.applicationId)??application.application;
    setFocusedRequest(requested.id);
    if(noticeRoute.section==="program"){
      const roots=application.applications.filter(item=>!item.parent_application_id);
      const index=roots.findIndex(item=>item.id===(requested.parent_application_id??requested.id));
      const archives=progress.filter(item=>item.recordType!=="baseline"&&Boolean(item.plan));
      setSelectedProgram(index>=0&&index<archives.length?archives[index].id:data.currentDelivered?"current":"");
    }
  },[noticeRoute,data,application,progress]);
  useEffect(()=>{
    if(!noticeRoute||!data||!application)return;
    const id=noticeRoute.section==="muscles"?"student-muscles":noticeRoute.section==="life"?"student-life":noticeRoute.section==="training"?"student-training":noticeRoute.section==="renewal"?"student-renewal":noticeRoute.section==="wellness"?"student-wellness":noticeRoute.section==="chat"?"student-chat":noticeRoute.section==="program"?(selectedProgram?"student-program-open":"student-program"):noticeRoute.section==="request"?"student-request-history":"student-notifications";
    const frame=requestAnimationFrame(()=>document.getElementById(id)?.scrollIntoView({block:"start"}));return()=>cancelAnimationFrame(frame);
  },[noticeRoute,selectedProgram,focusedRequest,Boolean(data),Boolean(application)]);

  const [exercisePreview,setExercisePreview]=useState<{src:string;name:string}|null>(null);
  const [pdfBusy,setPdfBusy]=useState("");
  const [pdfMessage,setPdfMessage]=useState("");
  const [error, setError] = useState("");
  const refreshPortal=useCallback(async()=>{
    const responses=await Promise.allSettled(['/api/student/plan','/api/student/application','/api/student/progress'].map(async url=>{const r=await fetch(url,{cache:'no-store',signal:AbortSignal.timeout(15000)});if(!r.ok)throw Error('اطلاعات دریافت نشد.');return r.json()}));
    const [planResult,applicationResult,progressResult]=responses;
    if(planResult.status==='fulfilled'){setData(planResult.value);setError('')}else if(!data)setError('دریافت اطلاعات انجام نشد؛ پس از اتصال دوباره خودکار تلاش می‌شود.');
    if(applicationResult.status==='fulfilled')setApplication(applicationResult.value);
    if(progressResult.status==='fulfilled')setProgress(progressResult.value.records??[]);
  },[Boolean(data)]);
  useAutoRefresh(refreshPortal,{initial:true,intervalMs:20000});
  const logout = async () => { await fetch("/api/student/logout", { method: "POST" }); window.location.reload(); };
  if (error) return <main className="student-portal"><div className="student-empty"><p>{error}</p><Button onClick={logout}>بازگشت به ورود</Button></div></main>;
  if (!data) return <main className="student-portal"><LoaderCircle className="student-loader animate-spin" /></main>;
  const { client, plan } = data;
  const archivedProgress=progress.filter((record)=>record.recordType!=="baseline"&&Boolean(record.plan));
  const archivedPrograms=archivedProgress.map((record,index)=>({id:record.id,number:index+1,current:false as const,record,plan:record.plan!,exercises:record.exercises}));
  const programFiles=[...archivedPrograms,...(data.currentDelivered?[{id:"current",number:archivedPrograms.length+1,current:true as const,record:null,plan,exercises:data.exercises}]:[])];
  const selectedFile=programFiles.find(file=>file.id===selectedProgram);
  const visiblePlan=selectedFile?.plan;
  const exerciseMap=new Map((selectedFile?.exercises??[]).map(item=>[item.id,item]));
  const programApplications=application?.applications?.filter(item=>!item.parent_application_id)??[];
  const selectedApplication=selectedFile?programApplications[selectedFile.number-1]:undefined;
  const orderApplication=selectedApplication??application?.application;
  const orderReceipt=orderApplication?.uploads.find(upload=>upload.kind==="receipt");
  const programProfile=selectedApplication?.profile??{};
  const intakePhotos=selectedApplication?.uploads.filter(u=>["front","side","back","front_double","back_double"].includes(u.kind)).map(u=>({src:`/api/application-files/${u.id}`,label:({front:"روبه‌رو",side:"بغل",back:"پشت",front_double:"جفت بازو جلو",back_double:"جفت بازو پشت"} as Record<string,string>)[u.kind]||u.filename,caption:`برنامه شماره ${selectedFile?.number.toLocaleString("fa-IR")}`}))??[];
  const archivedPhotos=selectedFile?.record?Object.entries(selectedFile.record.photos).map(([kind,src])=>({src,label:({front:"روبه‌رو",side:"بغل",back:"پشت",front_double:"جفت بازو جلو",back_double:"جفت بازو پشت"} as Record<string,string>)[kind]||kind,caption:`برنامه شماره ${selectedFile.number.toLocaleString("fa-IR")}`})):[];
  const selectedPhotos=[...intakePhotos,...archivedPhotos];
  const currentStatus=application?.application.status??"";
  const mayRequestNew=!currentStatus||application?.canRequestNew===true||currentStatus==="delivered";
  const currentPosition=statusPosition[currentStatus]??0;
  const downloadSelectedSection=async(section:"training"|"nutrition"|"supplements"|"medications",label:string)=>{
    if(!selectedFile||!visiblePlan||pdfBusy)return;
    setPdfBusy(section);setPdfMessage("");
    try{await downloadPlanPdf(`student-plan-pdf-${section}`,`${label} - برنامه شماره ${selectedFile.number} - ${client.name}`);setPdfMessage(`PDF ${label} آماده و دانلود شد.`);}
    catch(reason){setPdfMessage(reason instanceof Error?reason.message:"ساخت PDF انجام نشد.");}
    finally{setPdfBusy("");}
  };
  return <StudentDashboardShell name={client.name} goal={client.goal} onLogout={logout} notice={noticeRoute} unread={studentUnread}>
    <div className="student-portal student-portal-workspace" dir="rtl">
    <header className="student-header">
      <div className="student-brand"><span>AS</span><div><strong>آرمین سرخه‌ای</strong><small>STUDENT PORTAL</small></div></div>
      <Button variant="outline" onClick={logout} className="border-white/10 bg-white/5"><LogOut /> خروج</Button>
    </header>
    <section className="student-welcome">
      <div className="student-avatar"><UserRound /></div>
      <div><p>خوش آمدی</p><h1>{client.name}</h1><span>{client.goal || "برنامه اختصاصی شما"}</span></div>
    </section>
    <StudentCompanionHeader/><StudentArea module="account"><GoogleSignInButton link/><p className="student-account-note">این حساب متعلق به {client.name} است. برای خروج از حساب از منوی پنل استفاده کن؛ تنظیمات سرویس‌های ورود فقط در پنل مدیر قرار دارند.</p></StudentArea>
    <StudentArea module="training"><StudentTrainingHub personalTasks={personalTasks} noticeStamp={noticeRoute?.section==="training"?noticeRoute.stamp:undefined}/></StudentArea>
    <StudentArea module="muscles"><StudentMuscleMap/></StudentArea>
    <StudentArea module="life"><StudentLifeHub onTasksChange={setPersonalTasks} noticeTab={noticeRoute?.lifeTab} noticeStamp={noticeRoute?.section==="life"?noticeRoute.stamp:undefined}/></StudentArea>
    <StudentArea module="orders"><ProgramRenewalCard/>
    <section className="student-renew-panel" aria-label="درخواست برنامه و انتخاب پکیج">
      <div className="student-renew-icon"><GraphicSectionIcon name="training" size={58}/></div>
      <div className="student-renew-copy"><strong>درخواست برنامه اختصاصی</strong><p>{mayRequestNew?"برای دوره جدید، پکیج دلخواهت را انتخاب کن. برنامه‌ها و سوابق قبلی محفوظ می‌مانند.":"درخواست فعلی‌ات در جریان است. بعد از ارسال رسید هم می‌توانی برنامه دیگری را جداگانه درخواست کنی."}</p></div>
      {mayRequestNew?<a className="student-renew-link" href="/signup?new=1"><Plus aria-hidden="true"/> درخواست برنامه جدید · انتخاب پکیج</a>:<a className="student-renew-link secondary" href="#student-current-request"><ClipboardCheck aria-hidden="true"/> پیگیری درخواست جاری</a>}
    </section>
    {(mayRequestNew||application?.canRequestAddon===true||["payment_review","payment_approved","writing","ready"].includes(currentStatus))&&<a className="student-renew-link student-addon-link" href="/signup?addon=1"><Plus aria-hidden="true"/> درخواست برنامه دیگر</a>}
    {application&&<section id="student-current-request" className={`student-process-banner status-${currentStatus}`}>
      <div className="student-process-copy"><span>وضعیت درخواست برنامه</span><h2>{statusLabels[currentStatus]??currentStatus}</h2><p>{statusDescriptions[currentStatus]??"آخرین وضعیت پرونده در این بخش نمایش داده می‌شود."}</p></div>
      <div className="student-process-progress"><div><span style={{width:`${((currentPosition+1)/processSteps.length)*100}%`}}/></div><small>مرحله {(currentPosition+1).toLocaleString("fa-IR")} از {processSteps.length.toLocaleString("fa-IR")}</small></div>
      {(currentStatus==="draft"||currentStatus==="awaiting_payment")&&<a href="/signup">{currentStatus==="draft"?"ادامه درخواست برنامه":"رفتن به مرحله پرداخت"}</a>}

    </section>}
    </StudentArea>
    <StudentArea module="wellness"><StudentWellness/></StudentArea>
    <StudentArea module="notifications"><div className="student-push-wrap"><PushNotificationControl /></div>
    <div id="student-notifications"><StudentNotifications onUnreadChange={setStudentUnread} onOpen={openStudentNotice}/></div></StudentArea>
    <StudentArea module="orders">{application&&<section id="student-request-history" className="student-orders-history"><h2>درخواست‌ها و پرداخت‌های من</h2>{[...application.applications].reverse().map(item=><article key={item.id} className={focusedRequest===item.id?"active":""}><button type="button" onClick={()=>setFocusedRequest(focusedRequest===item.id?"":item.id)}>{item.package_name} · {statusLabels[item.status]??item.status}</button>{focusedRequest===item.id&&<div><p>{statusDescriptions[item.status]}</p>{item.uploads.filter(upload=>upload.kind==="receipt").map(upload=>upload.content_type==="application/pdf"?<a key={upload.id} href={`/api/application-files/${upload.id}`} target="_blank" rel="noreferrer">مشاهده فیش پرداخت</a>:<PhotoGallery key={upload.id} images={[{src:`/api/application-files/${upload.id}`,label:"رسید پرداخت",caption:item.package_name}]}/>)}{item.id===application.application.id&&["draft","awaiting_payment"].includes(item.status)&&<a href="/signup">تکمیل درخواست و پرداخت</a>}</div>}</article>)}</section>}
    </StudentArea><StudentArea module="programs"><section id="student-program" className="student-program-files">
      <div className="student-files-heading"><div><span>پرونده برنامه‌ها</span><h2>برنامه‌های من</h2><p>برای دیدن برنامه و عکس‌های هر دوره، پوشه همان برنامه را باز کن.</p></div><strong>{programFiles.length.toLocaleString("fa-IR")} برنامه</strong></div>
      <div className="student-files-grid">{[...programFiles].reverse().map(file=>{const active=file.id===selectedProgram;const intakeCount=programApplications[file.number-1]?.uploads.filter(u=>["front","side","back","front_double","back_double"].includes(u.kind)).length??0;const photoCount=intakeCount+Object.keys(file.record?.photos??{}).length;return <button type="button" key={file.id} aria-expanded={active} onClick={()=>setSelectedProgram(active?"":file.id)} className={active?"active":""}>
        <span>{active?<FolderOpen/>:<Folder/>}</span>
        <div><h3>برنامه شماره {file.number.toLocaleString("fa-IR")}</h3><p>{file.current?"برنامه جاری":new Date(file.record!.date).toLocaleDateString("fa-IR")}</p>{photoCount>0&&<small><Camera/> {photoCount.toLocaleString("fa-IR")} عکس</small>}</div>
        <ChevronLeft/>
      </button>;})}</div>
    </section>
    {!selectedFile&&<div className="student-file-placeholder"><Folder/><p>یکی از پوشه‌های برنامه را انتخاب کن.</p></div>}
    {selectedFile&&visiblePlan&&<section id="student-program-open" className="student-program-open">
      <div className="student-program-open-head"><div><span>{selectedFile.current?"برنامه جاری":"برنامه بایگانی‌شده"}</span><h2>برنامه شماره {selectedFile.number.toLocaleString("fa-IR")}</h2><p>{visiblePlan.title}</p></div><div className="student-program-open-actions"><button type="button" onClick={()=>setSelectedProgram("")}><X/> بستن پرونده</button></div></div>
      <div className="student-pdf-grid">
        <button type="button" onClick={()=>void downloadSelectedSection("training","برنامه تمرینی")} disabled={Boolean(pdfBusy)}>{pdfBusy==="training"?<LoaderCircle className="animate-spin"/>:<GraphicSectionIcon name="training" size={51} className="student-section-graphic"/>}<span>PDF تمرین</span></button>
        <button type="button" onClick={()=>void downloadSelectedSection("nutrition","برنامه غذایی")} disabled={Boolean(pdfBusy)}>{pdfBusy==="nutrition"?<LoaderCircle className="animate-spin"/>:<GraphicSectionIcon name="nutrition" size={51} className="student-section-graphic"/>}<span>PDF تغذیه</span></button>
        <button type="button" onClick={()=>void downloadSelectedSection("supplements","برنامه مکمل")} disabled={Boolean(pdfBusy)}>{pdfBusy==="supplements"?<LoaderCircle className="animate-spin"/>:<GraphicSectionIcon name="supplements" size={51} className="student-section-graphic"/>}<span>PDF مکمل</span></button>
        <button type="button" onClick={()=>void downloadSelectedSection("medications","برنامه دارو و PCT")} disabled={Boolean(pdfBusy)||(visiblePlan.medicationItems?.length??0)===0}>{pdfBusy==="medications"?<LoaderCircle className="animate-spin"/>:<GraphicSectionIcon name="medications" size={51} className="student-section-graphic"/>}<span>PDF دارو / PCT</span></button>
      </div>
      {pdfMessage&&<p className="student-pdf-message" role="status">{pdfMessage}</p>}
      <Tabs defaultValue="workout" className="student-tabs">
      <TabsList className="student-tabs-list student-main-tabs-list">
        <TabsTrigger value="workout"><GraphicSectionIcon name="training" size={41} className="student-tab-graphic"/> برنامه تمرینی</TabsTrigger>
        <TabsTrigger value="nutrition"><GraphicSectionIcon name="nutrition" size={41} className="student-tab-graphic"/> برنامه غذایی</TabsTrigger>
        <TabsTrigger value="supplements"><GraphicSectionIcon name="supplements" size={41} className="student-tab-graphic"/> مکمل</TabsTrigger>
      </TabsList>
      <TabsList className="student-tabs-list student-record-tabs-list">
        <TabsTrigger value="photos"><Camera /> عکس‌ها</TabsTrigger>
        <TabsTrigger value="profile"><UserRound /> مشخصات</TabsTrigger>
      </TabsList>
      <TabsList className="student-tabs-list student-secondary-tabs-list">
        {(visiblePlan.medicationItems?.length??0)>0&&<TabsTrigger value="medications"><GraphicSectionIcon name="medications" size={41} className="student-tab-graphic"/> دارو / PCT</TabsTrigger>}
        <TabsTrigger value="progress"><TrendingUp /> پیشرفت</TabsTrigger>
        <TabsTrigger value="order"><ClipboardCheck /> وضعیت سفارش</TabsTrigger>
      </TabsList>
      <TabsContent value="workout" className="student-tab-content">
        <div className="student-plan-title"><div><p>{selectedFile.current?"برنامه فعال":"نسخه بایگانی‌شده"}</p><h2>{visiblePlan.title || "برنامه تمرینی"}</h2></div><span><CalendarDays /> {visiblePlan.workoutDays.length.toLocaleString("fa-IR")} روز</span></div>
        {visiblePlan.workoutDays.length === 0 ? <div className="student-empty">برنامه تمرینی هنوز ثبت نشده است.</div> : visiblePlan.workoutDays.map((day) => <section key={day.id} className="student-day">
          <div className="student-day-title"><div><p>{day.focus}</p><h3>{day.title}</h3></div><span>{day.exercises.length.toLocaleString("fa-IR")} حرکت</span></div>
          <div className="student-exercises">{groupExerciseRows(day.exercises).map((unit, unitIndex) => {
            const rows=unit.items.map((row,pairIndex)=>{const exercise=exerciseMap.get(row.exerciseId);const index=day.exercises.findIndex(item=>item.rowId===row.rowId);return <article key={row.rowId} className={`student-exercise ${unit.type==="superset"?"student-superset":""}`}>
              {unit.type==="superset"&&<span className="student-superset-badge superset-label">{pairIndex===0?"A":"B"}</span>}
              <img src={exercise?.image || "/file.svg"} alt={exercise?.nameFa || "حرکت تمرینی"} role="button" tabIndex={0} className="cursor-zoom-in" onClick={()=>setExercisePreview({src:exercise?.image||"/file.svg",name:exercise?.nameFa||"حرکت تمرینی"})} onKeyDown={(event)=>{if(event.key==="Enter"||event.key===" ")setExercisePreview({src:exercise?.image||"/file.svg",name:exercise?.nameFa||"حرکت تمرینی"});}} />
              <div className="student-exercise-name"><small>{String(index + 1).padStart(2, "0")}</small><h4>{exercise?.nameFa || "حرکت تمرینی"}</h4><p dir="ltr">{exercise?.nameEn}</p>{row.notes && <span>{row.notes}</span>}</div>
              <TechniqueExplanation technique={row.technique}/><dl><div><dt>ست</dt><dd>{row.sets}</dd></div><div><dt>تکرار</dt><dd>{row.reps}</dd></div><div><dt>استراحت</dt><dd>{row.rest}</dd></div><div><dt>تکنیک</dt><dd>{row.technique}</dd></div></dl>
            </article>});
            return unit.type==="superset"?<section className="student-superset-group" key={unit.id}><div className="student-superset-title"><strong>سوپرست {(unitIndex+1).toLocaleString("fa-IR")}</strong><span>اجرای A سپس B بدون استراحت</span></div>{rows}</section>:<section key={unit.id}>{rows[0]}</section>;
          })}</div>
        </section>)}
        <PlanTechniqueGlossary days={visiblePlan.workoutDays}/>
      </TabsContent>
      <TabsContent value="nutrition" className="student-tab-content">
        <PlanNutritionChart meals={visiblePlan.nutritionMeals}/>
        <div className="student-macros" aria-label="هدف‌های تعیین‌شده توسط مربی">
          <div><span>کالری</span><strong>{visiblePlan.nutritionGoals.calories || "—"}</strong></div><div><span>پروتئین</span><strong>{visiblePlan.nutritionGoals.protein || "—"}</strong></div><div><span>کربوهیدرات</span><strong>{visiblePlan.nutritionGoals.carbs || "—"}</strong></div><div><span>چربی</span><strong>{visiblePlan.nutritionGoals.fat || "—"}</strong></div>
        </div>
        {visiblePlan.nutritionMeals.length === 0 ? <div className="student-empty">برنامه غذایی هنوز ثبت نشده است.</div> : <div className="student-meals">{visiblePlan.nutritionMeals.map((meal) => <article key={meal.id}><div><span>{meal.time}</span><h3>{meal.title}</h3></div><p>{mealFoodText(meal)}</p>{meal.notes && <small>{meal.notes}</small>}</article>)}</div>}
      </TabsContent>
      <TabsContent value="supplements" className="student-tab-content">
        <div className="student-plan-title"><div><p>SUPPLEMENT PLAN</p><h2>برنامه مکمل و ویتامین</h2></div><span><Pill/> {(visiblePlan.supplementItems?.length ?? 0).toLocaleString("fa-IR")} مورد</span></div>
        {(visiblePlan.supplementItems?.length ?? 0) === 0 ? <div className="student-empty">برنامه مکمل هنوز ثبت نشده است.</div> : <div className="student-supplements">{visiblePlan.supplementItems!.map((item, index) => <article key={item.id}><span>{(index + 1).toLocaleString("fa-IR")}</span><div><h3>{item.name}</h3>{item.notes && <p>{item.notes}</p>}</div><dl><div><dt>مقدار</dt><dd>{item.dose || "—"}</dd></div><div><dt>زمان</dt><dd>{item.timing || "—"}</dd></div><div><dt>دفعات</dt><dd>{item.frequency || "—"}</dd></div></dl></article>)}</div>}
      </TabsContent>
      {(visiblePlan.medicationItems?.length??0)>0&&<TabsContent value="medications" className="student-tab-content">
        <div className="student-plan-title"><div><p>MEDICATION PLAN</p><h2>برنامه دارویی و PCT</h2></div><span><Syringe/> {(visiblePlan.medicationItems?.length ?? 0).toLocaleString("fa-IR")} مورد</span></div>
        {(visiblePlan.medicationItems?.length ?? 0)===0?<div className="student-empty">برنامه دارویی یا PCT ثبت نشده است.</div>:<div className="student-supplements">{visiblePlan.medicationItems!.map((item,index)=><article key={item.id}><span>{(index+1).toLocaleString("fa-IR")}</span><div><h3>{item.name}</h3><p>{item.group==="pct"?"پاک‌سازی و PCT":"داروی بدنسازی"} · هفته {item.startWeek||"—"} تا {item.endWeek||"—"}</p>{item.notes&&<p>{item.notes}</p>}</div><dl><div><dt>دوز</dt><dd>{item.dose||"—"}</dd></div><div><dt>زمان</dt><dd>{item.timing||"—"}</dd></div><div><dt>دفعات</dt><dd>{item.frequency||"—"}</dd></div></dl></article>)}</div>}
      </TabsContent>}
      <TabsContent value="photos" className="student-tab-content">
        <div className="student-plan-title"><div><p>PROGRAM PHOTOS</p><h2>عکس‌های برنامه شماره {selectedFile.number.toLocaleString("fa-IR")}</h2></div><span><Camera/> {selectedPhotos.length.toLocaleString("fa-IR")} عکس</span></div>
        {selectedPhotos.length?<section className="student-intake-photos"><div><span>عکس‌های همین دوره</span><h2>پرونده تصویری</h2></div><PhotoGallery images={selectedPhotos}/></section>:<div className="student-empty">برای این برنامه هنوز عکسی ثبت نشده است.</div>}
      </TabsContent>
      <TabsContent value="profile" className="student-tab-content">
        <div className="student-plan-title"><div><p>PROGRAM PROFILE</p><h2>مشخصات برنامه شماره {selectedFile.number.toLocaleString("fa-IR")}</h2></div><span><UserRound/> اطلاعات همان دوره</span></div>
        <div className="student-macros">
          <div><span>قد</span><strong>{programProfile.height?`${programProfile.height} سانتی‌متر`:"—"}</strong></div>
          <div><span>وزن</span><strong>{programProfile.weight?`${programProfile.weight} کیلوگرم`:"—"}</strong></div>
          <div><span>دور کمر</span><strong>{programProfile.waist?`${programProfile.waist} سانتی‌متر`:"—"}</strong></div>
          <div><span>سن</span><strong>{programProfile.age?`${programProfile.age} سال`:"—"}</strong></div>
        </div>
        {(programProfile.goal||programProfile.experience||programProfile.trainingDays||programProfile.injuries||programProfile.diseases)&&<section className="student-meals mb-5">
          {programProfile.goal&&<article><div><h3>هدف این دوره</h3></div><p>{programProfile.goal}</p></article>}
          {programProfile.experience&&<article><div><h3>سابقه تمرین</h3></div><p>{programProfile.experience}</p></article>}
          {programProfile.trainingDays&&<article><div><h3>تعداد روز تمرین</h3></div><p>{programProfile.trainingDays}</p></article>}
          {programProfile.injuries&&<article><div><h3>آسیب یا محدودیت</h3></div><p>{programProfile.injuries}</p></article>}
          {programProfile.diseases&&<article><div><h3>سابقه بیماری</h3></div><p>{programProfile.diseases}</p></article>}
        </section>}
      </TabsContent>
      <TabsContent value="progress" className="student-tab-content">
        {progress.length>0&&<>
          <div className="student-plan-title student-progress-heading"><div><p>BODY PROGRESS</p><h2>روند تغییرات بدنی</h2></div><span><TrendingUp/> {progress.length.toLocaleString("fa-IR")} چک‌این</span></div>
          <div className="student-chart"><ResponsiveContainer width="100%" height={280}><LineChart data={progress.map(r=>({date:new Date(r.date).toLocaleDateString("fa-IR"),weight:r.measurements.weight,waist:r.measurements.waist}))}><CartesianGrid stroke="rgba(255,255,255,.07)" vertical={false}/><XAxis dataKey="date" stroke="#71717a" fontSize={11}/><YAxis stroke="#71717a" fontSize={11} domain={["dataMin - 3","dataMax + 3"]}/><Tooltip contentStyle={{background:"#18181b",border:"1px solid #3f3f46",borderRadius:12}}/><Line type="monotone" dataKey="weight" name="وزن" stroke="#d8dde4" strokeWidth={3} connectNulls/><Line type="monotone" dataKey="waist" name="دور کمر" stroke="#9199a5" strokeWidth={2} connectNulls/></LineChart></ResponsiveContainer></div>
          <PhotoComparison records={progress}/>
        </>}
        {progress.length===0&&<div className="student-empty">هنوز سابقه‌ای برای نمایش روند پیشرفت ثبت نشده است.</div>}
      </TabsContent>
      <TabsContent value="order" className="student-tab-content">
        {!orderApplication?<div className="student-empty">درخواستی برای این برنامه پیدا نشد.</div>:<section className="student-order"><div className="student-order-icon"><ClipboardCheck/></div><p>پکیج انتخابی</p><h2>{orderApplication.package_name}</h2><div className="student-order-status"><span>وضعیت این درخواست</span><strong>{statusLabels[orderApplication.status]??orderApplication.status}</strong></div><p className="student-order-description">{statusDescriptions[orderApplication.status]}</p><ol>{processSteps.map((label,i)=>{const position=statusPosition[orderApplication.status]??0;return <li key={label} className={`${i<position||orderApplication.status==="delivered"?"done":""} ${i===position?"current":""}`}><span>{i<position||orderApplication.status==="delivered"?<Check/>:i+1}</span>{label}</li>;})}</ol><small className="student-order-updated">آخرین به‌روزرسانی: {new Date(orderApplication.updated_at).toLocaleString("fa-IR")}</small>{orderReceipt&&<div className="student-order-receipt"><div><FileText/><span><strong>رسید پرداخت این دوره</strong><small>برای باز کردن و بزرگ‌نمایی روی تصویر بزن.</small></span></div>{orderReceipt.content_type==="application/pdf"?<a className="student-order-receipt-pdf" href={`/api/application-files/${orderReceipt.id}`} target="_blank" rel="noreferrer"><FileText/> مشاهده رسید PDF <ExternalLink/></a>:<PhotoGallery images={[{src:`/api/application-files/${orderReceipt.id}?v=${orderApplication.updated_at}`,label:"رسید پرداخت",caption:`${orderApplication.package_name} · برنامه شماره ${selectedFile.number.toLocaleString("fa-IR")}`}]} />}</div>}{selectedFile.current&&orderApplication.status==="awaiting_payment"&&<PaymentDetails/>}{selectedFile.current&&(orderApplication.status==="draft"||orderApplication.status==="awaiting_payment")&&<a className="student-order-action" href="/signup">{orderApplication.status==="draft"?"تکمیل درخواست و مدارک":"پرداخت و ارسال رسید"}</a>}{selectedFile.current&&orderApplication.status==="delivered"&&<a className="student-order-action" href="/signup?new=1"><Plus/> درخواست برنامه جدید</a>}</section>}
      </TabsContent>
      </Tabs>
    </section>}
    </StudentArea><StudentArea module="chat"><StudentChat /></StudentArea>
    {selectedFile&&visiblePlan&&<>
      <PlanPrint elementId="student-plan-pdf-training" section="training" client={client} plan={visiblePlan} exercises={selectedFile.exercises}/>
      <PlanPrint elementId="student-plan-pdf-nutrition" section="nutrition" client={client} plan={visiblePlan} exercises={selectedFile.exercises}/>
      <PlanPrint elementId="student-plan-pdf-supplements" section="supplements" client={client} plan={visiblePlan} exercises={selectedFile.exercises}/>
      <PlanPrint elementId="student-plan-pdf-medications" section="medications" client={client} plan={visiblePlan} exercises={selectedFile.exercises}/>
    </>} 
    <Dialog open={Boolean(exercisePreview)} onOpenChange={(open)=>{if(!open)setExercisePreview(null);}}><DialogContent className="max-h-[92dvh] max-w-4xl border-white/10 bg-[color:var(--ph-tone-16_1000)] p-3 sm:p-5" dir="rtl"><DialogHeader><DialogTitle>{exercisePreview?.name}</DialogTitle></DialogHeader>{exercisePreview&&<img src={exercisePreview.src} alt={exercisePreview.name} className="max-h-[78dvh] w-full rounded-2xl bg-white object-contain"/>}</DialogContent></Dialog>
    </div></StudentDashboardShell>;
}

function PhotoComparison({records}:{records:ProgressRecord[]}){
 const withPhotos=records.filter(r=>Object.keys(r.photos).length);if(withPhotos.length<1)return <div className="student-empty">عکس دوره‌ای برای مقایسه ثبت نشده است.</div>;
 const first=withPhotos[0],last=withPhotos[withPhotos.length-1];const poses=["front","side","back","front_double","back_double"];const pose=poses.find(p=>first.photos[p]&&last.photos[p])??poses.find(p=>last.photos[p]);if(!pose)return null;
 const labels:Record<string,string>={front:"روبه‌رو",side:"بغل",back:"پشت",front_double:"جفت بازو جلو",back_double:"جفت بازو پشت"};
 const gallery=withPhotos.flatMap(record=>Object.entries(record.photos).map(([key,src])=>({src,label:labels[key]||key,caption:new Date(record.date).toLocaleDateString("fa-IR")})));
 return <section className="photo-compare"><div className="student-plan-title"><div><p>PHOTO COMPARE</p><h2>مقایسه عکس دوره‌ها</h2></div><Camera/></div><PhotoGallery images={gallery}/><div><figure><img src={first.photos[pose]} alt="عکس شروع دوره"/><figcaption>شروع · {new Date(first.date).toLocaleDateString("fa-IR")}</figcaption></figure><figure><img src={last.photos[pose]} alt="آخرین عکس دوره"/><figcaption>آخرین ثبت · {new Date(last.date).toLocaleDateString("fa-IR")}</figcaption></figure></div></section>;
}
