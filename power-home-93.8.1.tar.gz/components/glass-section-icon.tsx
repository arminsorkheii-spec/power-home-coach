import {GraphicSectionIcon,type GraphicSectionIconName} from "@/components/graphic-section-icon";

export function GlassSectionIcon({name,size=42,className=""}:{name:GraphicSectionIconName;size?:number;className?:string}){
 return <span className={`glass-section-icon ${className}`} style={{width:size,height:size}} aria-hidden="true"><GraphicSectionIcon name={name} size={size}/></span>;
}
