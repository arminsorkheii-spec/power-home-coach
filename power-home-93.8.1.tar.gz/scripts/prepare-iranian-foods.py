"""Transparent example recipes. These are calculated recipes, not laboratory analyses of Iranian dishes."""
import json,sys
from pathlib import Path
root=Path(sys.argv[1]);base=[f for f in json.loads((root/'catalog.json').read_text()) if f['id'].startswith('usda:')];foods={f['fdcId']:f for f in base}
# All ingredient weights in grams; cooked/raw state explicitly retained in the USDA description.
I={'rice':(168878,'برنج سفید پخته'),'chicken':(171477,'سینه مرغ پخته بدون پوست'),'stewbeef':(170831,'گوشت گوساله خام مناسب خورش'),'beef':(171796,'گوشت چرخ‌کرده خام ۱۵٪ چربی'),'lentil':(172421,'عدس پخته'),'bean':(173740,'لوبیا قرمز پخته'),'spinach':(168462,'اسفناج خام'),'oil':(171413,'روغن زیتون'),'onion':(170000,'پیاز خام'),'tomato':(170457,'گوجه‌فرنگی خام'),'paste':(170459,'رب گوجه بدون نمک'),'egg':(171287,'تخم‌مرغ کامل خام'),'walnut':(170187,'گردوی خام'),'barley':(170285,'جو پوست‌کنده پخته'),'yogurt':(171284,'ماست ساده پرچرب'),'eggplant':(169228,'بادمجان خام'),'chickpea':(173757,'نخود پخته'),'parsley':(170416,'جعفری تازه'),'dill':(172233,'شوید تازه'),'potato':(170438,'سیب‌زمینی آبپز'),'greenbean':(169141,'لوبیا سبز پخته'),'fava':(173753,'باقلا پخته'),'splitpea':(172429,'لپه پخته'),'pomegranate':(167787,'آب انار بطری‌شده؛ جایگزین نمونه رب انار'),'lime':(168156,'آب لیموترش'),'pasta':(169737,'پاستای پخته'),'flour':(168893,'آرد گندم کامل'),'raisin':(168165,'کشمش تیره'),'sugar':(169655,'شکر'),'milk':(172217,'شیر کامل'),'butter':(173430,'کره بدون نمک')}
recipes=[
('ghormeh','قورمه‌سبزی؛ دستور نمونه',1500,{'beef':300,'bean':350,'parsley':250,'spinach':250,'onion':150,'oil':40,'lime':30}),
('gheymeh','خورش قیمه؛ دستور نمونه',1500,{'beef':300,'splitpea':350,'paste':100,'onion':150,'potato':250,'oil':40,'lime':20}),
('fesenjan','فسنجان با مرغ؛ دستور نمونه با آب انار',1400,{'chicken':400,'walnut':200,'pomegranate':400,'onion':150,'sugar':30,'oil':10}),
('adaspolo','عدس‌پلو؛ دستور نمونه',1200,{'rice':700,'lentil':300,'raisin':80,'onion':100,'oil':25}),
('loobiapolo','لوبیاپلو؛ دستور نمونه',1400,{'rice':700,'greenbean':350,'beef':200,'paste':80,'onion':100,'oil':30}),
('baghalipolo','باقالی‌پلو؛ دستور نمونه بدون گوشت',1250,{'rice':800,'fava':300,'dill':80,'oil':25}),
('zereshk','چلو مرغ زعفرانی؛ نمونه بدون زرشک و زعفران',1300,{'rice':800,'chicken':350,'onion':100,'oil':25}),
('koobideh','کباب کوبیده؛ دستور نمونه',850,{'beef':1000,'onion':200}),
('joojeh','جوجه‌کباب سینه؛ نمونه وزن پخته',900,{'chicken':800,'yogurt':100,'onion':100,'lime':50,'oil':20}),
('ash','آش رشته؛ نمونه با پاستا و بدون کشک',2400,{'pasta':400,'bean':300,'chickpea':300,'lentil':300,'spinach':300,'parsley':200,'onion':200,'oil':30}),
('abgoosht','آبگوشت؛ نمونه با گوشت چرخ‌کرده',2200,{'beef':500,'chickpea':400,'bean':300,'potato':400,'tomato':300,'onion':200,'paste':70}),
('kookoosabzi','کوکوسبزی؛ دستور نمونه جعفری و اسفناج',750,{'egg':300,'parsley':250,'spinach':250,'dill':100,'oil':40}),
('kookoosib','کوکو سیب‌زمینی؛ دستور نمونه',1000,{'potato':800,'egg':200,'onion':100,'oil':40}),
('kotlet','کتلت گوشت و سیب‌زمینی؛ دستور نمونه',1250,{'beef':400,'potato':600,'egg':100,'onion':150,'oil':60}),
('omelet','املت گوجه؛ دستور نمونه',700,{'egg':300,'tomato':450,'oil':20}),
('mirza','میرزاقاسمی؛ نمونه بدون سیر',1000,{'eggplant':700,'tomato':300,'egg':200,'oil':35}),
('bademjan','خوراک بادمجان و ماست؛ نمونه جایگزین کشک بادمجان',1000,{'eggplant':800,'yogurt':200,'onion':150,'walnut':30,'oil':40}),
('shirazi','سالاد شیرازی؛ نمونه بدون خیار',800,{'tomato':600,'onion':150,'lime':50}),
('tahchin','ته‌چین مرغ؛ دستور نمونه',1500,{'rice':850,'chicken':300,'yogurt':200,'egg':150,'oil':50}),
('khoreshtbademjan','خورش بادمجان؛ دستور نمونه',1700,{'eggplant':700,'beef':300,'tomato':300,'paste':80,'onion':150,'oil':45}),
('hلیم','حلیم گندم با مرغ؛ دستور نمونه',1700,{'flour':250,'chicken':350,'butter':30,'sugar':40}),
('sholezard','شله‌زرد؛ نمونه برنج و شکر بدون زعفران',1700,{'rice':600,'sugar':250,'butter':30}),
('souppo','سوپ جو با شیر؛ دستور نمونه',2000,{'barley':600,'milk':600,'chicken':200,'onion':100,'butter':20}),
('esfenaj','نرگسی اسفناج؛ دستور نمونه',1000,{'spinach':1000,'egg':300,'onion':150,'oil':25}),
('dampokht','دمپختک با باقلا؛ دستور نمونه',1200,{'rice':800,'fava':350,'onion':150,'oil':30}),
('makaroni','ماکارونی ایرانی با گوشت؛ دستور نمونه',1700,{'pasta':1000,'beef':300,'paste':100,'onion':150,'oil':35}),
('adasi','عدسی؛ دستور نمونه',1500,{'lentil':1000,'onion':150,'paste':60,'oil':25}),
('khorakloobia','خوراک لوبیا قرمز؛ دستور نمونه',1600,{'bean':1000,'potato':300,'onion':100,'paste':80,'oil':25}),
('khorakmorgh','خوراک مرغ و سیب‌زمینی؛ دستور نمونه',1300,{'chicken':500,'potato':600,'onion':150,'paste':60,'oil':25}),
('nan','نان گندم خانگی؛ دستور نمونه بدون تخمیر',800,{'flour':600,'oil':15}),
]
# Replace clearly named approximations with correct ingredient coverage where the USDA has the exact basic ingredient.
for f in base:
 if f['description']=='Cucumber, with peel, raw':I['cucumber']=(f['fdcId'],'خیار خام با پوست')
 if f['description']=='Garlic, raw':I['garlic']=(f['fdcId'],'سیر خام')
 if f['description']=='Spices, saffron':I['saffron']=(f['fdcId'],'زعفران')
 if f['description']=='Spices, turmeric, ground':I['turmeric']=(f['fdcId'],'زردچوبه')
for index,(slug,name,yieldg,parts) in enumerate(recipes):
 if slug in ['ghormeh','gheymeh','abgoosht','khoreshtbademjan']:
  parts['stewbeef']=parts.pop('beef')
  if slug=='abgoosht':name='آبگوشت با گوشت گوساله؛ دستور نمونه'
 if slug=='shirazi':name='سالاد شیرازی؛ دستور نمونه';parts={'tomato':300,'cucumber':350,'onion':100,'lime':50}
 if slug=='mirza':name='میرزاقاسمی؛ دستور نمونه';parts['garlic']=15
 if slug in ['zereshk','sholezard','tahchin','joojeh']:parts['saffron']=.2
 if slug=='zereshk':name='چلو مرغ زعفرانی؛ نمونه بدون زرشک'
 if slug=='sholezard':name='شله‌زرد؛ دستور نمونه'
 rows=[];total={k:0 for k in ['calories','protein','carbs','fat']}
 for key,g in parts.items():
  id,label=I[key];food=foods[id];rows.append({'foodId':food['id'],'name':label,'grams':g})
  for k in total:total[k]+=food[k]*g/100
 recipe={'yieldGrams':yieldg,'ingredients':rows,'note':'دستور نمونه محاسباتی؛ وزن نهایی فرض شده است. آب و تغییر وزن پخت در وزن نهایی لحاظ می‌شود. روغن به میزان واردشده مصرف‌شده فرض شده است. ارزش واقعی با دستور، برند و دورریز فرق می‌کند.'}
 base.append({'id':'iran:'+slug,'name':name,'description':name,'category':'غذاهای ایرانی — دستور نمونه','state':'cooked' if slug!='shirazi' else 'raw','aliases':'ایرانی سنتی خانگی '+name,'source':'محاسبه دستور نمونه از مواد USDA؛ آزمایش غذایی نیست',**{k:round(v/yieldg*100,4) for k,v in total.items()},'portions':[],'recipe':recipe})
(root/'catalog.json').write_text(json.dumps(base,ensure_ascii=False,separators=(',',':')))
with (root/'SOURCE.md').open('a') as out:out.write('\n30 transparent example Iranian recipes added. Not lab measurements. Ingredient USDA IDs, gram weights and assumed final cooked yields are included. Recipe variants and substitutions are explicit in dish names; coaches must adjust for their actual recipe. No generic cup or serving weights have been fabricated.\n')
print('Iranian recipes',len(recipes),'total',len(base))
