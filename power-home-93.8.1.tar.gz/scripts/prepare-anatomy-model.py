#!/usr/bin/env python3
"""Pack the CC BY-SA 4.0 Ecorche model into WebGL-1 indexed batches.
Input: original model/ecorche.glb from https://github.com/Charleeh/ecorche
Only geometry packing and training-region metadata change. Vertex anatomy,
colours and normals are retained. Requires numpy during preparation only.
"""
import sys,json,struct,hashlib,re
from pathlib import Path
import numpy as np
source=Path(sys.argv[1]);destination=Path(sys.argv[2]);destination.mkdir(parents=True,exist_ok=True)
data=source.read_bytes();assert data[:4]==b'glTF'
length,kind=struct.unpack_from('<II',data,12);assert kind==0x4e4f534a
g=json.loads(data[20:20+length]);offset=20+length;binary_length,binary_kind=struct.unpack_from('<II',data,offset);assert binary_kind==0x004e4942
binary=data[offset+8:offset+8+binary_length]
dtypes={5120:np.dtype('i1'),5121:np.dtype('u1'),5122:np.dtype('<i2'),5123:np.dtype('<u2')};components={'SCALAR':1,'VEC3':3,'VEC4':4}
def attribute(index):
 a=g['accessors'][index];v=g['bufferViews'][a['bufferView']];dt=dtypes[a['componentType']];dim=components[a['type']]
 return np.ndarray((a['count'],dim),dtype=dt,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',dim*dt.itemsize),dt.itemsize)).copy()
def region(name,layer):
 if layer=='skeleton':return None
 name=name.lower()
 patterns=[('hamstrings',r'biceps femoris|semitendinosus|semimembranosus'),('chest',r'pectoralis'),('traps',r'trapezius'),('back',r'latissimus|rhomboid|teres major'),('lowerback',r'erector spinae|iliocostalis|longissimus|spinalis|multifidus|quadratus lumborum|rotatores|thoracolumbar fascia'),('core',r'abdominis|oblique|serratus anterior|psoas|iliacus'),('quads',r'vastus|rectus femoris|sartorius'),('adductors',r'adductor.*(?:magnus|longus|brevis|minimus)|gracilis|pectineus'),('glutes',r'gluteus|tensor fascia'),('calves',r'gastrocnemius|soleus|tibialis|fibularis|peroneus|plantaris|popliteus|extensor digitorum longus|flexor digitorum longus|hallucis longus'),('shoulders',r'deltoid|supraspinatus|infraspinatus|teres minor|subscapularis'),('triceps',r'triceps brachii|anconeus'),('biceps',r'biceps brachii|brachialis|coracobrachialis'),('forearms',r'brachioradialis|pronator|supinator|carpi|palmaris|extensor digitorum$|flexor digitorum (?:superficialis|profundus)|pollicis longus|pollicis brevis')]
 # Names can contain a side between an anatomical term's words.
 name=re.sub(r'\b(?:left|right|head of|muscle)\b','',name);name=re.sub(r'\s+',' ',name).strip()
 for key,pattern in patterns:
  if re.search(pattern,name):return key
 return None
buckets={};structures=[];all_positions=[]
for node in g['nodes']:
 if 'mesh' not in node:continue
 assert not any(k in node for k in ['matrix','translation','rotation','scale'])
 extra=node.get('extras',{});name=extra.get('name',node.get('name',''));layer=extra.get('layer','');group=region(name,layer)
 for primitive in g['meshes'][node['mesh']]['primitives']:
  p=attribute(primitive['attributes']['POSITION']);n=attribute(primitive['attributes']['NORMAL']);c=attribute(primitive['attributes']['COLOR_0']);indices=attribute(primitive['indices']).ravel()
  assert len(p)==len(n)==len(c) and indices.max()<len(p)
  all_positions.append(p)
  chunks=buckets.setdefault(group,[])
  if not chunks or chunks[-1]['vertices']+len(p)>60000:chunks.append({'positions':[],'normals':[],'colors':[],'indices':[],'vertices':0})
  chunk=chunks[-1];chunk['positions'].append(p);chunk['normals'].append(n);chunk['colors'].append(c);chunk['indices'].append(indices.astype('u4')+chunk['vertices']);chunk['vertices']+=len(p)
 structures.append({'name':name,'layer':layer,'side':extra.get('side'),'group':group})
output=bytearray();parts=[]
def pack(array):
 while len(output)%4:output.append(0)
 start=len(output);raw=array.tobytes();output.extend(raw);return {'offset':start,'length':len(raw)}
for group,chunks in buckets.items():
 for chunk in chunks:
  positions=np.concatenate(chunk['positions']);normals=np.concatenate(chunk['normals']);colors=np.concatenate(chunk['colors']);indices=np.concatenate(chunk['indices']).astype('<u2')
  parts.append({'group':group,'vertexCount':len(positions),'indexCount':len(indices),'positions':pack(positions),'normals':pack(normals),'colors':pack(colors),'indices':pack(indices)})
points=np.concatenate(all_positions);minimum=points.min(axis=0).tolist();maximum=points.max(axis=0).tolist()
manifest={'version':1,'license':'CC-BY-SA-4.0','source':'https://github.com/Charleeh/ecorche','sourceSha256':hashlib.sha256(data).hexdigest(),'binarySha256':hashlib.sha256(output).hexdigest(),'binaryBytes':len(output),'quantization':.0001,'bounds':{'min':minimum,'max':maximum},'parts':parts,'structures':structures,'triangles':sum(p['indexCount']//3 for p in parts)}
(destination/'body-v1.bin').write_bytes(output);(destination/'body-v1.json').write_text(json.dumps(manifest,separators=(',',':')))
print('batches',len(parts),'vertices',len(points),'triangles',manifest['triangles'],'bytes',len(output),'regions',sorted(k for k in buckets if k))
