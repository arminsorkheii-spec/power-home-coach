#!/usr/bin/env bash
set -euo pipefail
cd /opt/power-home-coach
# Secret remains inside the app container; no credential is printed or put in arguments.
docker compose exec -T app node --input-type=module - <<'JS'
const secret=process.env.APP_CRON_SECRET;
if(!secret||secret.length<32)throw Error('APP_CRON_SECRET must contain at least 32 characters');
const response=await fetch('http://127.0.0.1:3000/api/cron/renewal-reminders',{method:'POST',headers:{authorization:'Bearer '+secret},signal:AbortSignal.timeout(240000)});
if(!response.ok)throw Error('Reminder job failed: '+response.status);
console.log(await response.text());
JS
