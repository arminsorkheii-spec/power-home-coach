import {runLifeReminders,runBillingReminders} from '@/lib/life-reminders';
import {timingSafeEqual} from 'node:crypto';
import {runRenewalReminders} from '@/lib/program-renewal';
export async function POST(request:Request){const secret=process.env.APP_CRON_SECRET,header=request.headers.get('authorization')??'',expected='Bearer '+secret;if(!secret||secret.length<32||header.length!==expected.length||!timingSafeEqual(Buffer.from(header),Buffer.from(expected)))return new Response(null,{status:403});return Response.json({...await runRenewalReminders(),lifeReminders:await runLifeReminders(),billingReminders:await runBillingReminders()},{headers:{'cache-control':'no-store'}})}
