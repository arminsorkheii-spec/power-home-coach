import {googleConfigured} from '@/lib/google-auth';
import {studentIdFromRequest} from '@/lib/student-auth';
import {database} from '@/lib/raw-db';
export async function GET(request:Request){const clientId=await studentIdFromRequest(request);const linked=clientId?database().prepare('SELECT email FROM student_google_accounts WHERE client_id=?').bind(clientId).first<{email:string}>():null;return Response.json({configured:googleConfigured(),linked:Boolean(linked),email:linked?.email??null},{headers:{'cache-control':'no-store'}})}
