import { z } from "zod";
import { sameOrigin } from "@/lib/raw-db";
import { normalizeDigits } from "@/lib/student-auth";
import { OtpError, requestIp, requestStudentCode } from "@/lib/student-otp";
export async function POST(request:Request){
  if(!sameOrigin(request))return new Response(null,{status:403});
  try{
    const body=z.object({phone:z.string().max(30)}).strict().parse(await request.json());
    return Response.json(await requestStudentCode(body.phone,requestIp(request),"registration"),{headers:{"cache-control":"no-store"}});
  }catch(e){
    const error=e instanceof OtpError?e:new OtpError("درخواست تأیید شماره معتبر نیست.");
    return Response.json({error:error.message,retryAfter:error.retryAfter},{status:error.status,headers:{"cache-control":"no-store",...(error.retryAfter?{"retry-after":String(error.retryAfter)}:{})}});
  }
}
