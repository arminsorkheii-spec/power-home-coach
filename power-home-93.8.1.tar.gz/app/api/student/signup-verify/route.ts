import { z } from "zod";
import { sameOrigin } from "@/lib/raw-db";
import { normalizeDigits } from "@/lib/student-auth";
import { OtpError, requestIp, verifyRegistrationCode } from "@/lib/student-otp";
export async function POST(request:Request){
  if(!sameOrigin(request))return new Response(null,{status:403});
  try{
    const body=z.object({phone:z.string().max(30),challengeId:z.string().max(80),code:z.string().max(12)}).strict().parse(await request.json());
    return Response.json(verifyRegistrationCode(body.phone,body.challengeId,normalizeDigits(body.code),requestIp(request)),{headers:{"cache-control":"no-store"}});
  }catch(e){
    const error=e instanceof OtpError?e:new OtpError("درخواست تأیید شماره معتبر نیست.");
    return Response.json({error:error.message,retryAfter:error.retryAfter},{status:error.status,headers:{"cache-control":"no-store",...(error.retryAfter?{"retry-after":String(error.retryAfter)}:{})}});
  }
}
