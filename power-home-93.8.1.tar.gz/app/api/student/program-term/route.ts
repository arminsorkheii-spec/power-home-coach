import {database} from '@/lib/raw-db';
import {studentIdFromRequest} from '@/lib/student-auth';
import {termSummary,type Term} from '@/lib/coaching-tracking';
export async function GET(request:Request){const clientId=await studentIdFromRequest(request);if(!clientId)return new Response(null,{status:401});const row=database().prepare('SELECT * FROM program_terms WHERE client_id=? AND active=1 ORDER BY started_at DESC LIMIT 1').bind(clientId).first<Term>();return Response.json({term:row?termSummary(row):null},{headers:{'cache-control':'no-store'}})}
