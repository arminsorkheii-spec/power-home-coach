import { notificationTarget, type NoticeTarget } from "@/lib/notification-target";
import { z } from "zod";
import { database, sameOrigin } from "@/lib/raw-db";
import { requestHasValidSession } from "@/lib/password-auth";
import { studentIdFromRequest } from "@/lib/student-auth";

async function identity(request:Request){
  const requested=request.headers.get("x-portal-role");
  if(requested==="student"){const clientId=await studentIdFromRequest(request);return clientId?{role:"student" as const,clientId}:null;}
  if(requested==="coach")return (await requestHasValidSession(request))?{role:"coach" as const,clientId:null}:null;
  const clientId=await studentIdFromRequest(request);if(clientId)return {role:"student" as const,clientId};
  if(await requestHasValidSession(request))return {role:"coach" as const,clientId:null};
  return null;
}

export async function GET(request:Request){
  const owner=await identity(request);if(!owner)return new Response(null,{status:401});
  const db=database();
  const rows=owner.role==="coach"
    ? await db.prepare("SELECT * FROM notification_events WHERE recipient_role='coach' ORDER BY created_at DESC LIMIT 100").all()
    : await db.prepare("SELECT * FROM notification_events WHERE recipient_role='student' AND recipient_client_id=? ORDER BY created_at DESC LIMIT 100").bind(owner.clientId).all();
  const unread=owner.role==="coach"?db.prepare("SELECT count(*) AS n FROM notification_events WHERE recipient_role='coach' AND read_at IS NULL").first<{n:number}>()!.n:db.prepare("SELECT count(*) AS n FROM notification_events WHERE recipient_role='student' AND recipient_client_id=? AND read_at IS NULL").bind(owner.clientId).first<{n:number}>()!.n;
  return Response.json({notifications:(rows.results as (NoticeTarget&Record<string,unknown>)[]).map(item=>({...item,url:notificationTarget(owner.role,item)})),unread},{headers:{"cache-control":"no-store"}});
}

export async function PATCH(request:Request){
  if(!sameOrigin(request))return new Response(null,{status:403});
  const owner=await identity(request);if(!owner)return new Response(null,{status:401});
  try{
    const body=z.object({all:z.boolean().optional(),ids:z.array(z.string().uuid()).max(100).optional()}).parse(await request.json());
    const now=new Date().toISOString();const db=database();
    if(body.all){
      if(owner.role==="coach")await db.prepare("UPDATE notification_events SET read_at=? WHERE recipient_role='coach' AND read_at IS NULL").bind(now).run();
      else await db.prepare("UPDATE notification_events SET read_at=? WHERE recipient_role='student' AND recipient_client_id=? AND read_at IS NULL").bind(now,owner.clientId).run();
    } else if(body.ids?.length){
      for(const id of body.ids){
        if(owner.role==="coach")await db.prepare("UPDATE notification_events SET read_at=? WHERE id=? AND recipient_role='coach'").bind(now,id).run();
        else await db.prepare("UPDATE notification_events SET read_at=? WHERE id=? AND recipient_role='student' AND recipient_client_id=?").bind(now,id,owner.clientId).run();
      }
    }
    const unread=owner.role==="coach"?db.prepare("SELECT count(*) AS n FROM notification_events WHERE recipient_role='coach' AND read_at IS NULL").first<{n:number}>()!.n:db.prepare("SELECT count(*) AS n FROM notification_events WHERE recipient_role='student' AND recipient_client_id=? AND read_at IS NULL").bind(owner.clientId).first<{n:number}>()!.n;
    return Response.json({ok:true,unread});
  }catch{return Response.json({error:"به‌روزرسانی اعلان‌ها انجام نشد."},{status:400});}
}
