import {cookieFrom,GOOGLE_SIGNUP_COOKIE,pendingGoogleSignup,googleConfigured,authCookie} from "@/lib/google-auth";
import { randomBytes } from "node:crypto";
import { smsLoginEnabled } from "@/lib/sms";
import { registrationProofHash } from "@/lib/student-otp";
import { z } from "zod";
import { blankPlan, DEFAULT_STATE, type CoachState } from "@/lib/coach-data";
import { coachDataKey } from "@/lib/password-auth";
import { quotePackages, PackageSelectionError } from "@/lib/package-pricing";
import { database, sameOrigin } from "@/lib/raw-db";
import { createStudentSession, deriveStudentPassword, normalizeDigits, normalizePhone, studentSessionCookie } from "@/lib/student-auth";
import { createNotification } from "@/lib/notifications";

const schema = z.object({
  authMethod:z.enum(["phone","google"]).optional(),
  name: z.string().trim().min(2).max(80),
  phone: z.string().max(30),
  password: z.string().min(1).max(20).optional(),
  registrationToken:z.string().min(40).max(100).optional(),
  packageId: z.string().max(40).optional(),
  packageIds: z.array(z.string().max(40)).min(1).max(7).optional(),
});

export async function POST(request: Request) {
  if (!sameOrigin(request)) return new Response(null, { status: 403 });
  try {
    const data = schema.parse(await request.json());
    const useGoogle=data.authMethod==="google";
    const googleProof=useGoogle&&googleConfigured()?pendingGoogleSignup(cookieFrom(request,GOOGLE_SIGNUP_COOKIE)):null;
    if(useGoogle&&!googleProof)return Response.json({error:"تأیید گوگل منقضی شده؛ دوباره ورود با گوگل را بزنید."},{status:401});
    const phone = googleProof?"google:"+googleProof.subject:normalizePhone(data.phone);
    const smsMode=!useGoogle&&smsLoginEnabled();
    const password = (smsMode||useGoogle)?randomBytes(32).toString("hex"):normalizeDigits(data.password??"").replace(/\D/g, "");
    const selectedPackage = quotePackages(data.packageIds ?? (data.packageId ? [data.packageId] : []));
    if ((!useGoogle&&!/^09\d{9}$/.test(phone)) || (!useGoogle&&!smsMode&&!/^\d{6}$/.test(password)) || !selectedPackage) return Response.json({ error: smsMode?"شماره موبایل یا خدمات انتخاب‌شده معتبر نیست.":"شماره موبایل، رمز ۶ رقمی یا پکیج معتبر نیست." }, { status: 400 });
    const db = database();
    const previous = await db.prepare("SELECT client_id FROM student_accounts WHERE phone=?").bind(phone).first<{ client_id: string }>();
    if (previous) return Response.json({ error: "این شماره قبلاً ثبت شده؛ از صفحه ورود شاگرد وارد شوید." }, { status: 409 });

    if(googleProof&&db.prepare("SELECT subject FROM student_google_accounts WHERE subject=?").bind(googleProof.subject).first())return Response.json({error:"این حساب گوگل قبلاً ثبت شده؛ از صفحه ورود شاگرد وارد شوید."},{status:409});
    const proofHash=smsMode&&data.registrationToken?registrationProofHash(data.registrationToken):"";
    if(smsMode&&!db.prepare("SELECT phone FROM student_registration_proofs WHERE token_hash=? AND phone=? AND expires_at>?").bind(proofHash,phone,Date.now()).first())return Response.json({error:"ابتدا شماره موبایل را با کد پیامکی تأیید کنید.",verificationRequired:true},{status:401});
    const clientId = crypto.randomUUID();
    const applicationId = crypto.randomUUID();
    const salt = crypto.randomUUID();
    const revision = crypto.randomUUID();
    const passwordHash = await deriveStudentPassword(password, salt);
    const now = new Date().toISOString();
    const stateRow = await db.prepare("SELECT payload FROM coach_states WHERE owner_email=?").bind(coachDataKey()).first<{ payload: string }>();
    const state = stateRow ? JSON.parse(stateRow.payload) as CoachState : JSON.parse(JSON.stringify(DEFAULT_STATE)) as CoachState;
    state.clients.push({ id: clientId, name: data.name, phone:useGoogle?"":phone, ...(googleProof?{email:googleProof.email}:{}), goal: selectedPackage.name, notes: "ثبت‌نام آنلاین؛ فرم اولیه در بخش درخواست‌ها" });
    state.plans[clientId] = blankPlan();
    state.syncRevision = Math.max(Date.now(), Number(state.syncRevision ?? 0) + 1);

    if(smsMode&&!db.prepare("SELECT phone FROM student_registration_proofs WHERE token_hash=? AND phone=? AND expires_at>?").bind(proofHash,phone,Date.now()).first())return Response.json({error:"تأیید شماره منقضی یا استفاده شده است؛ دوباره کد بگیرید.",verificationRequired:true},{status:401});
    if(googleProof&&!pendingGoogleSignup(cookieFrom(request,GOOGLE_SIGNUP_COOKIE)))return Response.json({error:"تأیید گوگل استفاده یا منقضی شده است."},{status:401});
    await db.batch([
      googleProof?db.prepare("INSERT INTO student_accounts (client_id,phone,password_hash,salt,revision,created_at,updated_at) SELECT ?,?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM google_registration_proofs WHERE token_hash=? AND expires_at>?)").bind(clientId,phone,passwordHash,salt,revision,now,now,googleProof.token_hash,Date.now()):smsMode?db.prepare("INSERT INTO student_accounts (client_id,phone,password_hash,salt,revision,created_at,updated_at) SELECT ?,?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM student_registration_proofs WHERE token_hash=? AND phone=? AND expires_at>?)").bind(clientId,phone,passwordHash,salt,revision,now,now,proofHash,phone,Date.now()):db.prepare("INSERT INTO student_accounts (client_id,phone,password_hash,salt,revision,created_at,updated_at) VALUES (?,?,?,?,?,?,?)").bind(clientId, phone, passwordHash, salt, revision, now, now),
      db.prepare("INSERT INTO applications (id,client_id,package_id,package_name,status,price_amount,profile_json,created_at,updated_at,package_items_json) VALUES (?,?,?,?,?,?,?,?,?,?)").bind(applicationId, clientId, selectedPackage.id, selectedPackage.name, "draft", selectedPackage.price, JSON.stringify({ name: data.name }), now, now, JSON.stringify(selectedPackage.items)),
      ...(googleProof?[db.prepare("INSERT INTO student_google_accounts(subject,client_id,email,linked_at) VALUES(?,?,?,?)").bind(googleProof.subject,clientId,googleProof.email,now),db.prepare("DELETE FROM google_registration_proofs WHERE token_hash=?").bind(googleProof.token_hash)]:[]),
      ...(smsMode?[db.prepare("DELETE FROM student_registration_proofs WHERE token_hash=? AND phone=?").bind(proofHash,phone)]:[]),
    ]);
    try {
      await db.prepare("INSERT INTO coach_states (owner_email,payload,updated_at) VALUES (?,?,?) ON CONFLICT(owner_email) DO UPDATE SET payload=excluded.payload, updated_at=excluded.updated_at").bind(coachDataKey(), JSON.stringify(state), now).run();
    } catch (stateError) {
      console.error("student_registration_state_sync_failed", stateError);
    }
    await createNotification({role:"coach",actorClientId:clientId,applicationId,type:"registration",title:"ثبت‌نام جدید",body:`${data.name} ثبت‌نام کرد و ${selectedPackage.name} را انتخاب کرد.`,url:"/coach",tag:`register-${applicationId}`});
    await createNotification({role:"student",clientId,applicationId,type:"welcome",title:"خوش آمدی",body:"ثبت‌نامت با موفقیت انجام شد.",url:"/student",tag:`welcome-${applicationId}`});
    const token = await createStudentSession(clientId, revision);
    const headers=new Headers({"set-cookie":studentSessionCookie(token),"cache-control":"no-store"});
    if(useGoogle)headers.append("set-cookie",authCookie(GOOGLE_SIGNUP_COOKIE,"",0));
    return Response.json({ ok: true, applicationId, priceAmount: selectedPackage.price }, {headers});
  } catch (error) {
    if(error instanceof PackageSelectionError)return Response.json({error:error.message},{status:400});
    console.error("student_registration_failed", error);
    const message = error instanceof z.ZodError ? "نام، شماره موبایل و اطلاعات ورود یا تأیید شماره را درست وارد کنید." : "ثبت‌نام انجام نشد؛ دوباره تلاش کنید.";
    return Response.json({ error: message }, { status: error instanceof z.ZodError ? 400 : 500 });
  }
}
