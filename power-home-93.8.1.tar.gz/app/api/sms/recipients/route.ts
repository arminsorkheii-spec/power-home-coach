import { coachDataKey, requestHasValidSession } from "@/lib/password-auth";
import { database } from "@/lib/raw-db";
export async function GET(request:Request){
  if(!await requestHasValidSession(request))return new Response(null,{status:401});
  const db=database();
  const state=db.prepare("SELECT payload FROM coach_states WHERE owner_email=?").bind(coachDataKey()).first<{payload:string}>();
  const clients=state?(JSON.parse(state.payload) as {clients?:{id:string;name:string}[]}).clients??[]:[];
  const names=new Map(clients.map(c=>[c.id,c.name]));
  const rows=db.prepare("SELECT client_id,phone FROM student_accounts ORDER BY created_at").all<{client_id:string;phone:string}>().results;
  return Response.json({recipients:rows.filter(r=>/^09\d{9}$/.test(r.phone)).map(r=>({id:r.client_id,name:names.get(r.client_id)??"شاگرد",phone:r.phone.slice(0,4)+"***"+r.phone.slice(-4)}))},{headers:{"cache-control":"no-store"}});
}
