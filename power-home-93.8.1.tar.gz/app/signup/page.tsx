import {cookies} from "next/headers";
import {GOOGLE_SIGNUP_COOKIE,pendingGoogleSignup} from "@/lib/google-auth";
import { smsLoginEnabled } from "@/lib/sms";
import { RegistrationFlow } from "@/components/registration-flow";
import { getPackages } from "@/lib/package-pricing";
import { packageById } from "@/lib/packages";

export const dynamic = "force-dynamic";

export default async function SignupPage({ searchParams }: { searchParams: Promise<{ package?: string; new?: string; addon?:string;google?:string }> }) {
  const query = await searchParams;
  const store=await cookies(),google=query.google==="1"?pendingGoogleSignup(store.get(GOOGLE_SIGNUP_COOKIE)?.value??""):null;
  return <RegistrationFlow initialGoogleProfile={google?{name:google.name,email:google.email}:undefined} initialSmsEnabled={smsLoginEnabled()} initialPackages={getPackages()} initialPackage={packageById(query.package ?? "")?.id ?? "natural"} newRequest={query.new === "1"||query.addon === "1"} addon={query.addon === "1"} />;
}
