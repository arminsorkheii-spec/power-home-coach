import test,{after} from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'vite';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
const vite=await createServer({configFile:false,appType:'custom',resolve:{alias:{'@':new URL('..',import.meta.url).pathname}},esbuild:{jsx:'automatic'},server:{middlewareMode:true,hmr:false}});
after(()=>vite.close());
const {PlanNutritionChart}=await vite.ssrLoadModule('/components/plan-nutrition-chart.tsx');
const {foodDisplayDetail}=await vite.ssrLoadModule('/lib/food-display.ts');
const render=meals=>renderToStaticMarkup(React.createElement(PlanNutritionChart,{meals}));
const item={id:'r',foodId:'rice',name:'برنج پخته',description:'Cooked rice',grams:200,source:'fixture',per100:{calories:130,protein:3,carbs:28,fat:1}};
test('food labels expose only preparation state regardless of reference detail',()=>{
 assert.equal(foodDisplayDetail({state:'cooked',description:'Chicken breast, boneless, roasted',category:'گوشت',recipe:{}}),'پخته');
 assert.equal(foodDisplayDetail({state:'raw',description:'skinless, without salt'}),'خام');
 assert.equal(foodDisplayDetail({description:'Long grain rice',category:'غلات',recipe:{}}),'');
});
test('shared plan chart scales saved gram amounts and preserves source snapshots',()=>{
 const copy=structuredClone(item),html=render([{foods:'',foodItems:[item]}]);
 assert.match(html,/۲۶۰/);assert.match(html,/۵۶/);assert.match(html,/۶/);assert.match(html,/۲/);assert.match(html,/<svg/);
 assert.equal((html.match(/stroke-dasharray=/g)||[]).length,3);assert.doesNotMatch(html,/Cooked rice/);assert.deepEqual(item,copy);
});
test('text-only and mixed plans cannot imply that uncalculated foods are included',()=>{
 assert.match(render([{foods:'غذای متنی'}]),/باید از بانک غذا انتخاب شوند/);
 assert.doesNotMatch(render([{foods:'غذای متنی'}]),/<svg/);
 assert.match(render([{foods:'سالاد متنی',foodItems:[item]}]),/غذاهای متنی در این جمع محاسبه نشده‌اند/);
 const zero={...item,per100:{calories:0,protein:0,carbs:0,fat:0}};
 assert.doesNotMatch(render([{foods:'',foodItems:[zero]}]),/NaN|Infinity/);
});
