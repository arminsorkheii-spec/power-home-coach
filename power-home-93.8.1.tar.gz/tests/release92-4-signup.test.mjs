import React from "react";
import {renderToStaticMarkup} from "react-dom/server";
import assert from 'node:assert/strict';
import test,{after} from 'node:test';
import {mkdtempSync} from 'node:fs';import {tmpdir} from 'node:os';import path from 'node:path';import {fileURLToPath} from 'node:url';import {createServer} from 'vite';
const root=fileURLToPath(new URL('..',import.meta.url));process.env.APP_DATA_DIR=mkdtempSync(path.join(tmpdir(),'r924-'));process.env.APP_SESSION_SECRET='r924-fixture-session';
const vite=await createServer({appType:'custom',configFile:false,root,resolve:{alias:{'@':root}},server:{middlewareMode:true,hmr:false}});const originalFetch=global.fetch;after(async()=>{global.fetch=originalFetch;await vite.close()});
const load=p=>vite.ssrLoadModule(p);const {database}=await load('/lib/raw-db.ts'),db=database();const sms=await load('/lib/sms.ts'),otp=await load('/lib/student-otp.ts');
const send=await load('/app/api/student/signup-code/route.ts'),verify=await load('/app/api/student/signup-verify/route.ts'),register=await load('/app/api/register/route.ts'),login=await load('/app/api/student/login/route.ts');
const req=(route,body,origin='https://coach.test')=>new Request('https://coach.test'+route,{method:'POST',headers:{host:'coach.test',origin,'content-type':'application/json'},body:JSON.stringify(body)});
let sent=[];global.fetch=async(url,options)=>{assert.equal(String(url),'https://api.sms.ir/v1/send/verify/');const body=JSON.parse(options.body);sent.push(body);return Response.json({status:1,data:{messageId:1}})};
const config={apiKey:'mock-r924-key',loginEnabled:true,notificationsEnabled:false,otpTemplateId:101,otpParameter:'CODE',notificationTemplateId:0,notificationParameter:'EVENT',coachPhone:'',lineNumber:''};
sms.saveSmsSettings(sms.smsSettingsSchema.parse(config));
const accountCount=()=>db.prepare('SELECT count(*) AS n FROM student_accounts').first().n;
async function challenge(phone){const response=await send.POST(req('/api/student/signup-code',{phone}));assert.equal(response.status,200);return {phone,...await response.json(),code:sent.at(-1).parameters[0].value}}
async function proof(phone){const c=await challenge(phone);const response=await verify.POST(req('/api/student/signup-verify',c));assert.equal(response.status,400); // strict request schema rejects response metadata
 const checked=await verify.POST(req('/api/student/signup-verify',{phone,challengeId:c.challengeId,code:c.code}));assert.equal(checked.status,200);return {...c,...await checked.json()}}

test('signup sends a real mocked OTP to a new normalized number without creating an account',async()=>{
 const c=await challenge('۰۹۱۲۱۱۱۱۱۱۱');assert.equal(sent.at(-1).mobile,'09121111111');assert.equal(accountCount(),0);const row=db.prepare('SELECT code_hash,ready FROM student_login_codes WHERE phone=?').bind('09121111111').first();assert.equal(row.ready,1);assert.ok(!row.code_hash.includes(c.code));
 assert.equal((await send.POST(req('/api/student/signup-code',{phone:c.phone}))).status,429);
 assert.equal((await send.POST(req('/api/student/signup-code',{phone:'09122222222'},'https://foreign.test'))).status,403);
 assert.equal((await verify.POST(req('/api/student/signup-verify',{phone:c.phone,challengeId:c.challengeId,code:c.code},'https://foreign.test'))).status,403);
});
test('registration OTP cannot log in, and phone-bound proof requires the correct one-time code',async()=>{
 const c=await challenge('09122222222');assert.throws(()=>otp.verifyStudentCode(c.phone,c.challengeId,c.code,'purpose-test'));
 assert.equal((await verify.POST(req('/api/student/signup-verify',{phone:c.phone,challengeId:c.challengeId,code:'000000'}))).status,401);
 const response=await verify.POST(req('/api/student/signup-verify',{phone:c.phone,challengeId:c.challengeId,code:c.code}));assert.equal(response.status,200);const p=await response.json();assert.ok(p.registrationToken.length>=40);assert.equal(accountCount(),0);
 assert.equal((await verify.POST(req('/api/student/signup-verify',{phone:c.phone,challengeId:c.challengeId,code:c.code}))).status,401);
 const altered=await register.POST(req('/api/register',{name:'شاگرد آزمایشی',phone:'09123333333',registrationToken:p.registrationToken,packageIds:['training']}));assert.equal(altered.status,401);assert.equal(accountCount(),0);
});
test('registration requires proof even when a password is supplied and keeps server-side package validation',async()=>{
 assert.equal((await register.POST(req('/api/register',{name:'شاگرد تست',phone:'09123333333',password:'123456',packageIds:['training']}))).status,401);
 const p=await proof('09123333333');assert.equal((await register.POST(req('/api/register',{name:'شاگرد تست',phone:p.phone,registrationToken:p.registrationToken,packageIds:['invalid-package']}))).status,400);
 const response=await register.POST(req('/api/register',{name:'شاگرد تست',phone:p.phone,registrationToken:p.registrationToken,packageIds:['training']}));assert.equal(response.status,200);assert.match(response.headers.get('set-cookie'),/HttpOnly/);assert.equal(accountCount(),1);
 assert.equal(db.prepare('SELECT count(*) AS n FROM student_registration_proofs WHERE token_hash=?').bind(otp.registrationProofHash(p.registrationToken)).first().n,0);
 assert.equal((await register.POST(req('/api/register',{name:'شاگرد تست',phone:p.phone,registrationToken:p.registrationToken,packageIds:['training']}))).status,409);assert.equal(accountCount(),1);
 assert.equal((await send.POST(req('/api/student/signup-code',{phone:p.phone}))).status,409);
 const before=sent.length;const c=await otp.requestStudentCode(p.phone,'existing-login');assert.equal(sent.length,before+1);assert.ok(otp.verifyStudentCode(p.phone,c.challengeId,sent.at(-1).parameters[0].value,'existing-login').client_id);
});
test('expired proofs and expired or over-attempted codes cannot create accounts',async()=>{
 const p=await proof('09124444444');db.prepare('UPDATE student_registration_proofs SET expires_at=0 WHERE token_hash=?').bind(otp.registrationProofHash(p.registrationToken)).run();
 assert.equal((await register.POST(req('/api/register',{name:'شاگرد تست',phone:p.phone,registrationToken:p.registrationToken,packageIds:['training']}))).status,401);
 const c=await challenge('09125555555');db.prepare('UPDATE student_login_codes SET expires_at=0 WHERE phone=?').bind(c.phone).run();assert.throws(()=>otp.verifyRegistrationCode(c.phone,c.challengeId,c.code,'expiry'));
 const locked=await challenge('09126666666');for(let i=0;i<5;i++)assert.throws(()=>otp.verifyRegistrationCode(locked.phone,locked.challengeId,'000000','attempts'));assert.throws(()=>otp.verifyRegistrationCode(locked.phone,locked.challengeId,locked.code,'attempts'));assert.equal(accountCount(),1);
});
test('concurrent registration consumes proof once and produces only one application',async()=>{
 const p=await proof('09127777777');const before=db.prepare('SELECT count(*) AS n FROM applications').first().n;
 const responses=await Promise.all([1,2].map(()=>register.POST(req('/api/register',{name:'شاگرد همزمان',phone:p.phone,registrationToken:p.registrationToken,packageIds:['training']}))));assert.equal(responses.filter(r=>r.status===200).length,1);assert.equal(db.prepare('SELECT count(*) AS n FROM applications').first().n,before+1);
});
test('SMS mode can be disabled without changing the existing password registration contract',async()=>{
 sms.saveSmsSettings(sms.smsSettingsSchema.parse({...config,loginEnabled:false}));assert.equal((await send.POST(req('/api/student/signup-code',{phone:'09128888888'}))).status,503);
 assert.equal((await register.POST(req('/api/register',{name:'شاگرد قدیمی',phone:'09128888888',password:'123456',packageIds:['training']}))).status,200);
 const response=await login.POST(req('/api/student/login',{phone:'09128888888',password:'123456'}));assert.equal(response.status,200);
});

test('SMS signup renders phone verification before services and never renders a fixed-password field',async()=>{
 const {RegistrationFlow}=await load('/components/registration-flow.tsx');
 const html=renderToStaticMarkup(React.createElement(RegistrationFlow,{initialPackage:'training',initialSmsEnabled:true}));
 assert.match(html,/تأیید شماره موبایل/);assert.match(html,/دریافت کد پیامکی/);assert.doesNotMatch(html,/رمز ۶ رقمی/);assert.doesNotMatch(html,/package-choices/);assert.match(html,/autocomplete="tel"/i);
 const legacy=renderToStaticMarkup(React.createElement(RegistrationFlow,{initialPackage:'training',initialSmsEnabled:false}));assert.match(legacy,/رمز ۶ رقمی/);assert.match(legacy,/package-choices/);
 const addon=renderToStaticMarkup(React.createElement(RegistrationFlow,{initialPackage:'training',initialSmsEnabled:true,newRequest:true,addon:true}));assert.match(addon,/package-choices/);assert.doesNotMatch(addon,/دریافت کد پیامکی/);
});
