import assert from 'node:assert/strict';import test,{after} from 'node:test';
import {mkdtempSync} from 'node:fs';import {tmpdir} from 'node:os';import path from 'node:path';import {fileURLToPath} from 'node:url';import {createServer} from 'vite';
const root=fileURLToPath(new URL('..',import.meta.url));process.env.APP_DATA_DIR=mkdtempSync(path.join(tmpdir(),'r928-login-'));process.env.APP_SESSION_SECRET='fixture-928-session';process.env.APP_ORIGIN='https://coach.test';delete process.env.GOOGLE_CLIENT_ID;delete process.env.GOOGLE_CLIENT_SECRET;
const vite=await createServer({appType:'custom',configFile:false,root,resolve:{alias:{'@':root}},server:{middlewareMode:true,hmr:false}});after(()=>vite.close());const load=p=>vite.ssrLoadModule(p);
const auth=await load('/lib/password-auth.ts'),{database}=await load('/lib/raw-db.ts'),db=database(),config=await load('/lib/google-config.ts'),google=await load('/app/api/coach/google-config/route.ts'),start=await load('/app/api/student/google/start/route.ts'),callback=await load('/app/api/student/google/callback/route.ts'),googleStatus=await load('/app/api/student/google/status/route.ts'),sms=await load('/lib/sms.ts'),smsRoute=await load('/app/api/sms/settings/route.ts'),otp=await load('/lib/student-otp.ts');
const cookie='power_home_session='+await auth.createSessionToken();const req=(route,body,method='PUT',session=cookie,origin='https://coach.test')=>new Request('https://coach.test'+route,{method,headers:{host:'coach.test',origin,cookie:session,'content-type':'application/json'},...(body===undefined?{}:{body:JSON.stringify(body)})});
const save=body=>google.PUT(req('/api/coach/google-config',body));
const id='123456-fixture.apps.googleusercontent.com',secret='GOCSPX-fixture-928';
test('an unconfigured Google provider can be disabled, but cannot be enabled without credentials',async()=>{
 assert.equal((await save({enabled:false})).status,200);
 assert.equal(config.googlePublicSettings().enabled,false);
 assert.equal((await save({enabled:true})).status,400);
 assert.equal(config.googlePublicSettings().enabled,false);
 assert.equal((await save({enabled:false,clientId:id})).status,400);
 assert.equal(db.prepare('SELECT count(*) AS n FROM google_oauth_settings').first().n,0);
});
test('disabled Google retains keys, blocks start/callback and public button, then re-enables without re-pasting',async()=>{
 assert.equal((await save({clientId:id,clientSecret:secret,enabled:false})).status,200);
 const ciphertext=db.prepare('SELECT encrypted_secret FROM google_oauth_settings').first().encrypted_secret;
 assert.equal(config.googlePublicSettings().configured,true);
 assert.equal((await start.GET(new Request('https://coach.test/api/student/google/start'))).status,503);
 assert.equal((await callback.GET(new Request('https://coach.test/api/student/google/callback'))).status,503);
 assert.equal((await(await googleStatus.GET(new Request('https://coach.test/api/student/google/status'))).json()).configured,false);
 assert.equal((await save({enabled:true})).status,200);
 assert.equal((await start.GET(new Request('https://coach.test/api/student/google/start'))).status,302);
 assert.equal(db.prepare('SELECT encrypted_secret FROM google_oauth_settings').first().encrypted_secret,ciphertext);
 assert.equal((await save({enabled:false})).status,200);
 const publicRead=await(await google.GET(req('/api/coach/google-config',undefined,'GET'))).json();
 assert.equal(publicRead.enabled,false);assert.equal(publicRead.secretConfigured,true);assert.equal(publicRead.origin,'https://coach.test');assert.equal(publicRead.redirectUri,'https://coach.test/api/student/google/callback');
 assert.ok(!JSON.stringify(publicRead).includes(secret));
});
test('Google toggle writes enforce coach authentication and CSRF, never modify SMS settings',async()=>{
 const before=config.googlePublicSettings();
 assert.equal((await google.PUT(req('/api/coach/google-config',{enabled:true},'PUT',''))).status,403);
 assert.equal((await google.PUT(req('/api/coach/google-config',{enabled:true},'PUT',cookie,'https://evil.test'))).status,403);
 assert.deepEqual(config.googlePublicSettings(),before);
 assert.equal(sms.getSmsSettings().loginEnabled,false);
});
test('SMS toggle and login fields persist independently of Google and notification templates',async()=>{
 const settings=sms.smsSettingsSchema.parse({apiKey:'fixture928-sms-key',loginEnabled:true,notificationsEnabled:true,otpTemplateId:321,otpParameter:'CODE',notificationTemplateId:777,notificationParameter:'EVENT',coachPhone:'09121111111',lineNumber:'30001234'});
 sms.saveSmsSettings(settings);const before=structuredClone(sms.getSmsSettings()),googleBefore=config.googlePublicSettings();
 const patch=enabled=>smsRoute.PATCH(req('/api/sms/settings',{section:'login',settings:{loginEnabled:enabled,otpTemplateId:321,otpParameter:'CODE'}},'PATCH'));
 assert.equal((await patch(false)).status,200);
 assert.equal((await smsRoute.PATCH(req('/api/sms/settings',{section:'login',settings:{loginEnabled:true,otpTemplateId:321,otpParameter:'CODE'}},'PATCH','','https://coach.test'))).status,403);
 await assert.rejects(otp.requestStudentCode('09121111111','fixture-ip'),e=>e.status===503);
 const saved=sms.getSmsSettings();assert.equal(saved.loginEnabled,false);assert.equal(saved.notificationsEnabled,true);assert.equal(saved.notificationTemplateId,777);assert.equal(saved.apiKeyConfigured,true);assert.deepEqual(saved.stageMessages,before.stageMessages);
 assert.equal((await patch(true)).status,200);assert.equal(sms.smsLoginEnabled(),true);assert.deepEqual(config.googlePublicSettings(),googleBefore);
});
test('unreadable saved Google key can be disabled and replaced without exposing or falling back to it',async()=>{
 db.prepare("UPDATE google_oauth_settings SET encrypted_secret='invalid-ciphertext'").run();
 assert.equal(config.googlePublicSettings().configured,false);
 assert.equal((await save({enabled:false,clientId:id})).status,200);
 assert.equal((await save({enabled:true})).status,400);
 assert.equal((await save({enabled:true,clientId:id,clientSecret:secret})).status,200);
 assert.equal(config.googleCredentials().clientSecret,secret);
});
