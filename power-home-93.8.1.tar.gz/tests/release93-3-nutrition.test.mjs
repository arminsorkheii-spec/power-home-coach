import assert from 'node:assert/strict';
import test,{after} from 'node:test';
import {readFile} from 'node:fs/promises';
import {createServer} from 'vite';
import {fileURLToPath} from 'node:url';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
const vite=await createServer({configFile:false,resolve:{alias:{'@':fileURLToPath(new URL('..',import.meta.url))}},server:{middlewareMode:true},appType:'custom'});
after(()=>vite.close());
const math=await vite.ssrLoadModule('/lib/food-catalog.ts');
const techniques=await vite.ssrLoadModule('/lib/training-techniques.ts');
const coach=await vite.ssrLoadModule('/lib/coach-data.ts');

const catalogue=JSON.parse(await readFile(new URL('../public/foods/catalog.json',import.meta.url),'utf8'));
const foods=catalogue.filter(f=>f.id.startsWith('usda:'));
test('official USDA catalogue preserves distinct records, source IDs, complete macros and positive portion weights',()=>{
 assert.equal(foods.length,7793);assert.equal(new Set(foods.map(f=>f.id)).size,7793);
 for(const f of foods){assert.ok(f.fdcId>0);assert.equal(f.id,'usda:'+f.fdcId);assert.equal(f.source,'USDA SR Legacy 2018');assert.ok(math.completeFood(f));for(const p of f.portions)assert.ok(p.grams>0)}
 const raw=foods.find(f=>f.fdcId===168877);
 const cooked=foods.find(f=>f.description==='Rice, white, long-grain, regular, enriched, cooked');
 assert.equal(raw.state,'raw');assert.equal(cooked.state,'cooked');assert.notEqual(raw.id,cooked.id);assert.ok(raw.calories>cooked.calories*2);
 assert.equal(cooked.portions.find(p=>p.label==='1 cup').grams,158);
});
test('portion and day totals use saved per-100g snapshots without rounding intermediate calculations',()=>{
 const row={id:'one',foodId:'test',name:'برنج پخته',description:'cooked rice',grams:158,source:'test',per100:{calories:130,protein:2.69,carbs:28.17,fat:.28}};
 const single=math.foodMacros(row);assert.equal(single.calories,205.4);assert.ok(Math.abs(single.protein-4.2502)<1e-10);
 const total=math.plannedTotal([row,{...row,id:'two',grams:100}]);assert.ok(Math.abs(total.calories-335.4)<1e-10);
 assert.deepEqual(math.plannedTotal(),math.emptyMacros());
 assert.deepEqual(math.plannedTotal(JSON.parse(JSON.stringify([row]))),math.plannedTotal([row]));
});
test('missing nutrient values are not treated as zero, Persian input and search variants work',()=>{
 assert.equal(math.completeFood({...foods[0],protein:null}),false);
 assert.equal(math.numericFoodInput('۱۲۵٫۵'),125.5);assert.equal(math.numericFoodInput('١٢٥'),125);assert.ok(Number.isNaN(math.numericFoodInput('')));assert.ok(Number.isNaN(math.numericFoodInput('-10')));
 assert.ok(foods.some(f=>math.foodMatches(f,'برنج پخته')));assert.ok(foods.some(f=>math.foodMatches(f,'chicken breast')));
 assert.equal(math.normalizeFoodSearch('كیوي'),'کیوی');
});
test('delivery text includes structured foods while preserving legacy free text',()=>{
 const text=math.mealFoodText({foods:'سالاد طبق توضیح مربی',foodItems:[{name:'برنج پخته',description:'Cooked rice',grams:200}]});
 assert.match(text,/سالاد طبق توضیح مربی/);assert.match(text,/برنج پخته/);assert.match(text,/۲۰۰/);assert.doesNotMatch(text,/Cooked rice/);
 assert.equal(math.mealFoodText({foods:'برنامه قبلی'}),'برنامه قبلی');
});

test('Iranian dishes retain ingredient sources and reproducible final-yield calculations',()=>{const recipes=catalogue.filter(f=>f.recipe);assert.equal(recipes.length,30);assert.ok(recipes.some(f=>f.name.includes('قورمه')));assert.ok(recipes.some(f=>f.name.includes('قیمه')));for(const food of recipes){assert.ok(food.recipe.yieldGrams>0);const expected=math.recipeMacros(food.recipe,foods);for(const k of Object.keys(expected))assert.ok(Math.abs(expected[k]-food[k])<0.0001);const doubled=math.recipeMacros({...food.recipe,yieldGrams:food.recipe.yieldGrams*2},foods);assert.ok(Math.abs(doubled.calories-expected.calories/2)<1e-8)}assert.throws(()=>math.recipeMacros({yieldGrams:0,ingredients:[]},foods));assert.throws(()=>math.recipeMacros({yieldGrams:100,ingredients:[{foodId:'missing',grams:100}]},foods))});

test('every selectable training system has a guide, including spelling variants',()=>{for(const name of coach.TECHNIQUES)assert.ok(techniques.techniqueGuide(name),name);assert.equal(techniques.techniqueGuide('رست پوز').id,'restpause');assert.equal(techniques.techniqueGuide('FST 7').id,'fst7');assert.equal(techniques.techniqueGuide('rest-pause').id,'restpause');assert.equal(techniques.techniqueGuide('تکنیک شخصی ناشناخته'),undefined)});
test('program glossary deduplicates used systems and never invents a custom explanation',()=>{const used=techniques.usedTechniqueGuides([{exercises:[{technique:'رست‌پاز'},{technique:'rest pause'},{technique:'FST-7'},{technique:'عادی',supersetId:'pair'},{technique:'تکنیک شخصی'}]}]);assert.deepEqual(used.map(t=>t.id),['restpause','fst7','normal','superset','custom:تکنیکشخصی']);assert.match(used.at(-1).description,/حدسی درج نشده/);assert.equal(techniques.usedTechniqueGuides([]).length,0)});
test('training PDF markup includes expanded system instructions, nutrition-only PDF excludes them',async()=>{const {PlanPrint}=await vite.ssrLoadModule('/components/plan-print.tsx');const client=coach.DEFAULT_STATE.clients[0],base=coach.DEFAULT_STATE.plans[client.id];const plan={...base,workoutDays:[{id:'guide-test',title:'جلسه تست',focus:'راهنمای اجرا',exercises:[{rowId:'a',exerciseId:coach.EXERCISES[0].id,sets:'7',reps:'10',rest:'30 ثانیه',tempo:'کنترل‌شده',technique:'FST-7',notes:''},{rowId:'b',exerciseId:coach.EXERCISES[0].id,sets:'3',reps:'12',rest:'90 ثانیه',tempo:'کنترل‌شده',technique:'رست‌پاز',notes:''}]}]};const html=renderToStaticMarkup(React.createElement(PlanPrint,{client,plan,exercises:coach.EXERCISES,section:'training'}));assert.match(html,/print-technique-item/);assert.match(html,/هفت ست/);assert.match(html,/تکرارهای تکمیلی/);assert.doesNotMatch(html,/<details/);assert.equal((html.match(/<h3>FST-7<\/h3>/g)||[]).length,1);const nutrition=renderToStaticMarkup(React.createElement(PlanPrint,{client,plan,exercises:coach.EXERCISES,section:'nutrition'}));assert.doesNotMatch(nutrition,/print-technique-item/)});
