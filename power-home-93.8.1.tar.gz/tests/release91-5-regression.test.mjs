import assert from 'node:assert/strict';
import {readFile, access} from 'node:fs/promises';
import test from 'node:test';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const root=fileURLToPath(new URL('..',import.meta.url));
const read=(p)=>readFile(path.join(root,p),'utf8');

test('renewal is visible outside application-specific status banner, including legacy students', async()=>{
 const source=await read('components/student-portal.tsx');
 const welcome=source.indexOf('className="student-welcome"');
 const renewal=source.indexOf('className="student-renew-panel"');
 const banner=source.indexOf('id="student-current-request"');
 assert.ok(welcome>=0 && renewal>welcome && banner>renewal);
 assert.match(source,/href="\/signup\?new=1"/);
 assert.match(source,/application\?\.canRequestNew===true/);
});

test('renewal POST keeps legacy deliveries valid and avoids duplicate active orders',async()=>{
 const source=await read('app/api/student/application/route.ts');
 assert.match(source,/Date\.parse\(delivery!\.delivered_at\)\s*>?=\s*Date\.parse\(latest\.created_at\)/);
 assert.match(source,/if\s*\(!latestCompleted\s*&&\s*!addonAllowed\)/);
 assert.match(source,/status:\s*409/);
 assert.match(source,/INSERT INTO applications/);
 assert.match(source,/SELECT delivered_at FROM current_program_deliveries/);
});

test('all dashboard destinations use image icons and images exist',async()=>{
 const source=await read('components/coach-operations.tsx');
 const match=source.match(/const modules=\[([\s\S]*?)\] as const;/);
 assert.ok(match);
 const names=[...match[1].matchAll(/key:"([a-z]+)"/g)].map(x=>x[1]);
 assert.deepEqual(names,['training','nutrition','supplements','medications','messages','billing','notifications','pdf']);
 assert.match(source,/<GraphicSectionIcon name=\{item\.key\}/);
 for(const name of names)await access(path.join(root,'public','section-icons',name+'.webp'));
});

test('small screens use safe wrapping and glass effect',async()=>{
 const css=await read('app/globals.css');
 assert.match(css,/\.dashboard-module-icon:after\s*\{/);
 assert.match(css,/\.dashboard-module-copy small\{[^}]*white-space:normal/);
 assert.match(css,/@media\(max-width:390px\)\s*\{[\s\S]*?\.dashboard-module-grid\{grid-template-columns:1fr/);
 assert.match(css,/\.student-renew-link\{[^}]*white-space:normal/);
});

test('registration and shared theme have no golden/yellow hardcoded palette',async()=>{
 const css=await read('app/globals.css');
 assert.doesNotMatch(css,/#(?:d6a62a|f0c75e|fbbf24|e3b84a)\b|rgba\((?:214,166,42|240,199,94),/i);
 assert.match(css,/\.register-page :is\(input,select,textarea\):focus-visible/);
 assert.match(css,/\.register-page \.register-title>svg/);
 assert.match(css,/--primary:\s*var\(--ph-tone-/);
});
