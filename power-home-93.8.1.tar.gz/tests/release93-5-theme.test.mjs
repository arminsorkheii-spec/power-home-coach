import test,{after} from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {createServer} from 'vite';
const vite=await createServer({configFile:false,appType:'custom',server:{middlewareMode:true,hmr:false}});after(()=>vite.close());
const {APPEARANCE_BOOTSTRAP,validAppearance}=await vite.ssrLoadModule('/lib/theme.ts');
function boot(getItem){const document={documentElement:{dataset:{},style:{}}};vm.runInNewContext(APPEARANCE_BOOTSTRAP,{document,localStorage:{getItem}});return document.documentElement}
test('saved day appearance is restored before the initial document paint',()=>{const root=boot(()=> 'light');assert.equal(root.dataset.theme,'light');assert.equal(root.style.colorScheme,'light')});
test('blocked storage and unrecognized preferences still produce a usable dark document',()=>{assert.equal(boot(()=>{throw Error('storage unavailable')}).dataset.theme,'dark');for(const value of [null,'', 'system','LIGHT','<script>'])assert.equal(boot(()=>value).dataset.theme,'dark');assert.equal(validAppearance('light'),'light')});
