import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFileSync } from 'node:fs';

function worker() {
  const listeners = {}; const navigation = []; const focused = [];
  const windows = [{url:'https://example.test/student', navigate: async url => { navigation.push(url); return {focus: async () => focused.push(url)}; }, focus: async () => focused.push('old')}];
  const cache = {match:async()=>null,put:async()=>{}};
  const self = {location:{origin:'https://example.test'}, registration:{}, skipWaiting(){}, addEventListener(name,fn){listeners[name]=fn;}, clients:{claim:async()=>{},matchAll:async()=>windows,openWindow:async url => navigation.push(url)}};
  vm.runInNewContext(readFileSync('public/sw.js','utf8'), {self,clients:self.clients,caches:{keys:async()=>[],delete:async()=>{},open:async()=>cache},URL,Response});
  return {listeners,navigation,focused};
}

test('activation preserves open forms and notification screens', async () => {
  const w=worker(); let task;
  w.listeners.activate({waitUntil:p=>task=p}); await task;
  assert.deepEqual(w.navigation,[]);
});
test('notification click navigates then focuses the app window', async () => {
  const w=worker(); let task;
  w.listeners.notificationclick({notification:{close(){},data:{url:'/student?view=messages'}},waitUntil:p=>task=p}); await task;
  assert.deepEqual(w.navigation,['https://example.test/student?view=messages']);
  assert.deepEqual(w.focused,w.navigation);
});
test('notification cannot send the app to an external or malformed URL', async () => {
  for(const url of ['https://other.test/login','http://[invalid']) {
    const w=worker();let task;
    w.listeners.notificationclick({notification:{close(){},data:{url}},waitUntil:p=>task=p});await task;
    assert.deepEqual(w.navigation,['https://example.test/']);
  }
});

test('service worker registration is shared, failed registration can retry, waits time out', async () => {
  const ts = await import('typescript');
  const js=ts.default.transpileModule(readFileSync('lib/pwa-client.ts','utf8'),{compilerOptions:{module:ts.default.ModuleKind.ESNext,target:ts.default.ScriptTarget.ES2022}}).outputText;
  const api=await import('data:text/javascript;base64,'+Buffer.from(js).toString('base64'));
  const original=Object.getOwnPropertyDescriptor(globalThis,'navigator');
  let calls=0;
  Object.defineProperty(globalThis,'navigator',{configurable:true,value:{serviceWorker:{register:async()=>{calls++;if(calls===1)throw new Error('offline');return {active:true}}}}});
  try {
    await assert.rejects(api.appServiceWorker(),/offline/);
    const first=api.appServiceWorker();const second=api.appServiceWorker();
    assert.equal(first,second);assert.deepEqual(await first,{active:true});assert.equal(calls,2);
    await assert.rejects(api.bounded(new Promise(()=>{}),5),/زمان انتظار/);
    assert.equal(await api.bounded(Promise.resolve('ok'),5),'ok');
  } finally {if(original)Object.defineProperty(globalThis,'navigator',original);else delete globalThis.navigator;}
});

test('clicking a phone push marks only its notification as read and keeps the remaining badge count',async()=>{
 const listeners={},requests=[],badges=[],id='00000000-0000-4000-a000-000000000001';
 const cache={match:async()=>new Response('3'),put:async(_key,response)=>badges.push(await response.text())};
 const self={location:{origin:'https://example.test'},registration:{},addEventListener:(name,callback)=>listeners[name]=callback,clients:{matchAll:async()=>[],openWindow:async()=>{}}};
 vm.runInNewContext(readFileSync('public/sw.js','utf8'),{self,clients:self.clients,caches:{open:async()=>cache},URL,Response,fetch:async(url,options)=>{requests.push({url,...options});return Response.json({ok:true,unread:2})}});
 let task;listeners.notificationclick({notification:{close(){},data:{url:'/student?section=renewal',notificationId:id,role:'student'}},waitUntil:p=>task=p});await task;
 assert.equal(requests.length,1);assert.equal(requests[0].url,'/api/notifications');assert.equal(requests[0].headers['x-portal-role'],'student');assert.deepEqual(JSON.parse(requests[0].body),{ids:[id]});assert.deepEqual(badges,['2']);
});
