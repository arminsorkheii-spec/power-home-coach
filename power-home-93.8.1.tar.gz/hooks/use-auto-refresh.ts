'use client';
import {useEffect,useRef} from 'react';
import {createRefreshLoop,DATA_UPDATED_EVENT} from '@/lib/auto-refresh';
export function useAutoRefresh(refresh:()=>Promise<unknown>|unknown,{intervalMs=30000,enabled=true,initial=false}:{intervalMs?:number;enabled?:boolean;initial?:boolean}={}){
 const latest=useRef(refresh),started=useRef(false);latest.current=refresh;
 useEffect(()=>{if(!enabled)return;const loop=createRefreshLoop({refresh:()=>latest.current(),canRefresh:()=>document.visibilityState!=='hidden'&&navigator.onLine!==false,intervalMs,initial:initial||started.current,clock:{now:Date.now,schedule:(fn,delay)=>window.setTimeout(fn,delay),cancel:id=>window.clearTimeout(id as number)}});started.current=true;const wake=()=>loop.trigger();const events=['focus','online',DATA_UPDATED_EVENT,'companion-updated','training-updated','discount-applied'];events.forEach(event=>window.addEventListener(event,wake));document.addEventListener('visibilitychange',wake);return()=>{loop.stop();events.forEach(event=>window.removeEventListener(event,wake));document.removeEventListener('visibilitychange',wake)}},[intervalMs,enabled,initial]);
}
