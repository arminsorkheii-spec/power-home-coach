# Prepared features — not installed

Google sign-in requires a Google OAuth web client, server-only GOOGLE_CLIENT_SECRET,
GOOGLE_CLIENT_ID, APP_ORIGIN and the exact authorized callback:
https://arminsorkhei.ir/api/student/google/callback
Only openid, email and profile scopes are requested. No Google passwords are
collected by this application. Existing students must link Google while signed
into their existing student account. Email alone never links an existing account.

APP_CRON_SECRET must contain at least 32 random characters and must be passed to
the app container through its normal environment configuration. Keep secrets in
the production environment only. Do not insert example values into production.

When deployment is authorized: copy the scripts directory along with source,
copy the .service/.timer units to /etc/systemd/system, then enable the timer.
The hourly job calls the internal authenticated endpoint. It checks renewal lead
time and expiry, and prompts for missing weekly reports on Fridays after 18:00
Asia/Tehran. Jobs continue without an open browser. Each event is deduplicated.
Site notifications, Push and SMS use the existing channel configuration; SMS to
Google-only accounts is skipped because they have no verified Iranian mobile.

A new program term starts on first delivery. Re-sending the same application
preserves its original start. An updated duration recomputes expiry from that
start. New deliveries supersede previous active terms. Expiry does not revoke
access to previous programs. Legacy programs with no duration remain unlimited.

All new records are isolated by student identity and use additive tables.
Weekly photos are private, compressed before upload and capped at 600 KiB each.
No production data or configured credentials are included in this release.
